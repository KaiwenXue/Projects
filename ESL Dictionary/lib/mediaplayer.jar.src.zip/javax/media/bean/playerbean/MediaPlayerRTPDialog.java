/*     */ package javax.media.bean.playerbean;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Button;
/*     */ import java.awt.Choice;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dialog;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Label;
/*     */ import java.awt.Panel;
/*     */ import java.awt.TextComponent;
/*     */ import java.awt.TextField;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ 
/*     */ public class MediaPlayerRTPDialog
/*     */   extends Dialog
/*     */ {
/*     */   TextField IPAdrFld;
/*     */   TextField PortFld;
/*     */   TextField ttlFld;
/*     */   Choice cbFormat;
/*     */   Button OKButton;
/*     */   Button CancelButton;
/*  32 */   String rtpString = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaPlayerRTPDialog(Frame frame)
/*     */   {
/*  41 */     super(frame, true);
/*  42 */     setTitle("Setup RTP Session");
/*  43 */     setBackground(Color.lightGray);
/*  44 */     addWindowListener(new WindowAdapter() {
/*     */       public void windowClosing(WindowEvent e) {
/*  46 */         MediaPlayerRTPDialog.this.cancel();
/*     */       }
/*     */       
/*  49 */     });
/*  50 */     setLayout(new BorderLayout());
/*  51 */     Panel row1 = new Panel();
/*  52 */     row1.setLayout(new FlowLayout());
/*  53 */     row1.add(new Label("IP Address"));
/*  54 */     this.IPAdrFld = new TextField("", 24);
/*  55 */     row1.add(this.IPAdrFld);
/*  56 */     row1.add(new Label("Media Type"), 2);
/*  57 */     this.cbFormat = new Choice();
/*  58 */     this.cbFormat.removeAll();
/*  59 */     row1.add(this.cbFormat);
/*  60 */     this.cbFormat.addItem("audio");
/*  61 */     this.cbFormat.addItem("video");
/*  62 */     Dimension d = this.cbFormat.getSize();
/*  63 */     d.width = 40;
/*  64 */     this.cbFormat.setSize(d);
/*  65 */     add("North", row1);
/*  66 */     Panel row2 = new Panel();
/*  67 */     add("Center", row2);
/*  68 */     row2.setLayout(new FlowLayout());
/*  69 */     row2.add(new Label("Port "));
/*  70 */     this.PortFld = new TextField("", 8);
/*  71 */     row2.add(this.PortFld);
/*  72 */     row2.add(new Label("Time to live"));
/*  73 */     this.ttlFld = new TextField("", 3);
/*  74 */     row2.add(this.ttlFld);
/*  75 */     Panel row3 = new Panel();
/*  76 */     add("South", row3);
/*  77 */     row3.setLayout(new FlowLayout());
/*  78 */     this.OKButton = new Button("OK");
/*  79 */     row3.add(this.OKButton);
/*  80 */     this.CancelButton = new Button("Cancel");
/*  81 */     row3.add(this.CancelButton);
/*  82 */     this.OKButton.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/*  84 */         MediaPlayerRTPDialog.this.close();
/*     */       }
/*     */       
/*  87 */     });
/*  88 */     this.CancelButton.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/*  90 */         MediaPlayerRTPDialog.this.cancel();
/*     */       }
/*  92 */     });
/*  93 */     setLocation(200, 300);
/*  94 */     setResizable(false);
/*  95 */     pack();
/*     */   }
/*     */   
/*     */   private void setRTPAdr()
/*     */   {
/* 100 */     this.rtpString = (this.IPAdrFld.getText() + ":" + this.PortFld.getText() + "/" + this.cbFormat.getSelectedItem() + "/" + this.ttlFld.getText());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRTPAdr()
/*     */   {
/* 110 */     return this.rtpString;
/*     */   }
/*     */   
/*     */   private void close() {
/* 114 */     setRTPAdr();
/* 115 */     dispose();
/*     */   }
/*     */   
/*     */   private void cancel()
/*     */   {
/* 120 */     this.rtpString = "";
/* 121 */     dispose();
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mediaplayer.jar!\javax\media\bean\playerbean\MediaPlayerRTPDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */