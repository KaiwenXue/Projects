/*    */ package javax.media.bean.playerbean;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MediaPlayerVolumePropertyEditor
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   public String getJavaInitializationString()
/*    */   {
/* 39 */     return "new java.lang.String(\"" + getAsText() + "\")";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String[] getTags()
/*    */   {
/* 51 */     String[] result = { MediaPlayerResource.getString("ZERO"), MediaPlayerResource.getString("ONE"), MediaPlayerResource.getString("TWO"), MediaPlayerResource.getString("THREE"), MediaPlayerResource.getString("FOUR"), MediaPlayerResource.getString("FIVE") };
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 59 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mediaplayer.jar!\javax\media\bean\playerbean\MediaPlayerVolumePropertyEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */