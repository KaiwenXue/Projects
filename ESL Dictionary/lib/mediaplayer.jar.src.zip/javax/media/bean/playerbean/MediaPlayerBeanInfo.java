/*     */ package javax.media.bean.playerbean;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.beans.BeanDescriptor;
/*     */ import java.beans.EventSetDescriptor;
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.beans.SimpleBeanInfo;
/*     */ import javax.media.ControllerListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaPlayerBeanInfo
/*     */   extends SimpleBeanInfo
/*     */ {
/*  26 */   private static final Class beanClass = MediaPlayer.class;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertyDescriptor[] getPropertyDescriptors()
/*     */   {
/*     */     try
/*     */     {
/*  40 */       PropertyDescriptor background = new PropertyDescriptor("background", beanClass);
/*     */       
/*  42 */       PropertyDescriptor foreground = new PropertyDescriptor("foreground", beanClass);
/*     */       
/*  44 */       PropertyDescriptor font = new PropertyDescriptor("font", beanClass);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  49 */       PropertyDescriptor Url = new PropertyDescriptor("mediaLocation", beanClass);
/*     */       
/*  51 */       Url.setDisplayName(MediaPlayerResource.getString("MEDIA_LOCATION"));
/*  52 */       Url.setBound(true);
/*  53 */       Url.setPropertyEditorClass(MediaPlayerMediaLocationEditor.class);
/*     */       
/*  55 */       PropertyDescriptor PanelVisible = new PropertyDescriptor("controlPanelVisible", beanClass);
/*     */       
/*  57 */       PanelVisible.setDisplayName(MediaPlayerResource.getString("CONTROL_PANEL_VISIBLE"));
/*     */       
/*  59 */       PanelVisible.setBound(true);
/*     */       
/*  61 */       PropertyDescriptor CacheVisible = new PropertyDescriptor("cachingControlVisible", beanClass);
/*     */       
/*  63 */       CacheVisible.setDisplayName(MediaPlayerResource.getString("CACHING_CONTROL_VISIBLE"));
/*     */       
/*  65 */       CacheVisible.setBound(true);
/*     */       
/*  67 */       PropertyDescriptor FixedAspectRatio = new PropertyDescriptor("fixedAspectRatio", beanClass);
/*     */       
/*  69 */       FixedAspectRatio.setDisplayName(MediaPlayerResource.getString("FIXED_ASPECT_RATIO"));
/*     */       
/*  71 */       FixedAspectRatio.setBound(true);
/*     */       
/*  73 */       PropertyDescriptor loop = new PropertyDescriptor("playbackLoop", beanClass);
/*     */       
/*  75 */       loop.setBound(true);
/*  76 */       loop.setDisplayName(MediaPlayerResource.getString("LOOP"));
/*     */       
/*  78 */       PropertyDescriptor volume = new PropertyDescriptor("volumeLevel", beanClass);
/*     */       
/*  80 */       volume.setBound(true);
/*  81 */       volume.setDisplayName(MediaPlayerResource.getString("VOLUME"));
/*  82 */       volume.setPropertyEditorClass(MediaPlayerVolumePropertyEditor.class);
/*     */       
/*     */ 
/*  85 */       return new PropertyDescriptor[] { Url, PanelVisible, CacheVisible, FixedAspectRatio, loop, volume, background, foreground, font };
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (IntrospectionException e)
/*     */     {
/*     */ 
/*  92 */       throw new Error(e.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDefaultPropertyIndex()
/*     */   {
/* 105 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BeanDescriptor getBeanDescriptor()
/*     */   {
/* 117 */     BeanDescriptor bd = new BeanDescriptor(MediaPlayer.class);
/* 118 */     bd.setDisplayName(MediaPlayerResource.getString("MEDIA_PLAYER") + " " + MediaPlayerResource.getString("BEAN"));
/*     */     
/*     */ 
/* 121 */     return bd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EventSetDescriptor[] getEventSetDescriptors()
/*     */   {
/*     */     try
/*     */     {
/* 135 */       EventSetDescriptor cl = new EventSetDescriptor(beanClass, "controllerUpdate", ControllerListener.class, "controllerUpdate");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 140 */       EventSetDescriptor pc = new EventSetDescriptor(beanClass, "propertyChange", PropertyChangeListener.class, "propertyChange");
/*     */       
/*     */ 
/*     */ 
/* 144 */       cl.setDisplayName("Controller Events");
/* 145 */       return new EventSetDescriptor[] { cl, pc };
/*     */ 
/*     */     }
/*     */     catch (IntrospectionException e)
/*     */     {
/* 150 */       throw new Error(e.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Image getIcon(int ic)
/*     */   {
/* 165 */     switch (ic) {
/*     */     case 1: 
/* 167 */       return loadImage("MediaPlayerColor16.gif");
/*     */     case 2: 
/* 169 */       return loadImage("MediaPlayerColor32.gif");
/*     */     case 3: 
/* 171 */       return loadImage("MediaPlayerMono16.gif");
/*     */     case 4: 
/* 173 */       return loadImage("MediaPlayerMono32.gif");
/*     */     }
/* 175 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mediaplayer.jar!\javax\media\bean\playerbean\MediaPlayerBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */