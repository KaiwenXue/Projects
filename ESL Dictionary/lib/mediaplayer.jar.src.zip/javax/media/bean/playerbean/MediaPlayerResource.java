/*    */ package javax.media.bean.playerbean;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.MissingResourceException;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MediaPlayerResource
/*    */ {
/*    */   public static ResourceBundle resourceBundle;
/*    */   
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 43 */       resourceBundle = ResourceBundle.getBundle("javax.media.bean.playerbean.MediaPlayerInfoResBundle", Locale.getDefault());
/*    */     }
/*    */     catch (MissingResourceException e) {}
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String getString(String inputString)
/*    */   {
/* 62 */     String s = null;
/*    */     try
/*    */     {
/* 65 */       s = resourceBundle.getString(inputString);
/*    */ 
/*    */     }
/*    */     catch (MissingResourceException e)
/*    */     {
/*    */ 
/* 71 */       s = '*' + inputString + '*';
/*    */ 
/*    */     }
/*    */     catch (Throwable e)
/*    */     {
/* 76 */       s = '*' + inputString + '*';
/*    */     }
/* 78 */     return s;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mediaplayer.jar!\javax\media\bean\playerbean\MediaPlayerResource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */