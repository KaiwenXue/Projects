/*     */ package javax.media.bean.playerbean;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Button;
/*     */ import java.awt.Choice;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dialog;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FileDialog;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Panel;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.TextComponent;
/*     */ import java.awt.TextField;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.beans.PropertyEditor;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaPlayerMediaLocationEditor
/*     */   extends Panel
/*     */   implements PropertyEditor, ActionListener, ItemListener
/*     */ {
/*  36 */   PropertyChangeSupport support = new PropertyChangeSupport(this);
/*     */   String mediaLocationString;
/*  38 */   TextField mediaLocationTextField = new TextField(this.mediaLocationString, 60);
/*  39 */   private String browseString = "...";
/*  40 */   private Button browseB = new Button(this.browseString);
/*     */   
/*     */ 
/*  43 */   private Choice protocolChooser = new Choice();
/*  44 */   private String httpString = MediaPlayerResource.getString("HTTP");
/*  45 */   private String httpsString = MediaPlayerResource.getString("HTTPS");
/*  46 */   private String fileString = MediaPlayerResource.getString("FILE");
/*  47 */   private String rtpString = MediaPlayerResource.getString("RTP");
/*  48 */   private String ftpString = MediaPlayerResource.getString("FTP");
/*  49 */   private String codeString = MediaPlayerResource.getString("CODEBASE");
/*  50 */   private String chooseOneString = MediaPlayerResource.getString("CHOOSE_ONE");
/*  51 */   private boolean isFile = false;
/*     */   
/*  53 */   Panel editPanel = new Panel();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaPlayerMediaLocationEditor()
/*     */   {
/*  61 */     setLayout(new BorderLayout());
/*  62 */     this.editPanel.setLayout(new BorderLayout());
/*  63 */     this.editPanel.add("Center", this.mediaLocationTextField);
/*  64 */     this.editPanel.add("East", this.browseB);
/*  65 */     this.browseB.addActionListener(this);
/*  66 */     this.browseB.setEnabled(false);
/*  67 */     this.protocolChooser.add(this.chooseOneString);
/*  68 */     this.protocolChooser.add(this.fileString);
/*  69 */     this.protocolChooser.add(this.httpString);
/*  70 */     this.protocolChooser.add(this.httpsString);
/*  71 */     this.protocolChooser.add(this.rtpString);
/*  72 */     this.protocolChooser.add(this.ftpString);
/*  73 */     this.protocolChooser.add(this.codeString);
/*  74 */     this.protocolChooser.addItemListener(this);
/*  75 */     this.editPanel.add("West", this.protocolChooser);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */     add("Center", this.editPanel);
/*  89 */     KeyListener l = new KeyAdapter()
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       public void keyReleased(KeyEvent keyEvent)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */         MediaPlayerMediaLocationEditor.this.mediaLocationString = MediaPlayerMediaLocationEditor.this.mediaLocationTextField.getText();
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 110 */     };
/* 111 */     this.mediaLocationTextField.addKeyListener(l);
/* 112 */     this.mediaLocationTextField.setEnabled(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getJavaInitializationString()
/*     */   {
/*     */     String initString;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */     if (this.mediaLocationString.length() == 0)
/*     */     {
/* 130 */       initString = "new java.lang.String(\"\\\")";
/*     */     }
/*     */     else
/*     */     {
/* 134 */       initString = "new java.lang.String(\"" + this.mediaLocationString + "\")";
/*     */     }
/*     */     
/*     */ 
/* 138 */     return initString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Dimension getPreferredSize()
/*     */   {
/* 149 */     return new Dimension(400, 100);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(Object o)
/*     */   {
/* 162 */     setAsText(o.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValue()
/*     */   {
/* 172 */     return getAsText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAsText(String s)
/*     */   {
/* 182 */     this.mediaLocationString = s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAsText()
/*     */   {
/* 194 */     return this.mediaLocationString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPaintable()
/*     */   {
/* 208 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void paintValue(Graphics g, Rectangle area)
/*     */   {
/* 221 */     Color c = g.getColor();
/* 222 */     g.setColor(Color.black);
/* 223 */     g.drawString(this.mediaLocationString, area.x, area.y + area.height - 6);
/*     */     
/* 225 */     g.setColor(c);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getTags()
/*     */   {
/* 237 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Component getCustomEditor()
/*     */   {
/* 249 */     return this.editPanel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean supportsCustomEditor()
/*     */   {
/* 260 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPropertyChangeListener(PropertyChangeListener listener)
/*     */   {
/* 274 */     this.support.addPropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removePropertyChangeListener(PropertyChangeListener listener)
/*     */   {
/* 286 */     this.support.removePropertyChangeListener(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent evt)
/*     */   {
/* 299 */     String command = evt.getActionCommand();
/*     */     
/* 301 */     if (command.equals(this.browseString)) {
/*     */       String filename;
/* 303 */       if (this.isFile == true)
/*     */       {
/* 305 */         FileDialog fd = new FileDialog(getFrame(this.editPanel), MediaPlayerResource.getString("SET_MEDIA_LOCATION"), 0);
/*     */         
/*     */ 
/* 308 */         fd.setDirectory("c:\\");
/* 309 */         fd.setTitle(MediaPlayerResource.getString("SET_MEDIA_LOCATION"));
/* 310 */         fd.show();
/* 311 */         filename = fd.getFile();
/* 312 */         if ((filename != null) && (fd.getDirectory() != null))
/*     */         {
/* 314 */           filename = fd.getDirectory() + filename;
/*     */         }
/* 316 */         if (filename != null) {
/* 317 */           filename = filename.replace('\\', '/');
/* 318 */           String tmp = "file:///" + filename;
/* 319 */           this.mediaLocationTextField.setText(tmp);
/* 320 */           setAsText(tmp);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 326 */         MediaPlayerRTPDialog rtpDlg = new MediaPlayerRTPDialog(getFrame(this.editPanel));
/* 327 */         rtpDlg.show();
/* 328 */         filename = rtpDlg.getRTPAdr();
/* 329 */         if (filename != null)
/*     */         {
/* 331 */           String tmp = "rtp://" + filename;
/* 332 */           this.mediaLocationTextField.setText(tmp);
/* 333 */           setAsText(tmp);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void itemStateChanged(ItemEvent evt)
/*     */   {
/* 360 */     String item = (String)evt.getItem();
/* 361 */     if (!item.equals(this.chooseOneString))
/*     */     {
/* 363 */       this.mediaLocationTextField.setEnabled(true);
/* 364 */       if (item.equals(this.fileString))
/*     */       {
/* 366 */         this.browseB.setEnabled(true);
/* 367 */         this.isFile = true;
/*     */       }
/* 369 */       else if (item.equals(this.rtpString))
/*     */       {
/* 371 */         this.browseB.setEnabled(true);
/*     */       }
/*     */       else
/*     */       {
/* 375 */         this.browseB.setEnabled(false);
/*     */       }
/* 377 */       if (!item.equals(this.codeString))
/*     */       {
/* 379 */         this.mediaLocationTextField.setText(item);
/*     */       }
/*     */       else
/*     */       {
/* 383 */         this.mediaLocationTextField.setText("");
/*     */       }
/*     */       
/* 386 */       this.mediaLocationString = this.mediaLocationTextField.getText();
/*     */     }
/*     */     else
/*     */     {
/* 390 */       this.mediaLocationTextField.setEnabled(false);
/* 391 */       this.browseB.setEnabled(false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Frame getFrame(Component comp)
/*     */   {
/* 405 */     Point p = comp.getLocationOnScreen();
/* 406 */     Frame f = new Frame();
/* 407 */     f.setLocation(p);
/* 408 */     return f;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mediaplayer.jar!\javax\media\bean\playerbean\MediaPlayerMediaLocationEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */