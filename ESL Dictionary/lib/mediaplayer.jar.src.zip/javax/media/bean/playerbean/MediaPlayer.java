/*      */ package javax.media.bean.playerbean;
/*      */ 
/*      */ import java.applet.Applet;
/*      */ import java.applet.AppletContext;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Menu;
/*      */ import java.awt.MenuItem;
/*      */ import java.awt.Panel;
/*      */ import java.awt.PopupMenu;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.TextComponent;
/*      */ import java.awt.TextField;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.ComponentAdapter;
/*      */ import java.awt.event.ComponentEvent;
/*      */ import java.awt.event.MouseAdapter;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.Externalizable;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInput;
/*      */ import java.io.ObjectOutput;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.util.EventObject;
/*      */ import java.util.Vector;
/*      */ import javax.media.CachingControl;
/*      */ import javax.media.CachingControlEvent;
/*      */ import javax.media.Clock;
/*      */ import javax.media.ClockStoppedException;
/*      */ import javax.media.Control;
/*      */ import javax.media.Controller;
/*      */ import javax.media.ControllerAdapter;
/*      */ import javax.media.ControllerClosedEvent;
/*      */ import javax.media.ControllerErrorEvent;
/*      */ import javax.media.ControllerListener;
/*      */ import javax.media.Duration;
/*      */ import javax.media.EndOfMediaEvent;
/*      */ import javax.media.GainControl;
/*      */ import javax.media.IncompatibleSourceException;
/*      */ import javax.media.IncompatibleTimeBaseException;
/*      */ import javax.media.Manager;
/*      */ import javax.media.MediaHandler;
/*      */ import javax.media.MediaLocator;
/*      */ import javax.media.NoPlayerException;
/*      */ import javax.media.Player;
/*      */ import javax.media.PrefetchCompleteEvent;
/*      */ import javax.media.RealizeCompleteEvent;
/*      */ import javax.media.SizeChangeEvent;
/*      */ import javax.media.StartEvent;
/*      */ import javax.media.Time;
/*      */ import javax.media.TimeBase;
/*      */ import javax.media.TransitionEvent;
/*      */ import javax.media.format.FormatChangeEvent;
/*      */ import javax.media.protocol.DataSource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MediaPlayer
/*      */   extends Container
/*      */   implements Player, Externalizable
/*      */ {
/*   91 */   private PropertyChangeSupport changes = new PropertyChangeSupport(this);
/*      */   
/*      */ 
/*      */ 
/*   95 */   private String urlString = "";
/*      */   private MediaLocator mrl;
/*      */   private URL url;
/*   98 */   private AppletContext mpAppletContext = null;
/*      */   
/*      */ 
/*  101 */   private boolean panelVisible = true;
/*      */   
/*      */ 
/*  104 */   private boolean cachingVisible = false;
/*      */   
/*      */ 
/*  107 */   private boolean fixedAspectRatio = true;
/*      */   
/*      */ 
/*  110 */   private boolean fitVideo = true;
/*      */   
/*      */ 
/*  113 */   private boolean looping = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  118 */   transient Player player = null;
/*      */   
/*      */ 
/*      */ 
/*      */   transient Panel panel;
/*      */   
/*      */ 
/*      */   transient Panel vPanel;
/*      */   
/*      */ 
/*      */   transient Panel newPanel;
/*      */   
/*      */ 
/*      */   transient Component visualComponent;
/*      */   
/*      */ 
/*      */   transient Component controlComponent;
/*      */   
/*      */ 
/*      */   transient Component cachingComponent;
/*      */   
/*      */ 
/*  140 */   private transient int controlPanelHeight = 0;
/*      */   
/*      */ 
/*  143 */   private transient int urlFieldHeight = 0;
/*      */   
/*      */ 
/*      */   private int preferredHeight;
/*      */   
/*      */ 
/*      */   private int preferredWidth;
/*      */   
/*      */ 
/*      */   private int state;
/*      */   
/*      */ 
/*  155 */   private Vector controlListeners = new Vector();
/*      */   
/*      */ 
/*  158 */   PopupMenu zoomMenu = null;
/*      */   
/*      */ 
/*  161 */   private URL mpCodeBase = null;
/*      */   
/*      */ 
/*      */   protected transient GainControl gainControl;
/*      */   
/*  166 */   protected transient String curVolumeLevel = MediaPlayerResource.getString("THREE");
/*      */   
/*      */ 
/*  169 */   protected transient float curVolumeValue = 0.6F;
/*      */   
/*      */ 
/*  172 */   protected transient String curZoomLevel = MediaPlayerResource.getString("SCALE_NORMAL");
/*      */   
/*      */ 
/*  175 */   protected transient float curZoomValue = 1.0F;
/*      */   
/*      */ 
/*      */   protected transient Time mediaTime;
/*      */   
/*      */   private InternalControllerAdapter selfListener;
/*      */   
/*  182 */   private long contentLength = 0L;
/*      */   
/*  184 */   private boolean fixtedFirstTime = true;
/*      */   
/*  186 */   private boolean displayURL = false;
/*      */   
/*      */ 
/*  189 */   private boolean isPopupActive = true;
/*      */   
/*      */ 
/*      */ 
/*      */   private transient TextField urlName;
/*      */   
/*      */ 
/*      */ 
/*      */   private transient visualMouseAdapter mouseListen;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   class InternalControllerAdapter
/*      */     extends ControllerAdapter
/*      */   {
/*      */     private MediaPlayer thisBean;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public InternalControllerAdapter(MediaPlayer b)
/*      */     {
/*  212 */       this.thisBean = b;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void replaceURL(Object e)
/*      */     {
/*  226 */       MediaPlayer.this.debug("ReplaceURLEvent ");
/*  227 */       URL retobj = null;
/*      */       try {
/*  229 */         Class cls = Class.forName("com.ibm.media.ReplaceURLEvent");
/*  230 */         Method meth = cls.getMethod("getURL", null);
/*  231 */         retobj = (URL)meth.invoke(e, null);
/*      */       } catch (Throwable t) {
/*  233 */         System.err.println(t);
/*      */       }
/*  235 */       MediaPlayer.this.setMediaLocation(retobj.toExternalForm());
/*  236 */       this.thisBean.start();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void showDocument(Object e)
/*      */     {
/*  250 */       MediaPlayer.this.debug("ShowDocumentEvent ");
/*  251 */       MediaPlayer.this.initSetCodeBase();
/*  252 */       URL retURL = null;
/*  253 */       String retContext = null;
/*      */       try {
/*  255 */         Class cls = Class.forName("com.ibm.media.ShowDocumentEvent");
/*  256 */         Method meth = cls.getMethod("getURL", null);
/*  257 */         retURL = (URL)meth.invoke(e, null);
/*  258 */         meth = cls.getMethod("getString", null);
/*  259 */         retContext = (String)meth.invoke(e, null);
/*      */       } catch (Throwable t) {
/*  261 */         System.err.println(t);
/*      */       }
/*  263 */       if (MediaPlayer.this.mpAppletContext != null) {
/*  264 */         MediaPlayer.this.mpAppletContext.showDocument(retURL, retContext);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void transition(TransitionEvent e)
/*      */     {
/*  277 */       MediaPlayer.this.debug("TransitionEvent " + e);
/*  278 */       MediaPlayer.this.state = e.getCurrentState();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void realizeComplete(RealizeCompleteEvent e)
/*      */     {
/*  294 */       MediaPlayer.this.debug("  Event:  RealizeComplete");
/*  295 */       MediaPlayer.this.doRealize();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void prefetchComplete(PrefetchCompleteEvent e)
/*      */     {
/*  307 */       MediaPlayer.this.debug("  Event:prefetchComplete");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void formatChange(FormatChangeEvent e)
/*      */     {
/*  320 */       MediaPlayer.this.debug(" formatChangeevent");
/*  321 */       Component oldVisualComp = MediaPlayer.this.visualComponent;
/*  322 */       if (MediaPlayer.this.player == null) {
/*  323 */         MediaPlayer.this.Fatal(MediaPlayerResource.getString("SHOULD NOT OCCUR"));
/*  324 */         System.exit(-1);
/*      */       }
/*  326 */       if ((MediaPlayer.this.visualComponent = MediaPlayer.this.player.getVisualComponent()) != null) {
/*  327 */         if (oldVisualComp != MediaPlayer.this.visualComponent) {
/*  328 */           if (oldVisualComp != null) {
/*  329 */             oldVisualComp.remove(MediaPlayer.this.zoomMenu);
/*  330 */             MediaPlayer.this.vPanel.remove(oldVisualComp);
/*  331 */             MediaPlayer.this.panel.remove(MediaPlayer.this.vPanel);
/*  332 */             Component oldComp = MediaPlayer.this.controlComponent;
/*  333 */             if ((oldComp != null) && (MediaPlayer.this.newPanel != null)) {
/*  334 */               MediaPlayer.this.newPanel.remove(oldComp);
/*  335 */               if (MediaPlayer.this.displayURL == true)
/*  336 */                 MediaPlayer.this.newPanel.remove(MediaPlayer.this.urlName);
/*  337 */               MediaPlayer.this.panel.remove(MediaPlayer.this.newPanel);
/*      */             }
/*      */           }
/*  340 */           MediaPlayer.this.doRealize();
/*  341 */         } else if ((MediaPlayer.this.getMediaLocation().endsWith("mvr")) || (MediaPlayer.this.getMediaLocation().endsWith("MVR")))
/*      */         {
/*      */ 
/*  344 */           MediaPlayer.this.zoomTo(1.0F);
/*      */         }
/*      */       }
/*      */       else {
/*  348 */         Component oldComp = MediaPlayer.this.controlComponent;
/*  349 */         if (((MediaPlayer.this.controlComponent = MediaPlayer.this.player.getControlPanelComponent()) != null) && (MediaPlayer.this.isControlPanelVisible()))
/*      */         {
/*  351 */           if (oldComp != MediaPlayer.this.controlComponent) {
/*  352 */             if (oldComp != null) {
/*  353 */               MediaPlayer.this.newPanel.remove(oldComp);
/*  354 */               if (MediaPlayer.this.displayURL == true)
/*  355 */                 MediaPlayer.this.newPanel.remove(MediaPlayer.this.urlName);
/*  356 */               MediaPlayer.this.panel.remove(MediaPlayer.this.newPanel);
/*      */             }
/*  358 */             MediaPlayer.this.doRealize();
/*      */           }
/*      */         }
/*  361 */         else if ((oldVisualComp != null) && (MediaPlayer.this.vPanel != null)) {
/*  362 */           oldVisualComp.remove(MediaPlayer.this.zoomMenu);
/*  363 */           MediaPlayer.this.vPanel.remove(oldVisualComp);
/*  364 */           MediaPlayer.this.panel.remove(MediaPlayer.this.vPanel);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void start(StartEvent e)
/*      */     {
/*  379 */       MediaPlayer.this.debug("  Event:StartEvent ");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void endOfMedia(EndOfMediaEvent e)
/*      */     {
/*  393 */       MediaPlayer.this.debug("  Event:EndofMediaEvent");
/*  394 */       if (MediaPlayer.this.isPlayBackLoop()) {
/*  395 */         synchronized (this) {
/*  396 */           if (MediaPlayer.this.player == null) {
/*  397 */             MediaPlayer.this.Fatal(MediaPlayerResource.getString("SHOULD NOT OCCUR"));
/*  398 */             System.exit(-1);
/*      */           }
/*  400 */           if (MediaPlayer.this.player != null)
/*  401 */             MediaPlayer.this.player.setMediaTime(new Time(0L));
/*  402 */           if (MediaPlayer.this.player != null) {
/*  403 */             MediaPlayer.this.player.start();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void controllerError(ControllerErrorEvent e)
/*      */     {
/*  419 */       MediaPlayer.this.debug("  Event:ControllerErrorEvent");
/*  420 */       MediaPlayer.this.player = null;
/*  421 */       MediaPlayer.this.Fatal(e.getMessage());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void sizeChange(SizeChangeEvent e)
/*      */     {
/*  434 */       MediaPlayer.this.debug("  Event:SizeChangeEvent");
/*  435 */       int newPanelHeight = 0;
/*  436 */       if ((MediaPlayer.this.controlComponent != null) && (MediaPlayer.this.isControlPanelVisible())) {
/*  437 */         newPanelHeight = MediaPlayer.this.controlPanelHeight;
/*      */       }
/*  439 */       if ((MediaPlayer.this.urlName != null) && (MediaPlayer.this.isMediaLocationVisible()))
/*  440 */         newPanelHeight += MediaPlayer.this.urlFieldHeight;
/*  441 */       if (MediaPlayer.this.visualComponent != null) {
/*  442 */         MediaPlayer.this.visualComponent.setSize(e.getWidth(), e.getHeight());
/*  443 */         MediaPlayer.this.preferredHeight = MediaPlayer.this.visualComponent.getPreferredSize().height;
/*  444 */         MediaPlayer.this.preferredWidth = MediaPlayer.this.visualComponent.getPreferredSize().width;
/*      */       }
/*  446 */       if (MediaPlayer.this.panel != null) {
/*  447 */         if (MediaPlayer.this.vPanel != null) {
/*  448 */           MediaPlayer.this.vPanel.setBounds(0, 0, e.getWidth(), e.getHeight() - newPanelHeight);
/*      */           
/*  450 */           MediaPlayer.this.vPanel.validate();
/*      */         }
/*  452 */         MediaPlayer.this.panel.setBounds(0, 0, e.getWidth(), e.getHeight());
/*  453 */         MediaPlayer.this.panel.validate();
/*      */       }
/*  455 */       MediaPlayer.this.invalidate();
/*  456 */       MediaPlayer.this.validate();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void cachingControl(CachingControlEvent e)
/*      */     {
/*  469 */       MediaPlayer.this.debug("  Event:  CachingControl");
/*  470 */       if (MediaPlayer.this.isCachingControlVisible() == true) {
/*  471 */         CachingControl cc = e.getCachingControl();
/*  472 */         long contentLength = cc.getContentLength();
/*  473 */         if ((cc != null) && (MediaPlayer.this.cachingComponent == null) && (contentLength != Long.MAX_VALUE))
/*      */         {
/*  475 */           MediaPlayer.this.cachingComponent = cc.getControlComponent();
/*  476 */           if (MediaPlayer.this.cachingComponent == null) {
/*  477 */             MediaPlayer.this.cachingComponent = cc.getProgressBarComponent();
/*      */           }
/*  479 */           if (MediaPlayer.this.cachingComponent != null) {
/*  480 */             MediaPlayer.this.panel.add("South", MediaPlayer.this.cachingComponent);
/*  481 */             Dimension prefSize = MediaPlayer.this.cachingComponent.getPreferredSize();
/*  482 */             MediaPlayer.this.cachingComponent.setBounds(0, 0, prefSize.width, prefSize.height);
/*  483 */             MediaPlayer.this.panel.setSize(prefSize.width, prefSize.height);
/*  484 */             MediaPlayer.this.panel.validate();
/*      */           }
/*      */         }
/*  487 */         else if ((cc.getContentProgress() == contentLength) && 
/*  488 */           (MediaPlayer.this.cachingComponent != null)) {
/*  489 */           MediaPlayer.this.panel.remove(MediaPlayer.this.cachingComponent);
/*  490 */           MediaPlayer.this.validate();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MediaPlayer()
/*      */   {
/*  507 */     setLayout(null);
/*  508 */     if (this.panel == null) {
/*  509 */       this.panel = new Panel();
/*  510 */       this.panel.setLayout(new BorderLayout());
/*  511 */       this.panel.setVisible(false);
/*  512 */       add("Center", this.panel);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void doRealize()
/*      */   {
/*  526 */     debug("in doRealize");
/*  527 */     if (this.player == null) {
/*  528 */       Fatal(MediaPlayerResource.getString("SHOULD NOT OCCUR"));
/*  529 */       System.exit(-1);
/*      */     }
/*  531 */     this.gainControl = this.player.getGainControl();
/*      */     float re;
/*  533 */     if (this.gainControl != null) {
/*  534 */       re = this.gainControl.setLevel(this.curVolumeValue);
/*      */     }
/*      */     
/*  537 */     if ((this.visualComponent = this.player.getVisualComponent()) != null) {
/*  538 */       this.vPanel = new Panel();
/*  539 */       this.vPanel.setLayout(new BorderLayout());
/*  540 */       this.panel.setVisible(false);
/*  541 */       this.visualComponent.setVisible(false);
/*  542 */       this.vPanel.add("Center", this.visualComponent);
/*  543 */       this.panel.add("Center", this.vPanel);
/*      */       
/*  545 */       addComponentListener(new visualComponentAdapter(this));
/*  546 */       addPopupMenu(this.visualComponent);
/*  547 */       setPopupActive();
/*      */     }
/*      */     
/*  550 */     this.newPanel = new Panel();
/*  551 */     this.newPanel.setLayout(new BorderLayout());
/*  552 */     this.panel.add("South", this.newPanel);
/*  553 */     this.urlName = new TextField(10);
/*  554 */     this.urlName.setEditable(false);
/*      */     
/*  556 */     if (this.displayURL == true) {
/*  557 */       this.urlName.setText(this.urlString);
/*  558 */       this.newPanel.add("South", this.urlName);
/*      */     }
/*      */     
/*  561 */     if (((this.controlComponent = this.player.getControlPanelComponent()) != null) && (isControlPanelVisible()))
/*      */     {
/*      */ 
/*  564 */       this.controlComponent.setVisible(false);
/*  565 */       this.newPanel.add("North", this.controlComponent);
/*      */     }
/*      */     
/*  568 */     calculateSize();
/*      */     
/*  570 */     if (this.visualComponent == null) {
/*  571 */       if (this.controlComponent != null) {
/*  572 */         this.panel.setSize(this.controlComponent.getPreferredSize().width, this.controlPanelHeight + this.urlFieldHeight);
/*      */       }
/*      */       else {
/*  575 */         this.panel.setSize(100, this.urlFieldHeight);
/*      */       }
/*      */     }
/*  578 */     showVisual();
/*      */   }
/*      */   
/*      */   private void calculateSize() {
/*  582 */     if (this.player == null)
/*  583 */       return;
/*  584 */     debug("claculateSize");
/*  585 */     if ((this.visualComponent = this.player.getVisualComponent()) != null)
/*      */     {
/*  587 */       this.preferredHeight = this.visualComponent.getPreferredSize().height;
/*  588 */       this.preferredWidth = this.visualComponent.getPreferredSize().width;
/*      */     }
/*      */     
/*      */ 
/*  592 */     if ((((this.controlComponent = this.player.getControlPanelComponent()) != null) && (isControlPanelVisible())) || (this.displayURL == true))
/*      */     {
/*  594 */       if ((this.controlComponent != null) && (isControlPanelVisible())) {
/*  595 */         this.controlPanelHeight = this.controlComponent.getPreferredSize().height;
/*  596 */         this.preferredHeight += this.controlPanelHeight;
/*  597 */         if (this.preferredWidth == 0) {
/*  598 */           this.preferredWidth = 320;
/*      */         }
/*      */       }
/*  601 */       if (this.displayURL == true) {
/*  602 */         this.urlFieldHeight = this.urlName.getPreferredSize().height;
/*  603 */         this.preferredHeight += this.urlFieldHeight;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  608 */     if (this.visualComponent != null) {
/*  609 */       Dimension vSize = this.visualComponent.getPreferredSize();
/*  610 */       int totalHeight = 0;
/*  611 */       if (this.controlComponent != null) {
/*  612 */         totalHeight += this.controlComponent.getPreferredSize().height;
/*      */       }
/*  614 */       if (this.displayURL == true) {
/*  615 */         totalHeight += this.urlName.getPreferredSize().height;
/*      */       }
/*      */       
/*  618 */       if ((this.fixedAspectRatio == true) && (this.curZoomValue == 1.0D))
/*      */       {
/*      */ 
/*      */ 
/*  622 */         if ((vSize.width != 0) && (vSize.height != 0)) {
/*  623 */           if (getSize().width / vSize.width >= (getSize().height - totalHeight) / vSize.height)
/*      */           {
/*      */ 
/*      */ 
/*  627 */             this.curZoomValue = ((getSize().height - totalHeight) / vSize.height);
/*      */           }
/*      */           else
/*      */           {
/*  631 */             this.curZoomValue = (getSize().width / vSize.width);
/*      */           }
/*      */         }
/*      */         
/*  635 */         if (this.curZoomValue < 0.5D) {
/*  636 */           this.curZoomValue = 1.0F;
/*      */         }
/*      */       }
/*  639 */       if (this.newPanel != null) {
/*  640 */         this.newPanel.setSize(this.visualComponent.getPreferredSize().width, this.controlPanelHeight + this.urlFieldHeight);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized void showVisual()
/*      */   {
/*  650 */     if (this.cachingComponent != null) {
/*  651 */       this.panel.remove(this.cachingComponent);
/*  652 */       validate();
/*      */     }
/*      */     
/*  655 */     if ((this.visualComponent != null) && ((this.fixedAspectRatio == true) || (!this.fixtedFirstTime)))
/*      */     {
/*  657 */       zoomTo(this.curZoomValue);
/*      */     } else {
/*  659 */       this.panel.setSize(getSize());
/*      */     }
/*  661 */     this.panel.setVisible(true);
/*  662 */     if (this.visualComponent != null) {
/*  663 */       this.visualComponent.setVisible(true);
/*      */     }
/*  665 */     if ((this.controlComponent != null) && (isControlPanelVisible())) {
/*  666 */       this.controlComponent.setVisible(true);
/*      */     }
/*      */     
/*  669 */     this.panel.validate();
/*  670 */     validate();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initSetCodeBase()
/*      */   {
/*  679 */     if (this.mpCodeBase != null) {
/*  680 */       return;
/*      */     }
/*  682 */     Container p = getParent();
/*  683 */     while (p != null) {
/*  684 */       if ((p instanceof Applet))
/*      */         break;
/*  686 */       p = p.getParent();
/*      */     }
/*  688 */     if (p != null) {
/*  689 */       setCodeBase(((Applet)p).getCodeBase());
/*  690 */       this.mpAppletContext = ((Applet)p).getAppletContext();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMediaLocation()
/*      */   {
/*  705 */     if (this.mrl != null) {
/*  706 */       return this.mrl.toString();
/*      */     }
/*  708 */     return this.urlString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected MediaLocator getMediaLocator(String filename)
/*      */   {
/*  723 */     MediaLocator localml = null;
/*      */     
/*  725 */     if (filename.regionMatches(true, 0, "<codebase>", 0, 10)) {
/*      */       try {
/*  727 */         if (this.mpCodeBase == null)
/*  728 */           initSetCodeBase();
/*  729 */         localml = new MediaLocator(new URL(this.mpCodeBase, filename.substring(11)));
/*      */       } catch (MalformedURLException e) {
/*  731 */         if (this.mpCodeBase != null) {
/*  732 */           log(MediaPlayerResource.getString("NO IMAGE:BAD_URL") + filename + " " + this.mpCodeBase);
/*      */           
/*  734 */           this.urlString = " ";
/*      */         }
/*  736 */         return null;
/*      */       }
/*      */     } else {
/*  739 */       localml = new MediaLocator(filename);
/*      */     }
/*      */     
/*  742 */     return localml;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMediaLocation(String location)
/*      */   {
/*      */     try
/*      */     {
/*  762 */       String old = "";
/*  763 */       if (this.mrl != null) {
/*  764 */         old = this.mrl.toExternalForm();
/*  765 */         if (this.panel != null)
/*  766 */           this.panel.removeAll();
/*  767 */         if (this.player != null) {
/*  768 */           this.player.stop();
/*  769 */           this.player.close();
/*  770 */           this.panel.validate();
/*  771 */           if (this.controlListeners.contains(this.selfListener))
/*  772 */             this.controlListeners.removeElement(this.selfListener);
/*      */         }
/*      */       }
/*  775 */       this.urlString = location;
/*  776 */       if ((this.mrl = getMediaLocator(location)) == null)
/*      */       {
/*  778 */         return;
/*      */       }
/*      */       try {
/*  781 */         this.player = Manager.createPlayer(this.mrl);
/*      */       } catch (Exception e) {
/*  783 */         this.player = null;
/*  784 */         this.urlString = " ";
/*  785 */         this.changes.firePropertyChange("mediaLocation", location, old);
/*  786 */         Fatal(MediaPlayerResource.getString("UNABLE_CREATE_PLAYER") + e);
/*  787 */         return;
/*      */       }
/*      */       
/*  790 */       if (this.player == null) {
/*  791 */         return;
/*      */       }
/*      */       
/*  794 */       if (this.urlName != null) {
/*  795 */         this.urlName.setText(this.urlString);
/*  796 */         this.urlName.setFont(getFont());
/*      */       }
/*  798 */       this.player.addControllerListener(this.selfListener = new InternalControllerAdapter(this));
/*      */       
/*  800 */       if (!this.controlListeners.isEmpty()) {
/*  801 */         for (int i = 0; i < this.controlListeners.size(); i++) {
/*  802 */           this.player.addControllerListener((ControllerListener)this.controlListeners.elementAt(i));
/*      */         }
/*      */       }
/*  805 */       this.changes.firePropertyChange("mediaLocation", old, location);
/*      */     }
/*      */     catch (Exception e) {
/*  808 */       this.mrl = null;
/*  809 */       e.printStackTrace();
/*  810 */       Fatal(MediaPlayerResource.getString("UNABLE_CREATE_PLAYER") + e);
/*  811 */       return;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMediaLocator(MediaLocator locator)
/*      */   {
/*      */     try
/*      */     {
/*  831 */       debug("setMediaLocator");
/*  832 */       if (locator != null) {
/*  833 */         if (this.mrl != null) {
/*  834 */           if (this.panel != null)
/*  835 */             this.panel.removeAll();
/*  836 */           if (this.player != null) {
/*  837 */             this.player.stop();
/*  838 */             this.player.close();
/*  839 */             if (this.controlListeners.contains(this.selfListener))
/*  840 */               this.controlListeners.removeElement(this.selfListener);
/*      */           }
/*      */         }
/*      */       } else {
/*  844 */         return;
/*      */       }
/*      */       try {
/*  847 */         this.player = Manager.createPlayer(locator);
/*      */       } catch (NoPlayerException e) {
/*  849 */         this.player = null;
/*  850 */         this.urlString = " ";
/*  851 */         Fatal(MediaPlayerResource.getString("UNABLE_CREATE_PLAYER") + e);
/*  852 */         return;
/*      */       } catch (IOException e) {
/*  854 */         this.player = null;
/*  855 */         this.urlString = " ";
/*  856 */         Fatal(MediaPlayerResource.getString("IO_EXCEPTION") + e);
/*  857 */         return;
/*      */       }
/*      */       
/*  860 */       if (this.player == null) {
/*  861 */         return;
/*      */       }
/*  863 */       this.urlString = locator.toExternalForm();
/*  864 */       this.mrl = locator;
/*  865 */       if (this.urlName != null) {
/*  866 */         this.urlName.setText(this.urlString);
/*  867 */         this.urlName.setFont(getFont());
/*      */       }
/*  869 */       this.player.addControllerListener(this.selfListener = new InternalControllerAdapter(this));
/*      */       
/*  871 */       if (!this.controlListeners.isEmpty()) {
/*  872 */         for (int i = 0; i < this.controlListeners.size(); i++) {
/*  873 */           this.player.addControllerListener((ControllerListener)this.controlListeners.elementAt(i));
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  878 */       this.url = null;
/*  879 */       e.printStackTrace();
/*  880 */       Fatal(MediaPlayerResource.getString("UNABLE_CREATE_PLAYER") + e);
/*  881 */       return;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDataSource(DataSource ds)
/*      */   {
/*      */     try
/*      */     {
/*  901 */       debug("setDataSource");
/*  902 */       if (ds != null) {
/*  903 */         if (this.panel != null)
/*  904 */           this.panel.removeAll();
/*  905 */         if (this.player != null) {
/*  906 */           this.player.stop();
/*  907 */           if (this.controlListeners.contains(this.selfListener))
/*  908 */             this.controlListeners.removeElement(this.selfListener);
/*      */         }
/*      */       }
/*  911 */       if (this.urlName != null) {
/*  912 */         if (ds.getLocator() != null) {
/*  913 */           this.urlName.setText(ds.getLocator().toExternalForm());
/*      */         } else
/*  915 */           this.urlName.setText("");
/*  916 */         this.urlName.setFont(getFont());
/*      */       }
/*      */       try {
/*  919 */         this.player = Manager.createPlayer(ds);
/*      */       } catch (Exception e) {
/*  921 */         this.player = null;
/*  922 */         this.urlString = " ";
/*  923 */         Fatal(MediaPlayerResource.getString("UNABLE_CREATE_PLAYER") + e);
/*  924 */         return;
/*      */       }
/*  926 */       if (this.player == null) {
/*  927 */         return;
/*      */       }
/*      */       
/*  930 */       if (ds.getLocator() != null) {
/*  931 */         this.urlString = ds.getLocator().toExternalForm();
/*      */       } else
/*  933 */         this.urlString = "";
/*  934 */       this.player.addControllerListener(this.selfListener = new InternalControllerAdapter(this));
/*      */       
/*  936 */       if (!this.controlListeners.isEmpty()) {
/*  937 */         for (int i = 0; i < this.controlListeners.size(); i++) {
/*  938 */           this.player.addControllerListener((ControllerListener)this.controlListeners.elementAt(i));
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception e) {
/*  943 */       this.mrl = null;
/*  944 */       e.printStackTrace();
/*  945 */       Fatal(MediaPlayerResource.getString("UNABLE_CREATE_PLAYER") + e);
/*  946 */       return;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPlayer(Player newPlayer)
/*      */   {
/*  964 */     debug("setPlayer");
/*      */     
/*  966 */     if (newPlayer == null) {
/*  967 */       return;
/*      */     }
/*  969 */     if (newPlayer != null) {
/*  970 */       if (this.panel != null)
/*  971 */         this.panel.removeAll();
/*  972 */       if (this.player != null) {
/*  973 */         this.player.stop();
/*  974 */         if (this.controlListeners.contains(this.selfListener))
/*  975 */           this.controlListeners.removeElement(this.selfListener);
/*      */       }
/*      */     }
/*  978 */     this.player = newPlayer;
/*  979 */     this.urlString = "";
/*  980 */     this.player.addControllerListener(this.selfListener = new InternalControllerAdapter(this));
/*  981 */     switch (this.player.getState()) {
/*      */     case 500: 
/*  983 */       debug("player state prefetched ");
/*  984 */       break;
/*      */     case 400: 
/*  986 */       debug("player state prefetching ");
/*  987 */       break;
/*      */     case 300: 
/*  989 */       debug("player state Realized ");
/*  990 */       break;
/*      */     case 200: 
/*  992 */       debug("player state  Realizing");
/*  993 */       break;
/*      */     case 600: 
/*  995 */       debug("player state started ");
/*  996 */       break;
/*      */     case 100: 
/*  998 */       debug("player state Unrealized ");
/*      */     }
/*      */     
/* 1001 */     if ((this.player.getState() == 300) || (this.player.getState() == 400))
/*      */     {
/* 1003 */       doRealize();
/*      */     }
/* 1005 */     if ((this.player.getState() == 500) || (this.player.getState() == 600))
/*      */     {
/* 1007 */       doRealize();
/*      */     }
/*      */     
/* 1010 */     if (!this.controlListeners.isEmpty()) {
/* 1011 */       for (int i = 0; i < this.controlListeners.size(); i++) {
/* 1012 */         this.player.addControllerListener((ControllerListener)this.controlListeners.elementAt(i));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getPlaybackLoop()
/*      */   {
/* 1030 */     return this.looping;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPlaybackLoop(boolean val)
/*      */   {
/* 1046 */     boolean old = this.looping;
/* 1047 */     this.looping = val;
/* 1048 */     this.changes.firePropertyChange("playbackLoop", new Boolean(old), new Boolean(this.looping));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isPlayBackLoop()
/*      */   {
/* 1063 */     return this.looping;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setZoomTo(String scale)
/*      */   {
/* 1078 */     debug("setZoomTo");
/* 1079 */     this.curZoomLevel = scale;
/* 1080 */     if (scale.trim().equals(MediaPlayerResource.getString("1:2"))) {
/* 1081 */       this.curZoomValue = 0.5F;
/* 1082 */     } else if (scale.trim().equals(MediaPlayerResource.getString("1:1"))) {
/* 1083 */       this.curZoomValue = 1.0F;
/* 1084 */     } else if (scale.trim().equals(MediaPlayerResource.getString("2:1"))) {
/* 1085 */       this.curZoomValue = 2.0F;
/* 1086 */     } else if (scale.trim().equals(MediaPlayerResource.getString("4:1"))) {
/* 1087 */       this.curZoomValue = 4.0F;
/*      */     }
/*      */     
/* 1090 */     this.fixtedFirstTime = false;
/* 1091 */     zoomTo(this.curZoomValue);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getZoomTo()
/*      */   {
/* 1105 */     return this.curZoomLevel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getControlPanelHeight()
/*      */   {
/* 1117 */     if (isControlPanelVisible()) {
/* 1118 */       return this.controlPanelHeight;
/*      */     }
/* 1120 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMediaLocationHeight()
/*      */   {
/* 1132 */     if (isMediaLocationVisible()) {
/* 1133 */       return this.urlFieldHeight;
/*      */     }
/* 1135 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setVolumeLevel(String volumeString)
/*      */   {
/* 1149 */     debug("in setVolumeLevel");
/* 1150 */     if (volumeString == null) {
/* 1151 */       return;
/*      */     }
/* 1153 */     String old = this.curVolumeLevel;
/* 1154 */     int level = Integer.parseInt(volumeString);
/* 1155 */     this.curVolumeLevel = volumeString;
/* 1156 */     this.curVolumeValue = (level * 0.2F);
/*      */     
/* 1158 */     if (this.gainControl != null) {
/* 1159 */       this.gainControl.setLevel(this.curVolumeValue);
/*      */     }
/* 1161 */     this.changes.firePropertyChange("volumeLevel", old, this.curVolumeLevel);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getVolumeLevel()
/*      */   {
/* 1175 */     return this.curVolumeLevel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isMediaLocationVisible()
/*      */   {
/* 1187 */     return this.displayURL;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMediaLocationVisible(boolean val)
/*      */   {
/* 1200 */     if (this.displayURL != val) {
/* 1201 */       if (this.urlName != null) {
/* 1202 */         if (val) {
/* 1203 */           this.urlName.setText(this.urlString);
/* 1204 */           this.newPanel.add("South", this.urlName);
/*      */         } else {
/* 1206 */           this.newPanel.remove(this.urlName);
/*      */         }
/*      */       }
/*      */       
/* 1210 */       this.panel.validate();
/* 1211 */       validate();
/* 1212 */       this.displayURL = val;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isControlPanelVisible()
/*      */   {
/* 1225 */     return this.panelVisible;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setControlPanelVisible(boolean isVisible)
/*      */   {
/* 1238 */     if (this.panelVisible != isVisible) {
/* 1239 */       boolean old = this.panelVisible;
/* 1240 */       if (this.controlComponent != null) {
/* 1241 */         if (isVisible) {
/* 1242 */           this.panel.add("South", this.controlComponent);
/*      */         } else {
/* 1244 */           this.panel.remove(this.controlComponent);
/*      */         }
/*      */       }
/* 1247 */       invalidate();
/* 1248 */       validate();
/* 1249 */       this.panelVisible = isVisible;
/* 1250 */       this.changes.firePropertyChange("controlPanelVisible", new Boolean(old), new Boolean(this.panelVisible));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isCachingControlVisible()
/*      */   {
/* 1267 */     return this.cachingVisible;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCachingControlVisible(boolean isVisible)
/*      */   {
/* 1282 */     if (this.cachingVisible != isVisible) {
/* 1283 */       boolean old = this.cachingVisible;
/* 1284 */       if (this.cachingComponent != null) {
/* 1285 */         if (isVisible) {
/* 1286 */           this.panel.add("South", this.cachingComponent);
/*      */         } else {
/* 1288 */           this.panel.remove(this.cachingComponent);
/*      */         }
/*      */       }
/* 1291 */       invalidate();
/* 1292 */       validate();
/* 1293 */       this.changes.firePropertyChange("cachingControlVisible", new Boolean(old), new Boolean(this.cachingVisible));
/*      */     }
/*      */     
/*      */ 
/* 1297 */     this.cachingVisible = isVisible;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFixedAspectRatio()
/*      */   {
/* 1311 */     return this.fixedAspectRatio;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFixedAspectRatio(boolean isFixed)
/*      */   {
/* 1326 */     boolean old = this.fixedAspectRatio;
/* 1327 */     this.fixedAspectRatio = isFixed;
/* 1328 */     this.changes.firePropertyChange("fixedAspectRatio", new Boolean(old), new Boolean(this.fixedAspectRatio));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPopupActive(boolean isActive)
/*      */   {
/* 1343 */     if (isActive != this.isPopupActive) {
/* 1344 */       this.isPopupActive = isActive;
/* 1345 */       setPopupActive();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setPopupActive()
/*      */   {
/* 1355 */     if (this.isPopupActive == true) {
/* 1356 */       this.visualComponent.addMouseListener(this.mouseListen = new visualMouseAdapter(null));
/* 1357 */     } else if (this.mouseListen != null) {
/* 1358 */       this.visualComponent.removeMouseListener(this.mouseListen);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Component getVisualComponent()
/*      */   {
/* 1366 */     if (this.player != null) {
/* 1367 */       return this.player.getVisualComponent();
/*      */     }
/* 1369 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public GainControl getGainControl()
/*      */   {
/* 1375 */     if (this.player != null) {
/* 1376 */       return this.player.getGainControl();
/*      */     }
/* 1378 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public Component getControlPanelComponent()
/*      */   {
/* 1384 */     if (this.player != null) {
/* 1385 */       return this.player.getControlPanelComponent();
/*      */     }
/* 1387 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void start()
/*      */   {
/* 1400 */     if (this.player != null) {
/* 1401 */       this.player.start();
/*      */     } else {
/* 1403 */       if (this.mrl == null) {
/* 1404 */         initSetCodeBase();
/* 1405 */         this.mrl = getMediaLocator(this.urlString);
/*      */       }
/*      */       
/* 1408 */       if (this.mrl != null) {
/*      */         try {
/* 1410 */           this.player = Manager.createPlayer(this.mrl);
/* 1411 */           this.player.addControllerListener(this.selfListener = new InternalControllerAdapter(this));
/*      */           
/* 1413 */           start();
/*      */           
/* 1415 */           if (this.controlListeners.size() > 0) {
/* 1416 */             for (int i = 0; i < this.controlListeners.size(); i++) {
/* 1417 */               this.player.addControllerListener((ControllerListener)this.controlListeners.elementAt(i));
/*      */             }
/*      */           }
/*      */         } catch (Exception e) {
/* 1421 */           this.player = null;
/* 1422 */           this.urlString = " ";
/* 1423 */           Fatal(MediaPlayerResource.getString("UNABLE_CREATE_PLAYER") + e);
/* 1424 */           return;
/*      */         }
/*      */       } else {
/* 1427 */         Fatal(MediaPlayerResource.getString("COULD_NOT_START_PLAYER"));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void addController(Controller n)
/*      */   {
/*      */     try
/*      */     {
/* 1436 */       if (this.player != null) {
/* 1437 */         this.player.addController(n);
/*      */       }
/*      */     } catch (IncompatibleTimeBaseException e) {
/* 1440 */       Fatal(MediaPlayerResource.getString("PLAYER_NO_COMPATIBLE_TIME_BASE"));
/* 1441 */       return;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Player getPlayer()
/*      */   {
/* 1454 */     return this.player;
/*      */   }
/*      */   
/*      */   public void removeController(Controller old)
/*      */   {
/* 1459 */     if (this.player != null) {
/* 1460 */       this.player.removeController(old);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setSource(DataSource data)
/*      */   {
/*      */     try
/*      */     {
/* 1470 */       if (this.player != null) {
/* 1471 */         this.player.setSource(data);
/*      */       }
/*      */     } catch (IOException e) {
/* 1474 */       Fatal(MediaPlayerResource.getString("IO_EXCEPTION") + e);
/* 1475 */       return;
/*      */     } catch (IncompatibleSourceException e) {
/* 1477 */       Fatal(MediaPlayerResource.getString("INCOMPATIBLE_SOURCE_EXCEPTION") + e);
/* 1478 */       return;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getState()
/*      */   {
/* 1487 */     if (this.player != null) {
/* 1488 */       return this.player.getState();
/*      */     }
/* 1490 */     return 100;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getTargetState()
/*      */   {
/* 1497 */     if (this.player != null) {
/* 1498 */       return this.player.getTargetState();
/*      */     }
/* 1500 */     return 100;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void realize()
/*      */   {
/* 1507 */     if (this.player != null) {
/* 1508 */       this.player.realize();
/*      */     } else {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void prefetch()
/*      */   {
/* 1517 */     if (this.player != null) {
/* 1518 */       this.player.prefetch();
/*      */     } else {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deallocate()
/*      */   {
/* 1528 */     if (this.player != null) {
/* 1529 */       debug("in deallocate");
/* 1530 */       this.player.deallocate();
/*      */     }
/*      */     else {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */   {
/* 1540 */     if (this.player != null) {
/* 1541 */       this.panel.removeAll();
/* 1542 */       this.player.close();
/* 1543 */       this.player = null;
/*      */     }
/*      */     else {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Time getStartLatency()
/*      */   {
/* 1552 */     if (this.player != null) {
/* 1553 */       return this.player.getStartLatency();
/*      */     }
/* 1555 */     return Controller.LATENCY_UNKNOWN;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Control[] getControls()
/*      */   {
/* 1562 */     if (this.player != null) {
/* 1563 */       return this.player.getControls();
/*      */     }
/* 1565 */     return new Control[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Control getControl(String forName)
/*      */   {
/* 1572 */     if (this.player != null) {
/* 1573 */       return this.player.getControl(forName);
/*      */     }
/* 1575 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addControllerListener(ControllerListener listener)
/*      */   {
/* 1583 */     if (this.player != null) {
/* 1584 */       this.player.addControllerListener(listener);
/*      */     }
/* 1586 */     if (!this.controlListeners.contains(listener)) {
/* 1587 */       this.controlListeners.addElement(listener);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void removeControllerListener(ControllerListener listener)
/*      */   {
/* 1594 */     if (this.player != null) {
/* 1595 */       this.player.removeControllerListener(listener);
/*      */     }
/* 1597 */     if (this.controlListeners.contains(listener)) {
/* 1598 */       this.controlListeners.removeElement(listener);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTimeBase(TimeBase master)
/*      */   {
/*      */     try
/*      */     {
/* 1608 */       if (this.player != null) {
/* 1609 */         this.player.setTimeBase(master);
/*      */       }
/*      */     } catch (IncompatibleTimeBaseException e) {
/* 1612 */       Fatal(MediaPlayerResource.getString("INCOMPATIBLE_TIME_BASE") + e);
/* 1613 */       return;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void syncStart(Time at)
/*      */   {
/* 1621 */     debug("syncStart ");
/* 1622 */     if (this.player != null) {
/* 1623 */       this.player.syncStart(at);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void stop()
/*      */   {
/* 1630 */     if (this.player != null) {
/* 1631 */       this.player.stop();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stopAndDeallocate()
/*      */   {
/* 1641 */     if (this.player != null) {
/* 1642 */       this.player.stop();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setStopTime(Time stopTime)
/*      */   {
/* 1649 */     if (this.player != null) {
/* 1650 */       this.player.setStopTime(stopTime);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Time getStopTime()
/*      */   {
/* 1657 */     if (this.player != null) {
/* 1658 */       return this.player.getStopTime();
/*      */     }
/* 1660 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setMediaTime(Time now)
/*      */   {
/* 1667 */     if (this.player != null) {
/* 1668 */       this.player.setMediaTime(now);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Time getMediaTime()
/*      */   {
/* 1675 */     if (this.player != null) {
/* 1676 */       return this.player.getMediaTime();
/*      */     }
/* 1678 */     return Controller.LATENCY_UNKNOWN;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getMediaNanoseconds()
/*      */   {
/* 1690 */     if (this.player != null) {
/* 1691 */       return this.player.getMediaNanoseconds();
/*      */     }
/* 1693 */     return Long.MAX_VALUE;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getSyncTime()
/*      */   {
/* 1701 */     if (this.player != null) {
/* 1702 */       return this.player.getSyncTime();
/*      */     }
/* 1704 */     return Controller.LATENCY_UNKNOWN;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public TimeBase getTimeBase()
/*      */   {
/* 1711 */     if (this.player != null) {
/* 1712 */       return this.player.getTimeBase();
/*      */     }
/* 1714 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public Time mapToTimeBase(Time t)
/*      */   {
/*      */     try
/*      */     {
/* 1722 */       if (this.player != null) {
/* 1723 */         return this.player.mapToTimeBase(t);
/*      */       }
/*      */     } catch (ClockStoppedException e) {
/* 1726 */       log(MediaPlayerResource.getString("CALL_A_STOPPED_CLOCK"));
/*      */     }
/*      */     
/* 1729 */     return Controller.LATENCY_UNKNOWN;
/*      */   }
/*      */   
/*      */ 
/*      */   public float getRate()
/*      */   {
/* 1735 */     if (this.player != null) {
/* 1736 */       return this.player.getRate();
/*      */     }
/* 1738 */     return 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public float setRate(float factor)
/*      */   {
/* 1745 */     if (this.player != null) {
/* 1746 */       return this.player.setRate(factor);
/*      */     }
/* 1748 */     return 0.0F;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getDuration()
/*      */   {
/* 1756 */     if (this.player != null) {
/* 1757 */       return this.player.getDuration();
/*      */     }
/* 1759 */     return Duration.DURATION_UNKNOWN;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized void waitForState(int s)
/*      */   {
/* 1777 */     while (this.state != s) {
/*      */       try {
/* 1779 */         wait(1000L);
/*      */       }
/*      */       catch (Exception e) {}
/*      */     }
/*      */   }
/*      */   
/* 1785 */   Method errMeth = null;
/*      */   
/*      */   private void Fatal(String name)
/*      */   {
/*      */     try {
/* 1790 */       if (this.errMeth == null) {
/* 1791 */         Class cls = Class.forName("com.sun.media.Log");
/* 1792 */         Class[] params = { Class.forName("java.lang.Object") };
/*      */         
/* 1794 */         this.errMeth = cls.getMethod("error", params);
/*      */       }
/* 1796 */       Object[] args = { name };
/* 1797 */       this.errMeth.invoke(null, args);
/*      */     } catch (Throwable t) {
/* 1799 */       System.err.println(name);
/*      */     }
/*      */   }
/*      */   
/*      */   private void log(String name)
/*      */   {
/*      */     try {
/* 1806 */       if (this.errMeth == null) {
/* 1807 */         Class cls = Class.forName("com.sun.media.Log");
/* 1808 */         Class[] params = { Class.forName("java.lang.Object") };
/*      */         
/* 1810 */         this.errMeth = cls.getMethod("comment", params);
/*      */       }
/* 1812 */       Object[] args = { name };
/* 1813 */       this.errMeth.invoke(null, args);
/*      */     } catch (Throwable t) {
/* 1815 */       System.err.println(name);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readExternal(ObjectInput in)
/*      */     throws IOException, ClassNotFoundException
/*      */   {
/* 1833 */     setBounds((Rectangle)in.readObject());
/* 1834 */     setBackground((Color)in.readObject());
/* 1835 */     setForeground((Color)in.readObject());
/* 1836 */     setFont((Font)in.readObject());
/* 1837 */     setVisible(in.readBoolean());
/* 1838 */     setEnabled(in.readBoolean());
/*      */     
/* 1840 */     String n = (String)in.readObject();
/* 1841 */     if (n != null) {
/* 1842 */       this.mrl = new MediaLocator(n);
/*      */     }
/* 1844 */     if (this.mrl != null) {
/*      */       try {
/* 1846 */         setMediaLocator(this.mrl);
/*      */       } catch (Exception e) {}
/*      */     }
/* 1849 */     setMediaLocationVisible(in.readBoolean());
/* 1850 */     this.panelVisible = in.readBoolean();
/* 1851 */     this.cachingVisible = in.readBoolean();
/* 1852 */     this.fixedAspectRatio = in.readBoolean();
/* 1853 */     this.preferredHeight = in.readInt();
/* 1854 */     this.preferredWidth = in.readInt();
/*      */     
/*      */ 
/* 1857 */     if (in.readBoolean()) {
/* 1858 */       int s = in.readInt();
/* 1859 */       int ts = in.readInt();
/* 1860 */       this.state = 100;
/* 1861 */       if (s >= 300) {
/* 1862 */         long mt = in.readLong();
/* 1863 */         long st = in.readLong();
/* 1864 */         float r = in.readFloat();
/* 1865 */         if (ts >= 500) {
/* 1866 */           this.player.prefetch();
/* 1867 */           waitForState(500);
/* 1868 */         } else if (ts >= 300) {
/* 1869 */           this.player.realize();
/* 1870 */           waitForState(300);
/*      */         }
/* 1872 */         this.player.setMediaTime(new Time(mt));
/* 1873 */         this.player.setStopTime(new Time(st));
/* 1874 */         this.player.setRate(r);
/* 1875 */         float l = in.readFloat();
/* 1876 */         if (l != -1.0F) {
/* 1877 */           GainControl g = this.player.getGainControl();
/* 1878 */           if (g != null) {
/* 1879 */             boolean mute = in.readBoolean();
/* 1880 */             g.setLevel(l);
/* 1881 */             g.setMute(mute);
/*      */           } else {
/* 1883 */             in.readBoolean();
/*      */           }
/*      */         }
/*      */         
/* 1887 */         if (ts >= 600) {
/* 1888 */           this.player.start();
/*      */         }
/*      */       }
/*      */     }
/* 1892 */     invalidate();
/* 1893 */     validate();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeExternal(ObjectOutput out)
/*      */     throws IOException
/*      */   {
/* 1908 */     out.writeObject(getBounds());
/* 1909 */     out.writeObject(getBackground());
/* 1910 */     out.writeObject(getForeground());
/* 1911 */     out.writeObject(getFont());
/* 1912 */     out.writeBoolean(isVisible());
/* 1913 */     out.writeBoolean(isEnabled());
/*      */     
/*      */ 
/* 1916 */     if (this.mrl != null) {
/* 1917 */       out.writeObject(this.mrl.toExternalForm());
/*      */     } else {
/* 1919 */       out.writeObject(null);
/*      */     }
/* 1921 */     out.writeBoolean(this.displayURL);
/* 1922 */     out.writeBoolean(this.panelVisible);
/* 1923 */     out.writeBoolean(this.cachingVisible);
/* 1924 */     out.writeBoolean(this.fixedAspectRatio);
/* 1925 */     out.writeInt(this.preferredHeight);
/* 1926 */     out.writeInt(this.preferredWidth);
/*      */     
/* 1928 */     if (this.player == null) {
/* 1929 */       out.writeBoolean(false);
/*      */     } else {
/* 1931 */       out.writeBoolean(true);
/* 1932 */       out.writeInt(this.player.getState());
/* 1933 */       out.writeInt(this.player.getTargetState());
/* 1934 */       if (this.player.getState() >= 300) {
/* 1935 */         out.writeLong(this.player.getMediaNanoseconds());
/* 1936 */         out.writeLong(this.player.getStopTime().getNanoseconds());
/* 1937 */         out.writeFloat(this.player.getRate());
/*      */         
/*      */         GainControl g;
/* 1940 */         if ((g = this.player.getGainControl()) != null) {
/* 1941 */           out.writeFloat(g.getLevel());
/* 1942 */           out.writeBoolean(g.getMute());
/*      */         } else {
/* 1944 */           out.writeFloat(-1.0F);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void zoomTo(float z)
/*      */   {
/* 1960 */     debug("zoomTo " + z);
/* 1961 */     int ddwidth = 0;
/* 1962 */     int ddheight = 0;
/* 1963 */     if ((this.visualComponent != null) && (this.fitVideo)) {
/*      */       try {
/* 1965 */         Dimension d = this.visualComponent.getPreferredSize();
/* 1966 */         ddwidth = (int)(d.width * z);
/* 1967 */         ddheight = (int)(d.height * z);
/*      */         
/* 1969 */         int dheight = 0;
/* 1970 */         if ((this.controlComponent != null) && (isControlPanelVisible()))
/* 1971 */           dheight = this.controlComponent.getPreferredSize().height;
/* 1972 */         if (this.displayURL == true) {
/* 1973 */           dheight += this.urlName.getPreferredSize().height;
/*      */         }
/* 1975 */         if (this.newPanel != null)
/* 1976 */           this.newPanel.setSize(ddwidth, dheight);
/* 1977 */         this.panel.setSize(ddwidth, ddheight + dheight);
/*      */         
/* 1979 */         if ((this.fixedAspectRatio == true) || ((!this.fixedAspectRatio) && (!this.fixtedFirstTime)))
/*      */         {
/* 1981 */           center(this, this.panel, true, dheight);
/*      */         } else {
/* 1983 */           center(this, this.panel, false, dheight);
/*      */         }
/* 1985 */         this.panel.validate();
/*      */       }
/*      */       catch (Exception e) {
/* 1988 */         log(MediaPlayerResource.getString("UNABLE_TO_ZOOM") + e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private float aspectRatio(float width, float height, int controllerHeight)
/*      */   {
/* 2008 */     return width / (height - controllerHeight);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void center(Container parent, Panel comp, boolean fit, int dheight)
/*      */   {
/* 2025 */     int pwidth = parent.getSize().width;
/* 2026 */     int pheight = parent.getSize().height;
/*      */     
/* 2028 */     int width = comp.getSize().width;
/* 2029 */     int height = comp.getSize().height;
/* 2030 */     if (fit) {
/* 2031 */       float aspect = aspectRatio(width, height, dheight);
/* 2032 */       if (width > pwidth) {
/* 2033 */         height = (int)(pwidth / aspect) + dheight;
/* 2034 */         if (height > pheight) {
/* 2035 */           width = (int)(aspect * (pheight - dheight));
/* 2036 */           height = pheight;
/*      */         } else {
/* 2038 */           width = pwidth; }
/* 2039 */         comp.setBounds(parent.getBounds().x, parent.getBounds().y, width, height);
/* 2040 */       } else if (height > pheight) {
/* 2041 */         width = (int)(aspect * (pheight - dheight));
/* 2042 */         height = pheight;
/* 2043 */         comp.setBounds(parent.getBounds().x, parent.getBounds().y, width, height);
/*      */       }
/*      */     }
/* 2046 */     comp.setLocation(pwidth / 2 - width / 2, pheight / 2 - height / 2);
/* 2047 */     comp.setSize(width, height);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addPopupMenu(Component visual)
/*      */   {
/* 2065 */     this.zoomMenu = new PopupMenu("Zoom");
/* 2066 */     ActionListener zoomSelect = new popupActionListener(null);
/* 2067 */     visual.add(this.zoomMenu);
/* 2068 */     MenuItem mi = new MenuItem("Scale 1:2");
/* 2069 */     this.zoomMenu.add(mi);
/* 2070 */     mi.addActionListener(zoomSelect);
/* 2071 */     mi = new MenuItem("Scale 1:1");
/* 2072 */     this.zoomMenu.add(mi);
/* 2073 */     mi.addActionListener(zoomSelect);
/* 2074 */     mi = new MenuItem("Scale 2:1");
/* 2075 */     this.zoomMenu.add(mi);
/* 2076 */     mi.addActionListener(zoomSelect);
/* 2077 */     mi = new MenuItem("Scale 4:1");
/* 2078 */     this.zoomMenu.add(mi);
/* 2079 */     mi.addActionListener(zoomSelect);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBounds(int x, int y, int w, int h)
/*      */   {
/* 2096 */     debug("setBounds " + x + " " + y + " " + w + " " + h + " ");
/* 2097 */     super.setBounds(x, y, w, h);
/* 2098 */     Dimension d = getSize();
/* 2099 */     int pheight = d.height;
/* 2100 */     int pwidth = d.width;
/* 2101 */     int p = 0;
/* 2102 */     int totalHeight = 0;
/*      */     
/* 2104 */     if ((this.urlName != null) && (isMediaLocationVisible())) {
/* 2105 */       totalHeight = this.urlFieldHeight = this.urlName.getPreferredSize().height;
/* 2106 */       if ((pheight < 5) && (this.displayURL == true)) {
/* 2107 */         pheight = 5;
/*      */       }
/*      */     }
/* 2110 */     if ((this.controlComponent != null) && (isControlPanelVisible())) {
/* 2111 */       this.controlPanelHeight = this.controlComponent.getPreferredSize().height;
/* 2112 */       totalHeight += this.controlPanelHeight;
/*      */       
/* 2114 */       if (d.width < 160)
/* 2115 */         d.width = 160;
/* 2116 */       if ((pheight < 2) && (this.visualComponent != null))
/*      */       {
/* 2118 */         pheight += 2;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2123 */     if (this.visualComponent != null) {
/* 2124 */       Dimension vSize = this.visualComponent.getPreferredSize();
/* 2125 */       if (this.fixedAspectRatio == true)
/*      */       {
/* 2127 */         if (pwidth / vSize.width >= (pheight - totalHeight) / (vSize.height - totalHeight))
/*      */         {
/*      */ 
/* 2130 */           this.curZoomValue = ((pheight - totalHeight) / (vSize.height - totalHeight));
/*      */         }
/*      */         else
/*      */         {
/* 2134 */           this.curZoomValue = (pwidth / vSize.width);
/*      */         }
/* 2136 */         if (this.curZoomValue < 1.0D)
/* 2137 */           this.curZoomValue = 1.0F;
/* 2138 */         zoomTo(this.curZoomValue);
/*      */       } else {
/* 2140 */         this.panel.setBounds(getBounds());
/*      */       }
/*      */     } else {
/* 2143 */       this.panel.setSize(getSize());
/* 2144 */       validate();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Dimension getPreferredSize()
/*      */   {
/* 2157 */     return new Dimension(this.preferredWidth, this.preferredHeight);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addPropertyChangeListener(PropertyChangeListener c)
/*      */   {
/* 2169 */     this.changes.addPropertyChangeListener(c);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removePropertyChangeListener(PropertyChangeListener c)
/*      */   {
/* 2181 */     this.changes.removePropertyChangeListener(c);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCodeBase(URL cb)
/*      */   {
/* 2191 */     this.mpCodeBase = cb;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private class visualComponentAdapter
/*      */     extends ComponentAdapter
/*      */   {
/*      */     private MediaPlayer thisBean;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public visualComponentAdapter(MediaPlayer b)
/*      */     {
/* 2209 */       this.thisBean = b;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void componentResized(ComponentEvent ce)
/*      */     {
/* 2220 */       if (ce.getSource() == this.thisBean) {
/* 2221 */         MediaPlayer.this.debug("componentResized");
/* 2222 */         int dheight = 0;
/* 2223 */         if ((MediaPlayer.this.controlComponent != null) && (MediaPlayer.this.isControlPanelVisible()))
/* 2224 */           dheight = MediaPlayer.this.controlComponent.getPreferredSize().height;
/* 2225 */         MediaPlayer.this.center(this.thisBean, MediaPlayer.this.panel, MediaPlayer.this.isFixedAspectRatio(), dheight);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private class visualMouseAdapter
/*      */     extends MouseAdapter
/*      */   {
/*      */     visualMouseAdapter(MediaPlayer.1 x1)
/*      */     {
/* 2237 */       this();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void mousePressed(MouseEvent me)
/*      */     {
/* 2247 */       if (me.isPopupTrigger()) {
/* 2248 */         MediaPlayer.this.zoomMenu.show(MediaPlayer.this.visualComponent, me.getX(), me.getY());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void mouseReleased(MouseEvent me)
/*      */     {
/* 2260 */       if (me.isPopupTrigger()) {
/* 2261 */         MediaPlayer.this.zoomMenu.show(MediaPlayer.this.visualComponent, me.getX(), me.getY());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void mouseClicked(MouseEvent me)
/*      */     {
/* 2273 */       if (me.isPopupTrigger()) {
/* 2274 */         MediaPlayer.this.zoomMenu.show(MediaPlayer.this.visualComponent, me.getX(), me.getY());
/*      */       }
/*      */     }
/*      */     
/*      */     private visualMouseAdapter() {}
/*      */   }
/*      */   
/*      */   private class popupActionListener
/*      */     implements ActionListener
/*      */   {
/*      */     popupActionListener(MediaPlayer.1 x1)
/*      */     {
/* 2286 */       this();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void actionPerformed(ActionEvent ae)
/*      */     {
/* 2296 */       String action = ae.getActionCommand();
/* 2297 */       MediaPlayer.this.setZoomTo(action);
/*      */     }
/*      */     
/*      */ 
/*      */     private popupActionListener() {}
/*      */   }
/*      */   
/*      */ 
/*      */   public void saveMediaTime()
/*      */   {
/* 2307 */     this.mediaTime = getMediaTime();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void restoreMediaTime()
/*      */   {
/* 2316 */     setMediaTime(this.mediaTime);
/*      */   }
/*      */   
/*      */   private void debug(String s) {}
/*      */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mediaplayer.jar!\javax\media\bean\playerbean\MediaPlayer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */