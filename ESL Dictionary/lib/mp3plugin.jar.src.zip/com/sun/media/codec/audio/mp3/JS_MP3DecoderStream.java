/*     */ package com.sun.media.codec.audio.mp3;
/*     */ 
/*     */ import codecLib.mp3.Decoder;
/*     */ import codecLib.mp3.FrameInfo;
/*     */ import codecLib.mp3.MPADException;
/*     */ import codecLib.mp3.OutputConverter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JS_MP3DecoderStream
/*     */   extends AudioInputStream
/*     */ {
/*  25 */   public static boolean DEBUG = false;
/*     */   
/*     */ 
/*  28 */   private byte[] pendingData = new byte['ᾠ'];
/*     */   
/*  30 */   private int pendingDataSize = 0;
/*     */   
/*  32 */   private int pendingDataOffset = 0;
/*  33 */   private boolean streamEOF = false;
/*     */   
/*  35 */   private Decoder decoder = null;
/*  36 */   private AudioFormat sourceFormat = null;
/*     */   
/*     */ 
/*  39 */   private float[][] fsamp = new float[12]['Ҁ'];
/*  40 */   private int[] fsampOffset = new int[12];
/*     */   
/*     */ 
/*     */   private static final int OUTSIZE = 9216;
/*     */   
/*  45 */   private byte[] outData = new byte['␀'];
/*     */   
/*  47 */   private int outFrameSize = 0;
/*     */   
/*  49 */   private int outDataOffset = 0;
/*     */   
/*     */ 
/*  52 */   private boolean outputBigEndian = false;
/*     */   
/*     */   static {
/*  55 */     if (DEBUG) { System.out.println("JS_MP3DecoderStream: DEBUG enabled");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   JS_MP3DecoderStream(AudioInputStream stream, AudioFormat format, long length)
/*     */   {
/*  63 */     super(stream, format, length);
/*  64 */     this.sourceFormat = stream.getFormat();
/*  65 */     this.outputBigEndian = getFormat().isBigEndian();
/*  66 */     open();
/*     */   }
/*     */   
/*     */   private synchronized void open()
/*     */   {
/*  71 */     if (this.decoder != null) {
/*  72 */       close();
/*     */     }
/*     */     
/*  75 */     this.decoder = new Decoder();
/*  76 */     this.pendingDataSize = 0;
/*  77 */     this.streamEOF = false;
/*  78 */     if (DEBUG) System.out.println("JS_MP3DecoderStream: input format:  " + this.sourceFormat);
/*  79 */     if (DEBUG) System.out.println("JS_MP3DecoderStream: output format: " + getFormat());
/*  80 */     this.outFrameSize = 0;
/*  81 */     this.outDataOffset = 0;
/*     */   }
/*     */   
/*     */   public synchronized void close() {
/*  85 */     if (this.decoder != null) {
/*  86 */       this.decoder = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void reset() throws IOException
/*     */   {
/*  92 */     super.reset();
/*  93 */     if (this.decoder != null) {
/*  94 */       close();
/*     */     }
/*  96 */     open();
/*     */   }
/*     */   
/*     */   public int read() throws IOException {
/* 100 */     throw new IOException("cannot read a single byte from stream");
/*     */   }
/*     */   
/*     */   public int read(byte[] b) throws IOException
/*     */   {
/* 105 */     return read(b, 0, b.length);
/*     */   }
/*     */   
/*     */   public synchronized int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 111 */     if (len % this.frameSize != 0) {
/* 112 */       len -= len % getFormat().getFrameSize();
/*     */     }
/*     */     
/* 115 */     int totalRead = 0;
/*     */     
/*     */ 
/*     */ 
/* 119 */     if (this.decoder == null) {
/* 120 */       return -1;
/*     */     }
/*     */     
/* 123 */     boolean endDecoding = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 129 */     while (totalRead < len)
/*     */     {
/* 131 */       int toCopyFromOutBuffer = len - totalRead;
/* 132 */       if (toCopyFromOutBuffer > this.outFrameSize - this.outDataOffset) {
/* 133 */         toCopyFromOutBuffer = this.outFrameSize - this.outDataOffset;
/*     */       }
/* 135 */       if (toCopyFromOutBuffer > 0) {
/* 136 */         System.arraycopy(this.outData, this.outDataOffset, b, off, toCopyFromOutBuffer);
/*     */         
/* 138 */         off += toCopyFromOutBuffer;
/* 139 */         this.outDataOffset += toCopyFromOutBuffer;
/* 140 */         totalRead += toCopyFromOutBuffer;
/*     */       } else {
/* 142 */         if (endDecoding)
/*     */           break;
/*     */       }
/* 145 */       if ((!endDecoding) && (totalRead < len)) {
/* 146 */         endDecoding = decodeNextFrame();
/*     */       }
/*     */     }
/*     */     
/* 150 */     if (totalRead > 0) {
/* 151 */       return totalRead;
/*     */     }
/* 153 */     if (endDecoding) {
/* 154 */       if (DEBUG) { System.out.println("Close.   outTotalSize=" + this.outFrameSize + "  outOffset=" + this.outDataOffset + "  remaining pendingData=" + this.pendingDataSize);
/*     */       }
/*     */       
/*     */ 
/* 158 */       close();
/* 159 */       return -1;
/*     */     }
/* 161 */     return totalRead;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean decodeNextFrame()
/*     */     throws IOException
/*     */   {
/* 169 */     boolean ERROR = false;
/*     */     
/* 171 */     boolean needRead = false;
/* 172 */     boolean skipFrame = false;
/* 173 */     FrameInfo info = new FrameInfo();
/*     */     do {
/* 175 */       if ((!this.streamEOF) && ((needRead) || (this.pendingDataSize < 2024)))
/*     */       {
/*     */ 
/*     */ 
/* 179 */         if ((this.pendingDataOffset > 0) && (this.pendingDataSize > 0)) {
/* 180 */           System.arraycopy(this.pendingData, this.pendingDataOffset, this.pendingData, 0, this.pendingDataSize);
/*     */         }
/*     */         
/*     */ 
/* 184 */         this.pendingDataOffset = 0;
/*     */         
/*     */ 
/* 187 */         while ((this.pendingDataSize + 20 < this.pendingData.length) && (!this.streamEOF)) {
/* 188 */           int read = super.read(this.pendingData, this.pendingDataSize, this.pendingData.length - this.pendingDataSize);
/*     */           
/* 190 */           if (read < 0) {
/* 191 */             this.streamEOF = true;
/*     */           } else {
/* 193 */             this.pendingDataSize += read;
/* 194 */             if (this.pendingDataSize < this.pendingData.length) {
/* 195 */               Thread.yield();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 200 */       if (skipFrame) {
/* 201 */         skipFrame = false;
/*     */         try
/*     */         {
/* 204 */           this.decoder.getCurrFrameInfo(info);
/*     */         } catch (MPADException e2) {
/*     */           try {
/* 207 */             this.decoder.getNextFrameInfo(info, this.pendingData, this.pendingDataOffset, this.pendingDataSize);
/*     */ 
/*     */           }
/*     */           catch (MPADException e3)
/*     */           {
/* 212 */             if (this.streamEOF)
/*     */             {
/* 214 */               this.pendingDataSize = 0;
/* 215 */               return true;
/*     */             }
/* 217 */             skipFrame = true;
/* 218 */             needRead = true;
/* 219 */             continue;
/*     */           }
/*     */         }
/*     */         
/* 223 */         int byteCount = info.getHeaderOffset() + info.getFrameLength();
/* 224 */         if (byteCount > this.pendingDataSize) {
/* 225 */           byteCount = this.pendingDataSize;
/*     */         }
/* 227 */         this.pendingDataOffset += byteCount;
/* 228 */         this.pendingDataSize -= byteCount;
/*     */         
/* 230 */         if (this.pendingDataSize < 0) { this.pendingDataSize = 0;
/*     */         }
/*     */       }
/* 233 */       if ((this.streamEOF) && (this.pendingDataSize <= 13))
/*     */       {
/* 235 */         return true;
/*     */       }
/*     */       try
/*     */       {
/* 239 */         boolean useDecodeLast = false;
/*     */         
/* 241 */         if ((this.streamEOF) && (this.pendingDataSize > 0))
/*     */         {
/* 243 */           this.decoder.getNextFrameInfo(info, this.pendingData, this.pendingDataOffset, this.pendingDataSize);
/*     */           
/*     */ 
/*     */ 
/* 247 */           useDecodeLast = info.getFrameLength() + info.getHeaderOffset() >= this.pendingDataSize;
/*     */         }
/*     */         int byteCount;
/*     */         int byteCount;
/* 251 */         if (useDecodeLast) {
/* 252 */           if (DEBUG) { System.out.println("Using DecodeLast");
/*     */           }
/* 254 */           byteCount = this.decoder.decodeLast(this.fsamp, this.fsampOffset, this.pendingData, this.pendingDataOffset, this.pendingDataSize);
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/* 263 */           byteCount = this.decoder.decode(this.fsamp, this.fsampOffset, this.pendingData, this.pendingDataOffset, this.pendingDataSize);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 268 */         this.decoder.getCurrFrameInfo(info);
/* 269 */         this.outFrameSize = (info.getNumberOfSamples() * info.getNumberOfChannels() * 2);
/*     */         
/*     */ 
/* 272 */         if (info.getNumberOfChannels() == 1) {
/* 273 */           if (this.outputBigEndian) {
/* 274 */             OutputConverter.convert(this.outData, 0, this.fsamp[0], this.fsampOffset[0], info.getNumberOfSamples());
/*     */           }
/*     */           else
/*     */           {
/* 278 */             convertLE(this.outData, 0, this.fsamp[0], this.fsampOffset[0], info.getNumberOfSamples());
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 283 */         else if (this.outputBigEndian) {
/* 284 */           OutputConverter.convert(this.outData, 0, this.fsamp[0], this.fsampOffset[0], this.fsamp[1], this.fsampOffset[1], info.getNumberOfSamples());
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 289 */           convertLE(this.outData, 0, this.fsamp[0], this.fsampOffset[0], this.fsamp[1], this.fsampOffset[1], info.getNumberOfSamples());
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 296 */         this.outDataOffset = 0;
/* 297 */         this.pendingDataOffset += byteCount;
/* 298 */         this.pendingDataSize -= byteCount;
/*     */         
/* 300 */         if (this.pendingDataSize < 0) this.pendingDataSize = 0;
/* 301 */         needRead = false;
/*     */       } catch (MPADException e) {
/* 303 */         if (e.getState() == -10) {
/* 304 */           if (DEBUG) System.out.println("JS_MP3DecoderStream: frame not supported.");
/* 305 */           skipFrame = true;
/*     */         }
/* 307 */         else if (e.getState() == -3) {
/* 308 */           if (!this.streamEOF)
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 325 */             if ((this.pendingDataOffset > 0) || (this.pendingDataSize < 13))
/*     */             {
/* 327 */               if (DEBUG) { System.out.println("JS_MP3DecoderStream: Low buffer -> need to read from input.");
/*     */               }
/* 329 */               needRead = true;
/*     */             } else {
/* 331 */               if (DEBUG) { System.out.println("JS_MP3DecoderStream: Low buffer  but enough input data available! -> skip this frame.");
/*     */               }
/*     */               
/* 334 */               skipFrame = true;
/*     */             }
/*     */           }
/*     */           else {
/* 338 */             if (DEBUG) { System.out.println("JS_MP3DecoderStream: Low buffer but EOF -> finish");
/*     */             }
/* 340 */             this.pendingDataSize = 0;
/* 341 */             break;
/*     */           }
/* 343 */         } else if (e.getState() == -9) {
/* 344 */           if (DEBUG) { System.out.println("JS_MP3DecoderStream: NO_PREV-> skip this frame");
/*     */           }
/* 346 */           skipFrame = true;
/*     */         }
/* 348 */         else if (e.getState() == -7) {
/* 349 */           if (DEBUG) { System.out.println("JS_MP3DecoderStream: no header found -> skip this frame");
/*     */           }
/* 351 */           skipFrame = true;
/*     */         }
/*     */         else
/*     */         {
/* 355 */           if (DEBUG) { System.out.println("JS_MP3DecoderStream: Unknown state: " + e.getState() + ". Skipping frame.");
/*     */           }
/* 357 */           skipFrame = true;
/*     */         }
/* 359 */       } catch (Exception e) { if (DEBUG) {
/* 360 */           System.out.println("Unexpected Exception! Advancing to next frame.");
/* 361 */           e.printStackTrace();
/*     */         }
/* 363 */         skipFrame = true;
/*     */       }
/*     */       
/* 366 */     } while ((needRead) || (skipFrame));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 371 */     return ((this.streamEOF) && (this.pendingDataSize <= 13)) || (ERROR);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void convertLE(byte[] out, int outoff, float[] in, int inoff, int number)
/*     */   {
/* 395 */     for (int i = 0; i < number; i++) {
/* 396 */       float xd = in[(inoff++)];
/* 397 */       int tmp = (int)xd;
/* 398 */       tmp = tmp <= 32768 ? 32768 : tmp >= 32767 ? 32767 : tmp;
/* 399 */       out[(outoff + i * 2)] = ((byte)tmp);
/* 400 */       out[(outoff + i * 2 + 1)] = ((byte)(tmp >> 8));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void convertLE(byte[] out, int outoff, float[] in1, int inoff1, float[] in2, int inoff2, int number)
/*     */   {
/* 429 */     for (int i = 0; i < number; i++) {
/* 430 */       float xd = in1[(inoff1++)];
/* 431 */       int tmp = (int)xd;
/* 432 */       tmp = tmp <= 32768 ? 32768 : tmp >= 32767 ? 32767 : tmp;
/* 433 */       out[(outoff + i * 4)] = ((byte)tmp);
/* 434 */       out[(outoff + i * 4 + 1)] = ((byte)(tmp >> 8));
/* 435 */       xd = in2[(inoff2++)];
/* 436 */       tmp = (int)xd;
/* 437 */       tmp = tmp <= 32768 ? 32768 : tmp >= 32767 ? 32767 : tmp;
/* 438 */       out[(outoff + i * 4 + 2)] = ((byte)tmp);
/* 439 */       out[(outoff + i * 4 + 3)] = ((byte)(tmp >> 8));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mp3plugin.jar!\com\sun\media\codec\audio\mp3\JS_MP3DecoderStream.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */