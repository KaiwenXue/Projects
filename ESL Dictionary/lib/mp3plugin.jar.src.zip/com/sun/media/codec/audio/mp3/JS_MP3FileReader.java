/*     */ package com.sun.media.codec.audio.mp3;
/*     */ 
/*     */ import codecLib.mp3.Decoder;
/*     */ import codecLib.mp3.FrameInfo;
/*     */ import codecLib.mp3.MPADException;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import javax.sound.sampled.AudioFileFormat;
/*     */ import javax.sound.sampled.AudioFileFormat.Type;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioFormat.Encoding;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.UnsupportedAudioFileException;
/*     */ import javax.sound.sampled.spi.AudioFileReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JS_MP3FileReader
/*     */   extends AudioFileReader
/*     */ {
/*  32 */   public static boolean DEBUG = false;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int MIN_HEADER_SIZE = 1024;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int MAX_HEADER_SIZE = 16384;
/*     */   
/*     */ 
/*  43 */   static final AudioFileFormat.Type MPEG = getType("MPEG", "mpeg");
/*  44 */   static final AudioFileFormat.Type MP3 = getType("MP3", "mp3");
/*     */   private static final String TFILETYPES_CLASS = "org.tritonus.share.sampled.AudioFileTypes";
/*     */   
/*  47 */   static { if (DEBUG) { System.out.println("JS_MP3FileReader: DEBUG enabled");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String TGETFILETYPE_METHOD = "getType";
/*     */   
/*     */ 
/*     */ 
/*     */   public AudioFileFormat getAudioFileFormat(InputStream stream)
/*     */     throws UnsupportedAudioFileException, IOException
/*     */   {
/*  62 */     return getAudioFileFormat(stream, true, 1024);
/*     */   }
/*     */   
/*     */ 
/*     */   public AudioFileFormat getAudioFileFormat(URL url)
/*     */     throws UnsupportedAudioFileException, IOException
/*     */   {
/*  69 */     AudioFileFormat fileFormat = null;
/*  70 */     InputStream urlStream = url.openStream();
/*     */     try {
/*  72 */       fileFormat = getAudioFileFormat(urlStream, false, 16384);
/*     */     } finally {
/*  74 */       urlStream.close();
/*     */     }
/*  76 */     return fileFormat;
/*     */   }
/*     */   
/*     */   public AudioFileFormat getAudioFileFormat(File file) throws UnsupportedAudioFileException, IOException
/*     */   {
/*  81 */     AudioFileFormat fileFormat = null;
/*  82 */     FileInputStream fis = new FileInputStream(file);
/*     */     try {
/*  84 */       fileFormat = getAudioFileFormat(fis, false, 16384);
/*     */     } finally {
/*  86 */       fis.close();
/*     */     }
/*  88 */     return fileFormat;
/*     */   }
/*     */   
/*     */   public AudioInputStream getAudioInputStream(InputStream stream) throws UnsupportedAudioFileException, IOException
/*     */   {
/*  93 */     return getAudioInputStream(stream, 1024);
/*     */   }
/*     */   
/*     */   public AudioInputStream getAudioInputStream(URL url) throws UnsupportedAudioFileException, IOException
/*     */   {
/*  98 */     InputStream urlStream = url.openStream();
/*  99 */     AudioInputStream result = null;
/*     */     try {
/* 101 */       BufferedInputStream bis = new BufferedInputStream(urlStream, 16384);
/* 102 */       result = getAudioInputStream(bis, 16384);
/*     */     } finally {
/* 104 */       if (result == null) {
/* 105 */         urlStream.close();
/*     */       }
/*     */     }
/* 108 */     return result;
/*     */   }
/*     */   
/*     */   public AudioInputStream getAudioInputStream(File file) throws UnsupportedAudioFileException, IOException
/*     */   {
/* 113 */     FileInputStream fis = new FileInputStream(file);
/* 114 */     AudioInputStream result = null;
/*     */     try {
/* 116 */       BufferedInputStream bis = new BufferedInputStream(fis, 16384);
/* 117 */       result = getAudioInputStream(bis, 16384);
/*     */     } finally {
/* 119 */       if (result == null) {
/* 120 */         fis.close();
/*     */       }
/*     */     }
/* 123 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private AudioInputStream getAudioInputStream(InputStream stream, int headerSize)
/*     */     throws UnsupportedAudioFileException, IOException
/*     */   {
/* 131 */     AudioFileFormat fileFormat = getAudioFileFormat(stream, true, headerSize);
/*     */     
/* 133 */     AudioFormat format = fileFormat.getFormat();
/*     */     
/*     */ 
/* 136 */     return new AudioInputStream(stream, format, fileFormat.getFrameLength());
/*     */   }
/*     */   
/*     */   private AFF getAudioFileFormat(InputStream stream, boolean doReset, int headerSize)
/*     */     throws UnsupportedAudioFileException, IOException
/*     */   {
/* 142 */     if (doReset) {
/* 143 */       stream.mark(headerSize);
/*     */     }
/*     */     
/* 146 */     boolean isMP3 = true;
/* 147 */     boolean hasID3 = false;
/* 148 */     boolean isWAVE = false;
/* 149 */     int dataOffset = 0;
/* 150 */     AudioFileFormat.Type fileType = null;
/*     */     
/* 152 */     FrameInfo info = new FrameInfo();
/* 153 */     Decoder decoder = new Decoder();
/*     */     
/* 155 */     byte[] data = new byte[headerSize - 1];
/* 156 */     int read = stream.read(data, 0, data.length);
/*     */     
/*     */ 
/* 159 */     int maxSyncSearch = 1000;
/*     */     
/*     */ 
/* 162 */     int magic = readLE32(data, 0);
/* 163 */     switch (magic) {
/*     */     case 1297239878: 
/* 165 */       if (DEBUG) System.out.println("JS_MP3FileReader: Detected AIFF file");
/* 166 */       isMP3 = false;
/* 167 */       break;
/*     */     
/*     */     case 1179011410: 
/* 170 */       if (DEBUG) System.out.println("JS_MP3FileReader: Detected RIFF file");
/* 171 */       isWAVE = true;
/* 172 */       dataOffset = isWAVE_MP3(data, read);
/* 173 */       isMP3 = dataOffset >= 0;
/* 174 */       maxSyncSearch = 100;
/* 175 */       fileType = AudioFileFormat.Type.WAVE;
/* 176 */       break;
/*     */     
/*     */     case 1684960046: 
/* 179 */       if (DEBUG) System.out.println("JS_MP3FileReader: Detected AU file");
/* 180 */       isMP3 = false;
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 185 */     if ((magic & 0xFFFFFF) == 3359817) {
/* 186 */       if (DEBUG) { System.out.println("JS_MP3FileReader: Detected ID3v2 header");
/*     */       }
/* 188 */       hasID3 = true;
/*     */       
/* 190 */       maxSyncSearch = read;
/*     */     }
/*     */     
/* 193 */     if (isMP3) {
/*     */       try {
/* 195 */         decoder.getNextFrameInfo(info, data, dataOffset, maxSyncSearch);
/*     */         
/*     */ 
/* 198 */         if ((!isWAVE) && (info.getHeaderOffset() > 0)) {
/* 199 */           int nextOffset = dataOffset + info.getHeaderOffset() + info.getFrameLength();
/* 200 */           int maxLength = nextOffset + 100 > read ? read - nextOffset : 100;
/* 201 */           if (maxLength > 0) {
/* 202 */             FrameInfo nextInfo = new FrameInfo();
/* 203 */             if (DEBUG) { System.out.println("JS_MP3FileReader: trying to find consecutive frame from offset " + nextOffset + " on. maxLength=" + maxLength);
/*     */             }
/*     */             
/* 206 */             decoder.getNextFrameInfo(nextInfo, data, nextOffset, maxLength);
/* 207 */             if (nextInfo.getHeaderOffset() != 0) {
/* 208 */               isMP3 = false;
/* 209 */               if (DEBUG) { System.out.println("JS_MP3FileReader: unable to find next consecutive frame. Probably not an mp3 file.");
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (MPADException e)
/*     */       {
/* 217 */         isMP3 = false;
/* 218 */         if (DEBUG) { System.out.println("JS_MP3FileReader: getNextFrameInfo threw Exception. state=" + e.getState());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 223 */     if (!isMP3)
/*     */     {
/* 225 */       if (doReset) {
/* 226 */         stream.reset();
/*     */       }
/* 228 */       throw new UnsupportedAudioFileException("not an MP3 file");
/*     */     }
/*     */     
/* 231 */     AFF fileFormat = new AFF(fileType, info);
/*     */     
/*     */ 
/* 234 */     if (doReset) {
/* 235 */       stream.reset();
/*     */       
/* 237 */       if (info.getHeaderOffset() + dataOffset > 0) {
/* 238 */         stream.skip(info.getHeaderOffset() + dataOffset);
/*     */       }
/*     */     }
/* 241 */     return fileFormat;
/*     */   }
/*     */   
/*     */ 
/*     */   private static AudioFileFormat.Type getFileTypeByInfo(FrameInfo info)
/*     */   {
/* 247 */     AudioFileFormat.Type type = MPEG;
/*     */     
/* 249 */     if ((info.getMpegId() == 1) && (info.getLayerId() == 3)) {
/* 250 */       type = MP3;
/*     */     }
/* 252 */     return type;
/*     */   }
/*     */   
/*     */   private static AudioFormat.Encoding getEncByInfo(FrameInfo info)
/*     */   {
/* 257 */     if (info.getMpegId() == 1) {
/* 258 */       switch (info.getLayerId()) {
/* 259 */       case 1:  return JS_MP3ConversionProvider.MPEG1L1;
/* 260 */       case 2:  return JS_MP3ConversionProvider.MPEG1L2;
/* 261 */       case 3:  return JS_MP3ConversionProvider.MPEG1L3;
/*     */       }
/* 263 */     } else if (info.getMpegId() == 2) {
/* 264 */       switch (info.getLayerId()) {
/* 265 */       case 1:  return JS_MP3ConversionProvider.MPEG2L1;
/* 266 */       case 2:  return JS_MP3ConversionProvider.MPEG2L2;
/* 267 */       case 3:  return JS_MP3ConversionProvider.MPEG2L3;
/*     */       }
/*     */     }
/* 270 */     throw new IllegalArgumentException("invalid frame: MPEG " + info.getMpegId() + ", layer " + info.getMpegId());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 276 */   private static Class tAudioFileTypes = null;
/* 277 */   private static Method tGetType = null;
/* 278 */   private static boolean triedTritonus = false;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int WAVE_FORMAT_MPEG = 80;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int WAVE_FORMAT_MPEGLAYER3 = 85;
/*     */   
/*     */ 
/*     */ 
/*     */   private static AudioFileFormat.Type getType(String name, String ext)
/*     */   {
/* 292 */     AudioFileFormat.Type ret = null;
/* 293 */     if ((!triedTritonus) || (tGetType != null)) {
/*     */       try
/*     */       {
/* 296 */         boolean firstTime = !triedTritonus;
/* 297 */         if (!triedTritonus) {
/* 298 */           triedTritonus = true;
/* 299 */           tAudioFileTypes = Class.forName("org.tritonus.share.sampled.AudioFileTypes");
/* 300 */           tGetType = tAudioFileTypes.getMethod("getType", new Class[] { String.class, String.class });
/*     */         }
/*     */         
/* 303 */         Object[] args = new Object[2];
/* 304 */         args[0] = name;
/* 305 */         args[1] = ext;
/* 306 */         ret = (AudioFileFormat.Type)tGetType.invoke(null, args);
/* 307 */         if ((DEBUG) && (firstTime)) { System.out.println("JS_MP3FileReader: Using Tritonus' AudioFileTypes class");
/*     */         }
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/* 313 */     if (ret == null) {
/* 314 */       ret = new AFFT(name, ext);
/*     */     }
/* 316 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int isWAVE_MP3(byte[] data, int len)
/*     */   {
/* 329 */     if (len < 40) return -1;
/* 330 */     int offset = 8;
/* 331 */     int waveMagic = readBE32(data, offset);offset += 4;
/*     */     
/* 333 */     if (waveMagic != 1463899717) {
/* 334 */       if (DEBUG) System.out.println("JS_MP3FileReader: RIFF, but not WAVE");
/* 335 */       return -1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 340 */     boolean found = false;
/* 341 */     int chunklen = 0;
/* 342 */     while (offset + 8 < len) {
/* 343 */       int fmt = readBE32(data, offset);offset += 4;
/* 344 */       chunklen = readLE32(data, offset);offset += 4;
/* 345 */       if (chunklen % 2 > 0) chunklen++;
/* 346 */       if (fmt == 1718449184)
/*     */       {
/* 348 */         found = true;
/* 349 */         break;
/*     */       }
/*     */       
/* 352 */       offset += chunklen;
/*     */     }
/*     */     
/* 355 */     if (!found) {
/* 356 */       if (DEBUG) System.out.println("JS_MP3FileReader: FMF_ chunk not found --> corrupt wave file");
/* 357 */       return -1;
/*     */     }
/*     */     
/* 360 */     int chunkStartOffset = offset;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 365 */     int wav_type = readLE16(data, offset);offset += 2;
/*     */     
/* 367 */     if ((wav_type != 80) && (wav_type != 85))
/*     */     {
/* 369 */       if (DEBUG) System.out.println("JS_MP3FileReader: WAVE, but not MP3 encoding");
/* 370 */       return -1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 376 */     offset += chunklen - (offset - chunkStartOffset);
/*     */     
/*     */ 
/*     */ 
/* 380 */     found = false;
/* 381 */     while (offset + 8 < len) {
/* 382 */       int datahdr = readBE32(data, offset);offset += 4;
/* 383 */       chunklen = readLE32(data, offset);offset += 4;
/* 384 */       if (chunklen % 2 > 0) chunklen++;
/* 385 */       if (datahdr == 1684108385)
/*     */       {
/* 387 */         found = true;
/* 388 */         break;
/*     */       }
/*     */       
/* 391 */       offset += chunklen;
/*     */     }
/*     */     
/* 394 */     if (!found) {
/* 395 */       if (DEBUG) System.out.println("JS_MP3FileReader: data chunk not found in WAVE file.");
/* 396 */       return -1;
/*     */     }
/* 398 */     if (DEBUG) { System.out.println("JS_MP3FileReader: Correctly parsed WAVE file. MP3 data starts at offset " + offset);
/*     */     }
/* 400 */     return offset;
/*     */   }
/*     */   
/*     */   private static int readLE32(byte[] data, int offset)
/*     */   {
/* 405 */     return data[offset] & 0xFF | (data[(offset + 1)] & 0xFF) << 8 | (data[(offset + 2)] & 0xFF) << 16 | (data[(offset + 3)] & 0xFF) << 24;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static int readBE32(byte[] data, int offset)
/*     */   {
/* 412 */     return data[(offset + 3)] & 0xFF | (data[(offset + 2)] & 0xFF) << 8 | (data[(offset + 1)] & 0xFF) << 16 | (data[offset] & 0xFF) << 24;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static int readLE16(byte[] data, int offset)
/*     */   {
/* 419 */     return data[offset] & 0xFF | (data[(offset + 1)] & 0xFF) << 8;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class AFFT
/*     */     extends AudioFileFormat.Type
/*     */   {
/*     */     public AFFT(String name, String ext)
/*     */     {
/* 436 */       super(ext);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class AFF
/*     */     extends AudioFileFormat
/*     */   {
/*     */     private FrameInfo frameInfo;
/*     */     
/*     */     public AFF(AudioFileFormat.Type afft, FrameInfo info)
/*     */     {
/* 448 */       super(new AudioFormat(JS_MP3FileReader.getEncByInfo(info), (float)info.getSamplingRate(), -1, info.getNumberOfChannels(), -1, -1.0F, false), -1);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 457 */       this.frameInfo = info;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mp3plugin.jar!\com\sun\media\codec\audio\mp3\JS_MP3FileReader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */