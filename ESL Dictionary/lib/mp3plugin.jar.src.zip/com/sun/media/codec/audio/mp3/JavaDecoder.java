/*     */ package com.sun.media.codec.audio.mp3;
/*     */ 
/*     */ import codecLib.mp3.Decoder;
/*     */ import codecLib.mp3.FrameInfo;
/*     */ import codecLib.mp3.MPADException;
/*     */ import codecLib.mp3.OutputConverter;
/*     */ import com.sun.media.codec.audio.AudioCodec;
/*     */ import java.io.PrintStream;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Codec;
/*     */ import javax.media.Format;
/*     */ import javax.media.PlugInManager;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaDecoder
/*     */   extends AudioCodec
/*     */ {
/*  34 */   private int pendingDataSize = 0;
/*     */   private static final int OUTSIZE = 32768;
/*  36 */   private byte[] pendingData = new byte[32768];
/*  37 */   private Decoder decoder = null;
/*  38 */   private FrameInfo info = null;
/*  39 */   private boolean expectingSameInputBuffer = false;
/*  40 */   private long accumTS = 0L;
/*  41 */   private AudioFormat aFormat = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JavaDecoder()
/*     */   {
/*  50 */     this.inputFormats = new Format[] { new AudioFormat("mpeglayer3", 16000.0D, -1, -1, -1, 1), new AudioFormat("mpeglayer3", 22050.0D, -1, -1, -1, 1), new AudioFormat("mpeglayer3", 24000.0D, -1, -1, -1, 1), new AudioFormat("mpeglayer3", 32000.0D, -1, -1, -1, 1), new AudioFormat("mpeglayer3", 44100.0D, -1, -1, -1, 1), new AudioFormat("mpeglayer3", 48000.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 16000.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 22050.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 24000.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 32000.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 44100.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 48000.0D, -1, -1, -1, 1) };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 136 */     return "MPEG Layer 3 Decoder";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Format[] getSupportedOutputFormats(Format input)
/*     */   {
/* 150 */     if (input == null) {
/* 151 */       return new Format[] { new AudioFormat("LINEAR") };
/*     */     }
/*     */     
/* 154 */     if ((input instanceof AudioFormat)) {
/* 155 */       AudioFormat af = (AudioFormat)input;
/* 156 */       this.outputFormats = new Format[] { new AudioFormat("LINEAR", af.getSampleRate(), af.getSampleSizeInBits(), af.getChannels(), 1, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */       this.outputFormats = new Format[0];
/*     */     }
/* 170 */     return this.outputFormats;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void open()
/*     */     throws ResourceUnavailableException
/*     */   {
/* 182 */     if (this.decoder != null) {
/* 183 */       close();
/*     */     }
/*     */     try
/*     */     {
/* 187 */       this.decoder = new Decoder();
/* 188 */       this.pendingDataSize = 0;
/* 189 */       this.expectingSameInputBuffer = false;
/* 190 */       this.accumTS = 0L;
/* 191 */       this.aFormat = ((AudioFormat)this.outputFormat);
/*     */       
/*     */ 
/* 194 */       return;
/*     */     } catch (Throwable e) {
/* 196 */       System.out.println("mpa JavaDecoder: open " + e);
/*     */       
/*     */ 
/* 199 */       throw new ResourceUnavailableException("could not open " + getName());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/* 209 */     if (this.decoder != null) {
/* 210 */       this.decoder = null;
/*     */     }
/* 212 */     if (this.info != null) {
/* 213 */       this.info = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void reset()
/*     */   {
/* 224 */     if (this.decoder != null) {
/* 225 */       close();
/*     */       try
/*     */       {
/* 228 */         open();
/*     */       } catch (ResourceUnavailableException rue) {
/* 230 */         System.err.println("MP3 Decoder: " + rue);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 235 */   float[][] fsamp = new float[12]['Ҁ'];
/*     */   
/* 237 */   int[] fsampOffset = new int[12];
/* 238 */   int MAXOUTFRAMESIZE = 27648;
/*     */   
/*     */ 
/* 241 */   int MIMINFRAMESIZE = 13;
/* 242 */   int outFrameSize = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized int process(Buffer in, Buffer out)
/*     */   {
/* 256 */     if (isEOM(in)) {
/* 257 */       propagateEOM(out);
/* 258 */       return 0;
/*     */     }
/*     */     
/* 261 */     Object inObject = in.getData();
/* 262 */     Object outObject = out.getData();
/*     */     
/* 264 */     if (outObject == null) {
/* 265 */       outObject = new byte[32768];
/* 266 */       out.setData(outObject);
/*     */     }
/*     */     
/* 269 */     if ((!(inObject instanceof byte[])) || (!(outObject instanceof byte[])))
/*     */     {
/* 271 */       return 1;
/*     */     }
/*     */     
/* 274 */     byte[] inData = (byte[])inObject;
/* 275 */     byte[] outData = (byte[])outObject;
/* 276 */     int inLength = in.getLength();
/* 277 */     int inOffset = in.getOffset();
/* 278 */     int outDataSize = outData.length;
/* 279 */     int outOffset = 0;
/* 280 */     int pendingDataOffset = 0;
/* 281 */     int byteCount = 0;
/*     */     
/* 283 */     if ((!this.expectingSameInputBuffer) && 
/* 284 */       (this.pendingDataSize + inLength <= this.pendingData.length)) {
/* 285 */       System.arraycopy(inData, inOffset, this.pendingData, this.pendingDataSize, inLength);
/*     */       
/*     */ 
/* 288 */       this.pendingDataSize += inLength;
/*     */     }
/*     */     
/*     */ 
/* 292 */     if (this.decoder != null)
/*     */     {
/*     */ 
/*     */ 
/* 296 */       while (outDataSize - outOffset >= this.MAXOUTFRAMESIZE)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 301 */         if (this.pendingDataSize < this.MIMINFRAMESIZE) {
/*     */           break;
/*     */         }
/*     */         
/* 305 */         if (this.info == null) {
/* 306 */           this.info = new FrameInfo();
/*     */           try {
/* 308 */             this.decoder.getNextFrameInfo(this.info, this.pendingData, pendingDataOffset, this.pendingDataSize);
/*     */             
/*     */ 
/*     */ 
/* 312 */             this.outFrameSize = (this.info.getNumberOfSamples() * this.info.getNumberOfChannels() * 2);
/*     */ 
/*     */           }
/*     */           catch (MPADException e)
/*     */           {
/* 317 */             this.info = null;
/* 318 */             break;
/*     */           }
/*     */         }
/*     */         try
/*     */         {
/* 323 */           byteCount = this.decoder.decode(this.fsamp, this.fsampOffset, this.pendingData, pendingDataOffset, this.pendingDataSize);
/*     */ 
/*     */         }
/*     */         catch (MPADException e)
/*     */         {
/*     */ 
/* 329 */           if (e.getState() == -10) {
/* 330 */             return 1;
/*     */           }
/*     */           try {
/* 333 */             this.decoder.getCurrFrameInfo(this.info);
/*     */           }
/*     */           catch (MPADException e2) {
/* 336 */             this.info = null;
/* 337 */             break;
/*     */           }
/*     */           
/* 340 */           if (e.getState() == -9) {
/* 341 */             byteCount = this.info.getHeaderOffset() + this.info.getFrameLength();
/* 342 */             pendingDataOffset += byteCount;
/* 343 */             this.pendingDataSize -= byteCount;
/* 344 */             continue;
/*     */           }
/*     */           
/*     */ 
/* 348 */           this.info = null;
/* 349 */           break;
/*     */         }
/*     */         
/* 352 */         if (this.info.getNumberOfChannels() == 1) {
/* 353 */           OutputConverter.convert(outData, outOffset, this.fsamp[0], this.fsampOffset[0], this.info.getNumberOfSamples());
/*     */         }
/*     */         else
/*     */         {
/* 357 */           OutputConverter.convert(outData, outOffset, this.fsamp[0], this.fsampOffset[0], this.fsamp[1], this.fsampOffset[1], this.info.getNumberOfSamples());
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 363 */         outOffset += this.outFrameSize;
/* 364 */         pendingDataOffset += byteCount;
/* 365 */         this.pendingDataSize -= byteCount;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 370 */     if (pendingDataOffset != 0) {
/* 371 */       System.arraycopy(this.pendingData, pendingDataOffset, this.pendingData, 0, this.pendingDataSize);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 376 */     out.setLength(outOffset);
/* 377 */     out.setFormat(this.outputFormat);
/* 378 */     if ((this.aFormat != null) && (this.accumTS != 0L) && (in.getTimeStamp() > 0L)) {
/* 379 */       out.setTimeStamp(in.getTimeStamp() + this.aFormat.computeDuration(this.accumTS));
/*     */     }
/*     */     
/* 382 */     if (this.pendingDataSize > 1024) {
/* 383 */       this.expectingSameInputBuffer = true;
/* 384 */       this.accumTS += out.getLength();
/* 385 */       return 2;
/*     */     }
/* 387 */     this.accumTS = 0L;
/* 388 */     this.expectingSameInputBuffer = false;
/* 389 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 401 */       Codec c = new JavaDecoder();
/* 402 */       Format[] inputs = c.getSupportedInputFormats();
/* 403 */       Format[] outputs = c.getSupportedOutputFormats(null);
/* 404 */       PlugInManager.addPlugIn("com.sun.media.codec.audio.mp3.JavaDecoder", inputs, outputs, 2);
/*     */       
/* 406 */       PlugInManager.commit();
/* 407 */       System.out.println("Registered succesfully");
/*     */     } catch (Throwable t) {
/* 409 */       System.err.println("Error: Could not register plugin. \nCheck if jmf.properties is in the CLASSPATH and is writable.");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mp3plugin.jar!\com\sun\media\codec\audio\mp3\JavaDecoder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */