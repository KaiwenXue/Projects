/*     */ package com.sun.media.codec.audio.mp3;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioFormat.Encoding;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.spi.FormatConversionProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JS_MP3ConversionProvider
/*     */   extends FormatConversionProvider
/*     */ {
/*  28 */   public static boolean DEBUG = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  34 */   static final AudioFormat.Encoding MPEG1L1 = getEncoding("MPEG1L1");
/*  35 */   static final AudioFormat.Encoding MPEG1L2 = getEncoding("MPEG1L2");
/*  36 */   static final AudioFormat.Encoding MPEG1L3 = getEncoding("MPEG1L3");
/*  37 */   static final AudioFormat.Encoding MPEG2L1 = getEncoding("MPEG2L1");
/*  38 */   static final AudioFormat.Encoding MPEG2L2 = getEncoding("MPEG2L2");
/*  39 */   static final AudioFormat.Encoding MPEG2L3 = getEncoding("MPEG2L3");
/*     */   
/*     */ 
/*  42 */   static final AudioFormat.Encoding MP3 = getEncoding("MP3");
/*     */   
/*  44 */   static final AudioFormat.Encoding SIGNED = AudioFormat.Encoding.PCM_SIGNED;
/*     */   
/*  46 */   private static final AudioFormat.Encoding[] sourceEncodings = { MPEG1L1, MPEG1L2, MPEG1L3, MP3, MPEG2L1, MPEG2L2, MPEG2L3 };
/*     */   
/*  48 */   private static final AudioFormat.Encoding[] targetEncodings = { SIGNED };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int MAX_CHANNELS = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  59 */   private static final int[] SAMPLE_SIZE_IN_BITS = { 16 };
/*     */   
/*     */ 
/*  62 */   private static final float[] SAMPLE_RATES = { 16000.0F, 22050.0F, 24000.0F, 32000.0F, 44100.0F, 48000.0F };
/*     */   
/*     */ 
/*  65 */   private static AudioFormat[] targetFormats = null;
/*     */   private static final String TENCODINGS_CLASS = "org.tritonus.share.sampled.Encodings";
/*     */   private static final String TGETENCODING_METHOD = "getEncoding";
/*     */   
/*     */   static {
/*  70 */     if (DEBUG) System.out.println("JS_MP3ConversionProvider: DEBUG enabled");
/*  71 */     if (targetFormats == null) {
/*  72 */       targetFormats = new AudioFormat[SAMPLE_RATES.length * SAMPLE_SIZE_IN_BITS.length * 2 * 2];
/*     */       
/*     */ 
/*     */ 
/*  76 */       int index = 0;
/*  77 */       for (int sr = 0; sr < SAMPLE_RATES.length; sr++) {
/*  78 */         for (int b = 0; b < SAMPLE_SIZE_IN_BITS.length; b++) {
/*  79 */           for (int c = 0; c < 2; c++)
/*     */           {
/*  81 */             int bits = SAMPLE_SIZE_IN_BITS[b];
/*  82 */             targetFormats[(index++)] = new AudioFormat(SAMPLE_RATES[sr], bits, c + 1, bits > 8, false);
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*  87 */             targetFormats[(index++)] = new AudioFormat(SAMPLE_RATES[sr], bits, c + 1, bits > 8, true);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioFormat.Encoding[] getSourceEncodings()
/*     */   {
/* 108 */     return sourceEncodings;
/*     */   }
/*     */   
/*     */   public AudioFormat.Encoding[] getTargetEncodings() {
/* 112 */     return targetEncodings;
/*     */   }
/*     */   
/*     */   public AudioFormat.Encoding[] getTargetEncodings(AudioFormat sourceFormat) {
/* 116 */     if (getTargetFormats(sourceFormat, true) == null) {
/* 117 */       return new AudioFormat.Encoding[0];
/*     */     }
/* 119 */     return getTargetEncodings();
/*     */   }
/*     */   
/*     */ 
/*     */   public AudioFormat[] getTargetFormats(AudioFormat.Encoding targetEncoding, AudioFormat sourceFormat)
/*     */   {
/* 125 */     if (!encodingEquals(targetEncoding, SIGNED)) {
/* 126 */       return new AudioFormat[0];
/*     */     }
/* 128 */     return getTargetFormats(sourceFormat, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AudioInputStream getAudioInputStream(AudioFormat.Encoding targetEncoding, AudioInputStream sourceStream)
/*     */   {
/* 135 */     AudioFormat targetFormat = new AudioFormat(targetEncoding, -1.0F, -1, -1, -1, -1.0F, true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */     return getAudioInputStream(targetFormat, sourceStream);
/*     */   }
/*     */   
/*     */   public AudioInputStream getAudioInputStream(AudioFormat targetFormat, AudioInputStream sourceStream)
/*     */   {
/* 148 */     AudioFormat sourceFormat = sourceStream.getFormat();
/*     */     
/* 150 */     if ((sourceFormat.getSampleRate() > 0.0F) && (sourceFormat.getChannels() > 0))
/*     */     {
/*     */ 
/* 153 */       AudioFormat[] targetFormats = getTargetFormats(sourceFormat, false);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 158 */       for (int i = 0; i < targetFormats.length; i++) {
/* 159 */         if (audioFormatMatches(targetFormat, targetFormats[i])) {
/* 160 */           return new JS_MP3DecoderStream(sourceStream, targetFormats[i], -1L);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 166 */     throw new IllegalArgumentException("conversion not supported");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private AudioFormat[] getTargetFormats(AudioFormat sourceFormat, boolean testOnly)
/*     */   {
/* 173 */     int count = 0;
/*     */     
/*     */ 
/* 176 */     for (int e = 0; e < sourceEncodings.length; e++) {
/* 177 */       count += (encodingEquals(sourceFormat.getEncoding(), sourceEncodings[e]) ? 1 : 0);
/*     */     }
/*     */     
/* 180 */     float sampleRate = sourceFormat.getSampleRate();
/* 181 */     boolean allSampleRates = floatEquals(sampleRate, -1.0F);
/* 182 */     if (count > 0)
/*     */     {
/*     */ 
/* 185 */       if (allSampleRates)
/*     */       {
/* 187 */         count *= SAMPLE_RATES.length;
/*     */       } else {
/* 189 */         boolean srMatches = false;
/* 190 */         for (int sr = 0; sr < SAMPLE_RATES.length; sr++) {
/* 191 */           if (floatEquals(SAMPLE_RATES[sr], sampleRate)) {
/* 192 */             srMatches = true;
/* 193 */             break;
/*     */           }
/*     */         }
/* 196 */         if (!srMatches)
/*     */         {
/* 198 */           count = 0;
/*     */         }
/*     */       }
/*     */     }
/* 202 */     int channels = sourceFormat.getChannels();
/* 203 */     boolean allChannels = channels == -1;
/* 204 */     if (count > 0)
/*     */     {
/* 206 */       if (allChannels)
/*     */       {
/* 208 */         count *= 2;
/*     */       }
/* 210 */       else if ((channels < 1) || (channels > 2))
/*     */       {
/* 212 */         count = 0;
/*     */       }
/*     */     }
/*     */     
/* 216 */     int bits = sourceFormat.getSampleSizeInBits();
/* 217 */     boolean allBits = bits == -1;
/* 218 */     if (count > 0)
/*     */     {
/* 220 */       if (allBits)
/*     */       {
/* 222 */         count *= SAMPLE_SIZE_IN_BITS.length;
/*     */       } else {
/* 224 */         boolean bitsSupported = false;
/* 225 */         for (int b = 0; b < SAMPLE_SIZE_IN_BITS.length; b++) {
/* 226 */           if (bits == SAMPLE_SIZE_IN_BITS[b]) {
/* 227 */             bitsSupported = true;
/* 228 */             break;
/*     */           }
/*     */         }
/* 231 */         if (!bitsSupported)
/*     */         {
/* 233 */           count = 0;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 239 */     if (testOnly)
/*     */     {
/* 241 */       if (count == 0) {
/* 242 */         return null;
/*     */       }
/*     */       
/*     */ 
/* 246 */       return new AudioFormat[0];
/*     */     }
/*     */     
/*     */ 
/* 250 */     count *= 2;
/*     */     
/*     */ 
/* 253 */     AudioFormat[] ret = new AudioFormat[count];
/* 254 */     if (count == 0) {
/* 255 */       return ret;
/*     */     }
/*     */     
/*     */ 
/* 259 */     if ((count == 2) && (!allSampleRates) && (!allChannels) && (!allBits)) {
/* 260 */       ret[0] = new AudioFormat(sampleRate, bits, channels, bits > 8, false);
/*     */       
/* 262 */       ret[1] = new AudioFormat(sampleRate, bits, channels, bits > 8, true);
/*     */       
/* 264 */       return ret;
/*     */     }
/*     */     
/*     */ 
/* 268 */     int index = 0;
/* 269 */     for (int f = 0; f < targetFormats.length; f++) {
/* 270 */       AudioFormat format = targetFormats[f];
/* 271 */       if (((allSampleRates) || (floatEquals(sampleRate, format.getSampleRate()))) && ((allChannels) || (channels == format.getChannels())) && ((allBits) || (bits == format.getSampleSizeInBits())))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 277 */         ret[(index++)] = format;
/*     */       }
/*     */     }
/* 280 */     if ((DEBUG) && 
/* 281 */       (index != count)) {
/* 282 */       System.out.println("JS_MP3ConversionProvider: inconsistency ERROR: did not fill all audio formats!");
/*     */     }
/*     */     
/*     */ 
/* 286 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean encodingEquals(AudioFormat.Encoding enc1, AudioFormat.Encoding enc2)
/*     */   {
/* 298 */     return (enc1 == enc2) || ((enc1 != null) && (enc2 != null) && (enc1.toString().equals(enc2.toString())));
/*     */   }
/*     */   
/*     */   private static boolean floatEquals(float f1, float f2)
/*     */   {
/* 303 */     return Math.abs(f1 - f2) < 1.0E-9F;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean audioFormatMatches(AudioFormat f1, AudioFormat f2)
/*     */   {
/* 312 */     return (encodingEquals(f1.getEncoding(), f2.getEncoding())) && ((floatEquals(f1.getSampleRate(), f2.getSampleRate())) || (floatEquals(f1.getSampleRate(), -1.0F)) || (floatEquals(f2.getSampleRate(), -1.0F))) && ((floatEquals(f1.getFrameRate(), f2.getFrameRate())) || (floatEquals(f1.getFrameRate(), -1.0F)) || (floatEquals(f2.getFrameRate(), -1.0F))) && ((f1.getChannels() == f2.getChannels()) || (f1.getChannels() == -1) || (f2.getChannels() == -1)) && ((f1.getSampleSizeInBits() == f2.getSampleSizeInBits()) || (f1.getSampleSizeInBits() == -1) || (f2.getSampleSizeInBits() == -1)) && ((f1.getFrameSize() == f2.getFrameSize()) || (f1.getFrameSize() == -1) || (f2.getFrameSize() == -1)) && ((f1.getChannels() <= 8) || (f2.getChannels() <= 8) || (f1.isBigEndian() == f2.isBigEndian()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 342 */   private static Class tEncodings = null;
/* 343 */   private static Method tGetEncoding = null;
/* 344 */   private static boolean triedTritonus = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static AudioFormat.Encoding getEncoding(String name)
/*     */   {
/* 355 */     AudioFormat.Encoding ret = null;
/* 356 */     if ((!triedTritonus) || (tGetEncoding != null)) {
/*     */       try
/*     */       {
/* 359 */         boolean firstTime = !triedTritonus;
/* 360 */         if (!triedTritonus) {
/* 361 */           triedTritonus = true;
/* 362 */           tEncodings = Class.forName("org.tritonus.share.sampled.Encodings");
/* 363 */           tGetEncoding = tEncodings.getMethod("getEncoding", new Class[] { String.class });
/*     */         }
/*     */         
/* 366 */         Object[] args = new Object[1];
/* 367 */         args[0] = name;
/* 368 */         ret = (AudioFormat.Encoding)tGetEncoding.invoke(null, args);
/* 369 */         if ((DEBUG) && (firstTime)) { System.out.println("JS_MP3ConversionProvider: Using Tritonus' Encodings class");
/*     */         }
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/* 375 */     if (ret == null) {
/* 376 */       ret = new AFE(name);
/*     */     }
/* 378 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class AFE
/*     */     extends AudioFormat.Encoding
/*     */   {
/*     */     public AFE(String name)
/*     */     {
/* 394 */       super();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mp3plugin.jar!\com\sun\media\codec\audio\mp3\JS_MP3ConversionProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */