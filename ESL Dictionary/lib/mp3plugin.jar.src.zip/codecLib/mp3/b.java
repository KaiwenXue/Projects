package codecLib.mp3;

class b
{
  private int jdField_int;
  private int jdField_for;
  private byte[] jdField_do;
  private int jdField_if;
  private int jdField_new;
  private int a;
  
  byte[] jdMethod_else()
  {
    return this.jdField_do;
  }
  
  int jdMethod_char()
  {
    return this.jdField_new;
  }
  
  int jdMethod_try()
  {
    return this.a;
  }
  
  void jdMethod_do(int paramInt)
  {
    this.jdField_for -= paramInt;
    this.jdField_int <<= paramInt;
    if (this.jdField_for <= 16)
    {
      this.jdField_int |= (this.jdField_do[(this.jdField_if++)] & 0xFF) << 24 - this.jdField_for;
      this.jdField_int |= (this.jdField_do[(this.jdField_if++)] & 0xFF) << 16 - this.jdField_for;
      this.jdField_for += 16;
    }
  }
  
  void jdMethod_case()
  {
    this.jdField_int = (((this.jdField_do[(this.jdField_if - 4)] & 0xFF) << 24 | (this.jdField_do[(this.jdField_if - 3)] & 0xFF) << 16 | (this.jdField_do[(this.jdField_if - 2)] & 0xFF) << 8 | this.jdField_do[(this.jdField_if - 1)] & 0xFF) << 32 - this.jdField_for);
  }
  
  int jdMethod_for(int paramInt)
  {
    return this.jdField_int >>> 32 - paramInt;
  }
  
  void jdMethod_int()
  {
    jdMethod_do(this.jdField_for & 0x7);
  }
  
  int jdMethod_if()
  {
    return (this.jdField_if - this.jdField_new << 3) - this.jdField_for;
  }
  
  int jdMethod_goto()
  {
    return (this.a - this.jdField_if << 3) + this.jdField_for;
  }
  
  int jdMethod_byte()
  {
    return this.jdField_if - (this.jdField_for >> 3);
  }
  
  int jdMethod_for()
  {
    return this.jdField_if - (this.jdField_for + 7 >> 3);
  }
  
  int jdMethod_new()
  {
    return 32 - this.jdField_for & 0x7;
  }
  
  void a(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.jdField_do = paramArrayOfByte;
    this.jdField_if = paramInt1;
    this.jdField_new = paramInt1;
    this.a = (paramInt1 + paramInt2);
    this.jdField_for = 0;
    this.jdField_int = 0;
    jdMethod_do(0);
    jdMethod_do(0);
  }
  
  int jdMethod_if(int paramInt)
  {
    int i = this.jdField_int >>> 32 - paramInt;
    this.jdField_for -= paramInt;
    this.jdField_int <<= paramInt;
    if (this.jdField_for <= 16)
    {
      this.jdField_int |= (this.jdField_do[(this.jdField_if++)] & 0xFF) << 24 - this.jdField_for;
      this.jdField_int |= (this.jdField_do[(this.jdField_if++)] & 0xFF) << 16 - this.jdField_for;
      this.jdField_for += 16;
    }
    return i;
  }
  
  static void a(b paramb1, b paramb2)
  {
    paramb1.jdField_int = paramb2.jdField_int;
    paramb1.jdField_for = paramb2.jdField_for;
    paramb1.jdField_do = paramb2.jdField_do;
    paramb1.jdField_if = paramb2.jdField_if;
    paramb1.jdField_new = paramb2.jdField_new;
    paramb1.a = paramb2.a;
  }
  
  int jdMethod_do()
  {
    int i = this.jdField_int;
    this.jdField_for -= 1;
    this.jdField_int <<= 1;
    if (this.jdField_for <= 16)
    {
      this.jdField_int |= (this.jdField_do[(this.jdField_if++)] & 0xFF) << 24 - this.jdField_for;
      this.jdField_int |= (this.jdField_do[(this.jdField_if++)] & 0xFF) << 16 - this.jdField_for;
      this.jdField_for += 16;
    }
    return i;
  }
  
  int a()
  {
    int i = this.jdField_int;
    this.jdField_int <<= 16;
    this.jdField_int |= (this.jdField_do[(this.jdField_if++)] & 0xFF) << 40 - this.jdField_for;
    this.jdField_int |= (this.jdField_do[(this.jdField_if++)] & 0xFF) << 32 - this.jdField_for;
    return i;
  }
  
  void a(int paramInt)
  {
    paramInt += 32 - this.jdField_for;
    this.jdField_if -= 4;
    this.jdField_if += (paramInt >> 3);
    paramInt &= 0x7;
    this.jdField_for = 0;
    this.jdField_int = 0;
    jdMethod_do(0);
    jdMethod_do(paramInt);
  }
  
  static void a(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if (paramInt5 <= 0) {
      return;
    }
    int k = paramInt5;
    paramInt1 += (paramInt3 >> 3);
    paramInt2 += (paramInt4 >> 3);
    int m = paramInt3 & 0x7;
    int n = paramInt4 & 0x7;
    if (m != 0)
    {
      int i = (paramArrayOfByte2[paramInt2] & 0xFF) << n | (paramArrayOfByte2[(paramInt2 + 1)] & 0xFF) >> 8 - n;
      i = (i & 0xFF) >> m | (paramArrayOfByte1[paramInt1] & 0xFF) >> 8 - m << 8 - m;
      paramArrayOfByte1[paramInt1] = ((byte)i);
      k -= 8 - m;
      paramInt1++;
      if (n < m)
      {
        n += 8 - m;
      }
      else
      {
        n = n + (8 - m) & 0x7;
        paramInt2++;
      }
    }
    int j;
    if (n == 0) {
      for (j = 0; j <= k >> 3; j++) {
        paramArrayOfByte1[(paramInt1 + j)] = paramArrayOfByte2[(paramInt2 + j)];
      }
    } else {
      for (j = 0; j <= k >> 3; j++) {
        paramArrayOfByte1[(paramInt1 + j)] = ((byte)((paramArrayOfByte2[(paramInt2 + j)] & 0xFF) << n | (paramArrayOfByte2[(paramInt2 + j + 1)] & 0xFF) >> 8 - n));
      }
    }
  }
  
  void a(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    int i;
    if (paramInt2 == 0) {
      for (i = 0; i < paramInt3; i++) {
        paramArrayOfByte[(paramInt1 + i)] = 0;
      }
    } else {
      for (i = 0; i < paramInt3; i++) {
        paramArrayOfByte[(paramInt1 + i)] = ((byte)jdMethod_if(paramInt2));
      }
    }
  }
  
  void a(short[] paramArrayOfShort, int paramInt1, int paramInt2, int paramInt3)
  {
    int i;
    if (paramInt2 == 0) {
      for (i = 0; i < paramInt3; i++) {
        paramArrayOfShort[(paramInt1 + i)] = 0;
      }
    } else {
      for (i = 0; i < paramInt3; i++) {
        paramArrayOfShort[(paramInt1 + i)] = ((short)jdMethod_if(paramInt2));
      }
    }
  }
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mp3plugin.jar!\codecLib\mp3\b.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */