package codecLib.mp3;

class k
  extends o
  implements Constants
{
  private byte[] M = new byte['ߠ'];
  private int L;
  private static final int[] P = { 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768 };
  private static final float[] N = { 0.0F, -1.0F, -3.0F, -7.0F, -15.0F, -31.0F, -63.0F, -127.0F, -255.0F, -511.0F, -1023.0F, -2047.0F, -4095.0F, -8191.0F, -16383.0F };
  private static final float[] O = { 0.0F, 0.6666667F, 0.2857143F, 0.13333334F, 0.06451613F, 0.031746034F, 0.015748031F, 0.007843138F, 0.0039138943F, 0.0019550342F, 9.770396E-4F, 4.884005E-4F, 2.4417043E-4F, 1.2207776E-4F, 6.103702E-5F };
  
  k(m paramm, c paramc)
  {
    super(paramm, paramc);
  }
  
  private void a(byte[][] paramArrayOfByte1, byte[][] paramArrayOfByte2, int paramInt1, int paramInt2, float[][] paramArrayOfFloat)
  {
    byte[] arrayOfByte1 = paramArrayOfByte1[0];
    byte[] arrayOfByte2 = paramArrayOfByte1[1];
    byte[] arrayOfByte3 = paramArrayOfByte2[0];
    byte[] arrayOfByte4 = paramArrayOfByte2[1];
    float[] arrayOfFloat1 = paramArrayOfFloat[0];
    float[] arrayOfFloat2 = paramArrayOfFloat[1];
    int i;
    int m;
    int k;
    float f;
    for (int j = 0; j < paramInt2; j++)
    {
      if (0 != (i = arrayOfByte1[j]))
      {
        m = P[i];
        k = this.F.bv.jdMethod_if(i + 1);
        f = 1.0F;
        if ((k & m) == 0) {
          f = N[i];
        }
        m--;
        f += (k & m);
        arrayOfFloat1[j] = (Tables.t_multiple[arrayOfByte3[j]] * f * O[i]);
      }
      else
      {
        arrayOfFloat1[j] = 0.0F;
      }
      if (paramInt1 > 1) {
        if (0 != (i = arrayOfByte2[j]))
        {
          m = P[i];
          k = this.F.bv.jdMethod_if(i + 1);
          f = 1.0F;
          if ((k & m) == 0) {
            f = N[i];
          }
          m--;
          f += (k & m);
          arrayOfFloat2[j] = (Tables.t_multiple[arrayOfByte4[j]] * f * O[i]);
        }
        else
        {
          arrayOfFloat2[j] = 0.0F;
        }
      }
    }
    while (j < 32)
    {
      if (0 != (i = arrayOfByte1[j]))
      {
        m = P[i];
        k = this.F.bv.jdMethod_if(i + 1);
        f = 1.0F;
        if ((k & m) == 0) {
          f = N[i];
        }
        m--;
        f += (k & m);
        arrayOfFloat1[j] = (arrayOfFloat2[j] = Tables.t_multiple[arrayOfByte3[j]] * f * O[i]);
      }
      else
      {
        arrayOfFloat1[j] = (arrayOfFloat2[j] = 0.0F);
      }
      j++;
    }
  }
  
  void jdMethod_do()
    throws MPADException
  {
    int i3 = this.F.bv.jdMethod_if();
    byte[][] arrayOfByte1 = this.F.bs[this.F.bk];
    byte[][] arrayOfByte2 = this.F.bp[this.F.bk];
    float[][][] arrayOfFloat = this.F.bu[this.F.bk];
    int k = 32;
    if (this.F.bn.jdField_goto == 1) {
      k = (this.F.bn.jdField_else + 1) * 4;
    }
    int n = this.F.bn.k;
    if ((this.F.br == 0) && (this.F.bn.c == 0))
    {
      int i1 = 128 + 4 * k * (n - 1);
      if (this.F.bv.jdMethod_goto() < i1) {
        throw new MPADException(-3);
      }
      int i2 = this.F.bq.jdMethod_do(this.F.bv, this.F.bn, i1);
      if (i2 != 0) {
        throw new MPADException(-2);
      }
    }
    byte[] arrayOfByte3 = arrayOfByte1[0];
    byte[] arrayOfByte4 = arrayOfByte1[1];
    byte[] arrayOfByte5 = arrayOfByte2[0];
    byte[] arrayOfByte6 = arrayOfByte2[1];
    for (int j = 0; j < 32; j++)
    {
      arrayOfByte3[j] = 0;
      arrayOfByte4[j] = 0;
      arrayOfByte5[j] = 63;
      arrayOfByte6[j] = 63;
    }
    arrayOfByte3 = arrayOfByte1[0];
    arrayOfByte4 = arrayOfByte1[1];
    if (n > 1)
    {
      for (j = 0; j < k; j++)
      {
        arrayOfByte3[j] = ((byte)this.F.bv.jdMethod_if(4));
        arrayOfByte4[j] = ((byte)this.F.bv.jdMethod_if(4));
      }
      for (j = k; j < 32; j++) {
        arrayOfByte3[j] = (arrayOfByte4[j] = (byte)this.F.bv.jdMethod_if(4));
      }
    }
    else
    {
      for (j = 0; j < 32; j++) {
        arrayOfByte3[j] = ((byte)this.F.bv.jdMethod_if(4));
      }
    }
    arrayOfByte3 = arrayOfByte1[0];
    arrayOfByte4 = arrayOfByte1[1];
    arrayOfByte5 = arrayOfByte2[0];
    arrayOfByte6 = arrayOfByte2[1];
    if (n > 1) {
      for (j = 0; j < 32; j++)
      {
        if (arrayOfByte3[j] != 0) {
          arrayOfByte5[j] = ((byte)this.F.bv.jdMethod_if(6));
        }
        if (arrayOfByte4[j] != 0) {
          arrayOfByte6[j] = ((byte)this.F.bv.jdMethod_if(6));
        }
      }
    } else {
      for (j = 0; j < 32; j++) {
        if (arrayOfByte3[j] != 0) {
          arrayOfByte5[j] = ((byte)this.F.bv.jdMethod_if(6));
        }
      }
    }
    if (this.F.bv.jdMethod_goto() < 0) {
      throw new MPADException(-3);
    }
    for (int i = 0; i < 12; i++) {
      a(arrayOfByte1, arrayOfByte2, n, k, arrayOfFloat[i]);
    }
    if (this.F.bv.jdMethod_goto() < 0) {
      throw new MPADException(-3);
    }
    int i4;
    this.F.bn.jdField_new = (i4 = this.F.bn.jdField_do - (this.F.bv.jdMethod_if() - i3) - this.F.bn.jdField_if);
    if (i4 < 0) {
      throw new MPADException(-1);
    }
    if (this.F.bv.jdMethod_goto() < 0) {
      throw new MPADException(-3);
    }
    if (i4 > this.F.bv.jdMethod_goto()) {
      this.D.ao.cE = -1;
    }
    if (this.F.bk == 0) {
      this.L = 0;
    }
    i4--;
    if ((this.D.ao.cz & 0x3) == 0)
    {
      this.D.ao.cE = 0;
      this.F.bn.jdField_char = 384;
      a(1);
      if (++this.F.bk == 3) {
        this.F.bk = 0;
      }
    }
    else
    {
      if ((i4 > 0) && (this.L >= 0))
      {
        b.a(this.M, 0, this.F.bv.jdMethod_else(), this.F.bv.jdMethod_for(), this.L, this.F.bv.jdMethod_new(), i4);
        this.L += i4;
      }
      else
      {
        this.L = -1;
        if ((this.D.ao.cz & 0x3) == 3)
        {
          this.D.ao.cE = -1;
          return;
        }
      }
      if ((this.F.bk == 2) && (this.L > 15))
      {
        b localb = this.F.bv;
        int i5 = this.L;
        this.D.al.a(this.M, 0, this.L + 7 >> 3);
        this.F.bv = this.D.al;
        for (int m = 0; m < n; m++) {
          for (j = 0; j < 32; j++) {
            if (this.F.bs[0][m][j] == 0) {
              if (this.F.bs[1][m][j] > 0) {
                this.F.bs[0][m][j] = this.F.bs[1][m][j];
              } else if (this.F.bs[2][m][j] > 0) {
                this.F.bs[0][m][j] = this.F.bs[2][m][j];
              }
            }
          }
        }
        this.D.ao.cE = this.D.jdMethod_int(i5);
        this.F.bv = localb;
      }
      else if ((this.F.bk != 2) && (this.L >= 0))
      {
        this.D.ao.cE = 1;
      }
      else
      {
        this.D.ao.cE = -1;
      }
      if (++this.F.bk == 3)
      {
        this.F.bk = 0;
        this.F.bn.jdField_char = 1152;
        if ((this.D.ao.cz & 0x3) != 3) {
          a(2);
        }
      }
    }
  }
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mp3plugin.jar!\codecLib\mp3\k.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */