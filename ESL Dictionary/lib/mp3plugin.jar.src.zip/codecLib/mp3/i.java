package codecLib.mp3;

class i
  extends Defines
  implements Constants
{
  protected m a8;
  protected h aZ = new h(2);
  static final byte[][] bf = { { 1, 2 }, { 5, 3 } };
  static final byte[] a1 = { 8, 9 };
  static final byte[] aO = { 9, 4 };
  static final short[][] bh = { { 72, 128 }, { 136, 256 } };
  static final int bj = 4;
  static final int aU = 3;
  static final int a6 = 36;
  static final int be = 39;
  static final int bd = 576;
  static final int a9 = 31;
  static final int aQ = 2;
  static final int ba = 0;
  private short[][][] aS = new short[2][2][39];
  private byte[][] aP = new byte[2][4];
  private d[][] aY = new d[2][2];
  private byte[] aW = new byte['ߠ'];
  private int bc = 0;
  static final float[] aX = { 0.0F, 0.21132487F, 0.3660254F, 0.5F, 0.6339746F, 0.7886751F, 1.0F };
  static final float[][] aV = { { 1.0F, 0.8408964F, 0.70710677F, 0.59460354F, 0.5F, 0.4204482F, 0.35355338F, 0.29730177F, 0.25F, 0.2102241F, 0.17677669F, 0.14865088F, 0.125F, 0.10511205F, 0.088388346F, 0.07432544F }, { 1.0F, 0.70710677F, 0.5F, 0.35355338F, 0.25F, 0.17677669F, 0.125F, 0.088388346F, 0.0625F, 0.044194173F, 0.03125F, 0.022097087F, 0.015625F, 0.011048543F, 0.0078125F, 0.005524272F } };
  static final byte[] a2 = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 3, 3, 3, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
  static final int bb = 21;
  static final int bg = 8;
  static final int a4 = 6;
  static final int bi = 27;
  static final byte[][] a5 = { { 11, 10 }, { 18, 18 }, { 17, 18 } };
  static final byte[][] aN = { { 6, 1 }, { 5, 1 }, { 5, 2 }, { 5, 2 } };
  static final byte[][] aT = { { 0, 0, 0, 0, 3, 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4 }, { 0, 1, 2, 3, 0, 1, 2, 3, 1, 2, 3, 1, 2, 3, 2, 3 } };
  static final byte[][][] a0 = { { { 6, 5, 5, 5 }, { 9, 9, 9, 9 }, { 6, 9, 9, 9 } }, { { 6, 5, 7, 3 }, { 9, 9, 12, 6 }, { 6, 9, 12, 6 } }, { { 11, 10, 0, 0 }, { 18, 18, 0, 0 }, { 15, 18, 0, 0 } }, { { 7, 7, 7, 0 }, { 12, 12, 12, 0 }, { 6, 15, 12, 0 } }, { { 6, 6, 6, 3 }, { 12, 9, 9, 6 }, { 6, 12, 9, 6 } }, { { 8, 8, 5, 0 }, { 15, 12, 9, 0 }, { 6, 18, 9, 0 } } };
  static final float[] aR = { 5.144879E-12F, 6.1183268E-12F, 7.2759576E-12F, 8.65262E-12F, 1.0289758E-11F, 1.2236653E-11F, 1.4551915E-11F, 1.7305242E-11F, 2.0579516E-11F, 2.4473305E-11F, 2.910383E-11F, 3.461048E-11F, 4.115903E-11F, 4.894661E-11F, 5.820766E-11F, 6.922097E-11F, 8.231806E-11F, 9.789322E-11F, 1.1641532E-10F, 1.3844192E-10F, 1.6463612E-10F, 1.9578644E-10F, 2.3283064E-10F, 2.7688385E-10F, 3.2927225E-10F, 3.9157289E-10F, 4.656613E-10F, 5.537677E-10F, 6.585445E-10F, 7.8314577E-10F, 9.313226E-10F, 1.1075354E-9F, 1.317089E-9F, 1.5662915E-9F, 1.8626451E-9F, 2.2150708E-9F, 2.634178E-9F, 3.132583E-9F, 3.7252903E-9F, 4.4301416E-9F, 5.268356E-9F, 6.265166E-9F, 7.4505806E-9F, 8.860283E-9F, 1.0536712E-8F, 1.2530332E-8F, 1.4901161E-8F, 1.7720568E-8F, 2.1073424E-8F, 2.5060665E-8F, 2.9802322E-8F, 3.5441136E-8F, 4.2146848E-8F, 5.012133E-8F, 5.9604645E-8F, 7.0882265E-8F, 8.4293696E-8F, 1.0024266E-7F, 1.1920929E-7F, 1.4176453E-7F, 1.6858739E-7F, 2.0048533E-7F, 2.3841856E-7F, 2.8352906E-7F, 3.3717478E-7F, 4.0097066E-7F, 4.7683713E-7F, 5.670582E-7F, 6.7434956E-7F, 8.0194127E-7F, 9.536743E-7F, 1.1341162E-6F, 1.3486991E-6F, 1.6038825E-6F, 1.9073486E-6F, 2.2682327E-6F, 2.6973983E-6F, 3.207765E-6F, 3.8146973E-6F, 4.536465E-6F, 5.3947965E-6F, 6.41553E-6F, 7.6293945E-6F, 9.07293E-6F, 1.0789593E-5F, 1.283106E-5F, 1.5258789E-5F, 1.814586E-5F, 2.1579186E-5F, 2.5662122E-5F, 3.0517578E-5F, 3.629172E-5F, 4.3158372E-5F, 5.132424E-5F, 6.1035156E-5F, 7.258344E-5F, 8.6316744E-5F, 1.0264848E-4F, 1.2207031E-4F, 1.4516688E-4F, 1.7263349E-4F, 2.0529696E-4F, 2.4414061E-4F, 2.9033376E-4F, 3.4526698E-4F, 4.1059393E-4F, 4.8828125E-4F, 5.806675E-4F, 6.9053395E-4F, 8.2118786E-4F, 9.765625E-4F, 0.001161335F, 0.0013810679F, 0.0016423757F, 0.001953125F, 0.00232267F, 0.0027621358F, 0.0032847514F, 0.00390625F, 0.0046453406F, 0.0055242716F, 0.006569503F, 0.0078125F, 0.009290681F, 0.011048543F, 0.013139006F, 0.015625F, 0.01858136F, 0.022097087F, 0.026278013F, 0.03125F, 0.03716272F, 0.044194173F, 0.052556023F, 0.0625F, 0.07432544F, 0.088388346F, 0.10511205F, 0.125F, 0.14865088F, 0.17677669F, 0.21022409F, 0.25F, 0.29730177F, 0.35355338F, 0.42044818F, 0.5F, 0.59460354F, 0.70710677F, 0.84089637F, 1.0F, 1.1892071F, 1.4142135F, 1.6817927F, 2.0F, 2.3784142F, 2.8284273F, 3.3635855F, 4.0F, 4.756829F, 5.656854F, 6.727171F, 8.0F, 9.513657F, 11.313708F, 13.454342F, 16.0F, 19.027315F, 22.627417F, 26.908684F, 32.0F, 38.054626F, 45.254833F, 53.817368F, 64.0F, 76.10926F, 90.50967F, 107.63474F, 128.0F, 152.2185F, 181.01933F, 215.26947F, 256.0F, 304.437F, 362.03867F, 430.53894F, 512.0F, 608.874F, 724.07733F, 861.0779F, 1024.0F, 1217.748F, 1448.1547F, 1722.1558F, 2048.0F, 2435.496F, 2896.3093F, 3444.3118F, 4096.0F, 4870.992F, 5792.6187F, 6888.623F, 8192.0F, 9741.985F, 11585.237F, 13777.246F, 16384.0F, 19483.97F, 23170.475F, 27554.492F, 32768.0F, 38967.94F, 46340.95F, 55108.984F, 65536.0F, 77935.88F, 92681.9F, 110217.97F, 131072.0F, 155871.77F, 185363.8F, 220435.94F, 262144.0F, 311743.53F, 370727.6F, 440871.88F, 524288.0F, 623487.0F, 741455.2F, 881743.75F, 1048576.0F, 1246974.0F, 1482910.4F, 1763487.5F, 2097151.9F, 2493948.0F, 2965820.8F, 3526975.2F, 4194303.8F, 4987896.5F, 5931641.5F, 7053950.0F, 8388608.0F, 9975793.0F, 1.1863283E7F, 1.41079E7F, 1.6777215E7F, 1.9951586E7F, 2.3726566E7F, 2.82158E7F, 3.3554432E7F, 3.9903168E7F, 4.7453132E7F, 5.6431604E7F, 6.7108864E7F, 7.9806336E7F };
  static final short[][][][] a7 = { { { { 6, 6, 6, 6, 6, 6, 8, 10, 12, 14, 16, 20, 24, 28, 32, 38, 46, 52, 60, 68, 58, 54 }, { 4, 4, 4, 4, 4, 4, 4, 4, 4, 6, 6, 6, 6, 6, 6, 8, 8, 8, 10, 10, 10, 14, 14, 14, 18, 18, 18, 26, 26, 26, 32, 32, 32, 42, 42, 42, 18, 18, 18 }, { 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 8, 8, 8, 10, 10, 10, 14, 14, 14, 18, 18, 18, 26, 26, 26, 32, 32, 32, 42, 42, 42, 18, 18, 18, 0, 0, 0 } }, { { 6, 6, 6, 6, 6, 6, 8, 10, 12, 14, 16, 18, 22, 26, 32, 38, 46, 54, 62, 70, 76, 36 }, { 4, 4, 4, 4, 4, 4, 4, 4, 4, 6, 6, 6, 8, 8, 8, 10, 10, 10, 12, 12, 12, 14, 14, 14, 18, 18, 18, 24, 24, 24, 32, 32, 32, 44, 44, 44, 12, 12, 12 }, { 6, 6, 6, 6, 6, 6, 6, 6, 6, 8, 8, 8, 10, 10, 10, 12, 12, 12, 14, 14, 14, 18, 18, 18, 24, 24, 24, 32, 32, 32, 44, 44, 44, 12, 12, 12, 0, 0, 0 } }, { { 6, 6, 6, 6, 6, 6, 8, 10, 12, 14, 16, 20, 24, 28, 32, 38, 46, 52, 60, 68, 58, 54 }, { 4, 4, 4, 4, 4, 4, 4, 4, 4, 6, 6, 6, 8, 8, 8, 10, 10, 10, 12, 12, 12, 14, 14, 14, 18, 18, 18, 24, 24, 24, 30, 30, 30, 40, 40, 40, 18, 18, 18 }, { 6, 6, 6, 6, 6, 6, 6, 6, 6, 8, 8, 8, 10, 10, 10, 12, 12, 12, 14, 14, 14, 18, 18, 18, 24, 24, 24, 30, 30, 30, 40, 40, 40, 18, 18, 18, 0, 0, 0 } } }, { { { 4, 4, 4, 4, 4, 4, 6, 6, 8, 8, 10, 12, 16, 20, 24, 28, 34, 42, 50, 54, 76, 158 }, { 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 6, 6, 6, 8, 8, 8, 10, 10, 10, 12, 12, 12, 14, 14, 14, 18, 18, 18, 22, 22, 22, 30, 30, 30, 56, 56, 56 }, { 4, 4, 4, 4, 4, 4, 6, 6, 4, 4, 4, 6, 6, 6, 8, 8, 8, 10, 10, 10, 12, 12, 12, 14, 14, 14, 18, 18, 18, 22, 22, 22, 30, 30, 30, 56, 56, 56, 0 } }, { { 4, 4, 4, 4, 4, 4, 6, 6, 6, 8, 10, 12, 16, 18, 22, 28, 34, 40, 46, 54, 54, 192 }, { 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 6, 6, 6, 6, 6, 6, 10, 10, 10, 12, 12, 12, 14, 14, 14, 16, 16, 16, 20, 20, 20, 26, 26, 26, 66, 66, 66 }, { 4, 4, 4, 4, 4, 4, 6, 6, 4, 4, 4, 6, 6, 6, 6, 6, 6, 10, 10, 10, 12, 12, 12, 14, 14, 14, 16, 16, 16, 20, 20, 20, 26, 26, 26, 66, 66, 66, 0 } }, { { 4, 4, 4, 4, 4, 4, 6, 6, 8, 10, 12, 16, 20, 24, 30, 38, 46, 56, 68, 84, 102, 26 }, { 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 6, 6, 6, 8, 8, 8, 12, 12, 12, 16, 16, 16, 20, 20, 20, 26, 26, 26, 34, 34, 34, 42, 42, 42, 12, 12, 12 }, { 4, 4, 4, 4, 4, 4, 6, 6, 4, 4, 4, 6, 6, 6, 8, 8, 8, 12, 12, 12, 16, 16, 16, 20, 20, 20, 26, 26, 26, 34, 34, 34, 42, 42, 42, 12, 12, 12, 0 } } } };
  static final int[][][][] a3 = { { { { 22, 0 }, { 39, 13 }, { 36, 10 } }, { { 22, 0 }, { 39, 13 }, { 36, 10 } }, { { 22, 0 }, { 39, 13 }, { 36, 10 } } }, { { { 22, 0 }, { 39, 13 }, { 38, 10 } }, { { 22, 0 }, { 39, 13 }, { 38, 10 } }, { { 22, 0 }, { 39, 13 }, { 38, 10 } } } };
  
  i(m paramm)
  {
    this.a8 = paramm;
    n.jdMethod_else();
  }
  
  void jdMethod_char()
    throws MPADException
  {
    int n = 0;
    byte[] arrayOfByte = new byte['ޠ'];
    float[][][] arrayOfFloat = new float[2][2][];
    int k = this.a8.bn.k;
    int i = bh[this.a8.bn.jdField_long][(k - 1)];
    if (this.a8.bv.jdMethod_goto() < i) {
      throw new MPADException(-3);
    }
    int i13 = this.a8.bv.jdMethod_byte();
    int j = this.a8.bn.jdField_do - this.a8.bn.jdField_if;
    int i14;
    if (this.a8.bv.jdMethod_goto() >= j) {
      i14 = i13 + (j >> 3);
    } else {
      i14 = 0;
    }
    if (this.a8.bn.b == 0) {
      a(this.a8);
    } else {
      this.a8.bn.jdField_null = 0;
    }
    if ((this.a8.br == 0) && (this.a8.bn.c == 0) && (this.a8.bq.jdMethod_if(this.a8.bv, this.a8.bn, i) != 0))
    {
      n = -2;
    }
    else
    {
      int i1 = aO[this.a8.bn.jdField_long];
      int i2 = this.a8.bv.jdMethod_if();
      int i3 = this.a8.bv.jdMethod_if(a1[this.a8.bn.jdField_long]);
      this.a8.bv.jdMethod_do(bf[this.a8.bn.jdField_long][(k - 1)]);
      int m;
      int i7;
      if (this.a8.bn.jdField_long == 0)
      {
        m = 1;
      }
      else
      {
        for (i7 = 0; i7 < k; i7++) {
          for (int i10 = 0; i10 < 4; i10++) {
            this.aP[i7][i10] = ((byte)this.a8.bv.jdMethod_if(1));
          }
        }
        m = 2;
      }
      int i4 = 0;
      int i15;
      int i9;
      for (int i8 = 0; i8 < m; i8++) {
        for (i7 = 0; i7 < k; i7++)
        {
          this.aY[i7][i8] = new d();
          this.aY[i7][i8].jdField_case = this.a8.bv.jdMethod_if(12);
          i4 += this.aY[i7][i8].jdField_case;
          this.aY[i7][i8].g = this.a8.bv.jdMethod_if(9);
          if (this.aY[i7][i8].g > 288) {
            n = -1;
          }
          this.aY[i7][i8].jdField_byte = this.a8.bv.jdMethod_if(8);
          this.aY[i7][i8].b = this.a8.bv.jdMethod_if(i1);
          if (0 != (this.aY[i7][i8].d = this.a8.bv.jdMethod_if(1)))
          {
            i15 = this.a8.bv.jdMethod_if(13);
            this.aY[i7][i8].i = (i15 >>> 11);
            this.aY[i7][i8].c = (i15 >>> 10 & 0x1);
            this.aY[i7][i8].jdField_long[0] = (i15 >>> 5 & 0x1F);
            this.aY[i7][i8].jdField_long[1] = (i15 & 0x1F);
            this.aY[i7][i8].jdField_long[2] = 0;
            for (i9 = 0; i9 < 3; i9++) {
              if ((this.aY[i7][i8].jdField_long[i9] == 4) || (this.aY[i7][i8].jdField_long[i9] == 14)) {
                n = -1;
              }
            }
            i15 = this.a8.bv.jdMethod_if(9);
            this.aY[i7][i8].jdField_goto[0] = (i15 >>> 6);
            this.aY[i7][i8].jdField_goto[1] = (i15 >>> 3 & 0x7);
            this.aY[i7][i8].jdField_goto[2] = (i15 & 0x7);
          }
          else
          {
            i15 = this.a8.bv.jdMethod_if(15);
            this.aY[i7][i8].jdField_long[0] = (i15 >>> 10);
            this.aY[i7][i8].jdField_long[1] = (i15 >>> 5 & 0x1F);
            this.aY[i7][i8].jdField_long[2] = (i15 & 0x1F);
            i15 = this.a8.bv.jdMethod_if(7);
            this.aY[i7][i8].a = (i15 >>> 3);
            this.aY[i7][i8].jdField_char = (i15 & 0x7);
          }
          if (this.a8.bn.jdField_long != 0) {
            this.aY[i7][i8].e = this.a8.bv.jdMethod_if(1);
          } else {
            this.aY[i7][i8].e = 0;
          }
          i15 = this.a8.bv.jdMethod_if(2);
          this.aY[i7][i8].jdField_new = (i15 >>> 1);
          this.aY[i7][i8].jdField_if = (i15 & 0x1);
        }
      }
      if (n == 0)
      {
        if (this.a8.bv.jdMethod_goto() < i4 - (i3 << 3)) {
          throw new MPADException(-3);
        }
        int i12 = this.a8.bn.jdField_do - this.a8.bn.jdField_if - (this.a8.bv.jdMethod_if() - i2);
        int i11;
        if (this.a8.bn.jdField_null >= 0)
        {
          i11 = i12 - i4 - 8 * (this.a8.bn.jdField_null - i3);
          if (i11 < 0) {
            n = -1;
          }
        }
        else
        {
          i11 = 0;
          this.a8.bn.jdField_do = (this.a8.bn.jdField_if + (this.a8.bv.jdMethod_if() - i2));
          if (i3 << 3 < i4) {
            this.a8.bn.jdField_do += i4 - (i3 << 3);
          }
        }
        this.a8.bn.jdField_new = i11;
        j = i12;
        if (i12 > this.a8.bv.jdMethod_goto()) {
          j = this.a8.bv.jdMethod_goto();
        }
        if (i3 > this.bc)
        {
          int i17 = this.a8.bv.jdMethod_char() - (this.a8.bn.jdField_if >> 3);
          if ((this.bc == 0) && (i17 >= i3))
          {
            a(arrayOfByte, 0, this.a8.bv.jdMethod_else(), i17 - i3, i3);
          }
          else
          {
            i15 = this.bc == 0 ? i17 : this.bc;
            if (i15 > 511) {
              i15 = 511;
            }
            a(arrayOfByte, 0, this.a8.bv.jdMethod_else(), i17 - i15, i15);
            a(arrayOfByte, i15, this.a8.bv.jdMethod_else(), this.a8.bv.jdMethod_byte(), j >> 3);
            i15 += (j >> 3);
            int i16 = i3 + (j >> 3) - (i4 + 7 >> 3);
            if (i16 > i15) {
              i16 = i15;
            }
            if (i16 > this.a8.bn.jdField_null) {
              if (this.a8.bn.jdField_null >= 0) {
                i16 = this.a8.bn.jdField_null;
              } else if (i16 > 511) {
                i16 = 511;
              }
            }
            a(this.aW, 0, arrayOfByte, i15 - i16, i16);
            this.bc = i16;
            throw new MPADException(-9);
          }
        }
        else
        {
          a(arrayOfByte, 0, this.aW, this.bc - i3, i3);
        }
        a(arrayOfByte, i3, this.a8.bv.jdMethod_else(), this.a8.bv.jdMethod_byte(), j >> 3);
        this.a8.bv.a(arrayOfByte, 0, (j >> 3) + i3);
        i2 = this.a8.bv.jdMethod_if();
        float[] arrayOfFloat1;
        d locald;
        for (i8 = 0; i8 < m; i8++) {
          for (i7 = 0; i7 < k; i7++)
          {
            if (i8 == 1) {
              for (i9 = 0; i9 < 39; i9++) {
                this.aS[i7][1][i9] = this.aS[i7][0][i9];
              }
            }
            arrayOfFloat1 = arrayOfFloat[i7][i8] = new float['ɀ'];
            locald = this.aY[i7][i8];
            a(locald);
            int i5 = this.a8.bv.jdMethod_if();
            if (this.a8.bn.jdField_long == 1) {
              a(locald, this.aP[i7], this.aS[i7][i8], i8);
            } else {
              a(locald, this.aS[i7][i8], i7);
            }
            jdMethod_if(locald);
            if (n.a(locald, this.a8.bv, arrayOfFloat1, this.a8.bv.jdMethod_if() - i5) != 0)
            {
              n = -1;
              break;
            }
            a(locald, this.aS[i7][i8], arrayOfFloat1);
            i5 = locald.jdField_case - (this.a8.bv.jdMethod_if() - i5);
            if (i5 != 0) {
              this.a8.bv.a(i5);
            }
          }
        }
        if (j < i12) {
          throw new MPADException(-4);
        }
        i12 >>= 3;
        i12 += i3;
        int i6 = i12 - (this.a8.bv.jdMethod_if() - i2 >> 3);
        j = this.a8.bn.jdField_null;
        if (j < 0)
        {
          j = 511;
          if (i6 < 511) {
            j = i6;
          }
        }
        a(this.aW, 0, arrayOfByte, i12 - j, j);
        this.bc = j;
        if ((this.a8.bn.jdField_goto == 1) && (this.a8.bn.jdField_else != 0)) {
          if (this.a8.bn.jdField_else == 2)
          {
            jdMethod_if(arrayOfFloat[0][0], 0, arrayOfFloat[1][0], 0, 576);
            if (m == 2) {
              jdMethod_if(arrayOfFloat[0][1], 0, arrayOfFloat[1][1], 0, 576);
            }
          }
          else
          {
            a(this.aY[1][0], arrayOfFloat[0][0], arrayOfFloat[1][0], this.aS[1][0]);
            if (m == 2) {
              a(this.aY[1][1], arrayOfFloat[0][1], arrayOfFloat[1][1], this.aS[1][1]);
            }
          }
        }
        for (i8 = 0; i8 < m; i8++) {
          for (i7 = 0; i7 < k; i7++)
          {
            arrayOfFloat1 = arrayOfFloat[i7][i8];
            locald = this.aY[i7][i8];
            if (locald.jdField_try != 0) {
              a(locald.jdField_void, locald.jdField_do, locald.h, arrayOfFloat1);
            }
            this.aZ.a(arrayOfFloat1, this.a8.bm[i7], (i8 * 576 >> this.a8.bz) + this.a8.bo[i7], this.aY[i7][i8].i, 2 * this.aY[i7][i8].c, i7, this.a8.bz);
          }
        }
        return;
      }
    }
    if (i14 != 0)
    {
      i >>= 3;
      j = i14 - i13;
      if (j - i >= 511)
      {
        a(this.aW, 0, this.a8.bv.jdMethod_else(), i14 - 511, 511);
        this.bc = 511;
      }
      else
      {
        a(this.aW, this.bc, this.a8.bv.jdMethod_else(), i13 + i, j - i);
        this.bc += j - i;
        if (this.bc > 1024)
        {
          a(this.aW, 0, this.aW, this.bc - 511, 511);
          this.bc = 511;
        }
      }
    }
    if (n != 0) {
      throw new MPADException(n);
    }
  }
  
  private static void a(m paramm)
  {
    byte[] arrayOfByte = paramm.bv.jdMethod_else();
    int i = paramm.bv.jdMethod_char() - (paramm.bn.jdField_if >> 3);
    i += (paramm.bn.jdField_do >> 3);
    int j = paramm.bv.jdMethod_try();
    if (i + 4 > j)
    {
      paramm.bn.jdField_null = -1;
      return;
    }
    if (((arrayOfByte[i] & 0xFF) != 255) || ((arrayOfByte[(i + 1)] & 0xF6) != 242))
    {
      paramm.bn.jdField_null = -1;
      return;
    }
    int k = arrayOfByte[(i + 1)] >> 3 & 0x1;
    int m = arrayOfByte[(i + 1)] & 0x1 ^ 0x1;
    i += 4 + (m << 1);
    if (k == 1)
    {
      if (i + 1 >= j)
      {
        paramm.bn.jdField_null = -1;
        return;
      }
      paramm.bn.jdField_null = ((arrayOfByte[i] & 0xFF) << 1 | (arrayOfByte[(i + 1)] & 0xFF) >> 7);
    }
    else
    {
      if (i >= j)
      {
        paramm.bn.jdField_null = -1;
        return;
      }
      paramm.bn.jdField_null = (arrayOfByte[i] & 0xFF);
    }
  }
  
  void a(d paramd)
  {
    if (paramd.d != 0)
    {
      if (paramd.i == 2)
      {
        if (paramd.c == 0)
        {
          paramd.a = 8;
          paramd.jdField_try = 1;
        }
        else
        {
          paramd.a = 7;
          paramd.jdField_try = 2;
        }
      }
      else
      {
        paramd.a = 7;
        paramd.jdField_try = 0;
      }
      paramd.jdField_char = 63;
    }
    else
    {
      paramd.i = 0;
      paramd.jdField_try = 0;
      paramd.c = 0;
    }
    paramd.jdField_void = a7[this.a8.bn.jdField_long][this.a8.bn.i][paramd.jdField_try];
    paramd.h = a3[this.a8.bn.jdField_long][this.a8.bn.i][paramd.jdField_try][0];
    paramd.jdField_do = a3[this.a8.bn.jdField_long][this.a8.bn.i][paramd.jdField_try][1];
  }
  
  int a(d paramd, byte[] paramArrayOfByte, short[] paramArrayOfShort, int paramInt)
  {
    int k = aT[0][paramd.b];
    int m = aT[1][paramd.b];
    int n = a5[paramd.jdField_try][0];
    int i1 = a5[paramd.jdField_try][1];
    int j = 0;
    if ((paramd.jdField_try == 0) && (paramInt == 1))
    {
      for (i = 0; i < 4; i++)
      {
        if (paramArrayOfByte[i] == 0) {
          if (aN[i][1] == 1) {
            this.a8.bv.a(paramArrayOfShort, j, k, aN[i][0]);
          } else {
            this.a8.bv.a(paramArrayOfShort, j, m, aN[i][0]);
          }
        }
        j += aN[i][0];
      }
    }
    else
    {
      this.a8.bv.a(paramArrayOfShort, j, k, n);
      j += n;
      this.a8.bv.a(paramArrayOfShort, j, m, i1);
      j += i1;
    }
    for (int i = 0; i < 3; i++) {
      paramArrayOfShort[(j++)] = 0;
    }
    paramd.f[0] = k;
    paramd.f[1] = m;
    paramd.f[2] = (paramd.f[3] = 0);
    paramd.jdField_for[0] = n;
    paramd.jdField_for[1] = i1;
    paramd.jdField_for[2] = (paramd.jdField_for[3] = 0);
    return 1;
  }
  
  int a(d paramd, short[] paramArrayOfShort, int paramInt)
  {
    int n = 0;
    int m = this.a8.bn.jdField_else;
    int k = paramd.b;
    paramd.e = 0;
    if (((m & 0x1) == 0) || (paramInt == 0))
    {
      paramd.jdField_null = 0;
      if (k < 400)
      {
        paramd.f[0] = ((k >> 4) / 5);
        paramd.f[1] = ((k >> 4) % 5);
        paramd.f[2] = ((k & 0xF) >> 2);
        paramd.f[3] = (k & 0x3);
        n = 0;
      }
      else if (k < 500)
      {
        k -= 400;
        paramd.f[0] = ((k >> 2) / 5);
        paramd.f[1] = ((k >> 2) % 5);
        paramd.f[2] = (k & 0x3);
        paramd.f[3] = 0;
        n = 1;
      }
      else if (k < 512)
      {
        k -= 500;
        paramd.f[0] = (k / 3);
        paramd.f[1] = (k % 3);
        paramd.f[2] = 0;
        paramd.f[3] = 0;
        paramd.e = 1;
        n = 2;
      }
    }
    else
    {
      paramd.jdField_null = (k & 0x1);
      k >>= 1;
      if (k < 180)
      {
        paramd.f[0] = (k / 36);
        paramd.f[1] = (k % 36 / 6);
        paramd.f[2] = (k % 36 % 6);
        paramd.f[3] = 0;
        n = 3;
      }
      else if (k < 244)
      {
        k -= 180;
        paramd.f[0] = ((k & 0x3F) >> 4);
        paramd.f[1] = ((k & 0xF) >> 2);
        paramd.f[2] = (k & 0x3);
        paramd.f[3] = 0;
        n = 4;
      }
      else if (k <= 255)
      {
        k -= 244;
        paramd.f[0] = (k / 3);
        paramd.f[1] = (k % 3);
        paramd.f[2] = 0;
        paramd.f[3] = 0;
        n = 5;
      }
    }
    int i1;
    if (paramd.i == 2) {
      i1 = 1 + paramd.c;
    } else {
      i1 = 0;
    }
    int j = 0;
    for (int i = 0; i < 4; i++)
    {
      int i2 = a0[n][i1][i];
      this.a8.bv.a(paramArrayOfShort, j, paramd.f[i], i2);
      j += i2;
      paramd.jdField_for[i] = i2;
    }
    i = 3;
    while (i-- > 0) {
      paramArrayOfShort[(j++)] = 0;
    }
    return 1;
  }
  
  void jdMethod_if(d paramd)
  {
    short[] arrayOfShort = paramd.jdField_void;
    int i2 = 0;
    int i = 0;
    int j = 0;
    i2 = 0;
    while (i < paramd.g * 2)
    {
      i += arrayOfShort[(i2++)];
      j++;
    }
    int k = paramd.a + 1;
    int m = paramd.jdField_char + 1;
    if (j < 2) {
      m = 0;
    }
    if (j == 0) {
      k = 0;
    }
    if (m + k > j) {
      m = j - k;
    }
    int n = j - m - k;
    if (n < 0) {
      n = 0;
    }
    i = 0;
    i2 = 0;
    int i1 = k - 1;
    while (i1-- >= 0) {
      i += arrayOfShort[(i2++)];
    }
    paramd.jdField_else[0] = (i >> 1);
    if (paramd.jdField_else[0] > paramd.g) {
      paramd.jdField_else[0] = paramd.g;
    }
    i = 0;
    i1 = m - 1;
    while (i1-- >= 0) {
      i += arrayOfShort[(i2++)];
    }
    paramd.jdField_else[1] = (i >> 1);
    if (paramd.jdField_else[1] > paramd.g - paramd.jdField_else[0]) {
      paramd.jdField_else[1] = (paramd.g - paramd.jdField_else[0]);
    }
    paramd.jdField_else[2] = (paramd.g - paramd.jdField_else[0] - paramd.jdField_else[1]);
  }
  
  void a(d paramd, short[] paramArrayOfShort, float[] paramArrayOfFloat)
  {
    int[] arrayOfInt = new int[39];
    int m = 1 + paramd.jdField_new;
    int n = 0;
    int i1 = 0;
    int k = paramd.jdField_byte;
    if (paramd.jdField_try == 0)
    {
      if (paramd.e != 0)
      {
        i5 = 0;
        i = paramd.h - 1;
        while (i-- >= 0) {
          arrayOfInt[(i1++)] = (k - (paramArrayOfShort[(n++)] + a2[(i5++)] << m));
        }
      }
      else
      {
        i = paramd.h - 1;
        while (i-- >= 0) {
          arrayOfInt[(i1++)] = (k - (paramArrayOfShort[(n++)] << m));
        }
      }
    }
    else
    {
      int i2 = 8 * paramd.jdField_goto[0];
      int i3 = 8 * paramd.jdField_goto[1];
      int i4 = 8 * paramd.jdField_goto[2];
      i = paramd.h - paramd.jdField_do * 3 - 1;
      while (i-- >= 0) {
        arrayOfInt[(i1++)] = (k - (paramArrayOfShort[(n++)] << m));
      }
      i = paramd.jdField_do - 1;
      while (i-- >= 0)
      {
        arrayOfInt[(i1++)] = (k - (paramArrayOfShort[(n++)] << m) - i2);
        arrayOfInt[(i1++)] = (k - (paramArrayOfShort[(n++)] << m) - i3);
        arrayOfInt[(i1++)] = (k - (paramArrayOfShort[(n++)] << m) - i4);
      }
    }
    int i5 = 0;
    int i6 = 0;
    i1 = 0;
    for (int i = 0; i < paramd.h; i++)
    {
      int i7 = paramd.jdField_void[(i5++)];
      float f = aR[arrayOfInt[(i1++)]];
      for (int j = 0; j < i7; j++) {
        paramArrayOfFloat[(i6++)] *= f;
      }
    }
  }
  
  static void jdMethod_if(float[] paramArrayOfFloat1, int paramInt1, float[] paramArrayOfFloat2, int paramInt2, int paramInt3)
  {
    for (int i = 0; i < paramInt3; i++)
    {
      float f1 = paramArrayOfFloat1[(paramInt1 + i)] * 0.70710677F;
      float f2 = paramArrayOfFloat2[(paramInt2 + i)] * 0.70710677F;
      paramArrayOfFloat1[(paramInt1 + i)] = (f1 + f2);
      paramArrayOfFloat2[(paramInt2 + i)] = (f1 - f2);
    }
  }
  
  void a(d paramd, float[] paramArrayOfFloat1, float[] paramArrayOfFloat2, short[] paramArrayOfShort)
  {
    int i2 = 0;
    int i3 = 0;
    short[] arrayOfShort = new short[39];
    int i = 38;
    while (i-- >= 0) {
      arrayOfShort[(i3++)] = paramArrayOfShort[(i2++)];
    }
    int j = paramd.h;
    int k = paramd.jdField_do;
    int m = j - k * 3;
    int n = 575;
    int i4 = j - 1;
    i3 = j - 1;
    a(paramArrayOfFloat2, n, k, m, paramd.jdField_void, i4, arrayOfShort, i3);
    if (this.a8.bn.jdField_long == 1) {
      paramd.f[0] = (paramd.f[1] = 3);
    }
    a(paramd, arrayOfShort);
    if (k != 0)
    {
      i2 = i3 - 3;
      arrayOfShort[(i3--)] = paramArrayOfShort[(i2--)];
      arrayOfShort[(i3--)] = paramArrayOfShort[(i2--)];
      arrayOfShort[(i3--)] = paramArrayOfShort[(i2--)];
      i3 += 3;
    }
    else
    {
      arrayOfShort[i3] = arrayOfShort[(i3 - 1)];
    }
    i4 = 0;
    i3 = 0;
    int i1 = n = 0;
    i = j;
    while (i-- > 0)
    {
      int i5 = paramd.jdField_void[(i4++)];
      if (arrayOfShort[i3] == 31)
      {
        if (this.a8.bn.jdField_else == 3) {
          jdMethod_if(paramArrayOfFloat1, i1, paramArrayOfFloat2, n, i5);
        }
      }
      else {
        a(paramArrayOfFloat1, i1, paramArrayOfFloat2, n, arrayOfShort[i3], i5, this.a8.bn.jdField_long, paramd.jdField_null);
      }
      i3++;
      i1 += i5;
      n += i5;
    }
  }
  
  void a(float[] paramArrayOfFloat, int paramInt1, int paramInt2, int paramInt3, short[] paramArrayOfShort1, int paramInt4, short[] paramArrayOfShort2, int paramInt5)
  {
    int k = -1;
    int[] arrayOfInt = new int[3];
    arrayOfInt[0] = (arrayOfInt[1] = arrayOfInt[2] = -1);
    int i = paramInt2 - 1;
    int n;
    int m;
    float f;
    while (i-- >= 0)
    {
      n = 2;
      int j = 2;
      while (j-- >= 0)
      {
        m = paramArrayOfShort1[(paramInt4--)];
        if (arrayOfInt[n] == -1)
        {
          f = a(paramArrayOfFloat, paramInt1 - m + 1, m);
          if (f != 0.0F)
          {
            arrayOfInt[n] = (i + 2);
            k = 1;
            paramArrayOfShort2[paramInt5] = 31;
          }
        }
        else
        {
          paramArrayOfShort2[paramInt5] = 31;
        }
        n--;
        paramInt1 -= m;
        paramInt5--;
      }
    }
    arrayOfInt[0] = (arrayOfInt[1] = arrayOfInt[2] = k);
    i = paramInt3 - 1;
    while (i-- >= 0)
    {
      n = 2;
      m = paramArrayOfShort1[(paramInt4--)];
      if (arrayOfInt[n] == -1)
      {
        f = a(paramArrayOfFloat, paramInt1 - m + 1, m);
        if (f != 0.0F)
        {
          arrayOfInt[n] = (i + 2);
          k = 1;
          paramArrayOfShort2[paramInt5] = 31;
        }
      }
      else
      {
        paramArrayOfShort2[paramInt5] = 31;
      }
      n--;
      paramInt1 -= m;
      paramInt5--;
    }
  }
  
  float a(float[] paramArrayOfFloat, int paramInt1, int paramInt2)
  {
    float f2 = 0.0F;
    for (int i = 0; i < paramInt2; i++)
    {
      float f1 = paramArrayOfFloat[(paramInt1 + i)];
      f2 += f1 * f1;
    }
    return f2;
  }
  
  void a(d paramd, short[] paramArrayOfShort)
  {
    int k = 0;
    int m = 0;
    int n = 0;
    int[] arrayOfInt1 = paramd.jdField_for;
    int[] arrayOfInt2 = paramd.f;
    int i = 3;
    while (i-- >= 0)
    {
      int i1 = 1;
      if (arrayOfInt2[n] != 0)
      {
        i1 <<= arrayOfInt2[n];
        i1--;
        int j = arrayOfInt1[m] - 1;
        while (j-- >= 0)
        {
          if (paramArrayOfShort[k] == i1) {
            paramArrayOfShort[k] = 31;
          }
          k++;
        }
      }
      else
      {
        k += arrayOfInt1[m];
      }
      m++;
      n++;
    }
  }
  
  void a(float[] paramArrayOfFloat1, int paramInt1, float[] paramArrayOfFloat2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    float f1;
    float f2;
    if (paramInt5 == 1)
    {
      f1 = aX[paramInt3];
      f2 = aX[(6 - paramInt3)];
    }
    else
    {
      int i = paramInt3 & 0x1;
      int j = paramInt3 + 1 >> 1;
      if (i == 0)
      {
        f2 = aV[paramInt6][j];
        f1 = 1.0F;
      }
      else
      {
        f1 = aV[paramInt6][j];
        f2 = 1.0F;
      }
    }
    for (int k = 0; k < paramInt4; k++)
    {
      float f3 = paramArrayOfFloat1[(paramInt1 + k)];
      paramArrayOfFloat1[(paramInt1 + k)] = (f3 * f1);
      paramArrayOfFloat2[(paramInt2 + k)] = (f3 * f2);
    }
  }
  
  void a(short[] paramArrayOfShort, int paramInt1, int paramInt2, float[] paramArrayOfFloat)
  {
    float[] arrayOfFloat = new float['ɀ'];
    int k = 0;
    int m = 0;
    int n = 0;
    int i1 = 0;
    int i = paramInt2 - paramInt1 * 3 - 1;
    while (i-- >= 0) {
      k += paramArrayOfShort[(i1++)];
    }
    n += k;
    i = paramInt1 - 1;
    while (i-- >= 0)
    {
      int j = paramArrayOfShort[i1];
      a(paramArrayOfFloat, n, arrayOfFloat, m, j);
      n += 3 * j;
      m += 3 * j;
      i1 += 3;
    }
    for (i = 0; i < 576 - k; i++) {
      paramArrayOfFloat[(k + i)] = arrayOfFloat[i];
    }
  }
  
  static void a(float[] paramArrayOfFloat1, int paramInt1, float[] paramArrayOfFloat2, int paramInt2, int paramInt3)
  {
    int j = paramInt1;
    int k = paramInt1 + paramInt3;
    int m = paramInt1 + paramInt3 * 2;
    for (int i = 0; i < paramInt3 >> 1; i++)
    {
      paramArrayOfFloat2[(paramInt2 + 6 * i + 0)] = paramArrayOfFloat1[(j + 2 * i)];
      paramArrayOfFloat2[(paramInt2 + 6 * i + 1)] = paramArrayOfFloat1[(k + 2 * i)];
      paramArrayOfFloat2[(paramInt2 + 6 * i + 2)] = paramArrayOfFloat1[(m + 2 * i)];
      paramArrayOfFloat2[(paramInt2 + 6 * i + 3)] = paramArrayOfFloat1[(j + 2 * i + 1)];
      paramArrayOfFloat2[(paramInt2 + 6 * i + 4)] = paramArrayOfFloat1[(k + 2 * i + 1)];
      paramArrayOfFloat2[(paramInt2 + 6 * i + 5)] = paramArrayOfFloat1[(m + 2 * i + 1)];
    }
  }
  
  static void a(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, int paramInt3)
  {
    for (int i = 0; i < paramInt3; i++) {
      paramArrayOfByte1[(paramInt1 + i)] = paramArrayOfByte2[(paramInt2 + i)];
    }
  }
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mp3plugin.jar!\codecLib\mp3\i.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */