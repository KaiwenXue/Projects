package codecLib.mp3;

public class OutputConverter
{
  public static void convert(byte[] paramArrayOfByte, int paramInt1, float[] paramArrayOfFloat, int paramInt2, int paramInt3)
  {
    for (int i = 0; i < paramInt3; i++)
    {
      float f = paramArrayOfFloat[(paramInt2++)];
      int j = (int)f;
      j = j <= 32768 ? 32768 : j >= 32767 ? 32767 : j;
      paramArrayOfByte[(paramInt1 + i * 2)] = ((byte)(j >> 8));
      paramArrayOfByte[(paramInt1 + i * 2 + 1)] = ((byte)j);
    }
  }
  
  public static void convert(byte[] paramArrayOfByte, int paramInt1, float[] paramArrayOfFloat1, int paramInt2, float[] paramArrayOfFloat2, int paramInt3, int paramInt4)
  {
    for (int i = 0; i < paramInt4; i++)
    {
      float f = paramArrayOfFloat1[(paramInt2++)];
      int j = (int)f;
      j = j <= 32768 ? 32768 : j >= 32767 ? 32767 : j;
      paramArrayOfByte[(paramInt1 + i * 4)] = ((byte)(j >> 8));
      paramArrayOfByte[(paramInt1 + i * 4 + 1)] = ((byte)j);
      f = paramArrayOfFloat2[(paramInt3++)];
      j = (int)f;
      j = j <= 32768 ? 32768 : j >= 32767 ? 32767 : j;
      paramArrayOfByte[(paramInt1 + i * 4 + 2)] = ((byte)(j >> 8));
      paramArrayOfByte[(paramInt1 + i * 4 + 3)] = ((byte)j);
    }
  }
  
  public static void convert(short[] paramArrayOfShort, int paramInt1, float[] paramArrayOfFloat, int paramInt2, int paramInt3)
  {
    for (int i = 0; i < paramInt3; i++)
    {
      float f = paramArrayOfFloat[(paramInt2++)];
      int j = (int)f;
      j = j <= 32768 ? 32768 : j >= 32767 ? 32767 : j;
      paramArrayOfShort[(paramInt1 + i)] = ((short)j);
    }
  }
  
  public static void convert(short[] paramArrayOfShort, int paramInt1, float[] paramArrayOfFloat1, int paramInt2, float[] paramArrayOfFloat2, int paramInt3, int paramInt4)
  {
    for (int i = 0; i < paramInt4; i++)
    {
      float f = paramArrayOfFloat1[(paramInt2++)];
      int j = (int)f;
      j = j <= 32768 ? 32768 : j >= 32767 ? 32767 : j;
      paramArrayOfShort[(paramInt1 + 2 * i)] = ((short)j);
      f = paramArrayOfFloat2[(paramInt3++)];
      j = (int)f;
      j = j <= 32768 ? 32768 : j >= 32767 ? 32767 : j;
      paramArrayOfShort[(paramInt1 + 2 * i + 1)] = ((short)j);
    }
  }
  
  public static void convert24Bit(byte[] paramArrayOfByte, int paramInt1, float[] paramArrayOfFloat, int paramInt2, int paramInt3)
  {
    float f1 = 256.0F;
    for (int i = 0; i < paramInt3; i++)
    {
      float f2 = paramArrayOfFloat[(paramInt2++)] * f1;
      int j = (int)f2;
      j = j <= -8388608 ? -8388608 : j >= 8388607 ? 8388607 : j;
      paramArrayOfByte[(paramInt1 + i * 3)] = ((byte)(j >> 16));
      paramArrayOfByte[(paramInt1 + i * 3 + 1)] = ((byte)(j >> 8));
      paramArrayOfByte[(paramInt1 + i * 3 + 2)] = ((byte)j);
    }
  }
  
  public static void convert24Bit(byte[] paramArrayOfByte, int paramInt1, float[] paramArrayOfFloat1, int paramInt2, float[] paramArrayOfFloat2, int paramInt3, int paramInt4)
  {
    float f1 = 256.0F;
    for (int i = 0; i < paramInt4; i++)
    {
      float f2 = paramArrayOfFloat1[(paramInt2++)] * f1;
      int j = (int)f2;
      j = j <= -8388608 ? -8388608 : j >= 8388607 ? 8388607 : j;
      paramArrayOfByte[(paramInt1 + i * 6)] = ((byte)(j >> 16));
      paramArrayOfByte[(paramInt1 + i * 6 + 1)] = ((byte)(j >> 8));
      paramArrayOfByte[(paramInt1 + i * 6 + 2)] = ((byte)j);
      f2 = paramArrayOfFloat2[(paramInt3++)] * f1;
      j = (int)f2;
      j = j <= -8388608 ? -8388608 : j >= 8388607 ? 8388607 : j;
      paramArrayOfByte[(paramInt1 + i * 6 + 3)] = ((byte)(j >> 16));
      paramArrayOfByte[(paramInt1 + i * 6 + 4)] = ((byte)(j >> 8));
      paramArrayOfByte[(paramInt1 + i * 6 + 5)] = ((byte)j);
    }
  }
  
  public static void convert24Bit(int[] paramArrayOfInt, int paramInt1, float[] paramArrayOfFloat, int paramInt2, int paramInt3)
  {
    float f1 = 256.0F;
    for (int i = 0; i < paramInt3; i++)
    {
      float f2 = paramArrayOfFloat[(paramInt2++)] * f1;
      int j = (int)f2;
      j = j <= -8388608 ? -8388608 : j >= 8388607 ? 8388607 : j;
      paramArrayOfInt[(paramInt1 + i)] = j;
    }
  }
  
  public static void convert24Bit(int[] paramArrayOfInt, int paramInt1, float[] paramArrayOfFloat1, int paramInt2, float[] paramArrayOfFloat2, int paramInt3, int paramInt4)
  {
    float f1 = 256.0F;
    for (int i = 0; i < paramInt4; i++)
    {
      float f2 = paramArrayOfFloat1[(paramInt2++)] * f1;
      int j = (int)f2;
      j = j <= -8388608 ? -8388608 : j >= 8388607 ? 8388607 : j;
      paramArrayOfInt[(paramInt1 + 2 * i)] = j;
      f2 = paramArrayOfFloat2[(paramInt3++)] * f1;
      j = (int)f2;
      j = j <= -8388608 ? -8388608 : j >= 8388607 ? 8388607 : j;
      paramArrayOfInt[(paramInt1 + 2 * i + 1)] = j;
    }
  }
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mp3plugin.jar!\codecLib\mp3\OutputConverter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */