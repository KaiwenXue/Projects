package codecLib.mp3;

class j
  extends o
{
  int G;
  int J;
  int H;
  byte[] I = new byte[64];
  private byte[] K = new byte['ເ'];
  
  j(m paramm, c paramc)
  {
    super(paramm, paramc);
  }
  
  void a()
    throws MPADException
  {
    b localb = new b();
    int n = 0;
    int i = this.F.bn.k;
    int k = this.F.bn.jdField_try >> i - 1;
    int j;
    if (this.F.bn.jdField_long == 0) {
      j = 4;
    } else if (k <= 48)
    {
      if (this.F.bn.i == 2) {
        j = 3;
      } else {
        j = 2;
      }
    }
    else if (k <= 80) {
      j = 0;
    } else if (k <= 192)
    {
      if (this.F.bn.i == 1) {
        j = 0;
      } else {
        j = 1;
      }
    }
    else {
      throw new MPADException(-1);
    }
    this.F.bA = Tables.t_bal[j];
    this.J = Tables.t_bal[j].jdField_int;
    this.G = this.J;
    if (this.F.bn.jdField_goto == 1) {
      this.G = ((this.F.bn.jdField_else + 1) * 4);
    }
    int i1 = this.F.bv.jdMethod_if();
    if (this.F.bn.c == 0) {
      b.a(localb, this.F.bv);
    }
    jdMethod_do(i);
    jdMethod_for(i);
    if (this.F.bv.jdMethod_goto() < 0) {
      throw new MPADException(-3);
    }
    if ((this.F.br == 0) && (this.F.bn.c == 0))
    {
      int m = this.F.bv.jdMethod_if() - i1;
      n = this.F.bq.a(localb, this.F.bn, m);
      if (n != 0) {
        throw new MPADException(-2);
      }
    }
    jdMethod_if(i);
    jdMethod_if();
    int i2;
    this.F.bn.jdField_new = (i2 = this.F.bn.jdField_do - (this.F.bv.jdMethod_if() - i1) - this.F.bn.jdField_if);
    if (i2 < 0) {
      throw new MPADException(-1);
    }
    if (this.F.bv.jdMethod_goto() < 0) {
      throw new MPADException(-3);
    }
    if ((this.D.ao.cz & 0x3) == 0)
    {
      this.D.ao.cE = 0;
    }
    else if (i2 > 15)
    {
      if (i2 > this.F.bv.jdMethod_goto()) {
        throw new MPADException(-8);
      }
      b.a(this.K, 0, this.F.bv.jdMethod_else(), this.F.bv.jdMethod_for(), 0, this.F.bv.jdMethod_new(), i2);
      this.F.bv.a(this.K, 0, i2 + 7 >> 3);
      this.D.ao.cE = this.D.jdMethod_int(i2);
    }
    else
    {
      this.D.ao.cE = -1;
    }
    if ((this.D.ao.cz & 0x3) != 3) {
      a(2);
    }
  }
  
  private void jdMethod_do(int paramInt)
  {
    b localb = this.F.bv;
    f localf = this.F.bA;
    int j = this.G;
    int k = this.J;
    byte[][] arrayOfByte = this.F.bs[0];
    if (j > k) {
      j = k;
    }
    if (paramInt == 1) {
      j = 0;
    }
    for (int i = 0; i < j; i++)
    {
      arrayOfByte[0][i] = ((byte)localb.jdMethod_if(localf.a[i]));
      arrayOfByte[1][i] = ((byte)localb.jdMethod_if(localf.a[i]));
    }
    while (i < k)
    {
      arrayOfByte[1][i] = (arrayOfByte[0][i] = (byte)localb.jdMethod_if(localf.a[i]));
      i++;
    }
  }
  
  private void jdMethod_for(int paramInt)
  {
    b localb = this.F.bv;
    byte[][] arrayOfByte1 = this.F.bs[0];
    byte[] arrayOfByte = this.I;
    int j = 0;
    int i;
    if (paramInt == 1) {
      for (i = 0; i < this.J; i++) {
        if (arrayOfByte1[0][i] != 0) {
          arrayOfByte[(j++)] = ((byte)localb.jdMethod_if(2));
        } else {
          arrayOfByte[(j++)] = 4;
        }
      }
    } else {
      for (i = 0; i < this.J; i++)
      {
        if (arrayOfByte1[0][i] != 0) {
          arrayOfByte[(j++)] = ((byte)localb.jdMethod_if(2));
        } else {
          arrayOfByte[(j++)] = 4;
        }
        if (arrayOfByte1[1][i] != 0) {
          arrayOfByte[(j++)] = ((byte)localb.jdMethod_if(2));
        } else {
          arrayOfByte[(j++)] = 4;
        }
      }
    }
  }
  
  private void jdMethod_if(int paramInt)
  {
    byte[][][] arrayOfByte1 = this.F.bp;
    b localb = this.F.bv;
    byte[] arrayOfByte = this.I;
    int k = 0;
    for (int j = 0; j < this.J; j++) {
      for (int i = 0; i < paramInt; i++) {
        switch (arrayOfByte[(k++)])
        {
        case 0: 
          arrayOfByte1[0][i][j] = ((byte)localb.jdMethod_if(6));
          arrayOfByte1[1][i][j] = ((byte)localb.jdMethod_if(6));
          arrayOfByte1[2][i][j] = ((byte)localb.jdMethod_if(6));
          break;
        case 1: 
          arrayOfByte1[1][i][j] = (arrayOfByte1[0][i][j] = (byte)localb.jdMethod_if(6));
          arrayOfByte1[2][i][j] = ((byte)localb.jdMethod_if(6));
          break;
        case 2: 
          arrayOfByte1[2][i][j] = (arrayOfByte1[1][i][j] = arrayOfByte1[0][i][j] = (byte)localb.jdMethod_if(6));
          break;
        case 3: 
          arrayOfByte1[0][i][j] = ((byte)localb.jdMethod_if(6));
          arrayOfByte1[2][i][j] = (arrayOfByte1[1][i][j] = (byte)localb.jdMethod_if(6));
        }
      }
    }
  }
  
  private void jdMethod_if()
  {
    byte[][] arrayOfByte = this.F.bs[0];
    byte[][][] arrayOfByte1 = this.F.bp;
    f localf = this.F.bA;
    int i6 = this.F.bn.k;
    int i7 = this.G;
    int i8 = this.J;
    if (i7 > i8) {
      i7 = i8;
    }
    if (i6 == 1) {
      i7 = 0;
    }
    for (int i = 0; i < 12; i++)
    {
      int i9 = i / 4;
      int i10 = 3 * (i - 4 * i9);
      float[][][] arrayOfFloat = this.F.bu[i9];
      int n;
      int i1;
      int m;
      int i3;
      int i4;
      int i5;
      int i2;
      byte[] arrayOfByte2;
      int i11;
      float f5;
      float f4;
      float f6;
      float f7;
      float f3;
      float f2;
      float f1;
      for (int j = 0; j < i7; j++) {
        for (int k = 0; k < 2; k++) {
          if (arrayOfByte[k][j] != 0)
          {
            n = localf.jdField_if[j][arrayOfByte[k][j]];
            i1 = Tables.t_alloc[n];
            m = localf.jdField_for[j][arrayOfByte[k][j]];
            if (m > 0)
            {
              i3 = this.F.bv.jdMethod_if(m);
              i4 = this.F.bv.jdMethod_if(m);
              i5 = this.F.bv.jdMethod_if(m);
            }
            else
            {
              i2 = this.F.bv.jdMethod_if(-m);
              m = -m & 0x6;
              m /= 2;
              arrayOfByte2 = this.F.bw[m];
              i11 = i2 * 3;
              i3 = arrayOfByte2[i11];
              i4 = arrayOfByte2[(i11 + 1)];
              i5 = arrayOfByte2[(i11 + 2)];
            }
            f5 = Tables.t_d[n];
            f4 = Tables.t_c[n];
            f6 = Tables.t_finv_alloc[n];
            f7 = Tables.t_multiple[arrayOfByte1[(i >> 2)][k][j]];
            f1 = f2 = f3 = f5;
            if ((i3 & i1) == 0) {
              f1 -= f4;
            }
            if ((i4 & i1) == 0) {
              f2 -= f4;
            }
            if ((i5 & i1) == 0) {
              f3 -= f4;
            }
            f1 += (i3 & i1 - 1) * f6;
            f2 += (i4 & i1 - 1) * f6;
            f3 += (i5 & i1 - 1) * f6;
            f1 *= f7;
            f2 *= f7;
            f3 *= f7;
            arrayOfFloat[i10][k][j] = f1;
            arrayOfFloat[(i10 + 1)][k][j] = f2;
            arrayOfFloat[(i10 + 2)][k][j] = f3;
          }
          else
          {
            arrayOfFloat[i10][k][j] = 0.0F;
            arrayOfFloat[(i10 + 1)][k][j] = 0.0F;
            arrayOfFloat[(i10 + 2)][k][j] = 0.0F;
          }
        }
      }
      while (j < i8)
      {
        if (arrayOfByte[0][j] != 0)
        {
          n = localf.jdField_if[j][arrayOfByte[0][j]];
          i1 = Tables.t_alloc[n];
          m = localf.jdField_for[j][arrayOfByte[0][j]];
          if (m > 0)
          {
            i3 = this.F.bv.jdMethod_if(m);
            i4 = this.F.bv.jdMethod_if(m);
            i5 = this.F.bv.jdMethod_if(m);
          }
          else
          {
            i2 = this.F.bv.jdMethod_if(-m);
            m = -m & 0x6;
            m /= 2;
            arrayOfByte2 = this.F.bw[m];
            i11 = i2 * 3;
            i3 = arrayOfByte2[i11];
            i4 = arrayOfByte2[(i11 + 1)];
            i5 = arrayOfByte2[(i11 + 2)];
          }
          f5 = Tables.t_d[n];
          f4 = Tables.t_c[n];
          f6 = Tables.t_finv_alloc[n];
          f7 = Tables.t_multiple[arrayOfByte1[(i >> 2)][0][j]];
          f1 = f2 = f3 = f5;
          if ((i3 & i1) == 0) {
            f1 -= f4;
          }
          if ((i4 & i1) == 0) {
            f2 -= f4;
          }
          if ((i5 & i1) == 0) {
            f3 -= f4;
          }
          f1 += (i3 & i1 - 1) * f6;
          f2 += (i4 & i1 - 1) * f6;
          f3 += (i5 & i1 - 1) * f6;
          f1 *= f7;
          f2 *= f7;
          f3 *= f7;
          arrayOfFloat[i10][0][j] = f1;
          arrayOfFloat[i10][1][j] = f1;
          arrayOfFloat[(i10 + 1)][0][j] = f2;
          arrayOfFloat[(i10 + 1)][1][j] = f2;
          arrayOfFloat[(i10 + 2)][0][j] = f3;
          arrayOfFloat[(i10 + 2)][1][j] = f3;
        }
        else
        {
          arrayOfFloat[i10][0][j] = 0.0F;
          arrayOfFloat[i10][1][j] = 0.0F;
          arrayOfFloat[(i10 + 1)][0][j] = 0.0F;
          arrayOfFloat[(i10 + 1)][1][j] = 0.0F;
          arrayOfFloat[(i10 + 2)][0][j] = 0.0F;
          arrayOfFloat[(i10 + 2)][1][j] = 0.0F;
        }
        j++;
      }
      while (j < 32)
      {
        arrayOfFloat[i10][0][j] = 0.0F;
        arrayOfFloat[i10][1][j] = 0.0F;
        arrayOfFloat[(i10 + 1)][0][j] = 0.0F;
        arrayOfFloat[(i10 + 1)][1][j] = 0.0F;
        arrayOfFloat[(i10 + 2)][0][j] = 0.0F;
        arrayOfFloat[(i10 + 2)][1][j] = 0.0F;
        j++;
      }
    }
  }
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mp3plugin.jar!\codecLib\mp3\j.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */