package codecLib.mp3;

class o
  extends Defines
  implements Tables
{
  protected m F;
  protected c D;
  protected PolySynthesis C = new PolySynthesis();
  private byte[] B = new byte[12];
  private int[] E = new int[12];
  
  o(m paramm, c paramc)
  {
    this.F = paramm;
    this.D = paramc;
  }
  
  protected void a(int paramInt)
  {
    int m = this.F.bn.k;
    m += this.D.ao.cK;
    int i = 0;
    this.E[i] = 4;
    this.B[(i++)] = 0;
    if (this.F.bn.k == 2)
    {
      this.E[i] = 8;
      this.B[(i++)] = 1;
    }
    if (this.D.ao.cy != 0)
    {
      this.E[i] = 16;
      this.B[(i++)] = 2;
    }
    if (this.D.ao.cL != 0)
    {
      this.E[i] = 32;
      this.B[(i++)] = 3;
      if (this.D.ao.cL == 2)
      {
        this.E[i] = 64;
        this.B[(i++)] = 4;
      }
    }
    else if (this.D.ao.cD != 0)
    {
      this.E[i] = 32768;
      this.B[(i++)] = 3;
      this.E[i] = 32768;
      this.B[(i++)] = 4;
    }
    for (int n = 0; n < this.D.ao.cF; n++)
    {
      this.E[i] = (256 << n);
      this.B[(i++)] = ((byte)(5 + n));
    }
    float[] arrayOfFloat;
    int k;
    int j;
    if (paramInt == 2)
    {
      int i1;
      for (i = 0; i < m; i++) {
        if (((this.D.ao.cz & 0x3) == 0) || ((this.E[i] & this.D.ao.cz) != 0))
        {
          arrayOfFloat = this.F.bm[this.B[i]];
          k = this.F.bo[this.B[i]];
          for (n = 0; n < 3; n++) {
            for (j = 0; j < 12; j++)
            {
              i1 = 32 * (12 * n + j);
              System.arraycopy(this.F.bu[n][j][i], 0, arrayOfFloat, (i1 >> this.F.bz) + k, 32);
              switch (this.F.bz)
              {
              case 0: 
                this.C.kernel32(arrayOfFloat, (i1 >> this.F.bz) + k, i);
                break;
              case 1: 
                this.C.kernel16(arrayOfFloat, (i1 >> this.F.bz) + k, i);
                break;
              case 2: 
                this.C.kernel8(arrayOfFloat, (i1 >> this.F.bz) + k, i);
              }
            }
          }
        }
      }
      if (this.D.aB != 0)
      {
        n = 36 >> this.D.ac;
        i1 = 1152 >> this.D.ac;
        for (i = m; i < m + this.D.ao.cF; i++) {
          if ((this.E[i] & this.D.ao.cz) != 0)
          {
            arrayOfFloat = this.F.bm[this.B[i]];
            k = this.F.bo[this.B[i]];
            for (j = 0; j < n; j++)
            {
              System.arraycopy(this.F.bu[(j / 12)][(j % 12)][i], 0, arrayOfFloat, (j * 32 >> this.F.bz) + k, 32);
              switch (this.F.bz)
              {
              case 0: 
                this.C.kernel32(arrayOfFloat, (j * 32 >> this.F.bz) + k, i);
                break;
              case 1: 
                this.C.kernel16(arrayOfFloat, (j * 32 >> this.F.bz) + k, i);
                break;
              case 2: 
                this.C.kernel8(arrayOfFloat, (j * 32 >> this.F.bz) + k, i);
              }
            }
          }
        }
      }
    }
    else
    {
      for (i = 0; i < m; i++)
      {
        arrayOfFloat = this.F.bm[i];
        k = this.F.bo[i];
        for (j = 0; j < 12; j++)
        {
          System.arraycopy(this.F.bu[this.F.bk][j][i], 0, arrayOfFloat, (j * 32 >> this.F.bz) + k, 32);
          switch (this.F.bz)
          {
          case 0: 
            this.C.kernel32(arrayOfFloat, (j * 32 >> this.F.bz) + k, i);
            break;
          case 1: 
            this.C.kernel16(arrayOfFloat, (j * 32 >> this.F.bz) + k, i);
            break;
          case 2: 
            this.C.kernel8(arrayOfFloat, (j * 32 >> this.F.bz) + k, i);
          }
        }
      }
    }
  }
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mp3plugin.jar!\codecLib\mp3\o.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */