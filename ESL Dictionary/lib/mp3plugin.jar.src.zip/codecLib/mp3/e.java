package codecLib.mp3;

import java.util.ResourceBundle;

class e
{
  static String a(String paramString)
  {
    return ResourceBundle.getBundle("com.sun.medialib.codec.mpad.MPADExceptionStrings").getString(paramString);
  }
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\mp3plugin.jar!\codecLib\mp3\e.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */