package com.ibm.media.content.application.mvr;

import com.ibm.media.ShowDocumentEvent;
import com.sun.media.BasicController;
import hm20masterorig;
import java.net.URL;
import javax.media.StopByRequestEvent;

public class Master$MasterContrAdaptor
  extends BasicController
{
  public final Master bf;
  
  public static void b6(MasterContrAdaptor paramMasterContrAdaptor, URL paramURL, String paramString)
  {
    paramMasterContrAdaptor.b7(paramURL, paramString);
  }
  
  public Master$MasterContrAdaptor(Master paramMaster)
  {
    this.bf = paramMaster;
    this.bf = paramMaster;
  }
  
  private void b7(URL paramURL, String paramString)
  {
    sendEvent(new ShowDocumentEvent(this, paramURL, paramString));
  }
  
  public void stopAtTime() {}
  
  public void doClose()
  {
    this.bf.destroy();
  }
  
  public void doStop()
  {
    this.bf.stop();
  }
  
  public synchronized void stop()
  {
    super.stop();
    sendEvent(new StopByRequestEvent(this, 600, 500, getTargetState(), getMediaTime()));
  }
  
  public void doStart()
  {
    this.bf.start();
  }
  
  public void abortPrefetch() {}
  
  public boolean doPrefetch()
  {
    Master.b6(this.bf);
    Object[] arrayOfObject = new Object[5];
    arrayOfObject[0] = this.bf.mainApplet;
    Master localMaster1 = this.bf;
    arrayOfObject[1] = localMaster1.mvrURLFILE;
    Master localMaster2 = this.bf;
    arrayOfObject[2] = localMaster2.mvrFileForMaster;
    arrayOfObject[3] = new Long(System.currentTimeMillis());
    Master localMaster3 = this.bf;
    arrayOfObject[4] = localMaster3.trackDefs;
    this.bf.equals(arrayOfObject);
    return true;
  }
  
  public void abortRealize() {}
  
  public boolean doRealize()
  {
    return true;
  }
  
  public boolean isConfigurable()
  {
    return false;
  }
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\content\application\mvr\Master$MasterContrAdaptor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */