/*      */ package com.ibm.media.parser.video;
/*      */ 
/*      */ import com.ms.security.PermissionID;
/*      */ import com.ms.security.PolicyEngine;
/*      */ import com.sun.media.CircularBuffer;
/*      */ import com.sun.media.JMFSecurity;
/*      */ import com.sun.media.JMFSecurityManager;
/*      */ import com.sun.media.format.WavAudioFormat;
/*      */ import com.sun.media.parser.BasicPullParser;
/*      */ import com.sun.media.util.LoopThread;
/*      */ import com.sun.media.util.jdk12;
/*      */ import java.awt.Dimension;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Method;
/*      */ import javax.media.BadHeaderException;
/*      */ import javax.media.Buffer;
/*      */ import javax.media.Duration;
/*      */ import javax.media.Format;
/*      */ import javax.media.IncompatibleSourceException;
/*      */ import javax.media.Time;
/*      */ import javax.media.Track;
/*      */ import javax.media.TrackListener;
/*      */ import javax.media.format.AudioFormat;
/*      */ import javax.media.format.VideoFormat;
/*      */ import javax.media.protocol.ContentDescriptor;
/*      */ import javax.media.protocol.DataSource;
/*      */ import javax.media.protocol.PullSourceStream;
/*      */ import javax.media.protocol.Seekable;
/*      */ import javax.media.protocol.SourceStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MpegParser
/*      */   extends BasicPullParser
/*      */ {
/*   56 */   boolean saveOutputFlag = false;
/*   57 */   String AoutName = "Audio.mpg";
/*   58 */   String VoutName = "Video.mpg";
/*      */   
/*      */   FileOutputStream aout;
/*      */   FileOutputStream vout;
/*   62 */   boolean throwOutputFlag = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   69 */   boolean hideAudioTracks = false;
/*   70 */   boolean hideVideoTracks = false;
/*      */   
/*      */   static final long NO_PTS_VAL = -3333333L;
/*      */   
/*      */   private static final float EPSILON_PTS = 45000.0F;
/*      */   
/*      */   private static final float EPSILON_NS = 5.0E8F;
/*      */   
/*      */   private static final long PRE_ROLLING_DELTA_NS = 500000000L;
/*      */   
/*      */   private static final byte UNKNOWN_TYPE = 0;
/*      */   
/*      */   private static final byte AUDIO_TYPE = 1;
/*      */   
/*      */   private static final byte VIDEO_TYPE = 2;
/*      */   
/*      */   private static final byte SYS11172_TYPE = 3;
/*      */   
/*      */   private static final int AUDIO_TRACK_BUF_SIZE = 100000;
/*      */   
/*      */   private static final int VIDEO_TRACK_BUF_SIZE = 200000;
/*      */   
/*      */   private static final int PACK_START_CODE = 442;
/*      */   
/*      */   private static final int SYSTEM_HEADER_START_CODE = 443;
/*      */   
/*      */   private static final int PACKET_START_CODE_24 = 1;
/*      */   
/*      */   private static final int END_CODE = 441;
/*      */   
/*      */   private static final int MIN_STREAM_CODE = 188;
/*      */   
/*      */   private static final int MAX_STREAM_CODE = 255;
/*      */   
/*      */   private static final int PRIVATE_STREAM2_CODE = 191;
/*      */   
/*      */   private static final int VIDEO_PICTURE_START_CODE = 256;
/*      */   
/*      */   private static final int VIDEO_SEQUENCE_HEADER_CODE = 435;
/*      */   
/*      */   private static final int VIDEO_GROUP_START_CODE = 440;
/*      */   private static final int MAX_AUDIO_STREAMS = 32;
/*      */   private static final int MAX_VIDEO_STREAMS = 16;
/*      */   private static final int MAX_NUM_STREAMS = 48;
/*      */   private static final int MIN_AUDIO_ID = 0;
/*      */   private static final int MAX_AUDIO_ID = 31;
/*      */   private static final int MIN_VIDEO_ID = 32;
/*      */   private static final int MAX_VIDEO_ID = 47;
/*  118 */   private static int MAX_TRACKS_SUPPORTED = 48;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  124 */   private static ContentDescriptor[] supportedFormat = { new ContentDescriptor("audio.mpeg"), new ContentDescriptor("video.mpeg"), new ContentDescriptor("audio.mpeg") };
/*      */   
/*      */ 
/*      */ 
/*  128 */   private PullSourceStream stream = null;
/*  129 */   private TrackList[] trackList = new TrackList[MAX_TRACKS_SUPPORTED];
/*  130 */   private Track[] tracks = null;
/*  131 */   private Track[] videoTracks = null;
/*  132 */   private Track[] audioTracks = null;
/*  133 */   private int videoCount = 0;
/*  134 */   private int audioCount = 0;
/*  135 */   private int numSupportedTracks = 0;
/*  136 */   private int numTracks = 0;
/*  137 */   private int numPackets = 0;
/*      */   private int initTmpBufLen;
/*      */   private byte[] initTmpStreamBuf;
/*  140 */   private byte streamType = 0;
/*  141 */   private long streamContentLength = 0L;
/*  142 */   private SystemHeader sysHeader = new SystemHeader();
/*      */   
/*      */ 
/*  145 */   private boolean sysHeaderSeen = false;
/*  146 */   boolean EOMflag = false;
/*  147 */   boolean parserErrorFlag = false;
/*  148 */   private boolean durationInitialized = false;
/*  149 */   private boolean sysPausedFlag = false;
/*  150 */   private boolean seekableStreamFlag = false;
/*  151 */   private boolean randomAccessStreamFlag = true;
/*      */   
/*      */ 
/*      */ 
/*  155 */   private static JMFSecurity jmfSecurity = null;
/*  156 */   private static boolean securityPrivelege = false;
/*  157 */   private Method[] mSecurity = new Method[1];
/*  158 */   private Class[] clSecurity = new Class[1];
/*  159 */   private Object[][] argsSecurity = new Object[1][0];
/*      */   
/*  161 */   private long startLocation = 0L;
/*      */   
/*      */   static {
/*      */     try {
/*  165 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  166 */       securityPrivelege = true;
/*      */     }
/*      */     catch (SecurityException e) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  185 */   private Time durationNs = Duration.DURATION_UNKNOWN;
/*      */   
/*  187 */   private Time lastSetPositionTime = new Time(0L);
/*      */   
/*  189 */   private long startPTS = -3333333L;
/*      */   
/*  191 */   long currentPTS = -3333333L;
/*      */   
/*  193 */   long endPTS = -3333333L;
/*      */   
/*  195 */   private long AVstartTimeNs = 0L;
/*  196 */   private long AVcurrentTimeNs = 0L;
/*  197 */   private long AVlastTimeNs = 0L;
/*  198 */   private long lastAudioNs = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  204 */   private MpegBufferThread mpThread = null;
/*      */   
/*  206 */   static int[][][] bitrates = { { { -1 }, { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, -1 }, { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, -1 }, { 0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, -1 } }, { { -1 } }, { { -1 }, { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, -1 }, { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, -1 }, { 0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, -1 } }, { { -1 }, { 0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, -1 }, { 0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, -1 }, { 0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, -1 } } };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  239 */   static int[][] samplerates = { { 11025, 12000, 8000, -1 }, { -1 }, { 22050, 24000, 16000, -1 }, { 44100, 48000, 32000, -1 } };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSource(DataSource source)
/*      */     throws IOException, IncompatibleSourceException
/*      */   {
/*  250 */     super.setSource(source);
/*  251 */     this.stream = ((PullSourceStream)this.streams[0]);
/*  252 */     this.streamContentLength = this.stream.getContentLength();
/*  253 */     this.seekableStreamFlag = (this.streams[0] instanceof Seekable);
/*  254 */     if (!this.seekableStreamFlag)
/*  255 */       throw new IncompatibleSourceException("Mpeg Stream is not Seekable");
/*  256 */     this.randomAccessStreamFlag = ((this.seekableStreamFlag) && (((Seekable)this.streams[0]).isRandomAccess()));
/*      */   }
/*      */   
/*      */   public ContentDescriptor[] getSupportedInputContentDescriptors()
/*      */   {
/*  261 */     return supportedFormat;
/*      */   }
/*      */   
/*      */   public void start() throws IOException
/*      */   {
/*  266 */     super.start();
/*  267 */     this.sysPausedFlag = false;
/*  268 */     if (this.mpThread != null)
/*  269 */       this.mpThread.start();
/*      */   }
/*      */   
/*      */   public void stop() {
/*  273 */     super.stop();
/*  274 */     this.sysPausedFlag = true;
/*  275 */     if (this.mpThread != null) {
/*  276 */       this.mpThread.pause();
/*      */     }
/*      */     
/*      */ 
/*  280 */     for (int i = 0; i < this.numTracks; i++) {
/*  281 */       if ((this.tracks[i] != null) && (this.tracks[i].isEnabled())) {
/*  282 */         TrackList info = ((MediaTrack)this.tracks[i]).getTrackInfo();
/*  283 */         info.releaseReadFrame();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void close()
/*      */   {
/*  290 */     stop();
/*  291 */     flushInnerBuffers();
/*  292 */     super.close();
/*  293 */     if (this.mpThread != null) {
/*  294 */       this.mpThread.kill();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Track[] getTracks()
/*      */     throws IOException, BadHeaderException
/*      */   {
/*  306 */     if (this.streamType == 3) {
/*  307 */       if ((this.hideAudioTracks) && (this.videoTracks != null)) {
/*  308 */         return this.videoTracks;
/*      */       }
/*  310 */       if ((this.hideVideoTracks) && (this.audioTracks != null)) {
/*  311 */         return this.audioTracks;
/*      */       }
/*      */     }
/*  314 */     if (this.tracks != null) {
/*  315 */       return this.tracks;
/*      */     }
/*      */     try
/*      */     {
/*  319 */       this.initTmpBufLen = 100000;
/*      */       
/*  321 */       this.initTmpStreamBuf = new byte[this.initTmpBufLen];
/*      */       
/*      */ 
/*  324 */       this.initTmpBufLen = detectStreamType(this.initTmpStreamBuf);
/*      */       
/*      */ 
/*  327 */       switch (this.streamType) {
/*      */       case 1: 
/*      */       case 2: 
/*  330 */         initTrackAudioVideoOnly();
/*  331 */         break;
/*      */       case 3: 
/*  333 */         initTrackSystemStream();
/*  334 */         break;
/*      */       case 0: 
/*      */       default: 
/*  337 */         throw new BadHeaderException("Couldn't detect stream type");
/*      */       }
/*      */       
/*      */       
/*  341 */       initDuration();
/*      */       
/*  343 */       if (this.saveOutputFlag) {
/*  344 */         this.aout = new FileOutputStream(this.AoutName);
/*  345 */         this.vout = new FileOutputStream(this.VoutName);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  350 */       if (this.streamType == 3) {
/*  351 */         if (jmfSecurity != null) {
/*  352 */           String permission = null;
/*      */           try {
/*  354 */             if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  355 */               permission = "thread";
/*  356 */               jmfSecurity.requestPermission(this.mSecurity, this.clSecurity, this.argsSecurity, 16);
/*      */               
/*  358 */               this.mSecurity[0].invoke(this.clSecurity[0], this.argsSecurity[0]);
/*      */               
/*  360 */               permission = "thread group";
/*  361 */               jmfSecurity.requestPermission(this.mSecurity, this.clSecurity, this.argsSecurity, 32);
/*      */               
/*  363 */               this.mSecurity[0].invoke(this.clSecurity[0], this.argsSecurity[0]);
/*  364 */             } else if (jmfSecurity.getName().startsWith("internet")) {
/*  365 */               PolicyEngine.checkPermission(PermissionID.THREAD);
/*  366 */               PolicyEngine.assertPermission(PermissionID.THREAD);
/*      */             }
/*      */             
/*      */ 
/*      */           }
/*      */           catch (Throwable e)
/*      */           {
/*  373 */             securityPrivelege = false;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  379 */         if ((jmfSecurity != null) && (jmfSecurity.getName().startsWith("jdk12"))) {
/*      */           try {
/*  381 */             Constructor cons = jdk12CreateThreadAction.cons;
/*  382 */             this.mpThread = ((MpegBufferThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { MpegBufferThread.class }) }));
/*      */ 
/*      */ 
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/*      */ 
/*      */ 
/*  390 */             System.err.println("MpegParser: Caught Exception " + e);
/*      */           }
/*      */         } else {
/*  393 */           this.mpThread = new MpegBufferThread();
/*      */         }
/*  395 */         if (this.mpThread != null) {
/*  396 */           this.mpThread.setParser(this);
/*  397 */           this.mpThread.start();
/*      */         }
/*  399 */         if ((this.saveOutputFlag) || (this.throwOutputFlag)) {
/*      */           try {
/*  401 */             Thread.sleep(30000L);
/*      */           }
/*      */           catch (InterruptedException e) {}
/*      */         }
/*      */       }
/*      */       
/*  407 */       if (this.streamType == 3) {
/*  408 */         if (this.hideAudioTracks) {
/*  409 */           return this.videoTracks;
/*      */         }
/*  411 */         if (this.hideVideoTracks) {
/*  412 */           return this.audioTracks;
/*      */         }
/*      */       }
/*  415 */       return this.tracks;
/*      */     }
/*      */     catch (BadDataException e) {
/*  418 */       this.parserErrorFlag = true;
/*  419 */       throw new BadHeaderException("Bad data");
/*      */     } catch (BadHeaderException e) {
/*  421 */       this.parserErrorFlag = true;
/*  422 */       throw e;
/*      */     } catch (IOException e) {
/*  424 */       updateEOMState();
/*  425 */       this.EOMflag = true;
/*  426 */       throw e;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean isValidMp3Header(int code)
/*      */   {
/*  433 */     return ((code >>> 21 & 0x7FF) == 2047) && ((code >>> 19 & 0x3) != 1) && ((code >>> 17 & 0x3) != 0) && ((code >>> 12 & 0xF) != 0) && ((code >>> 12 & 0xF) != 15) && ((code >>> 10 & 0x3) != 3) && ((code & 0x3) != 2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int detectStreamType(byte[] streamBuf)
/*      */     throws IOException
/*      */   {
/*  449 */     int i = 0;int videoCount = 0;int audioCount = 0;
/*  450 */     boolean found = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  458 */     if (this.streamType != 0) {
/*  459 */       return 0;
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  464 */       readBytes(this.stream, streamBuf, 4);
/*      */       label241:
/*  466 */       do { int code = (streamBuf[i] & 0xFF) << 24 | (streamBuf[(i + 1)] & 0xFF) << 16 | (streamBuf[(i + 2)] & 0xFF) << 8 | streamBuf[(i + 3)] & 0xFF;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  471 */         switch (code)
/*      */         {
/*      */ 
/*      */         case 442: 
/*  475 */           i++;
/*  476 */           readBytes(this.stream, streamBuf, i + 3, 1);
/*  477 */           if ((streamBuf[(i + 3)] & 0xFFFFFFF1) != 33) break label241;
/*  478 */           this.streamType = 3;
/*  479 */           found = true; break;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         case 435: 
/*  486 */           if (i == 0) {
/*  487 */             this.streamType = 2;
/*  488 */             found = true;
/*      */           }
/*      */         case 256: 
/*      */         case 440: 
/*  492 */           videoCount++;
/*  493 */           break;
/*      */         }
/*      */         
/*      */         
/*  497 */         if (((code & 0xFFF00000) == -1048576) && ((code & 0x60000) != 0) && (isValidMp3Header(code)))
/*      */         {
/*      */ 
/*  500 */           audioCount++;
/*      */           
/*  502 */           this.streamType = 1;
/*  503 */           found = true;
/*      */           
/*  505 */           this.startLocation = i;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  511 */         i++;
/*  512 */         readBytes(this.stream, streamBuf, i + 3, 1);
/*  465 */         if (found) break; } while (i < streamBuf.length - 5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  516 */       if (this.streamType == 0) {
/*  517 */         if (videoCount > 0) {
/*  518 */           this.streamType = 2;
/*      */         }
/*  520 */         else if (audioCount > 0) {
/*  521 */           this.streamType = 1;
/*      */         }
/*      */       }
/*  524 */       updateEOMState();
/*  525 */       this.EOMflag = true;
/*  526 */       throw e;
/*      */     }
/*      */     
/*      */ 
/*  530 */     if (this.streamType == 0) {
/*  531 */       if (videoCount > 4) {
/*  532 */         this.streamType = 2;
/*      */       }
/*  534 */       else if (audioCount > 20) {
/*  535 */         this.streamType = 1;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  540 */     if ((this.seekableStreamFlag) && (this.streamType == 1)) {
/*  541 */       int duration = -1;
/*      */       
/*  543 */       Seekable s = (Seekable)this.stream;
/*  544 */       long currentPos = s.tell();
/*      */       
/*      */ 
/*  547 */       s.seek(this.startLocation);
/*      */       
/*  549 */       int frameHeader = readInt(this.stream);
/*      */       
/*  551 */       int h_id = frameHeader >>> 19 & 0x3;
/*      */       
/*  553 */       int h_layer = frameHeader >>> 17 & 0x3;
/*      */       
/*  555 */       int h_bitrate = frameHeader >>> 12 & 0xF;
/*      */       
/*  557 */       int h_samplerate = frameHeader >>> 10 & 0x3;
/*      */       
/*  559 */       int h_padding = frameHeader >>> 9 & 0x1;
/*      */       
/*  561 */       int h_mode = frameHeader >>> 6 & 0x3;
/*      */       
/*  563 */       int bitrate = bitrates[h_id][h_layer][h_bitrate];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  568 */       int offset = h_mode != 3 ? 21 : (h_id & 0x1) == 1 ? 21 : h_mode != 3 ? 36 : 13;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  575 */       s.seek(offset);
/*  576 */       String hdr = readString(this.stream);
/*  577 */       if (hdr.equals("Xing")) {
/*  578 */         int flags = readInt(this.stream);
/*  579 */         int frames = readInt(this.stream);
/*  580 */         int bytes = readInt(this.stream);
/*  581 */         int samplerate = samplerates[h_id][h_samplerate];
/*  582 */         int frameSize = 144000 * bitrate / samplerate + h_padding;
/*  583 */         duration = frameSize * frames / (bitrate * 125);
/*  584 */         if (duration > 0) {
/*  585 */           this.durationInitialized = true;
/*  586 */           this.durationNs = new Time(duration);
/*      */         }
/*      */       }
/*  589 */       s.seek(currentPos);
/*      */     }
/*  591 */     return i + 4;
/*      */   }
/*      */   
/*      */ 
/*      */   private void initTrackAudioVideoOnly()
/*      */     throws IOException, BadHeaderException, BadDataException
/*      */   {
/*  598 */     int itmp = 0;
/*      */     
/*  600 */     this.numTracks = 1;
/*  601 */     this.tracks = new Track[1];
/*  602 */     this.trackList[0] = new TrackList(null);
/*      */     
/*      */ 
/*  605 */     int possibleLen = this.streamType == 1 ? 100000 : 200000;
/*      */     
/*  607 */     if (this.initTmpBufLen < possibleLen) {
/*  608 */       if (possibleLen > this.initTmpStreamBuf.length) {
/*  609 */         byte[] tmpBuf2 = new byte[possibleLen];
/*  610 */         System.arraycopy(this.initTmpStreamBuf, 0, tmpBuf2, 0, this.initTmpBufLen);
/*  611 */         this.initTmpStreamBuf = tmpBuf2;
/*      */       }
/*      */       try {
/*  614 */         itmp = readBytes(this.stream, this.initTmpStreamBuf, this.initTmpBufLen, possibleLen - this.initTmpBufLen);
/*      */       } catch (IOException e) {
/*  616 */         updateEOMState();
/*  617 */         this.EOMflag = true;
/*      */       }
/*  619 */       this.initTmpBufLen += itmp;
/*      */     }
/*  621 */     TrackList trackInfo = this.trackList[0];
/*      */     do
/*      */     {
/*  624 */       extractStreamInfo(this.initTmpStreamBuf, 0, this.initTmpBufLen, true);
/*  625 */       if (trackInfo.infoFlag) {
/*      */         break;
/*      */       }
/*      */       try
/*      */       {
/*  630 */         itmp = readBytes(this.stream, this.initTmpStreamBuf, possibleLen);
/*      */       } catch (IOException e) {
/*  632 */         updateEOMState();
/*  633 */         this.EOMflag = true;
/*  634 */         break;
/*      */       }
/*  636 */       this.initTmpBufLen = itmp;
/*  637 */     } while (!trackInfo.infoFlag);
/*      */     
/*      */ 
/*  640 */     if (!trackInfo.infoFlag) {
/*  641 */       this.numTracks = 0;
/*  642 */       this.tracks = null;
/*  643 */       throw new BadHeaderException("Sorry, No tracks found");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  648 */     ((Seekable)this.stream).seek(0L);
/*  649 */     this.initTmpBufLen = 0;
/*  650 */     this.EOMflag = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void initTrackSystemStream()
/*      */     throws IOException, BadHeaderException, BadDataException
/*      */   {
/*  664 */     this.tracks = new Track[MAX_TRACKS_SUPPORTED];
/*  665 */     for (int i = 0; i < this.tracks.length; i++) {
/*  666 */       this.tracks[i] = null;
/*      */     }
/*  668 */     for (i = 0; i < this.trackList.length; i++) {
/*  669 */       this.trackList[i] = null;
/*      */     }
/*      */     
/*      */ 
/*  673 */     mpegSystemParseBitstream(false, 0L, true, -3333333L);
/*      */     
/*      */ 
/*  676 */     if (this.numTracks == 0) {
/*  677 */       throw new BadHeaderException("Sorry, No tracks found");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  682 */     Track[] tmpTracks = new Track[this.numTracks];
/*  683 */     for (i = 0; i < this.numTracks; i++) {
/*  684 */       tmpTracks[i] = this.tracks[i];
/*      */     }
/*  686 */     this.tracks = tmpTracks;
/*      */     
/*      */ 
/*      */ 
/*  690 */     if (this.hideAudioTracks)
/*      */     {
/*      */       TrackList trackInfo;
/*      */       
/*  694 */       for (i = 0; i < this.numTracks; i++) {
/*  695 */         if (this.tracks[i] != null) {
/*  696 */           trackInfo = ((MediaTrack)this.tracks[i]).getTrackInfo();
/*  697 */           if (trackInfo.trackType == 2) {
/*  698 */             this.videoCount += 1;
/*      */           }
/*      */         }
/*      */       }
/*  702 */       if (this.videoCount == 0) {
/*  703 */         throw new BadHeaderException("Sorry, No video tracks found");
/*      */       }
/*  705 */       this.videoTracks = new Track[this.videoCount];
/*      */       
/*  707 */       i = 0; for (int v = 0; i < this.numTracks; i++) {
/*  708 */         if (this.tracks[i] != null) {
/*  709 */           trackInfo = ((MediaTrack)this.tracks[i]).getTrackInfo();
/*  710 */           if (trackInfo.trackType == 2) {
/*  711 */             this.videoTracks[v] = this.tracks[i];
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  716 */     if (this.hideVideoTracks)
/*      */     {
/*      */       TrackList trackInfo;
/*      */       
/*  720 */       for (i = 0; i < this.numTracks; i++) {
/*  721 */         if (this.tracks[i] != null) {
/*  722 */           trackInfo = ((MediaTrack)this.tracks[i]).getTrackInfo();
/*  723 */           if (trackInfo.trackType == 1) {
/*  724 */             this.audioCount += 1;
/*      */           }
/*      */         }
/*      */       }
/*  728 */       if (this.audioCount == 0) {
/*  729 */         throw new BadHeaderException("Sorry, No video tracks found");
/*      */       }
/*  731 */       this.audioTracks = new Track[this.audioCount];
/*      */       
/*  733 */       i = 0; for (int v = 0; i < this.numTracks; i++) {
/*  734 */         if (this.tracks[i] != null) {
/*  735 */           trackInfo = ((MediaTrack)this.tracks[i]).getTrackInfo();
/*  736 */           if (trackInfo.trackType == 1) {
/*  737 */             this.audioTracks[v] = this.tracks[i];
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */   {
/*  750 */     return "Parser for MPEG-1 file format";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private long convPTStoNanoseconds(long val)
/*      */   {
/*  758 */     return val * 100000L / 9L;
/*      */   }
/*      */   
/*      */   private long convNanosecondsToPTS(long val)
/*      */   {
/*  763 */     return val * 9L / 100000L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private long convBytesToTimeAV(long bytes)
/*      */   {
/*  770 */     if (this.trackList[0] == null)
/*  771 */       return 0L;
/*      */     long time;
/*  773 */     if (this.streamType == 1) {
/*  774 */       if (((Audio)this.trackList[0].media).bitRate == 0) {
/*  775 */         time = 0L;
/*      */       } else {
/*  777 */         time = (bytes << 3) / ((Audio)this.trackList[0].media).bitRate;
/*  778 */         time *= 1000000L;
/*      */       }
/*      */     }
/*  781 */     else if (((Video)this.trackList[0].media).bitRate == 0) {
/*  782 */       time = 0L;
/*      */     } else {
/*  784 */       time = (bytes << 3) / ((Video)this.trackList[0].media).bitRate;
/*  785 */       time *= 1000000000L;
/*      */     }
/*      */     
/*  788 */     return time;
/*      */   }
/*      */   
/*      */ 
/*      */   private long convTimeToBytesAV(long time)
/*      */   {
/*      */     long bytes;
/*  795 */     if (this.streamType == 1) {
/*  796 */       bytes = (time >> 3) * ((Audio)this.trackList[0].media).bitRate;
/*  797 */       bytes /= 1000000L;
/*      */     } else {
/*  799 */       bytes = (time >> 3) * ((Video)this.trackList[0].media).bitRate;
/*  800 */       bytes /= 1000000000L;
/*      */     }
/*  802 */     return bytes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getDuration()
/*      */   {
/*  813 */     if (this.durationInitialized) {
/*  814 */       return this.durationNs;
/*      */     }
/*      */     
/*  817 */     if (this.EOMflag)
/*      */     {
/*      */ 
/*  820 */       this.durationInitialized = true;
/*      */     }
/*  822 */     return this.durationNs;
/*      */   }
/*      */   
/*      */ 
/*      */   private void initDuration()
/*      */   {
/*  828 */     if (this.streamContentLength != -1L) {
/*  829 */       if (this.streamType == 3) {
/*  830 */         if (this.randomAccessStreamFlag) {
/*  831 */           initDurationSystemSeekableRA();
/*      */         }
/*      */       } else {
/*  834 */         updateDurationAudioVideoOnly();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void updateDurationAudioVideoOnly()
/*      */   {
/*  842 */     if (this.durationInitialized)
/*  843 */       return;
/*  844 */     this.AVstartTimeNs = 0L;
/*  845 */     this.AVcurrentTimeNs = 0L;
/*  846 */     this.AVlastTimeNs = convBytesToTimeAV(this.streamContentLength);
/*  847 */     this.durationNs = new Time(this.AVlastTimeNs - this.AVstartTimeNs);
/*  848 */     this.durationInitialized = true;
/*      */   }
/*      */   
/*      */   private void initDurationSystemSeekableRA()
/*      */   {
/*  853 */     long baseLocation = 0L;
/*  854 */     int saveNumPackets = this.numPackets;
/*  855 */     boolean saveEOMflag = this.EOMflag;
/*      */     
/*  857 */     baseLocation = ((Seekable)this.stream).tell();
/*      */     
/*  859 */     if (this.startPTS == -3333333L) {
/*  860 */       this.EOMflag = false;
/*  861 */       ((Seekable)this.stream).seek(0L);
/*      */       try {
/*  863 */         mpegSystemParseBitstream(true, 65536L, false, -3333333L);
/*      */       }
/*      */       catch (Exception e) {}
/*      */     }
/*  867 */     if (this.startPTS == -3333333L) {
/*  868 */       this.startPTS = 0L;
/*      */     }
/*      */     
/*      */ 
/*  872 */     if (this.endPTS == -3333333L) {
/*  873 */       this.EOMflag = false;
/*  874 */       this.currentPTS = -3333333L;
/*  875 */       ltmp = this.streamContentLength - 131072L;
/*  876 */       if (ltmp < 0L) {
/*  877 */         ltmp = 0L;
/*      */       }
/*  879 */       ((Seekable)this.stream).seek(ltmp);
/*      */       try {
/*  881 */         mpegSystemParseBitstream(true, 131072L, false, -3333333L);
/*      */       }
/*      */       catch (Exception e) {}
/*  884 */       this.endPTS = this.currentPTS;
/*      */     }
/*  886 */     if (this.endPTS == -3333333L) {
/*  887 */       this.endPTS = this.startPTS;
/*      */     }
/*      */     
/*      */ 
/*  891 */     long ltmp = this.endPTS - this.startPTS;
/*  892 */     if (ltmp < 0L) {
/*  893 */       ltmp = 0L;
/*  894 */       this.parserErrorFlag = true;
/*      */     }
/*  896 */     this.durationNs = new Time(convPTStoNanoseconds(ltmp));
/*  897 */     this.lastSetPositionTime = new Time(convPTStoNanoseconds(this.startPTS));
/*  898 */     ((Seekable)this.stream).seek(baseLocation);
/*  899 */     this.EOMflag = saveEOMflag;
/*  900 */     this.numPackets = saveNumPackets;
/*  901 */     this.durationInitialized = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void updateTrackEOM()
/*      */   {
/*  909 */     for (int i = 0; i < this.trackList.length; i++) {
/*  910 */       if (this.trackList[i] != null) {
/*  911 */         this.trackList[i].generateEOM();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void updateEOMState()
/*      */   {
/*  930 */     if (!this.durationInitialized) {
/*  931 */       if (this.streamContentLength == -1L) {
/*  932 */         this.streamContentLength = getLocation(this.stream);
/*      */       }
/*      */       
/*      */ 
/*  936 */       if (this.streamType == 3) {
/*  937 */         if (this.startPTS == -3333333L) {
/*  938 */           this.startPTS = 0L;
/*      */         }
/*  940 */         if (this.endPTS == -3333333L) {
/*  941 */           this.endPTS = this.currentPTS;
/*      */         }
/*  943 */         if (this.endPTS == -3333333L) {
/*  944 */           this.endPTS = this.startPTS;
/*      */         }
/*  946 */         long ltmp = this.endPTS - this.startPTS;
/*  947 */         if (ltmp < 0L) {
/*  948 */           ltmp = 0L;
/*  949 */           this.parserErrorFlag = true;
/*      */         }
/*  951 */         this.durationNs = new Time(convPTStoNanoseconds(ltmp));
/*  952 */         this.durationInitialized = true;
/*      */       } else {
/*  954 */         updateDurationAudioVideoOnly();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time getMediaTime()
/*      */   {
/*      */     Time mtime;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  977 */     if (this.streamType == 3) {
/*  978 */       if (this.currentPTS == -3333333L) {
/*  979 */         mtime = new Time(0L);
/*      */       } else {
/*  981 */         mtime = new Time(convPTStoNanoseconds(this.currentPTS - this.startPTS));
/*      */       }
/*      */     }
/*      */     else {
/*  985 */       this.AVcurrentTimeNs = convBytesToTimeAV(getLocation(this.stream));
/*  986 */       mtime = new Time(this.AVcurrentTimeNs);
/*      */     }
/*  988 */     return mtime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time setPosition(Time where, int rounding)
/*      */   {
/*  997 */     Time newTime = null;
/*      */     
/*  999 */     if ((!this.durationInitialized) || (this.durationNs == Duration.DURATION_UNKNOWN)) {
/* 1000 */       return new Time(0L);
/*      */     }
/*      */     
/* 1003 */     Time preWhere = new Time(where.getNanoseconds() - 500000000L);
/*      */     
/*      */     long newTimeNs;
/*      */     
/* 1007 */     if (this.streamType == 3)
/*      */     {
/* 1009 */       flushInnerBuffers();
/*      */       
/*      */ 
/* 1012 */       long preWherePTS = convNanosecondsToPTS(preWhere.getNanoseconds());
/* 1013 */       preWherePTS += this.startPTS;
/* 1014 */       long wherePTS = convNanosecondsToPTS(where.getNanoseconds());
/* 1015 */       wherePTS += this.startPTS;
/* 1016 */       long newPTS = setPositionSystemSeekableRA(preWherePTS, wherePTS);
/*      */       
/* 1018 */       newTimeNs = convPTStoNanoseconds(newPTS);
/* 1019 */       this.lastAudioNs = newTimeNs;
/*      */     } else {
/* 1021 */       newTimeNs = setPositionAudioVideoOnly(preWhere.getNanoseconds(), where.getNanoseconds());
/*      */       
/* 1023 */       this.lastAudioNs = newTimeNs;
/*      */     }
/*      */     
/* 1026 */     newTime = new Time(newTimeNs);
/*      */     
/*      */ 
/* 1029 */     if (this.lastSetPositionTime.getNanoseconds() == newTimeNs)
/* 1030 */       newTimeNs += 1L;
/* 1031 */     this.lastSetPositionTime = new Time(newTimeNs);
/*      */     
/* 1033 */     this.EOMflag = false;
/* 1034 */     this.parserErrorFlag = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1039 */     return newTime;
/*      */   }
/*      */   
/*      */ 
/*      */   private long setPositionAudioVideoOnly(long where, long origWhere)
/*      */   {
/*      */     long newTime;
/* 1046 */     if ((float)origWhere <= (float)this.AVstartTimeNs + 5.0E8F) {
/* 1047 */       newTime = this.AVstartTimeNs;
/* 1048 */       ((Seekable)this.stream).seek(0L);
/*      */     }
/* 1050 */     else if ((float)origWhere >= (float)this.AVlastTimeNs - 5.0E8F) {
/* 1051 */       newTime = this.AVlastTimeNs - this.AVstartTimeNs;
/* 1052 */       ((Seekable)this.stream).seek(this.streamContentLength);
/*      */     }
/*      */     else {
/* 1055 */       newTime = where;
/* 1056 */       long pos = convTimeToBytesAV(where);
/* 1057 */       ((Seekable)this.stream).seek(pos);
/*      */     }
/*      */     
/* 1060 */     return newTime;
/*      */   }
/*      */   
/*      */   private long setPositionSystemSeekableRA(long wherePTS, long origWherePTS)
/*      */   {
/* 1065 */     long newTime = -3333333L;
/* 1066 */     long lres = -1L;
/*      */     
/* 1068 */     long saveStartPTS = this.startPTS;
/* 1069 */     boolean saveEOMflag = this.EOMflag;
/* 1070 */     boolean zeroPosFlag = false;
/*      */     
/* 1072 */     if ((this.endPTS == -3333333L) || (this.startPTS == -3333333L)) {
/* 1073 */       newTime = 0L;
/* 1074 */       ((Seekable)this.stream).seek(0L);
/* 1075 */     } else if ((float)origWherePTS <= (float)this.startPTS + 45000.0F) {
/* 1076 */       newTime = 0L;
/* 1077 */       ((Seekable)this.stream).seek(0L);
/* 1078 */     } else if ((float)origWherePTS >= (float)this.endPTS - 45000.0F) {
/* 1079 */       newTime = this.endPTS - this.startPTS;
/* 1080 */       ((Seekable)this.stream).seek(this.streamContentLength);
/* 1081 */     } else if ((float)(this.endPTS - this.startPTS) < 45000.0F) {
/* 1082 */       newTime = 0L;
/* 1083 */       ((Seekable)this.stream).seek(0L);
/*      */     }
/*      */     else {
/* 1086 */       long pos = ((float)this.streamContentLength * ((float)(wherePTS - this.startPTS) / (float)(this.endPTS - this.startPTS)));
/*      */       
/* 1088 */       long step = 20480L;
/* 1089 */       pos -= step;
/* 1090 */       if (pos < 0L) {
/* 1091 */         pos = 0L;
/*      */       }
/* 1093 */       long range = this.streamContentLength - pos;
/*      */       for (;;) {
/* 1095 */         ((Seekable)this.stream).seek(pos);
/* 1096 */         this.currentPTS = -3333333L;
/* 1097 */         this.startPTS = -3333333L;
/* 1098 */         this.EOMflag = false;
/*      */         try {
/* 1100 */           lres = mpegSystemParseBitstream(true, range, false, wherePTS);
/*      */         } catch (IOException e) {
/* 1102 */           lres = -2L;
/* 1103 */           saveEOMflag = true;
/*      */         } catch (Exception e) {
/* 1105 */           lres = -1L;
/*      */         }
/* 1107 */         if (lres >= 0L) {
/* 1108 */           newTime = this.currentPTS - saveStartPTS;
/* 1109 */           ((Seekable)this.stream).seek(lres);
/* 1110 */           break; }
/* 1111 */         if (lres == -2L) {
/* 1112 */           newTime = this.endPTS - saveStartPTS;
/* 1113 */           ((Seekable)this.stream).seek(this.streamContentLength);
/* 1114 */           break;
/*      */         }
/* 1116 */         pos -= step;
/* 1117 */         if (pos <= 0L) {
/* 1118 */           if (zeroPosFlag) {
/* 1119 */             newTime = 0L;
/* 1120 */             ((Seekable)this.stream).seek(0L);
/* 1121 */             break;
/*      */           }
/* 1123 */           pos = 0L;
/* 1124 */           zeroPosFlag = true;
/*      */         }
/* 1126 */         range = 3L * step;
/*      */       }
/*      */       
/* 1129 */       this.startPTS = saveStartPTS;
/* 1130 */       this.EOMflag = saveEOMflag;
/*      */     }
/*      */     
/* 1133 */     return newTime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   long mpegSystemParseBitstream(boolean justLooking, long range, boolean justEnough, long newPTS)
/*      */     throws IOException, BadHeaderException, BadDataException
/*      */   {
/* 1154 */     byte[] buf1 = new byte[1];
/* 1155 */     int code = 0;
/* 1156 */     boolean read4 = true;boolean packFound = false;
/* 1157 */     long baseLocation = getLocation(this.stream);
/* 1158 */     long lastPacketLocation = baseLocation;
/* 1159 */     long lastLastPacketLocation = baseLocation;
/* 1160 */     long loc = baseLocation + 4L;
/* 1161 */     long lastCurrentPTS = -3333333L;
/* 1162 */     long savePTS = -3333333L;
/*      */     
/* 1164 */     while (((!this.sysPausedFlag) && (!this.EOMflag)) || (justLooking) || (justEnough)) {
/* 1165 */       if ((justEnough) && (!needingMore())) {
/*      */         break;
/*      */       }
/* 1168 */       if (justLooking) {
/* 1169 */         if (getLocation(this.stream) - baseLocation > range) {
/*      */           break;
/*      */         }
/* 1172 */         if (newPTS != -3333333L) {
/* 1173 */           if (newPTS < this.startPTS) {
/* 1174 */             return -1L;
/*      */           }
/* 1176 */           if (newPTS <= this.currentPTS) {
/* 1177 */             if (newPTS == this.currentPTS) {
/* 1178 */               return lastPacketLocation;
/*      */             }
/* 1180 */             this.currentPTS = lastCurrentPTS;
/* 1181 */             return lastLastPacketLocation;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1187 */       if (read4) {
/* 1188 */         code = readInt(this.stream, true);
/*      */       } else {
/* 1190 */         readBytes(this.stream, buf1, 1);
/* 1191 */         code = code << 8 & 0xFF00 | buf1[0] & 0xFF;
/*      */       }
/*      */       
/* 1194 */       switch (code) {
/*      */       case 442: 
/* 1196 */         parsePackHeader();
/* 1197 */         read4 = true;
/* 1198 */         packFound = true;
/* 1199 */         break;
/*      */       
/*      */       case 443: 
/* 1202 */         parseSystemHeader();
/* 1203 */         read4 = true;
/* 1204 */         break;
/*      */       
/*      */       case 441: 
/* 1207 */         this.EOMflag = true;
/*      */         
/* 1209 */         if (this.endPTS == -3333333L) {
/* 1210 */           this.endPTS = this.currentPTS;
/*      */         }
/* 1212 */         if ((!justLooking) || (newPTS != -3333333L)) {
/* 1213 */           updateEOMState();
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       default: 
/* 1219 */         if ((code >> 8 == 1) && ((!justLooking) || ((packFound & justLooking))))
/*      */         {
/* 1221 */           if ((justLooking) && (newPTS != -3333333L)) {
/* 1222 */             loc = getLocation(this.stream);
/* 1223 */             savePTS = this.currentPTS;
/*      */           }
/* 1225 */           byte bval = (byte)(code & 0xFF);
/* 1226 */           parsePacket(bval, justLooking);
/* 1227 */           read4 = true;
/*      */           
/*      */ 
/* 1230 */           if ((justLooking) && (newPTS != -3333333L))
/*      */           {
/*      */ 
/*      */ 
/* 1234 */             if (savePTS != this.currentPTS) {
/* 1235 */               lastCurrentPTS = savePTS;
/* 1236 */               lastLastPacketLocation = lastPacketLocation;
/* 1237 */               lastPacketLocation = loc - 4L;
/*      */             }
/*      */           }
/*      */         }
/*      */         else {
/* 1242 */           read4 = false;
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       }
/*      */       
/*      */     }
/*      */     
/*      */ 
/* 1252 */     return this.EOMflag ? -2L : -1L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void parsePackHeader()
/*      */     throws IOException, BadDataException
/*      */   {
/* 1260 */     byte[] buf1 = new byte[1];
/*      */     
/* 1262 */     readBytes(this.stream, buf1, 1);
/* 1263 */     if ((buf1[0] & 0xFFFFFFF0) != 32) {
/* 1264 */       throw new BadDataException("invalid pack header");
/*      */     }
/*      */     
/* 1267 */     if ((buf1[0] & 0x1) != 1) {
/* 1268 */       throw new BadDataException("illegal marker bit");
/*      */     }
/*      */     
/*      */ 
/* 1272 */     skip(this.stream, 7);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseSystemHeader()
/*      */     throws IOException, BadHeaderException
/*      */   {
/* 1307 */     byte[] buf1 = new byte[1];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1312 */     int len = readShort(this.stream, true);
/*      */     
/* 1314 */     if (this.sysHeaderSeen) {
/* 1315 */       skip(this.stream, len);
/*      */     } else {
/* 1317 */       this.sysHeader.resetSystemHeader();
/* 1318 */       this.sysHeader.headerLen = len;
/*      */       
/* 1320 */       int itmp = readInt(this.stream, true);
/* 1321 */       len -= 4;
/* 1322 */       if ((itmp & 0x80000100) != -2147483392) {
/* 1323 */         throw new BadHeaderException("illegal marker bits in system header");
/*      */       }
/* 1325 */       this.sysHeader.rateBound = ((itmp & 0x7FFFFE00) >> 9);
/* 1326 */       this.sysHeader.audioBound = ((itmp & 0xFC) >> 2);
/* 1327 */       this.sysHeader.fixedFlag = ((itmp & 0x2) >> 1);
/* 1328 */       this.sysHeader.CSPSFlag = (itmp & 0x1);
/* 1329 */       readBytes(this.stream, buf1, 1);
/* 1330 */       byte bval = buf1[0];
/* 1331 */       len--;
/* 1332 */       if ((bval & 0x20) != 32) {
/* 1333 */         throw new BadHeaderException("illegal marker bits in system header");
/*      */       }
/* 1335 */       this.sysHeader.audioLockFlag = ((bval & 0x80) >> 7);
/* 1336 */       this.sysHeader.videoLockFlag = ((bval & 0x40) >> 6);
/* 1337 */       this.sysHeader.videoBound = (bval & 0x1F);
/* 1338 */       readBytes(this.stream, buf1, 1);
/* 1339 */       len--;
/* 1340 */       this.sysHeader.reserved = buf1[0];
/*      */       
/*      */ 
/* 1343 */       while (len > 1) {
/* 1344 */         readBytes(this.stream, buf1, 1);
/* 1345 */         bval = buf1[0];
/* 1346 */         len--;
/* 1347 */         if ((bval & 0xFFFFFF80) != Byte.MIN_VALUE) break;
/*      */         short stmp;
/*      */         int size;
/*      */         int i;
/* 1351 */         if (bval == -72) {
/* 1352 */           stmp = readShort(this.stream, true);
/* 1353 */           len -= 2;
/* 1354 */           if ((stmp & 0xC000) != 49152) {
/* 1355 */             throw new BadHeaderException("illegal marker bits in system header");
/*      */           }
/* 1357 */           size = stmp & 0x1FFF;
/* 1358 */           this.sysHeader.allAudioSTDFlag = true;
/* 1359 */           for (i = 0; i <= 31; i++)
/*      */           {
/*      */ 
/*      */ 
/* 1363 */             this.sysHeader.STDBufBoundScale[i] = 0;
/* 1364 */             this.sysHeader.STDBufSizeBound[i] = size;
/*      */           }
/*      */           
/*      */         }
/* 1368 */         else if (bval == -71) {
/* 1369 */           stmp = readShort(this.stream, true);
/* 1370 */           len -= 2;
/* 1371 */           if ((stmp & 0xC000) != 49152) {
/* 1372 */             throw new BadHeaderException("illegal marker bits in system header");
/*      */           }
/* 1374 */           size = stmp & 0x1FFF;
/* 1375 */           this.sysHeader.allVideoSTDFlag = true;
/* 1376 */           for (i = 32; i <= 47; i++)
/*      */           {
/*      */ 
/*      */ 
/* 1380 */             this.sysHeader.STDBufBoundScale[i] = 1;
/* 1381 */             this.sysHeader.STDBufSizeBound[i] = size;
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1386 */           if (((bval & 0xFF) < 188) || ((bval & 0xFF) > 255))
/*      */           {
/* 1388 */             throw new BadHeaderException("illegal track number in system header");
/*      */           }
/* 1390 */           int streamID = getStreamID(bval);
/* 1391 */           if ((streamID >= 0) && (streamID < 48)) {
/* 1392 */             stmp = readShort(this.stream, true);
/* 1393 */             len -= 2;
/* 1394 */             if ((stmp & 0xC000) != 49152) {
/* 1395 */               throw new BadHeaderException("illegal marker bits in system header");
/*      */             }
/* 1397 */             int scale = (stmp & 0x2000) >> 13;
/* 1398 */             size = stmp & 0x1FFF;
/* 1399 */             this.sysHeader.streamFlags[streamID] = true;
/* 1400 */             this.sysHeader.STDBufBoundScale[streamID] = scale;
/* 1401 */             this.sysHeader.STDBufSizeBound[streamID] = size;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 1406 */       if (len < 0) {
/* 1407 */         throw new BadHeaderException("illegal system header");
/*      */       }
/* 1409 */       if (len > 0) {
/* 1410 */         skip(this.stream, len);
/*      */       }
/*      */       
/* 1413 */       this.sysHeaderSeen = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parsePacket(byte bval, boolean justLooking)
/*      */     throws IOException, BadDataException
/*      */   {
/* 1425 */     int count = 0;
/* 1426 */     int STDBufSize = 0;
/* 1427 */     int STDBufScale = 0;
/* 1428 */     int numWrittenToTmpBuf = 0;
/* 1429 */     byte[] tmpBuf = null;
/* 1430 */     byte[] buf1 = new byte[1];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1435 */     if (((bval & 0xFF) < 188) || ((bval & 0xFF) > 255)) {
/* 1436 */       throw new BadDataException("invalid stream(track) number");
/*      */     }
/* 1438 */     int streamID = getStreamID(bval);
/*      */     
/*      */ 
/* 1441 */     int packetLen = readShort(this.stream, true);
/* 1442 */     buf1[0] = bval;
/*      */     
/*      */ 
/* 1445 */     if ((buf1[0] & 0xFF) != 191)
/*      */     {
/*      */       do {
/* 1448 */         readBytes(this.stream, buf1, 1);
/* 1449 */         count++;
/* 1450 */       } while (buf1[0] == -1);
/*      */       
/*      */ 
/* 1453 */       if ((buf1[0] & 0xFFFFFFC0) == 64) {
/* 1454 */         STDBufScale = (buf1[0] & 0x20) >> 5;
/* 1455 */         STDBufSize = (buf1[0] & 0x1F) << 8;
/* 1456 */         readBytes(this.stream, buf1, 1);
/* 1457 */         STDBufSize |= buf1[0];
/* 1458 */         readBytes(this.stream, buf1, 1);
/* 1459 */         count += 2;
/*      */       }
/*      */       
/*      */ 
/* 1463 */       if ((buf1[0] & 0xFFFFFFE0) == 32) {
/* 1464 */         long pts = (buf1[0] & 0xE) << 29;
/* 1465 */         pts = pts << 31 >> 31;
/* 1466 */         if ((buf1[0] & 0x1) != 1) {
/* 1467 */           throw new BadDataException("illegal marker bit");
/*      */         }
/* 1469 */         int itmp = readInt(this.stream, true);
/* 1470 */         count += 4;
/* 1471 */         if ((itmp & 0x10001) != 65537) {
/* 1472 */           throw new BadDataException("illegal marker bit");
/*      */         }
/*      */         
/* 1475 */         int itmp2 = (itmp & 0xFFFE0000) >> 2;
/* 1476 */         pts |= itmp2 & 0x3FFFFFFF;
/* 1477 */         pts |= (itmp & 0xFFFE) >> 1;
/* 1478 */         this.currentPTS = pts;
/* 1479 */         if (this.startPTS == -3333333L) {
/* 1480 */           this.startPTS = this.currentPTS;
/* 1481 */           if ((this.startPTS > 0L) && ((float)this.startPTS <= 45000.0F)) {
/* 1482 */             this.startPTS = 0L;
/*      */           }
/*      */         }
/*      */         
/* 1486 */         if ((buf1[0] & 0xFFFFFFF0) == 48) {
/* 1487 */           skip(this.stream, 5);
/* 1488 */           count += 5;
/*      */         }
/* 1490 */       } else if (buf1[0] != 15) {
/* 1491 */         throw new BadDataException("invalid packet");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1496 */     int dataSize = packetLen - count;
/* 1497 */     if (justLooking) {
/* 1498 */       skip(this.stream, dataSize);
/* 1499 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1503 */     if ((streamID < 0) || (streamID >= 48)) {
/* 1504 */       skip(this.stream, dataSize);
/*      */     } else {
/* 1506 */       if (this.trackList[streamID] == null) {
/* 1507 */         this.trackList[streamID] = new TrackList(null);
/*      */       }
/* 1509 */       TrackList trackInfo = this.trackList[streamID];
/*      */       
/*      */ 
/* 1512 */       if (!trackInfo.infoFlag) {
/* 1513 */         tmpBuf = new byte[dataSize];
/* 1514 */         numWrittenToTmpBuf = extractStreamInfo(tmpBuf, streamID, dataSize, false);
/*      */       }
/*      */       
/* 1517 */       if (!trackInfo.infoFlag) {
/* 1518 */         this.trackList[streamID] = null;
/* 1519 */         if (numWrittenToTmpBuf < dataSize) {
/* 1520 */           skip(this.stream, dataSize - numWrittenToTmpBuf);
/*      */         }
/*      */       }
/*      */       else {
/* 1524 */         if (this.startPTS == -3333333L) {
/* 1525 */           trackInfo.startPTS = this.currentPTS;
/*      */         }
/*      */         
/*      */ 
/* 1529 */         trackInfo.copyStreamDataToInnerBuffer(tmpBuf, numWrittenToTmpBuf, dataSize - numWrittenToTmpBuf, this.currentPTS);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1534 */         trackInfo.numPackets += 1;
/* 1535 */         if (dataSize > trackInfo.maxPacketSize) {
/* 1536 */           trackInfo.maxPacketSize = dataSize;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1541 */     this.numPackets += 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int extractStreamInfo(byte[] tmpBuf, int streamID, int dataLen, boolean AVOnlyState)
/*      */     throws IOException, BadDataException
/*      */   {
/* 1551 */     byte stype = 0;
/* 1552 */     TrackList trackInfo = this.trackList[streamID];
/*      */     
/*      */ 
/*      */ 
/* 1556 */     if (trackInfo.trackType == 0)
/*      */     {
/* 1558 */       stype = streamID < 32 ? 1 : AVOnlyState ? this.streamType : 2;
/*      */       
/* 1560 */       trackInfo.init(stype);
/* 1561 */       this.sysHeader.streamFlags[streamID] = true;
/* 1562 */       trackInfo.startPTS = this.currentPTS;
/*      */     }
/*      */     
/*      */     int numBytes;
/* 1566 */     if (stype == 1) {
/* 1567 */       numBytes = extractAudioInfo(tmpBuf, trackInfo, dataLen, AVOnlyState);
/*      */     } else {
/* 1569 */       numBytes = extractVideoInfo(tmpBuf, trackInfo, dataLen, AVOnlyState);
/*      */     }
/*      */     
/* 1572 */     if (trackInfo.infoFlag == true) {
/* 1573 */       if (AVOnlyState) {
/* 1574 */         this.tracks[0] = new MediaTrack(trackInfo);
/*      */       } else {
/* 1576 */         this.tracks[this.numTracks] = new MediaTrack(trackInfo);
/* 1577 */         this.numTracks += 1;
/*      */       }
/*      */     }
/*      */     
/* 1581 */     return numBytes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int extractAudioInfo(byte[] tmpBuf, TrackList trackInfo, int dataLen, boolean AVOnlyState)
/*      */     throws IOException, BadDataException
/*      */   {
/* 1597 */     Audio audio = new Audio(null);
/*      */     
/*      */ 
/*      */ 
/* 1601 */     int[] samplingFrequencyTable = { 44100, 48000, 32000 };
/* 1602 */     short[] bitrateIndexTableL2 = { 0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1610 */     short[] bitrateIndexTableL23Ext = { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1616 */     int numBytes = AVOnlyState ? dataLen : readBytes(this.stream, tmpBuf, dataLen);
/* 1617 */     for (int i = (int)this.startLocation; i < numBytes - 3; i++)
/*      */     {
/* 1619 */       if ((tmpBuf[i] == -1) && ((tmpBuf[(i + 1)] & 0xFFFFFFF0) == -16)) {
/* 1620 */         audio.ID = ((tmpBuf[(i + 1)] & 0x8) >> 3);
/* 1621 */         audio.layer = (4 - ((tmpBuf[(i + 1)] & 0x6) >> 1));
/* 1622 */         audio.protection = (tmpBuf[(i + 1)] & 0x1);
/* 1623 */         int br = (tmpBuf[(i + 2)] & 0xF0) >> 4;
/* 1624 */         int sr = (tmpBuf[(i + 2)] & 0xC) >> 2;
/*      */         
/* 1626 */         if ((sr < 0) || (sr >= samplingFrequencyTable.length)) {
/* 1627 */           throw new BadDataException("Non Standard sample rates not supported");
/*      */         }
/*      */         
/* 1630 */         audio.mode = ((tmpBuf[(i + 3)] & 0xC0) >> 6);
/* 1631 */         audio.modeExt = ((tmpBuf[(i + 3)] & 0x30) >> 4);
/* 1632 */         audio.channels = (audio.mode == 3 ? 1 : 2);
/* 1633 */         audio.copyright = ((tmpBuf[(i + 3)] & 0x8) >> 3);
/* 1634 */         audio.original = ((tmpBuf[(i + 3)] & 0x4) >> 2);
/* 1635 */         audio.emphasis = (tmpBuf[(i + 3)] & 0x3);
/* 1636 */         audio.valid = (br != 15);
/*      */         
/* 1638 */         if (audio.ID == 1) {
/* 1639 */           audio.sampleRate = samplingFrequencyTable[sr];
/* 1640 */           if (audio.layer == 3) {
/* 1641 */             if (br < 2) {
/* 1642 */               audio.bitRate = bitrateIndexTableL2[br];
/* 1643 */             } else if (br == 2) {
/* 1644 */               audio.bitRate = 40;
/*      */             } else {
/* 1646 */               audio.bitRate = bitrateIndexTableL2[(br - 1)];
/*      */             }
/* 1648 */           } else if (audio.layer == 2) {
/* 1649 */             audio.bitRate = bitrateIndexTableL2[br];
/*      */           } else {
/* 1651 */             audio.bitRate = (br << 5);
/*      */           }
/*      */         } else {
/* 1654 */           audio.sampleRate = (samplingFrequencyTable[sr] >> 1);
/* 1655 */           if ((audio.layer == 3) || (audio.layer == 2)) {
/* 1656 */             audio.bitRate = bitrateIndexTableL23Ext[br];
/*      */           }
/* 1658 */           else if (br < 9) {
/* 1659 */             audio.bitRate = bitrateIndexTableL2[br];
/* 1660 */           } else if (br == 9) {
/* 1661 */             audio.bitRate = 144;
/* 1662 */           } else if (br == 10) {
/* 1663 */             audio.bitRate = bitrateIndexTableL2[(br - 1)];
/* 1664 */           } else if (br == 11) {
/* 1665 */             audio.bitRate = 176;
/*      */           } else {
/* 1667 */             audio.bitRate = bitrateIndexTableL2[(br - 2)];
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1681 */         trackInfo.readFrameSize = (audio.bitRate * 1000 >> 3);
/*      */         
/* 1683 */         trackInfo.infoFlag = true;
/* 1684 */         trackInfo.media = audio;
/* 1685 */         break;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1690 */     return numBytes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int extractVideoInfo(byte[] tmpBuf, TrackList trackInfo, int dataLen, boolean AVOnlyState)
/*      */     throws IOException, BadDataException
/*      */   {
/* 1700 */     Video video = new Video(null);
/*      */     
/* 1702 */     float[] aspectRatioTable = { 0.0F, 1.0F, 0.6735F, 0.7031F, 0.7615F, 0.8055F, 0.8437F, 0.8935F, 0.9375F, 0.9815F, 1.0255F, 1.0695F, 1.125F, 1.1575F, 1.2015F, 1.0F };
/*      */     
/*      */ 
/*      */ 
/* 1706 */     float[] pictureRateTable = { 0.0F, 23.976F, 24.0F, 25.0F, 29.97F, 30.0F, 50.0F, 59.94F, 60.0F, -1.0F, -1.0F, -1.0F, -1.0F, -1.0F, -1.0F, -1.0F };
/*      */     
/*      */ 
/*      */ 
/* 1710 */     int numBytes = AVOnlyState ? dataLen : readBytes(this.stream, tmpBuf, dataLen);
/* 1711 */     for (int i = 0; i < numBytes - 10; i++)
/*      */     {
/*      */ 
/*      */ 
/* 1715 */       int code = tmpBuf[i] << 24 & 0xFF000000 | tmpBuf[(i + 1)] << 16 & 0xFF0000 | tmpBuf[(i + 2)] << 8 & 0xFF00 | tmpBuf[(i + 3)] & 0xFF;
/*      */       
/* 1717 */       if (code == 435) {
/* 1718 */         video.width = ((tmpBuf[(i + 4 + 0)] & 0xFF) << 4);
/* 1719 */         video.width |= tmpBuf[(i + 4 + 1)] >> 4 & 0xF;
/* 1720 */         video.height = ((tmpBuf[(i + 4 + 1)] & 0xF) << 8);
/* 1721 */         video.height |= tmpBuf[(i + 4 + 2)] & 0xFF;
/* 1722 */         int pr = (tmpBuf[(i + 4 + 3)] & 0xF0) >> 4;
/* 1723 */         video.pelAspectRatio = aspectRatioTable[pr];
/* 1724 */         pr = tmpBuf[(i + 4 + 3)] & 0xF;
/* 1725 */         video.pictureRate = pictureRateTable[pr];
/* 1726 */         pr = (tmpBuf[(i + 4 + 4)] & 0xFF) << 10 | (tmpBuf[(i + 4 + 5)] & 0xFF) << 2 | (tmpBuf[(i + 4 + 6)] & 0xC0) >> 6;
/*      */         
/*      */ 
/* 1729 */         video.bitRate = (pr * 400);
/* 1730 */         if ((video.pelAspectRatio == 0.0D) || (video.pictureRate == 0.0D)) {
/* 1731 */           throw new BadDataException("video header corrupted");
/*      */         }
/* 1733 */         if (video.pictureRate < 23.0D) {
/* 1734 */           trackInfo.readFrameSize = 65536;
/*      */         }
/*      */         else
/*      */         {
/* 1738 */           trackInfo.readFrameSize = (video.bitRate >> 3);
/* 1739 */           if (trackInfo.readFrameSize > 100000) {
/* 1740 */             trackInfo.readFrameSize = 100000;
/*      */           }
/*      */         }
/* 1743 */         trackInfo.infoFlag = true;
/* 1744 */         trackInfo.media = video;
/*      */         
/* 1746 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1750 */     return numBytes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getStreamID(byte bval)
/*      */   {
/* 1758 */     return (bval & 0xFF) - 192;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private long getLocation()
/*      */   {
/* 1767 */     return getLocation(this.stream);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean needingMore()
/*      */   {
/* 1778 */     for (int i = 0; i < this.numTracks; i++) {
/* 1779 */       if (this.tracks[i] != null) {
/* 1780 */         TrackList trackInfo = ((MediaTrack)this.tracks[i]).getTrackInfo();
/* 1781 */         if (trackInfo.bufQ.canRead()) {
/* 1782 */           return false;
/*      */         }
/*      */       }
/*      */     }
/* 1786 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void flushInnerBuffers()
/*      */   {
/* 1794 */     for (int i = 0; i < this.numTracks; i++) {
/* 1795 */       if (this.tracks[i] != null)
/*      */       {
/* 1797 */         TrackList trackInfo = ((MediaTrack)this.tracks[i]).getTrackInfo();
/*      */         
/*      */ 
/* 1800 */         synchronized (trackInfo.bufQ) {
/* 1801 */           trackInfo.flushFlag = true;
/* 1802 */           trackInfo.bufQ.notifyAll();
/*      */         }
/*      */         
/* 1805 */         trackInfo.flushBuffer();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void saveInnerBuffersToFiles()
/*      */   {
/* 1815 */     for (int i = 0; i < this.numTracks; i++) {
/* 1816 */       if (this.tracks[i] != null) {
/* 1817 */         TrackList trackInfo = ((MediaTrack)this.tracks[i]).getTrackInfo();
/* 1818 */         trackInfo.saveBufToFile();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void throwInnerBuffersContents()
/*      */   {
/* 1826 */     for (int i = 0; i < this.numTracks; i++) {
/* 1827 */       if (this.tracks[i] != null) {
/* 1828 */         TrackList trackInfo = ((MediaTrack)this.tracks[i]).getTrackInfo();
/* 1829 */         trackInfo.flushBuffer();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private abstract class Media {
/*      */     private Media() {}
/*      */     
/*      */     abstract Format createFormat();
/*      */     
/*      */     Media(MpegParser.1 x1) {
/* 1840 */       this();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private class Audio
/*      */     extends MpegParser.Media
/*      */   {
/* 1850 */     private Audio() { super(null); } Audio(MpegParser.1 x1) { this(); }
/* 1851 */     boolean valid = false;
/* 1852 */     int ID = 0;
/* 1853 */     int layer = 0;
/* 1854 */     int protection = 0;
/* 1855 */     int bitRate = 0;
/* 1856 */     int sampleRate = 0;
/* 1857 */     int mode = 0;
/* 1858 */     int modeExt = 0;
/* 1859 */     int copyright = 0;
/* 1860 */     int original = 0;
/* 1861 */     int emphasis = 0;
/* 1862 */     int channels = 0;
/* 1863 */     AudioFormat format = null;
/*      */     
/*      */     Format createFormat()
/*      */     {
/* 1867 */       if (this.format != null) {
/* 1868 */         return this.format;
/*      */       }
/*      */       String encodingString;
/* 1871 */       if (this.layer == 3) {
/* 1872 */         encodingString = "mpeglayer3";
/*      */       } else {
/* 1874 */         encodingString = "mpegaudio";
/*      */       }
/*      */       
/*      */ 
/* 1878 */       int bitsPerSample = 16;
/* 1879 */       int frameSizeInBits = (this.layer == 1 ? 352 : 1024) * this.channels * bitsPerSample;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1892 */       int bytesPerSecond = this.bitRate * 1000 >> 3;
/* 1893 */       this.format = new WavAudioFormat(encodingString, this.sampleRate, bitsPerSample, this.channels, frameSizeInBits, bytesPerSecond, 0, 1, -1.0F, new byte[0].getClass(), null);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1907 */       return this.format;
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/* 1912 */       System.out.println("Audio Media: " + this.format);
/* 1913 */       System.out.println("Number of channels " + this.channels);
/* 1914 */       System.out.println("valid " + this.valid);
/* 1915 */       System.out.println("ID " + this.ID);
/* 1916 */       System.out.println("layer " + this.layer);
/* 1917 */       System.out.println("protection " + this.protection);
/* 1918 */       System.out.println("bitrate " + this.bitRate);
/* 1919 */       System.out.println("sample rate " + this.sampleRate);
/* 1920 */       System.out.println("Mode " + this.mode + " ext " + this.modeExt);
/* 1921 */       System.out.println("copyright " + this.copyright);
/* 1922 */       System.out.println("original " + this.original);
/* 1923 */       System.out.println("emphasis " + this.emphasis);
/* 1924 */       System.out.println("channels " + this.channels);
/* 1925 */       return super.toString();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private class Video
/*      */     extends MpegParser.Media
/*      */   {
/* 1934 */     private Video() { super(null); } Video(MpegParser.1 x1) { this(); }
/* 1935 */     int width = 0;
/* 1936 */     int height = 0;
/* 1937 */     float pelAspectRatio = 0.0F;
/* 1938 */     float pictureRate = 0.0F;
/* 1939 */     int bitRate = 0;
/* 1940 */     VideoFormat format = null;
/*      */     
/*      */     Format createFormat()
/*      */     {
/* 1944 */       int size = (int)(this.width * this.height * 1.5D);
/* 1945 */       if (this.format != null) {
/* 1946 */         return this.format;
/*      */       }
/* 1948 */       this.format = new VideoFormat("mpeg", new Dimension(this.width, this.height), size, new byte[0].getClass(), this.pictureRate);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1954 */       return this.format;
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/* 1959 */       System.out.println("Video Media: " + this.format);
/* 1960 */       System.out.println("width " + this.width);
/* 1961 */       System.out.println("height " + this.height);
/* 1962 */       System.out.println("pixel aspect ratio " + this.pelAspectRatio);
/* 1963 */       System.out.println("picture rate " + this.pictureRate);
/* 1964 */       System.out.println("bitrate " + this.bitRate);
/* 1965 */       return super.toString();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private class TrackList
/*      */   {
/* 1974 */     TrackList(MpegParser.1 x1) { this(); }
/* 1975 */     byte trackType = 0;
/* 1976 */     Time duration = Duration.DURATION_UNKNOWN;
/* 1977 */     long startPTS = -3333333L;
/* 1978 */     boolean infoFlag = false;
/* 1979 */     int numPackets = 0;
/* 1980 */     int maxPacketSize = 0;
/* 1981 */     int readFrameSize = 0;
/*      */     MpegParser.Media media;
/* 1983 */     boolean supported = false;
/* 1984 */     boolean flushFlag = false;
/*      */     
/* 1986 */     CircularBuffer bufQ = null;
/* 1987 */     Buffer current = null;
/*      */     
/* 1989 */     MpegParser parser = MpegParser.this;
/*      */     
/*      */     void init(byte stype)
/*      */     {
/* 1993 */       this.supported = true;
/* 1994 */       this.trackType = stype;
/*      */       
/*      */ 
/*      */ 
/* 1998 */       if (this.trackType == 2) {
/* 1999 */         this.bufQ = new CircularBuffer(15);
/*      */       } else {
/* 2001 */         this.bufQ = new CircularBuffer(10);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     int readyDataBytes()
/*      */     {
/* 2009 */       return 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void copyStreamDataToInnerBuffer(byte[] in, int inSize, int size, long pts)
/*      */       throws IOException
/*      */     {
/* 2019 */       int total = size;
/* 2020 */       int len = 0;
/* 2021 */       if (inSize > 0) {
/* 2022 */         total += inSize;
/*      */       } else {
/* 2024 */         inSize = 0;
/*      */       }
/* 2026 */       synchronized (this.bufQ) {
/* 2027 */         if (this.current != null) {
/* 2028 */           len = this.current.getLength();
/* 2029 */           if ((len != 0) && (len + total >= this.readFrameSize))
/*      */           {
/* 2031 */             this.bufQ.writeReport();
/* 2032 */             this.bufQ.notify();
/* 2033 */             this.current = null;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2039 */         this.flushFlag = false;
/*      */         byte[] data;
/* 2041 */         if (this.current == null) {
/* 2042 */           while ((!this.bufQ.canWrite()) && (!this.flushFlag)) {
/*      */             try {
/* 2044 */               this.bufQ.wait();
/*      */             }
/*      */             catch (InterruptedException e) {}
/*      */           }
/* 2048 */           if (this.flushFlag) {
/* 2049 */             return;
/*      */           }
/* 2051 */           this.current = this.bufQ.getEmptyBuffer();
/*      */           
/* 2053 */           this.current.setFlags(0);
/* 2054 */           this.current.setOffset(0);
/* 2055 */           this.current.setLength(0);
/* 2056 */           this.current.setTimeStamp(MpegParser.this.convPTStoNanoseconds(pts));
/*      */           
/*      */ 
/* 2059 */           int bsize = total > this.readFrameSize ? total : this.readFrameSize;
/* 2060 */           data = (byte[])this.current.getData();
/*      */           
/* 2062 */           if ((data == null) || (data.length < bsize)) {
/* 2063 */             data = new byte[bsize];
/* 2064 */             this.current.setData(data);
/*      */           }
/*      */         } else {
/* 2067 */           data = (byte[])this.current.getData();
/*      */         }
/* 2069 */         len = this.current.getLength();
/*      */         
/*      */ 
/* 2072 */         if (inSize > 0) {
/* 2073 */           System.arraycopy(in, 0, data, len, inSize);
/*      */         }
/*      */         
/* 2076 */         this.parser.readBytes(MpegParser.this.stream, data, len + inSize, size);
/*      */         
/* 2078 */         this.current.setLength(len + total);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void copyFromInnerBuffer(Buffer out)
/*      */     {
/* 2090 */       synchronized (this.bufQ) {
/* 2091 */         while ((!this.bufQ.canRead()) && (!MpegParser.this.sysPausedFlag) && (!MpegParser.this.parserErrorFlag)) {
/*      */           try {
/* 2093 */             this.bufQ.wait();
/*      */           }
/*      */           catch (InterruptedException e) {}
/*      */         }
/* 2097 */         if ((MpegParser.this.sysPausedFlag) || (MpegParser.this.parserErrorFlag)) {
/* 2098 */           out.setLength(0);
/* 2099 */           out.setDiscard(true);
/* 2100 */           return;
/*      */         }
/*      */         
/* 2103 */         Buffer buf = this.bufQ.read();
/* 2104 */         byte[] saved = (byte[])out.getData();
/*      */         
/* 2106 */         out.copy(buf);
/* 2107 */         buf.setData(saved);
/*      */         
/* 2109 */         this.bufQ.readReport();
/* 2110 */         this.bufQ.notify();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     void releaseReadFrame()
/*      */     {
/* 2119 */       synchronized (this.bufQ) {
/* 2120 */         this.bufQ.notifyAll();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void generateEOM()
/*      */     {
/* 2132 */       synchronized (this.bufQ)
/*      */       {
/* 2134 */         if (this.current != null) {
/* 2135 */           this.bufQ.writeReport();
/* 2136 */           this.bufQ.notify();
/* 2137 */           this.current = null;
/*      */         }
/*      */         
/*      */ 
/* 2141 */         while (!this.bufQ.canWrite()) {
/*      */           try {
/* 2143 */             this.bufQ.wait();
/*      */           } catch (InterruptedException e) {}
/*      */         }
/* 2146 */         Buffer buf = this.bufQ.getEmptyBuffer();
/*      */         
/* 2148 */         buf.setFlags(1);
/* 2149 */         buf.setLength(0);
/*      */         
/* 2151 */         this.bufQ.writeReport();
/* 2152 */         this.bufQ.notify();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     void flushBuffer()
/*      */     {
/* 2161 */       synchronized (this.bufQ) {
/* 2162 */         if (this.current != null) {
/* 2163 */           this.current.setDiscard(true);
/* 2164 */           this.bufQ.writeReport();
/* 2165 */           this.current = null;
/*      */         }
/* 2167 */         while (this.bufQ.canRead()) {
/* 2168 */           this.bufQ.read();
/* 2169 */           this.bufQ.readReport();
/*      */         }
/* 2171 */         this.bufQ.notifyAll();
/*      */       }
/*      */     }
/*      */     
/*      */     public String toString()
/*      */     {
/* 2177 */       System.out.println("track type " + this.trackType + "(0 ?, 1 audio, 2 video)");
/* 2178 */       System.out.println("start PTS " + this.startPTS);
/* 2179 */       System.out.println("info flag " + this.infoFlag);
/* 2180 */       System.out.println("number of packets " + this.numPackets);
/* 2181 */       System.out.println("maximum packet size " + this.maxPacketSize);
/* 2182 */       System.out.println("supported " + this.supported);
/* 2183 */       System.out.println("duration (?) " + this.duration);
/* 2184 */       return this.media.toString();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private TrackList() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void saveBufToFile() {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private class MediaTrack
/*      */     implements Track
/*      */   {
/*      */     private MpegParser.TrackList trackInfo;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private boolean enabled;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2222 */     private long sequenceNumber = 0L;
/*      */     private Format format;
/*      */     private TrackListener listener;
/* 2225 */     MpegParser parser = MpegParser.this;
/*      */     
/*      */     MediaTrack(MpegParser.TrackList trackInfo)
/*      */     {
/* 2229 */       this.trackInfo = trackInfo;
/* 2230 */       this.enabled = true;
/* 2231 */       this.format = trackInfo.media.createFormat();
/*      */     }
/*      */     
/*      */     public void setTrackListener(TrackListener l)
/*      */     {
/* 2236 */       this.listener = l;
/*      */     }
/*      */     
/*      */     public Format getFormat() {
/* 2240 */       return this.format;
/*      */     }
/*      */     
/*      */     public void setEnabled(boolean t)
/*      */     {
/* 2245 */       this.enabled = t;
/*      */     }
/*      */     
/*      */     public boolean isEnabled() {
/* 2249 */       return this.enabled;
/*      */     }
/*      */     
/*      */     public Time getDuration() {
/* 2253 */       return this.trackInfo.duration;
/*      */     }
/*      */     
/*      */     public Time getStartTime()
/*      */     {
/* 2258 */       if (MpegParser.this.streamType == 3) {
/* 2259 */         return new Time(MpegParser.this.startPTS / 90000.0D);
/*      */       }
/* 2261 */       return new Time(MpegParser.this.AVstartTimeNs);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void readFrame(Buffer buffer)
/*      */     {
/* 2268 */       if (buffer == null) {
/* 2269 */         return;
/*      */       }
/* 2271 */       if (!this.enabled) {
/* 2272 */         buffer.setDiscard(true);
/* 2273 */         return;
/*      */       }
/*      */       
/*      */ 
/* 2277 */       if (MpegParser.this.streamType == 3) {
/* 2278 */         systemStreamReadFrame(buffer);
/*      */       } else {
/* 2280 */         AudioVideoOnlyReadFrame(buffer);
/*      */       }
/*      */       
/* 2283 */       buffer.setFormat(this.format);
/* 2284 */       buffer.setSequenceNumber(++this.sequenceNumber);
/*      */       
/* 2286 */       if ((this.format instanceof AudioFormat)) {
/* 2287 */         long tmp = buffer.getTimeStamp();
/* 2288 */         buffer.setTimeStamp(MpegParser.this.lastAudioNs);
/* 2289 */         MpegParser.this.lastAudioNs = tmp;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     private void AudioVideoOnlyReadFrame(Buffer buffer)
/*      */     {
/* 2296 */       if ((MpegParser.this.sysPausedFlag) || (MpegParser.this.parserErrorFlag)) {
/* 2297 */         buffer.setLength(0);
/* 2298 */         buffer.setDiscard(true);
/*      */       }
/*      */       
/* 2301 */       int size = this.trackInfo.readFrameSize;
/* 2302 */       Object obj = buffer.getData();
/*      */       
/*      */       byte[] data;
/* 2305 */       if ((obj == null) || (!(obj instanceof byte[])) || (((byte[])obj).length < size))
/*      */       {
/*      */ 
/* 2308 */         data = new byte[size];
/* 2309 */         buffer.setData(data);
/*      */       } else {
/* 2311 */         data = (byte[])obj;
/*      */       }
/*      */       
/* 2314 */       int read1 = 0;int read2 = size;
/* 2315 */       int actualBytesRead = 0;int counter = 0;
/*      */       
/*      */ 
/* 2318 */       if (MpegParser.this.initTmpBufLen > 0) {
/* 2319 */         read1 = MpegParser.this.initTmpBufLen > size ? size : MpegParser.this.initTmpBufLen;
/* 2320 */         System.arraycopy(MpegParser.this.initTmpStreamBuf, 0, data, 0, read1);
/* 2321 */         MpegParser.access$1220(MpegParser.this, read1);
/* 2322 */         read2 -= read1;
/* 2323 */         counter = read1;
/*      */       }
/*      */       
/*      */ 
/* 2327 */       if (this.trackInfo.trackType == 1) {
/* 2328 */         buffer.setTimeStamp(MpegParser.this.convBytesToTimeAV(MpegParser.access$1400(MpegParser.this) - read1));
/*      */       }
/*      */       
/*      */ 
/* 2332 */       if ((read2 > 0) && (!MpegParser.this.EOMflag)) {
/*      */         try {
/* 2334 */           actualBytesRead = this.parser.readBytes(MpegParser.this.stream, data, read1, read2);
/* 2335 */           if (actualBytesRead == -2) {
/* 2336 */             if (read1 == 0) {
/* 2337 */               buffer.setDiscard(true);
/*      */             }
/*      */           }
/*      */           else {
/* 2341 */             counter += actualBytesRead;
/*      */           }
/*      */         }
/*      */         catch (IOException e) {
/* 2345 */           MpegParser.this.updateEOMState();
/* 2346 */           MpegParser.this.EOMflag = true;
/* 2347 */           if (MpegParser.this.AVlastTimeNs == 0L)
/*      */           {
/* 2349 */             MpegParser.this.AVcurrentTimeNs = MpegParser.this.convBytesToTimeAV(MpegParser.access$1400(MpegParser.this));
/* 2350 */             MpegParser.this.AVlastTimeNs = MpegParser.this.AVcurrentTimeNs;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2355 */       if (MpegParser.this.EOMflag) {
/* 2356 */         if (read1 > 0) {
/* 2357 */           buffer.setLength(read1);
/* 2358 */           buffer.setOffset(0);
/*      */         } else {
/* 2360 */           buffer.setLength(0);
/* 2361 */           buffer.setEOM(true);
/*      */         }
/*      */       }
/*      */       
/* 2365 */       buffer.setOffset(0);
/* 2366 */       buffer.setLength(counter);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private void systemStreamReadFrame(Buffer buffer)
/*      */     {
/* 2374 */       this.trackInfo.copyFromInnerBuffer(buffer);
/*      */       
/* 2376 */       if ((MpegParser.this.sysPausedFlag) || (MpegParser.this.parserErrorFlag)) {
/* 2377 */         return;
/*      */       }
/*      */       
/* 2380 */       for (int i = 0; i < MpegParser.this.numTracks; i++) {
/* 2381 */         if ((MpegParser.this.tracks[i] != null) && 
/* 2382 */           (!MpegParser.this.tracks[i].isEnabled())) {
/* 2383 */           MpegParser.TrackList AtrackInfo = ((MediaTrack)MpegParser.this.tracks[i]).getTrackInfo();
/* 2384 */           AtrackInfo.flushBuffer();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2390 */       if (MpegParser.this.hideAudioTracks)
/*      */       {
/* 2392 */         for (int i = 0; i < MpegParser.this.numTracks; i++) {
/* 2393 */           if (MpegParser.this.tracks[i] != null) {
/* 2394 */             MpegParser.TrackList AtrackInfo = ((MediaTrack)MpegParser.this.tracks[i]).getTrackInfo();
/* 2395 */             if (AtrackInfo.trackType == 1) {
/* 2396 */               AtrackInfo.flushBuffer();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 2402 */       if (MpegParser.this.hideVideoTracks)
/*      */       {
/* 2404 */         for (int i = 0; i < MpegParser.this.numTracks; i++) {
/* 2405 */           if (MpegParser.this.tracks[i] != null) {
/* 2406 */             MpegParser.TrackList AtrackInfo = ((MediaTrack)MpegParser.this.tracks[i]).getTrackInfo();
/* 2407 */             if (AtrackInfo.trackType == 2) {
/* 2408 */               AtrackInfo.flushBuffer();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public int mapTimeToFrame(Time t)
/*      */     {
/* 2417 */       return 0;
/*      */     }
/*      */     
/*      */     public Time mapFrameToTime(int frameNumber)
/*      */     {
/* 2422 */       return null;
/*      */     }
/*      */     
/*      */     private MpegParser.TrackList getTrackInfo() {
/* 2426 */       return this.trackInfo;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private class SystemHeader
/*      */   {
/* 2440 */     int headerLen = 0;
/* 2441 */     int rateBound = 0;
/* 2442 */     int audioBound = 0;
/* 2443 */     int fixedFlag = 0;
/* 2444 */     int CSPSFlag = 0;
/* 2445 */     int audioLockFlag = 0;
/* 2446 */     int videoLockFlag = 0;
/* 2447 */     int videoBound = 0;
/* 2448 */     int reserved = 0;
/* 2449 */     boolean allAudioSTDFlag = false;
/* 2450 */     boolean allVideoSTDFlag = false;
/* 2451 */     boolean[] streamFlags = new boolean[48];
/* 2452 */     int[] STDBufBoundScale = new int[48];
/* 2453 */     int[] STDBufSizeBound = new int[48];
/*      */     
/*      */     SystemHeader()
/*      */     {
/* 2457 */       for (int i = 0; i < 48; i++) {
/* 2458 */         this.streamFlags[i] = false;
/* 2459 */         this.STDBufBoundScale[i] = 0;
/* 2460 */         this.STDBufSizeBound[i] = 0;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     void resetSystemHeader()
/*      */     {
/* 2467 */       this.headerLen = 0;
/* 2468 */       this.rateBound = 0;
/* 2469 */       this.audioBound = 0;
/* 2470 */       this.fixedFlag = 0;
/* 2471 */       this.CSPSFlag = 0;
/* 2472 */       this.audioLockFlag = 0;
/* 2473 */       this.videoLockFlag = 0;
/* 2474 */       this.videoBound = 0;
/* 2475 */       this.reserved = 0;
/* 2476 */       this.allAudioSTDFlag = false;
/* 2477 */       this.allVideoSTDFlag = false;
/* 2478 */       for (int i = 0; i < 48; i++) {
/* 2479 */         this.streamFlags[i] = false;
/* 2480 */         this.STDBufBoundScale[i] = 0;
/* 2481 */         this.STDBufSizeBound[i] = 0;
/*      */       }
/*      */     }
/*      */     
/*      */     void printFields() {
/* 2486 */       System.out.println("headerLen " + this.headerLen);
/* 2487 */       System.out.println("rateBound " + this.rateBound);
/* 2488 */       System.out.println("audioBound " + this.audioBound);
/* 2489 */       System.out.println("fixedFlag " + this.fixedFlag);
/* 2490 */       System.out.println("CSPSFlag " + this.CSPSFlag);
/* 2491 */       System.out.println("audioLockFlag " + this.audioLockFlag);
/* 2492 */       System.out.println("videoLockFlag " + this.videoLockFlag);
/* 2493 */       System.out.println("videoBound " + this.videoBound);
/* 2494 */       System.out.println("reserved " + this.reserved);
/* 2495 */       System.out.println("allAudioSTDFlag " + this.allAudioSTDFlag);
/* 2496 */       System.out.println("allVideoSTDFlag " + this.allVideoSTDFlag);
/* 2497 */       for (int i = 0; i < 48; i++) {
/* 2498 */         if (this.streamFlags[i] != 0) {
/* 2499 */           System.out.println("[" + i + "]  STDBufBoundScale " + this.STDBufBoundScale[i] + "     STDBufSizeBound " + this.STDBufSizeBound[i]);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\parser\video\MpegParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */