/*     */ package com.ibm.media.codec.audio.gsm;
/*     */ 
/*     */ import com.ibm.media.codec.audio.AudioCodec;
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.controls.SilenceSuppressionAdapter;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Control;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaDecoder
/*     */   extends AudioCodec
/*     */ {
/*     */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1999.";
/*     */   protected GsmDecoder decoder;
/*     */   
/*     */   public JavaDecoder()
/*     */   {
/*  41 */     this.supportedInputFormats = new AudioFormat[] { new AudioFormat("gsm"), new AudioFormat("gsm/rtp") };
/*     */     
/*  43 */     this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR") };
/*  44 */     this.PLUGIN_NAME = "GSM Decoder";
/*     */   }
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in)
/*     */   {
/*  49 */     AudioFormat af = (AudioFormat)in;
/*     */     
/*  51 */     this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 0, 1) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */     return this.supportedOutputFormats;
/*     */   }
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/*  64 */     this.decoder = new GsmDecoder();
/*  65 */     this.decoder.decoderInit();
/*     */   }
/*     */   
/*     */   public void reset() {
/*  69 */     resetDecoder();
/*     */   }
/*     */   
/*     */   public void close()
/*     */   {
/*  74 */     freeDecoder();
/*     */   }
/*     */   
/*     */ 
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer)
/*     */   {
/*  80 */     if (!checkInputBuffer(inputBuffer)) {
/*  81 */       return 1;
/*     */     }
/*     */     
/*  84 */     if (isEOM(inputBuffer)) {
/*  85 */       propagateEOM(outputBuffer);
/*  86 */       return 0;
/*     */     }
/*     */     
/*  89 */     int inpLength = inputBuffer.getLength();
/*  90 */     int outLength = calculateOutputSize(inputBuffer.getLength());
/*     */     
/*  92 */     byte[] inpData = (byte[])inputBuffer.getData();
/*  93 */     byte[] outData = validateByteArraySize(outputBuffer, outLength);
/*     */     
/*     */ 
/*  96 */     decode(inpData, inputBuffer.getOffset(), outData, 0, inpLength);
/*     */     
/*  98 */     updateOutput(outputBuffer, this.outputFormat, outLength, 0);
/*  99 */     return 0;
/*     */   }
/*     */   
/*     */   protected void freeDecoder() {
/* 103 */     this.decoder = null;
/*     */   }
/*     */   
/*     */   protected void resetDecoder() {
/* 107 */     this.decoder.decoderInit();
/*     */   }
/*     */   
/*     */   protected int calculateOutputSize(int inputSize) {
/* 111 */     return inputSize / 33 * 320;
/*     */   }
/*     */   
/*     */   protected void decode(byte[] inpData, int readPtr, byte[] outData, int writePtr, int inpLength) {
/* 115 */     int numberOfFrames = inpLength / 33;
/*     */     
/* 117 */     for (int n = 1; n <= numberOfFrames; readPtr += 33) {
/* 118 */       this.decoder.decodeFrame(inpData, readPtr, outData, writePtr);n++;writePtr += 320;
/*     */     }
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 123 */     if (this.controls == null) {
/* 124 */       this.controls = new Control[1];
/* 125 */       this.controls[0] = new SilenceSuppressionAdapter(this, true, false);
/*     */     }
/* 127 */     return (Object[])this.controls;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\codec\audio\gsm\JavaDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */