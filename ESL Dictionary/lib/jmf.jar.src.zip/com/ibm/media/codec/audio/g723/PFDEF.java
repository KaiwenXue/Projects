package com.ibm.media.codec.audio.g723;

class PFDEF
{
  int Indx;
  float Gain;
  float ScGn;
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\codec\audio\g723\PFDEF.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */