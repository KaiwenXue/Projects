/*     */ package com.ibm.media.codec.audio.dvi;
/*     */ 
/*     */ import com.ibm.media.codec.audio.AudioCodec;
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.controls.SilenceSuppressionAdapter;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Control;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaDecoder
/*     */   extends AudioCodec
/*     */ {
/*     */   private DVIState dviState;
/*     */   
/*     */   public JavaDecoder()
/*     */   {
/*  35 */     this.supportedInputFormats = new AudioFormat[] { new AudioFormat("dvi/rtp") };
/*  36 */     this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR") };
/*  37 */     this.PLUGIN_NAME = "DVI Decoder";
/*     */   }
/*     */   
/*     */ 
/*     */   protected Format[] getMatchingOutputFormats(Format in)
/*     */   {
/*  43 */     AudioFormat af = (AudioFormat)in;
/*     */     
/*  45 */     this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 0, 1) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  54 */     return this.supportedOutputFormats;
/*     */   }
/*     */   
/*     */ 
/*     */   public void open()
/*     */   {
/*  60 */     this.dviState = new DVIState();
/*     */   }
/*     */   
/*     */ 
/*     */   public void close()
/*     */   {
/*  66 */     this.dviState = null;
/*     */   }
/*     */   
/*     */ 
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer)
/*     */   {
/*  72 */     int outLength = 0;
/*     */     
/*  74 */     if (!checkInputBuffer(inputBuffer)) {
/*  75 */       return 1;
/*     */     }
/*     */     
/*  78 */     if (isEOM(inputBuffer)) {
/*  79 */       propagateEOM(outputBuffer);
/*  80 */       return 0;
/*     */     }
/*     */     
/*  83 */     int channels = this.outputFormat.getChannels();
/*  84 */     byte[] inData = (byte[])inputBuffer.getData();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     byte[] outData = validateByteArraySize(outputBuffer, (inData.length - 4) * 4);
/*     */     
/*     */ 
/*  96 */     int offset = inputBuffer.getOffset();
/*     */     
/*     */ 
/*  99 */     int prevVal = inData[(offset++)] << 8;
/* 100 */     prevVal |= inData[(offset++)] & 0xFF;
/*     */     
/*     */ 
/* 103 */     int index = inData[(offset++)] & 0xFF;
/*     */     
/*     */ 
/* 106 */     offset++;
/* 107 */     this.dviState.valprev = prevVal;
/* 108 */     this.dviState.index = index;
/*     */     
/*     */ 
/* 111 */     DVI.decode(inData, offset, outData, 0, 2 * (inputBuffer.getLength() - 4), this.dviState);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */     outLength = 4 * (inputBuffer.getLength() - 4);
/* 120 */     updateOutput(outputBuffer, this.outputFormat, outLength, 0);
/*     */     
/* 122 */     return 0;
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 126 */     if (this.controls == null) {
/* 127 */       this.controls = new Control[1];
/* 128 */       this.controls[0] = new SilenceSuppressionAdapter(this, false, false);
/*     */     }
/* 130 */     return (Object[])this.controls;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\codec\audio\dvi\JavaDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */