/*     */ package com.ibm.media.codec.audio.dvi;
/*     */ 
/*     */ import com.ibm.media.codec.audio.ima4.IMA4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DVI
/*     */ {
/*     */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1998.";
/*     */   
/*     */   static void encode(byte[] indata, int inOffset, byte[] outdata, int outOffset, int len, DVIState state)
/*     */   {
/*  38 */     int outputbuffer = 0;
/*     */     
/*     */ 
/*     */ 
/*  42 */     int[] indexTable = IMA4.indexTable;
/*  43 */     int[] stepsizeTable = IMA4.stepsizeTable;
/*     */     
/*     */ 
/*  46 */     int valpred = state.valprev;
/*  47 */     int index = state.index;
/*  48 */     int step = stepsizeTable[index];
/*     */     
/*  50 */     boolean bufferstep = false;
/*  52 */     for (; 
/*  52 */         len > 0; len--) {
/*  53 */       int temp = indata[(inOffset++)] & 0xFF;
/*  54 */       int val = indata[(inOffset++)] << 8 | temp;
/*     */       
/*     */ 
/*  57 */       int diff = val - valpred;
/*     */       int sign;
/*  59 */       if (diff < 0) {
/*  60 */         sign = 8;
/*  61 */         diff = -diff;
/*     */       } else {
/*  63 */         sign = 0;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */       int delta = 0;
/*  76 */       int vpdiff = step >> 3;
/*     */       
/*  78 */       if (diff >= step) {
/*  79 */         delta = 4;
/*  80 */         diff -= step;
/*  81 */         vpdiff += step;
/*     */       }
/*  83 */       step >>= 1;
/*  84 */       if (diff >= step) {
/*  85 */         delta |= 0x2;
/*  86 */         diff -= step;
/*  87 */         vpdiff += step;
/*     */       }
/*  89 */       step >>= 1;
/*  90 */       if (diff >= step) {
/*  91 */         delta |= 0x1;
/*  92 */         vpdiff += step;
/*     */       }
/*     */       
/*     */ 
/*  96 */       if (sign != 0) {
/*  97 */         valpred -= vpdiff;
/*     */       } else {
/*  99 */         valpred += vpdiff;
/*     */       }
/*     */       
/* 102 */       if (valpred > 32767) {
/* 103 */         valpred = 32767;
/* 104 */       } else if (valpred < 32768) {
/* 105 */         valpred = 32768;
/*     */       }
/*     */       
/* 108 */       delta |= sign;
/*     */       
/* 110 */       index += indexTable[delta];
/* 111 */       if (index < 0) { index = 0;
/* 112 */       } else if (index > 88) index = 88;
/* 113 */       step = stepsizeTable[index];
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 118 */       if (bufferstep) {
/* 119 */         outputbuffer = delta << 4;
/*     */       } else {
/* 121 */         outdata[(outOffset++)] = ((byte)(delta | outputbuffer));
/*     */       }
/* 123 */       bufferstep = !bufferstep;
/*     */     }
/*     */     
/*     */ 
/* 127 */     if (bufferstep) {
/* 128 */       outdata[(outOffset++)] = ((byte)outputbuffer);
/*     */     }
/* 130 */     state.valprev = valpred;
/* 131 */     state.index = index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void decode(byte[] indata, int inOffset, byte[] outdata, int outOffset, int len, DVIState state)
/*     */   {
/* 144 */     int inputbuffer = 0;
/* 145 */     boolean bufferstep = false;
/*     */     
/* 147 */     byte[] outp = outdata;
/* 148 */     byte[] inp = indata;
/*     */     
/* 150 */     int valpred = state.valprev;
/* 151 */     int index = state.index;
/* 152 */     int lastIndex = index;
/*     */     
/* 154 */     int[] indexTable = IMA4.indexTable;
/* 155 */     int[] diffLUT = IMA4.diffLUT;
/* 157 */     for (; 
/* 157 */         len > 0; len--)
/*     */     {
/*     */       int delta;
/* 160 */       if (bufferstep) {
/* 161 */         delta = inputbuffer & 0xF;
/*     */       } else {
/* 163 */         inputbuffer = inp[(inOffset++)];
/* 164 */         delta = inputbuffer >> 4 & 0xF;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 173 */       bufferstep = !bufferstep;
/*     */       
/*     */ 
/* 176 */       index += indexTable[delta];
/* 177 */       if (index < 0) { index = 0;
/* 178 */       } else if (index > 88) { index = 88;
/*     */       }
/*     */       
/* 181 */       valpred += diffLUT[((lastIndex << 4) + delta)];
/*     */       
/*     */ 
/* 184 */       if (valpred > 32767) {
/* 185 */         valpred = 32767;
/* 186 */       } else if (valpred < 32768) {
/* 187 */         valpred = 32768;
/*     */       }
/*     */       
/* 190 */       lastIndex = index;
/*     */       
/*     */ 
/* 193 */       outp[(outOffset++)] = ((byte)valpred);
/* 194 */       outp[(outOffset++)] = ((byte)(valpred >> 8));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 202 */     state.valprev = valpred;
/* 203 */     state.index = index;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\codec\audio\dvi\DVI.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */