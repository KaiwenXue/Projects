/*     */ package com.ibm.media.codec.audio;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import java.io.PrintStream;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ public class GainCodec
/*     */   extends BasicCodec
/*     */ {
/*  14 */   private static String GainCodec = "GainCodec";
/*     */   
/*  16 */   public float gain = 2.0F;
/*     */   
/*     */   public void setGain(float newGain) {
/*  19 */     this.gain = newGain;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  23 */     return GainCodec;
/*     */   }
/*     */   
/*     */   public GainCodec() {
/*  27 */     this.inputFormats = new Format[] { new AudioFormat("LINEAR", -1.0D, 16, -1, -1, -1, -1, -1.0D, Format.shortArray) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  37 */     this.outputFormats = new Format[] { new AudioFormat("LINEAR", -1.0D, 16, -1, -1, -1, -1, -1.0D, Format.shortArray) };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Format[] getSupportedOutputFormats(Format in)
/*     */   {
/*  49 */     if (!(in instanceof AudioFormat)) {
/*  50 */       return this.outputFormats;
/*     */     }
/*  52 */     AudioFormat iaf = (AudioFormat)in;
/*  53 */     if ((!iaf.getEncoding().equals("LINEAR")) || (iaf.getDataType() != Format.shortArray))
/*     */     {
/*  55 */       return new Format[0];
/*     */     }
/*  57 */     AudioFormat oaf = new AudioFormat("LINEAR", iaf.getSampleRate(), 16, iaf.getChannels(), 0, 1, iaf.getFrameSizeInBits(), iaf.getFrameRate(), Format.shortArray);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */     return new Format[] { oaf };
/*     */   }
/*     */   
/*     */ 
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer)
/*     */   {
/*  72 */     if (isEOM(inputBuffer)) {
/*  73 */       propagateEOM(outputBuffer);
/*  74 */       return 0;
/*     */     }
/*     */     
/*  77 */     short[] inBuffer = (short[])inputBuffer.getData();
/*  78 */     int inLength = inputBuffer.getLength();
/*  79 */     int inOffset = inputBuffer.getOffset();
/*  80 */     int samplesNumber = inLength;
/*     */     
/*  82 */     short[] outBuffer = validateShortArraySize(outputBuffer, samplesNumber);
/*     */     
/*     */ 
/*     */ 
/*  86 */     for (int i = 0; i < samplesNumber; i++) {
/*  87 */       int sample = inBuffer[(inOffset + i)];
/*  88 */       sample = (int)(sample * this.gain);
/*  89 */       if (sample > 32767) {
/*  90 */         sample = 32767;
/*  91 */       } else if (sample < 32768)
/*  92 */         sample = 32768;
/*  93 */       outBuffer[i] = ((short)sample);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  98 */     updateOutput(outputBuffer, this.outputFormat, samplesNumber, 0);
/*     */     
/*     */ 
/* 101 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 107 */     GainCodec codec = new GainCodec();
/* 108 */     Format[] ifmt = codec.getSupportedInputFormats();
/* 109 */     Format[] ofmt = codec.getSupportedOutputFormats(null);
/* 110 */     Buffer inp = new Buffer();
/*     */     
/* 112 */     Buffer out = new Buffer();
/* 113 */     short[] buffer = new short[100];
/* 114 */     for (int i = 0; i < 100; i++) {
/* 115 */       buffer[i] = ((short)(i + 20500));
/*     */     }
/* 117 */     inp.setData(buffer);
/* 118 */     inp.setLength(10);
/* 119 */     inp.setOffset(0);
/* 120 */     codec.setGain(1.6F);
/* 121 */     int rc = codec.process(inp, out);
/*     */     
/* 123 */     System.out.println("rc=" + rc);
/* 124 */     short[] outbuf = (short[])out.getData();
/* 125 */     System.out.println("length=" + out.getLength());
/* 126 */     System.out.println("offset=" + out.getOffset());
/* 127 */     for (int i = 0; i < outbuf.length; i++) {
/* 128 */       System.out.println(i + " " + outbuf[i]);
/*     */     }
/* 130 */     inp.setLength(0);
/* 131 */     inp.setEOM(true);
/* 132 */     rc = codec.process(inp, out);
/* 133 */     System.out.println("rc=" + rc);
/* 134 */     outbuf = (short[])out.getData();
/* 135 */     System.out.println("length=" + out.getLength());
/* 136 */     System.out.println("offset=" + out.getOffset());
/* 137 */     for (int i = 0; i < outbuf.length; i++) {
/* 138 */       System.out.println(i + " " + outbuf[i]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\codec\audio\GainCodec.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */