/*      */ package com.ibm.media.codec.audio.gsm;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class GsmEncoder
/*      */ {
/*      */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1999.";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final int ORDER = 8;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final int BLOCKSIZE = 160;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final int SBLOCKSIZE = 40;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final int SBLOCKS = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final int SUBSAMPBLOCKS = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final int SUBSAMPSIZE = 13;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static final int nPARAMETERS = 77;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int INTERPLAR = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean USE_VAD = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean NO_VAD = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean GSM_FULL = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean GSM_LIGHT = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isVADsupported()
/*      */   {
/*   95 */     return this.vadSupportFlag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setVAD(boolean newVAD)
/*      */   {
/*  104 */     this.data_vad_mode = (this.vadSupportFlag ? newVAD : false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getVAD()
/*      */   {
/*  111 */     return this.data_vad_mode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSIDupdateRate(int newSIDupdateRate)
/*      */   {
/*  133 */     this.sidUpdateRate = newSIDupdateRate;
/*      */   }
/*      */   
/*      */ 
/*  137 */   protected int sidUpdateRate = 0;
/*      */   
/*      */ 
/*      */   public static final int GSM_SPEECH_FRAME = 0;
/*      */   
/*      */   public static final int GSM_SID_FRAME = 1;
/*      */   
/*      */   public static final int GSM_SILENCE_FRAME = 2;
/*      */   
/*      */ 
/*      */   public void setComplexity(boolean newcomplexity)
/*      */   {
/*  149 */     this.data_complexity_mode = newcomplexity;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean getComplexity()
/*      */   {
/*  156 */     return this.data_complexity_mode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFrameType()
/*      */   {
/*  167 */     return this.frameType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  181 */   protected int frameType = 0;
/*      */   
/*      */   protected boolean vadSupportFlag;
/*      */   
/*      */   protected float data_buffer;
/*      */   
/*      */   protected float data_scaledSample;
/*      */   
/*      */   protected int data_blockNumber;
/*      */   
/*  191 */   protected float[] aux_correlations = new float[121];
/*      */   
/*  193 */   protected int[] data_Nc = new int[4];
/*  194 */   protected float[] data_LAR = new float[8];
/*  195 */   protected float[] data_currentxmax = new float[4];
/*      */   
/*  197 */   protected int[] data_Parameters = new int[77];
/*      */   
/*      */   protected int data_pParams;
/*  200 */   protected float[] data_wt = new float[50];
/*  201 */   protected float[] data_u = new float[9];
/*  202 */   protected float[] data_prevLARpp = new float[9];
/*      */   
/*      */   protected boolean data_complexity_mode;
/*      */   
/*      */   protected boolean data_vad_mode;
/*  207 */   protected float[] data_residual = new float['Ę'];
/*      */   
/*      */   protected int data_residual_Index;
/*  210 */   protected float[] data_input = new float[' '];
/*  211 */   protected float[] data_first_res = new float[' '];
/*  212 */   protected float[] data_acf = new float[9];
/*  213 */   protected float[] data_r = new float[9];
/*  214 */   protected float[] data_LARpp = new float[9];
/*      */   
/*      */ 
/*  217 */   protected float[] aux_decimated_subsegment = new float[20];
/*  218 */   protected float[] aux_decimated_q_frstbase = new float[60];
/*  219 */   protected float[] aux_decimated_correlations = new float[41];
/*      */   
/*      */ 
/*      */ 
/*  223 */   protected float[] aux_KK = new float[9];
/*  224 */   protected float[] aux_P = new float[9];
/*      */   
/*  226 */   protected float[] encode_outsegment = new float[40];
/*  227 */   protected int[] encode_pitchArray = new int[1];
/*  228 */   protected float[] aux_rp = new float[9];
/*      */   
/*      */ 
/*  231 */   protected static float[] lut_A = { 0.0F, 20.0F, 20.0F, 20.0F, 20.0F, 13.637F, 15.0F, 8.334F, 8.824F };
/*      */   
/*      */ 
/*  234 */   protected static float[] lut_INVA = { 0.0F, 0.05F, 0.05F, 0.05F, 0.05F, 0.07332991F, 0.06666667F, 0.11999041F, 0.11332729F };
/*      */   
/*      */ 
/*  237 */   protected static float[] lut_MIC = { 0.0F, -32.0F, -32.0F, -16.0F, -16.0F, -8.0F, -8.0F, -4.0F, -4.0F };
/*      */   
/*      */ 
/*  240 */   protected static float[] lut_MAC = { 0.0F, 31.0F, 31.0F, 15.0F, 15.0F, 7.0F, 7.0F, 3.0F, 3.0F };
/*      */   
/*      */ 
/*  243 */   protected static float[] lut_B = { 0.0F, 0.0F, 0.0F, 4.0F, -5.0F, 0.184F, -3.5F, -0.666F, -2.235F };
/*      */   
/*      */ 
/*  246 */   protected static int[] lut_k_start = { 0, 13, 27, 40, 160 };
/*      */   
/*  248 */   protected static int[] lut_lg2s = new int[32];
/*      */   private static final int GSM_MAGIC = 13;
/*      */   
/*  251 */   static { int temp_index = 0;
/*  252 */     lut_lg2s[(temp_index++)] = 1;
/*  253 */     lut_lg2s[(temp_index++)] = 2;
/*      */     
/*  255 */     for (int ii = 3; ii <= 6; ii++) {
/*  256 */       for (int jj = 1; jj <= 1 << ii - 2; jj++) {
/*  257 */         lut_lg2s[(temp_index++)] = ii;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void gsm_encoder_reset()
/*      */   {
/*  279 */     this.data_buffer = 0.0F;
/*  280 */     this.data_scaledSample = 0.0F;
/*      */     
/*      */ 
/*      */ 
/*  284 */     for (int i = 0; i < this.data_first_res.length; i++) {
/*  285 */       this.data_first_res[i] = 0.0F;
/*      */     }
/*  287 */     for (i = 0; i < this.data_residual.length; i++) {
/*  288 */       this.data_residual[i] = 0.0F;
/*      */     }
/*  290 */     for (i = 0; i < this.data_u.length; i++) {
/*  291 */       this.data_u[i] = 0.0F;
/*      */     }
/*  293 */     for (i = 0; i < this.data_prevLARpp.length; i++) {
/*  294 */       this.data_prevLARpp[i] = 0.0F;
/*      */     }
/*  296 */     for (i = 0; i < this.data_wt.length; i++) {
/*  297 */       this.data_wt[i] = 0.0F;
/*      */     }
/*  299 */     this.data_complexity_mode = true;
/*  300 */     this.data_vad_mode = false;
/*  301 */     this.data_Parameters[76] = 0;
/*  302 */     this.vadSupportFlag = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void gsm_encode_frame(byte[] input_samples, int input_offset, byte[] output_bits, int output_offset)
/*      */   {
/*  328 */     float[] outsegment = this.encode_outsegment;
/*  329 */     float[] input = this.data_input;
/*  330 */     float[] first_res = this.data_first_res;
/*  331 */     float[] acf = this.data_acf;
/*  332 */     float[] r = this.data_r;
/*  333 */     float[] LARpp = this.data_LARpp;
/*  334 */     int[] pitchArray = this.encode_pitchArray;
/*      */     
/*      */ 
/*      */ 
/*  338 */     for (int i = 0; i < 160; i++) {
/*  339 */       int temp = input_samples[(2 * i + input_offset)] & 0xFF | input_samples[(2 * i + input_offset + 1)] << 8;
/*      */       
/*  341 */       input[i] = (temp * 3.0517578E-5F);
/*      */     }
/*      */     
/*  344 */     PreProcessing(input, first_res);
/*  345 */     Autocorrelations(first_res, acf);
/*  346 */     schurRecursion(acf, r);
/*  347 */     rToLAR(r, LARpp);
/*  348 */     latticeFilter(LARpp, first_res);
/*      */     
/*  350 */     this.data_residual_Index = 120;
/*      */     
/*  352 */     for (int blocknumber = 0; blocknumber < 4; blocknumber++)
/*      */     {
/*  354 */       this.data_blockNumber = blocknumber;
/*      */       float max_corr;
/*  356 */       if (this.data_complexity_mode == true) {
/*  357 */         max_corr = calculatePitch(first_res, blocknumber * 40, pitchArray);
/*      */       } else {
/*  359 */         max_corr = calculatePitch_Light(first_res, blocknumber * 40, pitchArray);
/*      */       }
/*  361 */       int pitch = pitchArray[0];
/*      */       
/*  363 */       float gain = calculatePitchGain(max_corr, pitch);
/*      */       
/*  365 */       int offset = analizeSecondResidual(gain, pitch, first_res, blocknumber * 40, outsegment);
/*      */       
/*      */ 
/*  368 */       quantizeSecondResidual(offset, outsegment);
/*      */       
/*  370 */       this.data_residual_Index += 40;
/*      */     }
/*      */     
/*      */ 
/*  374 */     if (true == this.data_vad_mode) {
/*  375 */       doVAD();
/*      */     }
/*      */     else {
/*  378 */       this.frameType = 0;
/*      */     }
/*      */     
/*      */ 
/*  382 */     packBitStream(output_bits, output_offset);
/*      */     
/*      */ 
/*  385 */     System.arraycopy(this.data_residual, 160, this.data_residual, 0, 120);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void PreProcessing(float[] input, float[] output)
/*      */   {
/*  399 */     float buffer = this.data_buffer;
/*  400 */     float scaledSample = this.data_scaledSample;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  407 */     for (int i = 0; i < 160; i++)
/*      */     {
/*  409 */       float temp = scaledSample;
/*      */       
/*  411 */       scaledSample = input[i] * 0.5F;
/*      */       
/*  413 */       output[i] = (buffer * -0.85998535F);
/*      */       
/*  415 */       buffer = scaledSample - temp + 0.9989929F * buffer;
/*      */       
/*      */ 
/*  418 */       output[i] += buffer + 1.0E-15F;
/*      */     }
/*      */     
/*  421 */     this.data_buffer = buffer;
/*  422 */     this.data_scaledSample = scaledSample;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void Autocorrelations(float[] firstResidual, float[] AutoCorrelations)
/*      */   {
/*  436 */     for (int correlNumber = 0; correlNumber <= 8; correlNumber++) {
/*  437 */       float result = 0.0F;
/*  438 */       for (int i = correlNumber; i < 160; i++) {
/*  439 */         result += firstResidual[i] * firstResidual[(i - correlNumber)];
/*      */       }
/*  441 */       AutoCorrelations[correlNumber] = result;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void schurRecursion(float[] AutoCorrelations, float[] reflectionCoef)
/*      */   {
/*  454 */     float[] KK = this.aux_KK;
/*      */     
/*      */ 
/*  457 */     float[] P = this.aux_P;
/*      */     
/*      */ 
/*      */ 
/*  461 */     if (AutoCorrelations[0] == 0.0F)
/*      */     {
/*  463 */       for (i = 1; i <= 8; i++)
/*  464 */         reflectionCoef[i] = 0.0F;
/*  465 */       return;
/*      */     }
/*      */     
/*  468 */     P[0] = AutoCorrelations[0];
/*  469 */     for (int i = 1; i <= 8; i++)
/*      */     {
/*  471 */       P[i] = (KK[(9 - i)] = AutoCorrelations[i]);
/*      */     }
/*      */     
/*  474 */     for (i = 1; i <= 8; i++)
/*      */     {
/*  476 */       float temp = P[1] > 0.0F ? P[1] : -P[1];
/*  477 */       if (P[0] < temp)
/*      */       {
/*  479 */         for (k = i; k <= 8; k++)
/*  480 */           reflectionCoef[k] = 0.0F;
/*  481 */         return;
/*      */       }
/*  483 */       reflectionCoef[i] = (temp / P[0]);
/*  484 */       if (P[1] > 0.0D)
/*  485 */         reflectionCoef[i] = (-reflectionCoef[i]);
/*  486 */       if (i == 8)
/*  487 */         return;
/*  488 */       P[0] += P[1] * reflectionCoef[i];
/*  489 */       for (int k = 1; k <= 8 - i; k++)
/*      */       {
/*  491 */         P[k] = (P[(k + 1)] + KK[(9 - k)] * reflectionCoef[i]);
/*  492 */         KK[(9 - k)] += P[(k + 1)] * reflectionCoef[i];
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void rToLAR(float[] r, float[] LARpp)
/*      */   {
/*  506 */     float[] MIC = lut_MIC;
/*  507 */     float[] MAC = lut_MAC;
/*  508 */     float[] A = lut_A;
/*  509 */     float[] B = lut_B;
/*  510 */     float[] INVA = lut_INVA;
/*  511 */     int[] Parameters = this.data_Parameters;
/*  512 */     int pParams = 0;
/*  513 */     float[] LAR = this.data_LAR;
/*      */     
/*  515 */     for (int i = 1; i <= 8; i++) {
/*      */       float temp;
/*  517 */       if (r[i] >= 1.0D)
/*      */       {
/*  519 */         temp = MAC[i];
/*  520 */         LAR[(i - 1)] = 1.625F;
/*      */       }
/*  522 */       else if (r[i] <= -1.0D)
/*      */       {
/*  524 */         temp = MIC[i];
/*  525 */         LAR[(i - 1)] = -1.625F;
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*  533 */         float reflectionCoef = r[i];
/*      */         float absReflectionCoef;
/*  535 */         float sgnReflectionCoef; if (reflectionCoef > 0.0F) {
/*  536 */           absReflectionCoef = reflectionCoef;
/*  537 */           sgnReflectionCoef = 1.0F;
/*      */         } else {
/*  539 */           absReflectionCoef = -reflectionCoef;
/*  540 */           sgnReflectionCoef = -1.0F;
/*      */         }
/*      */         float lar;
/*  543 */         if (absReflectionCoef < 0.675F) {
/*  544 */           lar = reflectionCoef;
/*  545 */         } else if (absReflectionCoef < 0.95F) {
/*  546 */           lar = sgnReflectionCoef * (2.0F * absReflectionCoef - 0.675F);
/*      */         } else {
/*  548 */           lar = sgnReflectionCoef * (8.0F * absReflectionCoef - 6.375F);
/*      */         }
/*  550 */         LAR[(i - 1)] = lar;
/*  551 */         temp = A[i] * lar + B[i];
/*      */         
/*  553 */         if (temp >= 0.0F) {
/*  554 */           temp = (float)(temp + 0.5D);
/*      */         } else {
/*  556 */           temp = (float)(temp - 0.5D);
/*      */         }
/*  558 */         temp = (int)temp;
/*      */         
/*  560 */         if (temp > MAC[i])
/*  561 */           temp = MAC[i];
/*  562 */         if (temp < MIC[i]) {
/*  563 */           temp = MIC[i];
/*      */         }
/*      */       }
/*  566 */       temp -= MIC[i];
/*  567 */       Parameters[(pParams++)] = ((int)temp);
/*  568 */       LARpp[i] = ((temp + MIC[i] - B[i]) * INVA[i]);
/*      */     }
/*      */     
/*      */ 
/*  572 */     this.data_pParams = pParams;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void latticeFilter(float[] LARpp, float[] first_res)
/*      */   {
/*  579 */     float[] rp = this.aux_rp;
/*      */     
/*  581 */     float[] u = this.data_u;
/*  582 */     float[] prevLARpp = this.data_prevLARpp;
/*  583 */     int[] k_start = lut_k_start;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  589 */     for (int j = 0; j < 4; j++)
/*      */     {
/*      */ 
/*  592 */       float PrevCoef = 0.75F - j * 0.25F;
/*  593 */       float PresentCoef = 1.0F - PrevCoef;
/*      */       
/*  595 */       for (int i = 1; i <= 8; i++)
/*      */       {
/*      */ 
/*      */ 
/*  599 */         float lar = prevLARpp[i] * PrevCoef + LARpp[i] * PresentCoef;
/*      */         float absLar;
/*  601 */         float sgnLar; if (lar > 0.0F) {
/*  602 */           absLar = lar;
/*  603 */           sgnLar = 1.0F;
/*      */         } else {
/*  605 */           absLar = -lar;
/*  606 */           sgnLar = -1.0F;
/*      */         }
/*      */         float reflectionCoef;
/*  609 */         if (absLar < 0.675F) {
/*  610 */           reflectionCoef = lar;
/*  611 */         } else if (absLar < 1.225F) {
/*  612 */           reflectionCoef = sgnLar * (0.5F * absLar + 0.3375F);
/*      */         } else {
/*  614 */           reflectionCoef = sgnLar * (0.125F * absLar + 0.796875F);
/*      */         }
/*  616 */         rp[i] = reflectionCoef;
/*      */       }
/*      */       
/*  619 */       float u0 = u[0];float u1 = u[1];float u2 = u[2];float u3 = u[3];
/*  620 */       float u4 = u[4];float u5 = u[5];float u6 = u[6];float u7 = u[7];
/*  621 */       float rp1 = rp[1];float rp2 = rp[2];float rp3 = rp[3];float rp4 = rp[4];
/*  622 */       float rp5 = rp[5];float rp6 = rp[6];float rp7 = rp[7];float rp8 = rp[8];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  628 */       int k_end = k_start[(j + 1)];
/*  629 */       for (int k = k_start[j]; k < k_end; k++)
/*      */       {
/*  631 */         float di = first_res[k];
/*  632 */         float temp2 = di;
/*      */         
/*      */ 
/*  635 */         float temp = u0 + rp1 * di;
/*  636 */         di += rp1 * u0;
/*  637 */         u0 = temp2;
/*  638 */         temp2 = temp;
/*      */         
/*  640 */         temp = u1 + rp2 * di;
/*  641 */         di += rp2 * u1;
/*  642 */         u1 = temp2;
/*  643 */         temp2 = temp;
/*      */         
/*  645 */         temp = u2 + rp3 * di;
/*  646 */         di += rp3 * u2;
/*  647 */         u2 = temp2;
/*  648 */         temp2 = temp;
/*      */         
/*  650 */         temp = u3 + rp4 * di;
/*  651 */         di += rp4 * u3;
/*  652 */         u3 = temp2;
/*  653 */         temp2 = temp;
/*      */         
/*  655 */         temp = u4 + rp5 * di;
/*  656 */         di += rp5 * u4;
/*  657 */         u4 = temp2;
/*  658 */         temp2 = temp;
/*      */         
/*  660 */         temp = u5 + rp6 * di;
/*  661 */         di += rp6 * u5;
/*  662 */         u5 = temp2;
/*  663 */         temp2 = temp;
/*      */         
/*  665 */         temp = u6 + rp7 * di;
/*  666 */         di += rp7 * u6;
/*  667 */         u6 = temp2;
/*  668 */         temp2 = temp;
/*      */         
/*  670 */         temp = u7 + rp8 * di;
/*  671 */         di += rp8 * u7;
/*  672 */         u7 = temp2;
/*  673 */         temp2 = temp;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  678 */         first_res[k] = di;
/*      */       }
/*      */       
/*  681 */       u[0] = u0;u[1] = u1;u[2] = u2;u[3] = u3;
/*  682 */       u[4] = u4;u[5] = u5;u[6] = u6;u[7] = u7;
/*      */       
/*  684 */       rp[1] = rp1;rp[2] = rp2;rp[3] = rp3;rp[4] = rp4;
/*  685 */       rp[5] = rp5;rp[6] = rp6;rp[7] = rp7;rp[8] = rp8;
/*      */     }
/*      */     
/*      */ 
/*  689 */     System.arraycopy(LARpp, 1, prevLARpp, 1, 8);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private float calculatePitch(float[] subsegment, int seg_offset, int[] pitch)
/*      */   {
/*  699 */     float max_corr = 0.0F;
/*  700 */     float[] correlations = this.aux_correlations;
/*  701 */     int[] Nc = this.data_Nc;
/*  702 */     int blocknumber = this.data_blockNumber;
/*  703 */     int residual_Index = this.data_residual_Index;
/*  704 */     float[] residual = this.data_residual;
/*  705 */     int pParams = this.data_pParams;
/*  706 */     int[] Parameters = this.data_Parameters;
/*      */     
/*  708 */     pitch[0] = 40;
/*      */     
/*      */ 
/*  711 */     for (int ii = 40; ii <= 120; ii += 3)
/*      */     {
/*  713 */       float result1 = 0.0F;
/*  714 */       float result2 = 0.0F;
/*  715 */       float result3 = 0.0F;
/*      */       
/*  717 */       float residual_p1 = residual[(residual_Index - 1 - ii)];
/*  718 */       float residual_p0 = residual[(residual_Index - 2 - ii)];
/*      */       
/*      */ 
/*      */ 
/*  722 */       for (jj = 0; jj < 40; jj += 2) {
/*  723 */         float subsegment_temp0 = subsegment[(seg_offset + jj)];
/*  724 */         float subsegment_temp1 = subsegment[(seg_offset + jj + 1)];
/*      */         
/*  726 */         int temp_index = residual_Index + jj - ii;
/*  727 */         float residual_n1 = residual_p1;
/*  728 */         float residual_n2 = residual_p0;
/*  729 */         residual_p1 = residual[(temp_index + 1)];
/*  730 */         residual_p0 = residual[temp_index];
/*      */         
/*      */ 
/*  733 */         result1 += subsegment_temp0 * residual_p0 + subsegment_temp1 * residual_p1;
/*  734 */         result2 += subsegment_temp0 * residual_n1 + subsegment_temp1 * residual_p0;
/*  735 */         result3 += subsegment_temp0 * residual_n2 + subsegment_temp1 * residual_n1;
/*      */       }
/*      */       
/*      */ 
/*  739 */       correlations[ii] = result1;
/*  740 */       correlations[(ii + 1)] = result2;
/*  741 */       correlations[(ii + 2)] = result3;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  746 */     for (int jj = 40; jj <= 120; jj++) {
/*  747 */       if (max_corr < correlations[jj])
/*      */       {
/*  749 */         max_corr = correlations[jj];
/*  750 */         pitch[0] = jj;
/*      */       }
/*      */     }
/*      */     
/*  754 */     Nc[blocknumber] = (Parameters[(pParams++)] = pitch[0]);
/*      */     
/*      */ 
/*  757 */     this.data_pParams = pParams;
/*      */     
/*      */ 
/*      */ 
/*  761 */     return max_corr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private float calculatePitch_Light(float[] subsegment, int seg_offset, int[] pitch)
/*      */   {
/*  771 */     float max_corr = 0.0F;
/*  772 */     float[] correlations = this.aux_correlations;
/*  773 */     int[] Nc = this.data_Nc;
/*  774 */     int blocknumber = this.data_blockNumber;
/*  775 */     int residual_Index = this.data_residual_Index;
/*  776 */     float[] residual = this.data_residual;
/*  777 */     int pParams = this.data_pParams;
/*  778 */     int[] Parameters = this.data_Parameters;
/*      */     
/*      */ 
/*  781 */     float[] decimated_subsegment = this.aux_decimated_subsegment;
/*  782 */     float[] decimated_q_frstbase = this.aux_decimated_q_frstbase;
/*  783 */     float[] decimated_correlations = this.aux_decimated_correlations;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  807 */     decimated_subsegment[0] = (0.5F * (subsegment[(seg_offset + 0)] + subsegment[(seg_offset + 1)]));
/*      */     
/*  809 */     int ii = 1; for (int jj = 2; ii <= 19; jj += 2) {
/*  810 */       decimated_subsegment[ii] = (0.25F * (subsegment[(seg_offset + jj - 1)] + subsegment[(seg_offset + jj + 1)]) + 0.5F * subsegment[(seg_offset + jj)]);ii++;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  818 */     decimated_q_frstbase[0] = (0.5F * (residual[(residual_Index - 120)] + residual[(residual_Index - 119)]));
/*      */     
/*  820 */     ii = 1; for (jj = -118; ii <= 59; jj += 2) {
/*  821 */       int index = residual_Index + jj;
/*  822 */       decimated_q_frstbase[ii] = (0.25F * (residual[(index - 1)] + residual[(index + 1)]) + 0.5F * residual[index]);ii++;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  828 */     int decimated_q_frstbase_index = 60;
/*      */     
/*  830 */     for (ii = 20; ii < 60; ii += 2)
/*      */     {
/*  832 */       result1 = 0.0F;result2 = 0.0F;
/*      */       
/*  834 */       for (jj = 0; jj < 20; jj += 2) {
/*  835 */         float decimatedSubsegmentSample0 = decimated_subsegment[jj];
/*  836 */         float decimatedSubsegmentSample1 = decimated_subsegment[(jj + 1)];
/*      */         
/*  838 */         int index = decimated_q_frstbase_index + jj - ii;
/*      */         
/*  840 */         result1 += decimatedSubsegmentSample0 * decimated_q_frstbase[index] + decimatedSubsegmentSample1 * decimated_q_frstbase[(index + 1)];
/*      */         
/*  842 */         result2 += decimatedSubsegmentSample0 * decimated_q_frstbase[(index - 1)] + decimatedSubsegmentSample1 * decimated_q_frstbase[index];
/*      */       }
/*      */       
/*      */ 
/*  846 */       decimated_correlations[(ii - 20)] = result1;
/*  847 */       decimated_correlations[(ii + 1 - 20)] = result2;
/*      */     }
/*      */     
/*      */ 
/*  851 */     float result1 = 0.0F;
/*  852 */     for (jj = 0; jj < 20; jj++)
/*  853 */       result1 += decimated_subsegment[jj] * decimated_q_frstbase[(decimated_q_frstbase_index + jj - ii)];
/*  854 */     decimated_correlations[(ii - 20)] = result1;
/*      */     
/*      */ 
/*      */ 
/*  858 */     int decimated_pitch = 20;
/*  859 */     max_corr = 0.0F;
/*      */     
/*  861 */     for (jj = 20; jj <= 60; jj++) {
/*  862 */       if (max_corr < decimated_correlations[(jj - 20)])
/*      */       {
/*  864 */         max_corr = decimated_correlations[(jj - 20)];
/*  865 */         decimated_pitch = jj;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  871 */     ii = 2 * decimated_pitch - 1;
/*      */     
/*  873 */     if (ii == 39) ii = 40;
/*  874 */     if (ii == 119) { ii = 118;
/*      */     }
/*  876 */     result1 = 0.0F;
/*  877 */     float result2 = 0.0F;
/*  878 */     float result3 = 0.0F;
/*  879 */     for (jj = 0; jj <= 39; jj++) {
/*  880 */       int index = residual_Index + jj - ii;
/*  881 */       float subsegmentSample = subsegment[(seg_offset + jj)];
/*  882 */       result1 += subsegmentSample * residual[index];
/*  883 */       result2 += subsegmentSample * residual[(index - 1)];
/*  884 */       result3 += subsegmentSample * residual[(index - 2)];
/*      */     }
/*      */     
/*  887 */     correlations[ii] = result1;
/*  888 */     correlations[(ii + 1)] = result2;
/*  889 */     correlations[(ii + 2)] = result3;
/*      */     
/*  891 */     pitch[0] = 40;
/*  892 */     max_corr = 0.0F;
/*      */     
/*      */ 
/*  895 */     for (jj = ii; jj <= ii + 2; jj++) {
/*  896 */       if (max_corr < correlations[jj])
/*      */       {
/*  898 */         max_corr = correlations[jj];
/*  899 */         pitch[0] = jj;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  904 */     Nc[blocknumber] = (Parameters[(pParams++)] = pitch[0]);
/*      */     
/*      */ 
/*  907 */     this.data_pParams = pParams;
/*      */     
/*      */ 
/*      */ 
/*  911 */     return max_corr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final float calculatePitchGain(float max_corr, int pitch)
/*      */   {
/*  919 */     float[] residual = this.data_residual;
/*  920 */     int residual_Index = this.data_residual_Index;
/*  921 */     int pParams = this.data_pParams;
/*  922 */     int[] Parameters = this.data_Parameters;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  929 */     float power = 0.0F;
/*  930 */     int index = residual_Index - pitch;
/*  931 */     for (int i = 0; i < 40; i++) {
/*  932 */       float sample = residual[(index++)];
/*  933 */       power += sample * sample;
/*      */     }
/*      */     
/*      */ 
/*      */     float gain;
/*      */     
/*  939 */     if (max_corr <= 0.2D * power) {
/*  940 */       Parameters[(pParams++)] = 0;
/*  941 */       gain = 0.1F;
/*  942 */     } else if (max_corr <= 0.5D * power) {
/*  943 */       Parameters[(pParams++)] = 1;
/*  944 */       gain = 0.35F;
/*  945 */     } else if (max_corr <= 0.8D * power) {
/*  946 */       Parameters[(pParams++)] = 2;
/*  947 */       gain = 0.65F;
/*      */     } else {
/*  949 */       Parameters[(pParams++)] = 3;
/*  950 */       gain = 1.0F;
/*      */     }
/*      */     
/*  953 */     this.data_pParams = pParams;
/*      */     
/*  955 */     return gain;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int analizeSecondResidual(float gain, int pitch, float[] subsegment, int subseg_ofs, float[] outsegment)
/*      */   {
/*  969 */     int Mc = 0;
/*  970 */     float EM = 0.0F;
/*  971 */     float[] wt = this.data_wt;
/*  972 */     int residual_Index = this.data_residual_Index;
/*  973 */     float[] residual = this.data_residual;
/*      */     
/*  975 */     int pParams = this.data_pParams;
/*  976 */     int[] Parameters = this.data_Parameters;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  983 */     int residual_index = residual_Index;
/*  984 */     for (int i = 0; i < 40; i++) {
/*  985 */       float pitchPredictSample = gain * residual[(residual_index - pitch)];
/*      */       
/*  987 */       residual[residual_index] = pitchPredictSample;
/*  988 */       wt[(5 + i)] = (subsegment[(subseg_ofs + i)] - pitchPredictSample);
/*  989 */       residual_index++;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1001 */     for (int i = 0; i < 40; i++) {
/* 1002 */       outsegment[i] = (-0.016357422F * (wt[i] + wt[(i + 10)]) + -0.045654297F * (wt[(i + 1)] + wt[(i + 9)]) + 0.25073242F * (wt[(i + 3)] + wt[(i + 7)]) + 0.70080566F * (wt[(i + 4)] + wt[(i + 6)]) + wt[(i + 5)]);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1015 */     for (int j = 0; j <= 3; j++)
/*      */     {
/*      */ 
/* 1018 */       float temp = 0.0F;
/* 1019 */       int index = j;
/* 1020 */       for (int i = 0; i <= 12; i++) {
/* 1021 */         float sample = outsegment[index];
/* 1022 */         index += 3;
/* 1023 */         temp += sample * sample;
/*      */       }
/*      */       
/* 1026 */       if (EM < temp) {
/* 1027 */         Mc = j;
/* 1028 */         EM = temp;
/*      */       }
/*      */     }
/*      */     
/* 1032 */     Parameters[(pParams++)] = Mc;
/* 1033 */     this.data_pParams = pParams;
/*      */     
/* 1035 */     return Mc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void quantizeSecondResidual(int Mc, float[] outsegment)
/*      */   {
/* 1043 */     int blocknumber = this.data_blockNumber;
/* 1044 */     float[] currentxmax = this.data_currentxmax;
/* 1045 */     float[] residual = this.data_residual;
/* 1046 */     int residual_Index = this.data_residual_Index;
/* 1047 */     int[] lg2s = lut_lg2s;
/* 1048 */     int pParams = this.data_pParams;
/* 1049 */     int[] Parameters = this.data_Parameters;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1055 */     float xmax = 0.0F;
/* 1056 */     for (int i = 0; i < 13; i++)
/*      */     {
/* 1058 */       float temp = outsegment[(Mc + i * 3)];
/* 1059 */       if (temp > xmax) {
/* 1060 */         xmax = temp;
/* 1061 */       } else if (-temp > xmax) {
/* 1062 */         xmax = -temp;
/*      */       }
/*      */     }
/* 1065 */     currentxmax[blocknumber] = xmax;
/*      */     int tempint;
/*      */     float xmaxp;
/*      */     int xmaxc;
/* 1069 */     if (xmax < 0.015625F) {
/* 1070 */       tempint = (int)(xmax * 1024.0F);
/* 1071 */       Parameters[(pParams++)] = tempint;
/* 1072 */       xmaxp = 31 + tempint * 32;
/* 1073 */       xmaxc = (int)(xmax * 1024.0F);
/*      */     }
/*      */     else
/*      */     {
/* 1077 */       tempint = (int)(32768.0F * xmax);
/*      */       
/* 1079 */       tempint >>= 10;
/* 1080 */       if (tempint < 31)
/*      */       {
/* 1082 */         i = lg2s[tempint];
/* 1083 */         xmaxc = (int)((i << 3) + xmax * (1024 >> i));
/* 1084 */         Parameters[(pParams++)] = xmaxc;
/* 1085 */         xmaxp = (256 << i) + (32 << i) - 1 + (xmaxc - 8 - 8 * i) * (32 << i);
/*      */       }
/*      */       else
/*      */       {
/* 1089 */         Parameters[(pParams++)] = 63;
/* 1090 */         xmaxc = 63;
/* 1091 */         xmaxp = 32767.0F;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1097 */     float div_xmaxp = 1.0F / xmaxp;
/*      */     
/* 1099 */     for (i = 0; i < 13; i++)
/*      */     {
/*      */ 
/* 1102 */       tempint = (int)(outsegment[(Mc + i * 3)] * div_xmaxp * 262144.0F);
/*      */       
/* 1104 */       if (tempint > 7) {
/* 1105 */         tempint = 7;
/* 1106 */       } else if (tempint < -7) {
/* 1107 */         tempint = -7;
/*      */       }
/* 1109 */       tempint = tempint + 7 >> 1;
/* 1110 */       Parameters[(pParams++)] = tempint;
/*      */       
/*      */ 
/* 1113 */       residual[(residual_Index + Mc + i * 3)] += (0.25F * tempint - 0.875F) * 3.0517578E-5F * xmaxp;
/*      */     }
/*      */     
/*      */ 
/* 1117 */     this.data_pParams = pParams;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void packBitStream(byte[] outputBits, int output_offset)
/*      */   {
/* 1126 */     int[] Params = this.data_Parameters;
/*      */     
/* 1128 */     int outPtr = output_offset;
/*      */     
/*      */ 
/* 1131 */     outputBits[(outPtr++)] = ((byte)(0xD0 | Params[0] >> 2 & 0xF));
/*      */     
/* 1133 */     outputBits[(outPtr++)] = ((byte)((Params[0] & 0x3) << 6 | Params[1] & 0x3F));
/*      */     
/* 1135 */     outputBits[(outPtr++)] = ((byte)((Params[2] & 0x1F) << 3 | Params[3] >> 2 & 0x7));
/*      */     
/* 1137 */     outputBits[(outPtr++)] = ((byte)((Params[3] & 0x3) << 6 | (Params[4] & 0xF) << 2 | Params[5] >> 2 & 0x3));
/*      */     
/*      */ 
/* 1140 */     outputBits[(outPtr++)] = ((byte)((Params[5] & 0x3) << 6 | (Params[6] & 0x7) << 3 | Params[7] & 0x7));
/*      */     
/*      */ 
/*      */ 
/* 1144 */     int paramPtr = 8;
/*      */     
/* 1146 */     for (int blocknum = 0; blocknum < 4; blocknum++) {
/* 1147 */       outputBits[(outPtr++)] = ((byte)((Params[(paramPtr++)] & 0x7F) << 1 | Params[paramPtr] >> 1 & 0x1));
/*      */       
/* 1149 */       outputBits[(outPtr++)] = ((byte)((Params[(paramPtr++)] & 0x1) << 7 | (Params[(paramPtr++)] & 0x3) << 5 | Params[paramPtr] >> 1 & 0x1F));
/*      */       
/*      */ 
/* 1152 */       outputBits[(outPtr++)] = ((byte)((Params[(paramPtr++)] & 0x1) << 7 | (Params[(paramPtr++)] & 0x7) << 4 | (Params[(paramPtr++)] & 0x7) << 1 | Params[paramPtr] >> 2 & 0x1));
/*      */       
/*      */ 
/*      */ 
/* 1156 */       outputBits[(outPtr++)] = ((byte)((Params[(paramPtr++)] & 0x3) << 6 | (Params[(paramPtr++)] & 0x7) << 3 | Params[(paramPtr++)] & 0x7));
/*      */       
/*      */ 
/* 1159 */       outputBits[(outPtr++)] = ((byte)((Params[(paramPtr++)] & 0x7) << 5 | (Params[(paramPtr++)] & 0x7) << 2 | Params[paramPtr] >> 1 & 0x3));
/*      */       
/*      */ 
/* 1162 */       outputBits[(outPtr++)] = ((byte)((Params[(paramPtr++)] & 0x1) << 7 | (Params[(paramPtr++)] & 0x7) << 4 | (Params[(paramPtr++)] & 0x7) << 1 | Params[paramPtr] >> 2 & 0x1));
/*      */       
/*      */ 
/*      */ 
/* 1166 */       outputBits[(outPtr++)] = ((byte)((Params[(paramPtr++)] & 0x3) << 6 | (Params[(paramPtr++)] & 0x7) << 3 | Params[(paramPtr++)] & 0x7));
/*      */     }
/*      */   }
/*      */   
/*      */   public void gsm_encoder_close() {}
/*      */   
/*      */   protected void doVAD() {}
/*      */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\codec\audio\gsm\GsmEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */