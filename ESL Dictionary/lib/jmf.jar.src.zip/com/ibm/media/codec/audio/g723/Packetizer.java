/*     */ package com.ibm.media.codec.audio.g723;
/*     */ 
/*     */ import com.ibm.media.codec.audio.AudioCodec;
/*     */ import com.ibm.media.codec.audio.AudioPacketizer;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import javax.media.Control;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Packetizer
/*     */   extends AudioPacketizer
/*     */ {
/*     */   public Packetizer()
/*     */   {
/*  24 */     this.packetSize = 48;
/*  25 */     this.supportedInputFormats = new AudioFormat[] { new AudioFormat("g723", 8000.0D, -1, 1, -1, -1, 192, -1.0D, Format.byteArray) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  38 */     this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("g723/rtp", 8000.0D, -1, 1, -1, -1, 192, -1.0D, Format.byteArray) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  52 */     this.PLUGIN_NAME = "G723 Packetizer";
/*     */   }
/*     */   
/*     */ 
/*     */   protected Format[] getMatchingOutputFormats(Format in)
/*     */   {
/*  58 */     AudioFormat af = (AudioFormat)in;
/*     */     
/*  60 */     this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("g723/rtp", 8000.0D, -1, 1, -1, -1, 192, -1.0D, Format.byteArray) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */     return this.supportedOutputFormats;
/*     */   }
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/*  77 */     setPacketSize(this.packetSize);
/*  78 */     reset();
/*     */   }
/*     */   
/*     */   public Object[] getControls()
/*     */   {
/*  83 */     if (this.controls == null) {
/*  84 */       this.controls = new Control[1];
/*  85 */       this.controls[0] = new PacketSizeAdapter(this, this.packetSize, true);
/*     */     }
/*  87 */     return (Object[])this.controls;
/*     */   }
/*     */   
/*     */   public synchronized void setPacketSize(int newPacketSize) {
/*  91 */     this.packetSize = newPacketSize;
/*     */     
/*  93 */     this.sample_count = (this.packetSize / 24 * 240);
/*     */     
/*  95 */     if (this.history == null) {
/*  96 */       this.history = new byte[this.packetSize];
/*  97 */       return;
/*     */     }
/*     */     
/* 100 */     if (this.packetSize > this.history.length) {
/* 101 */       byte[] newHistory = new byte[this.packetSize];
/* 102 */       System.arraycopy(this.history, 0, newHistory, 0, this.historyLength);
/* 103 */       this.history = newHistory;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\codec\audio\g723\Packetizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */