package com.ibm.media.codec.audio.dvi;

class DVIState
{
  public int valprev;
  public int index;
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\codec\audio\dvi\DVIState.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */