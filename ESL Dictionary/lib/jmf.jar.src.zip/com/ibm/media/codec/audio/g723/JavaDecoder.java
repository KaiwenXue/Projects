/*     */ package com.ibm.media.codec.audio.g723;
/*     */ 
/*     */ import com.ibm.media.codec.audio.AudioCodec;
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.controls.SilenceSuppressionAdapter;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Control;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaDecoder
/*     */   extends AudioCodec
/*     */ {
/*     */   protected G723Dec decoder;
/*     */   
/*     */   public JavaDecoder()
/*     */   {
/*  28 */     this.supportedInputFormats = new AudioFormat[] { new AudioFormat("g723"), new AudioFormat("g723/rtp") };
/*     */     
/*  30 */     this.defaultOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR") };
/*  31 */     this.PLUGIN_NAME = "G723 Decoder";
/*     */   }
/*     */   
/*     */   protected Format[] getMatchingOutputFormats(Format in)
/*     */   {
/*  36 */     AudioFormat af = (AudioFormat)in;
/*     */     
/*  38 */     this.supportedOutputFormats = new AudioFormat[] { new AudioFormat("LINEAR", af.getSampleRate(), 16, 1, 0, 1) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  47 */     return this.supportedOutputFormats;
/*     */   }
/*     */   
/*     */   public void open() throws ResourceUnavailableException {
/*  51 */     this.decoder = new G723Dec();
/*  52 */     this.decoder.decoderOpen();
/*     */   }
/*     */   
/*     */   public void reset() {
/*  56 */     resetDecoder();
/*     */   }
/*     */   
/*     */   public void close()
/*     */   {
/*  61 */     freeDecoder();
/*     */   }
/*     */   
/*     */ 
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer)
/*     */   {
/*  67 */     if (!checkInputBuffer(inputBuffer)) {
/*  68 */       return 1;
/*     */     }
/*     */     
/*  71 */     if (isEOM(inputBuffer)) {
/*  72 */       propagateEOM(outputBuffer);
/*  73 */       return 0;
/*     */     }
/*     */     
/*  76 */     int inpLength = inputBuffer.getLength();
/*  77 */     int outLength = calculateOutputSize(inputBuffer.getLength());
/*     */     
/*  79 */     byte[] inpData = (byte[])inputBuffer.getData();
/*  80 */     byte[] outData = validateByteArraySize(outputBuffer, outLength);
/*     */     
/*     */ 
/*  83 */     decode(inpData, inputBuffer.getOffset(), outData, 0, inpLength);
/*     */     
/*  85 */     updateOutput(outputBuffer, this.outputFormat, outLength, 0);
/*  86 */     return 0;
/*     */   }
/*     */   
/*     */   protected void initDecoder() {
/*  90 */     this.decoder.decoderReset();
/*     */   }
/*     */   
/*     */   protected void freeDecoder() {
/*  94 */     this.decoder = null;
/*     */   }
/*     */   
/*     */   protected void resetDecoder() {
/*  98 */     this.decoder.decoderReset();
/*     */   }
/*     */   
/*     */   protected int calculateOutputSize(int inputSize) {
/* 102 */     return inputSize / 24 * 480;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void decode(byte[] inpData, int readPtr, byte[] outData, int writePtr, int inpLength)
/*     */   {
/* 108 */     int numberOfFrames = inpLength / 24;
/* 109 */     int frameSize = 24;
/*     */     
/*     */ 
/*     */ 
/* 113 */     for (int n = 0; n < numberOfFrames; writePtr += 480) {
/* 114 */       this.decoder.decodeFrame(inpData, readPtr, outData, writePtr);n++;readPtr += frameSize;
/*     */     }
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 119 */     if (this.controls == null) {
/* 120 */       this.controls = new Control[1];
/* 121 */       this.controls[0] = new SilenceSuppressionAdapter(this, true, false);
/*     */     }
/* 123 */     return (Object[])this.controls;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\codec\audio\g723\JavaDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */