/*     */ package com.ibm.media.codec.audio.gsm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GsmDecoder_ms
/*     */   extends GsmDecoder
/*     */ {
/*     */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1999.";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean msFrameOdd;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean decodeFrame(byte[] src, int srcoffset, byte[] dst, int dstoffset)
/*     */   {
/*  28 */     this.msFrameOdd = true;
/*  29 */     super.decodeFrame(src, srcoffset, dst, dstoffset);
/*  30 */     this.msFrameOdd = false;
/*  31 */     super.decodeFrame(src, srcoffset, dst, dstoffset + 320);
/*  32 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean UnpackBitStream(byte[] inByteStream, int inputIndex, int[] Parameters)
/*     */   {
/*  37 */     int paramIndex = 0;
/*     */     
/*     */     int n;
/*  40 */     if (this.msFrameOdd)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  45 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] & 0x3F);
/*  46 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 6 & 0x3 | (inByteStream[(++inputIndex)] & 0xF) << 2);
/*  47 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 4 & 0xF | (inByteStream[(++inputIndex)] & 0x1) << 4);
/*  48 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 1 & 0x1F);
/*  49 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 6 & 0x3 | (inByteStream[(++inputIndex)] & 0x3) << 2);
/*  50 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 2 & 0xF);
/*  51 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 6 & 0x3 | (inByteStream[(++inputIndex)] & 0x1) << 2);
/*  52 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 1 & 0x7);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */       for (n = 0; n < 4; n++) {
/*  61 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 4 & 0xF | (inByteStream[(++inputIndex)] & 0x7) << 4);
/*  62 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 3 & 0x3);
/*  63 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 5 & 0x3);
/*  64 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 7 & 0x1 | (inByteStream[(++inputIndex)] & 0x1F) << 1);
/*  65 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 5 & 0x7);
/*  66 */         Parameters[(paramIndex++)] = (inByteStream[(++inputIndex)] & 0x7);
/*  67 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 3 & 0x7);
/*  68 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 6 & 0x3 | (inByteStream[(++inputIndex)] & 0x1) << 2);
/*  69 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 1 & 0x7);
/*  70 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 4 & 0x7);
/*  71 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 7 & 0x1 | (inByteStream[(++inputIndex)] & 0x3) << 1);
/*  72 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 2 & 0x7);
/*  73 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 5 & 0x7);
/*  74 */         Parameters[(paramIndex++)] = (inByteStream[(++inputIndex)] & 0x7);
/*  75 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 3 & 0x7);
/*  76 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 6 & 0x3 | (inByteStream[(++inputIndex)] & 0x1) << 2);
/*  77 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 1 & 0x7);
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/*  83 */       inputIndex += 32;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 4 & 0xF | (inByteStream[(++inputIndex)] & 0x3) << 4);
/*  90 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 2 & 0x3F);
/*  91 */       Parameters[(paramIndex++)] = (inByteStream[(++inputIndex)] & 0x1F);
/*  92 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 5 & 0x7 | (inByteStream[(++inputIndex)] & 0x3) << 3);
/*  93 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 2 & 0xF);
/*  94 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 6 & 0x3 | (inByteStream[(++inputIndex)] & 0x3) << 2);
/*  95 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 2 & 0x7);
/*  96 */       Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 5 & 0x7);
/*  97 */       inputIndex++;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 104 */       for (n = 0; n < 4; n++) {
/* 105 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] & 0x7F);
/* 106 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 7 & 0x1 | (inByteStream[(++inputIndex)] & 0x1) << 1);
/* 107 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 1 & 0x3);
/* 108 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 3 & 0x1F | (inByteStream[(++inputIndex)] & 0x1) << 5);
/* 109 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 1 & 0x7);
/* 110 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 4 & 0x7);
/* 111 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 7 & 0x1 | (inByteStream[(++inputIndex)] & 0x3) << 1);
/* 112 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 2 & 0x7);
/* 113 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 5 & 0x7);
/* 114 */         Parameters[(paramIndex++)] = (inByteStream[(++inputIndex)] & 0x7);
/* 115 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 3 & 0x7);
/* 116 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 6 & 0x3 | (inByteStream[(++inputIndex)] & 0x1) << 2);
/* 117 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 1 & 0x7);
/* 118 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 4 & 0x7);
/* 119 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 7 & 0x1 | (inByteStream[(++inputIndex)] & 0x3) << 1);
/* 120 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 2 & 0x7);
/* 121 */         Parameters[(paramIndex++)] = (inByteStream[inputIndex] >> 5 & 0x7);
/* 122 */         inputIndex++;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 127 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\codec\audio\gsm\GsmDecoder_ms.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */