/*     */ package com.ibm.media.codec.video.h263;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YCbCrToRGB
/*     */ {
/*     */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997, 1998.";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  28 */   private static final int[] E02xCr_Table = new int['Ā'];
/*     */   
/*  30 */   private static final int[] E11xCb_Table = new int['Ā'];
/*     */   
/*  32 */   private static final int[] E12xCr_Table = new int['Ā'];
/*     */   
/*  34 */   private static final int[] E21xCb_Table = new int['Ā'];
/*     */   
/*  36 */   private static final int[] Ex0xY_Table = new int['Ā'];
/*     */   
/*  38 */   private static final int[] clipR = new int['Ѐ'];
/*     */   
/*  40 */   private static final int[] clipG = new int['Ѐ'];
/*     */   
/*  42 */   private static final int[] clipB = new int['Ѐ'];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  55 */     for (int i = 0; i < 256; i++) {
/*  56 */       E02xCr_Table[i] = ((int)(1.596D * (i - 128)));
/*  57 */       E11xCb_Table[i] = ((int)(-0.392D * (i - 128)));
/*  58 */       E12xCr_Table[i] = ((int)(-0.813D * (i - 128)));
/*  59 */       E21xCb_Table[i] = ((int)(2.017D * (i - 128)));
/*  60 */       Ex0xY_Table[i] = ((int)(1.164D * (i - 16)));
/*     */     }
/*     */     
/*  63 */     for (int i = 0; i < 1024; i++) {
/*  64 */       int clip = i < 512 ? 255 : i < 256 ? i : 0;
/*     */       
/*     */ 
/*  67 */       clipB[i] = (clip << 16);
/*  68 */       clipG[i] = (clip << 8);
/*  69 */       clipR[i] = clip;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void convert(int[] Y, int[] Cb, int[] Cr, int[] pixData, int srcWidth, int srcHeight, int dstWidth, int dstHeight, int alpha, int colorDepth)
/*     */   {
/* 101 */     int srcDstOffset = srcWidth - dstWidth;
/*     */     
/* 103 */     if (srcDstOffset < 0) {
/* 104 */       return;
/*     */     }
/*     */     
/* 107 */     int shiftedAlpha = alpha << 24;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 115 */     int dstIndex00 = 0;int dstIndex10 = dstWidth;
/* 116 */     int yIndex00 = 0;int yIndex10 = srcWidth;
/* 117 */     int cbIndex = 0;int crIndex = 0;
/*     */     
/* 119 */     for (int i = 0; i < dstHeight; i += 2) {
/* 120 */       for (int j = 0; j < dstWidth; j += 2)
/*     */       {
/* 122 */         byte y00 = (byte)Y[(yIndex00++)];
/* 123 */         byte y01 = (byte)Y[(yIndex00++)];
/* 124 */         byte y10 = (byte)Y[(yIndex10++)];
/* 125 */         byte y11 = (byte)Y[(yIndex10++)];
/*     */         
/* 127 */         int Yval = Ex0xY_Table[(0xFF & y00)];
/* 128 */         int Cb_nCrCb_Idx = 0xFF & (byte)Cb[(cbIndex++)];
/* 129 */         int Cr_nCrCb_Idx = 0xFF & (byte)Cr[(crIndex++)];
/*     */         
/*     */         int partRed;
/* 132 */         int red = Yval + (partRed = E02xCr_Table[Cr_nCrCb_Idx]);
/* 133 */         int partGreen; int green = Yval + (partGreen = E11xCb_Table[Cb_nCrCb_Idx] + E12xCr_Table[Cr_nCrCb_Idx]);
/* 134 */         int partBlue; int blue = Yval + (partBlue = E21xCb_Table[Cb_nCrCb_Idx]);
/*     */         int tempRGB;
/* 136 */         pixData[(dstIndex00++)] = (tempRGB = shiftedAlpha | clipR[(red & 0x3FF)] | clipG[(green & 0x3FF)] | clipB[(blue & 0x3FF)]);
/*     */         
/* 138 */         pixData[(dstIndex00++)] = (y00 != y01 ? shiftedAlpha | clipR[((Yval = Ex0xY_Table[(y01 & 0xFF)]) + partRed & 0x3FF)] | clipG[(Yval + partGreen & 0x3FF)] | clipB[(Yval + partBlue & 0x3FF)] : tempRGB);
/*     */         
/* 140 */         pixData[(dstIndex10++)] = (y00 != y10 ? shiftedAlpha | clipR[((Yval = Ex0xY_Table[(y10 & 0xFF)]) + partRed & 0x3FF)] | clipG[(Yval + partGreen & 0x3FF)] | clipB[(Yval + partBlue & 0x3FF)] : tempRGB);
/*     */         
/* 142 */         pixData[(dstIndex10++)] = (y00 != y11 ? shiftedAlpha | clipR[((Yval = Ex0xY_Table[(y11 & 0xFF)]) + partRed & 0x3FF)] | clipG[(Yval + partGreen & 0x3FF)] | clipB[(Yval + partBlue & 0x3FF)] : tempRGB);
/*     */       }
/*     */       
/* 145 */       yIndex00 = yIndex10 + srcDstOffset;
/* 146 */       yIndex10 += srcWidth + srcDstOffset;
/* 147 */       dstIndex00 = dstIndex10;
/* 148 */       dstIndex10 += dstWidth;
/* 149 */       cbIndex += srcDstOffset / 2;
/* 150 */       crIndex += srcDstOffset / 2;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\codec\video\h263\YCbCrToRGB.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */