package com.ibm.media.protocol;

public abstract interface SourceStreamSlave
{
  public abstract void connect();
  
  public abstract void disconnect();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\protocol\SourceStreamSlave.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */