/*     */ package com.ibm.media.protocol;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.media.Time;
/*     */ import javax.media.protocol.PushBufferDataSource;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MergingPushBufferDataSource
/*     */   extends PushBufferDataSource
/*     */ {
/*     */   MergingDataSource superClass;
/*     */   PushBufferStream[] streams;
/*     */   
/*     */   public MergingPushBufferDataSource(PushBufferDataSource[] sources)
/*     */   {
/*  21 */     this.superClass = new MergingDataSource(sources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PushBufferStream[] getStreams()
/*     */   {
/*  35 */     if (this.streams == null) {
/*  36 */       int totalNoOfStreams = 0;
/*     */       
/*  38 */       for (int i = 0; i < this.superClass.sources.length; i++)
/*  39 */         totalNoOfStreams += ((PushBufferDataSource)this.superClass.sources[i]).getStreams().length;
/*  40 */       this.streams = new PushBufferStream[totalNoOfStreams];
/*  41 */       int totalIndex = 0;
/*  42 */       for (int sourceIndex = 0; sourceIndex < this.superClass.sources.length; sourceIndex++) {
/*  43 */         PushBufferStream[] s = ((PushBufferDataSource)this.superClass.sources[sourceIndex]).getStreams();
/*  44 */         for (int streamIndex = 0; streamIndex < s.length; streamIndex++) {
/*  45 */           this.streams[(totalIndex++)] = s[streamIndex];
/*     */         }
/*     */       }
/*     */     }
/*  49 */     return this.streams;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getContentType()
/*     */   {
/*  63 */     return this.superClass.getContentType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void connect()
/*     */     throws IOException
/*     */   {
/*  78 */     this.superClass.connect();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void disconnect()
/*     */   {
/*  94 */     this.superClass.disconnect();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */     throws IOException
/*     */   {
/* 107 */     this.superClass.start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */     throws IOException
/*     */   {
/* 117 */     this.superClass.stop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Time getDuration()
/*     */   {
/* 132 */     return this.superClass.getDuration();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object[] getControls()
/*     */   {
/* 147 */     return this.superClass.getControls();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getControl(String controlType)
/*     */   {
/* 164 */     return this.superClass.getControl(controlType);
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\protocol\MergingPushBufferDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */