/*     */ package com.ibm.media.protocol;
/*     */ 
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.util.MediaThread;
/*     */ import com.sun.media.util.jdk12;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Controls;
/*     */ import javax.media.Format;
/*     */ import javax.media.protocol.BufferTransferHandler;
/*     */ import javax.media.protocol.PullBufferStream;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ import javax.media.protocol.PushSourceStream;
/*     */ import javax.media.protocol.SourceStream;
/*     */ import javax.media.protocol.SourceTransferHandler;
/*     */ 
/*     */ public class CloneableSourceStreamAdapter
/*     */ {
/*     */   SourceStream master;
/*  27 */   SourceStream adapter = null;
/*  28 */   Vector slaves = new Vector();
/*     */   
/*  30 */   private static JMFSecurity jmfSecurity = null;
/*  31 */   private static boolean securityPrivelege = false;
/*  32 */   private Method[] m = new Method[1];
/*  33 */   private Class[] cl = new Class[1];
/*  34 */   private Object[][] args = new Object[1][0];
/*  35 */   protected int numTracks = 0;
/*     */   protected Format[] trackFormats;
/*     */   
/*     */   static
/*     */   {
/*     */     try {
/*  41 */       jmfSecurity = com.sun.media.JMFSecurityManager.getJMFSecurity();
/*  42 */       securityPrivelege = true;
/*     */     }
/*     */     catch (SecurityException e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   CloneableSourceStreamAdapter(SourceStream master)
/*     */   {
/*  52 */     this.master = master;
/*     */     
/*     */ 
/*  55 */     if ((master instanceof PullSourceStream))
/*  56 */       this.adapter = new PullSourceStreamAdapter();
/*  57 */     if ((master instanceof PullBufferStream))
/*  58 */       this.adapter = new PullBufferStreamAdapter();
/*  59 */     if ((master instanceof PushSourceStream))
/*  60 */       this.adapter = new PushSourceStreamAdapter();
/*  61 */     if ((master instanceof PushBufferStream)) {
/*  62 */       this.adapter = new PushBufferStreamAdapter();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   SourceStream getAdapter()
/*     */   {
/*  72 */     return this.adapter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   SourceStream createSlave()
/*     */   {
/*  83 */     SourceStream slave = null;
/*     */     
/*  85 */     if (((this.master instanceof PullSourceStream)) || ((this.master instanceof PushSourceStream)))
/*     */     {
/*  87 */       slave = new PushSourceStreamSlave(); }
/*  88 */     if (((this.master instanceof PullBufferStream)) || ((this.master instanceof PushBufferStream)))
/*     */     {
/*  90 */       slave = new PushBufferStreamSlave(); }
/*  91 */     this.slaves.addElement(slave);
/*     */     
/*  93 */     return slave;
/*     */   }
/*     */   
/*     */   void copyAndRead(Buffer b) throws IOException
/*     */   {
/*  98 */     if ((this.master instanceof PullBufferStream)) {
/*  99 */       ((PullBufferStream)this.master).read(b);
/*     */     }
/* 101 */     if ((this.master instanceof PushBufferStream)) {
/* 102 */       ((PushBufferStream)this.master).read(b);
/*     */     }
/* 104 */     for (Enumeration e = this.slaves.elements(); e.hasMoreElements();) {
/* 105 */       Object stream = e.nextElement();
/* 106 */       ((PushBufferStreamSlave)stream).setBuffer((Buffer)b.clone());
/* 107 */       Thread.yield();
/*     */     }
/*     */   }
/*     */   
/*     */   int copyAndRead(byte[] buffer, int offset, int length) throws IOException
/*     */   {
/* 113 */     int totalRead = 0;
/* 114 */     if ((this.master instanceof PullSourceStream))
/* 115 */       totalRead = ((PullSourceStream)this.master).read(buffer, offset, length);
/* 116 */     if ((this.master instanceof PushSourceStream)) {
/* 117 */       totalRead = ((PushSourceStream)this.master).read(buffer, offset, length);
/*     */     }
/* 119 */     for (Enumeration e = this.slaves.elements(); e.hasMoreElements();) {
/* 120 */       Object stream = e.nextElement();
/* 121 */       byte[] copyBuffer = new byte[totalRead];
/* 122 */       System.arraycopy(buffer, offset, copyBuffer, 0, totalRead);
/* 123 */       ((PushSourceStreamSlave)stream).setBuffer(copyBuffer);
/*     */     }
/*     */     
/* 126 */     return totalRead;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   class SourceStreamAdapter
/*     */     implements SourceStream
/*     */   {
/*     */     SourceStreamAdapter() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public javax.media.protocol.ContentDescriptor getContentDescriptor()
/*     */     {
/* 140 */       return CloneableSourceStreamAdapter.this.master.getContentDescriptor();
/*     */     }
/*     */     
/*     */     public long getContentLength()
/*     */     {
/* 145 */       return CloneableSourceStreamAdapter.this.master.getContentLength();
/*     */     }
/*     */     
/*     */     public boolean endOfStream()
/*     */     {
/* 150 */       return CloneableSourceStreamAdapter.this.master.endOfStream();
/*     */     }
/*     */     
/*     */     public Object[] getControls()
/*     */     {
/* 155 */       return CloneableSourceStreamAdapter.this.master.getControls();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 160 */     public Object getControl(String controlType) { return CloneableSourceStreamAdapter.this.master.getControl(controlType); }
/*     */   }
/*     */   
/*     */   abstract class PushStreamSlave extends CloneableSourceStreamAdapter.SourceStreamAdapter implements SourceStreamSlave, Runnable { MediaThread notifyingThread;
/*     */     
/* 165 */     PushStreamSlave() { super(); }
/*     */     
/*     */ 
/* 168 */     boolean connected = false;
/*     */     
/*     */     public synchronized void connect()
/*     */     {
/* 172 */       if (this.connected) {
/* 173 */         return;
/*     */       }
/* 175 */       this.connected = true;
/*     */       
/* 177 */       if (CloneableSourceStreamAdapter.jmfSecurity != null) {
/* 178 */         String permission = null;
/*     */         try {
/* 180 */           if (CloneableSourceStreamAdapter.jmfSecurity.getName().startsWith("jmf-security")) {
/* 181 */             permission = "thread";
/* 182 */             CloneableSourceStreamAdapter.jmfSecurity.requestPermission(CloneableSourceStreamAdapter.this.m, CloneableSourceStreamAdapter.this.cl, CloneableSourceStreamAdapter.this.args, 16);
/* 183 */             CloneableSourceStreamAdapter.this.m[0].invoke(CloneableSourceStreamAdapter.this.cl[0], CloneableSourceStreamAdapter.this.args[0]);
/*     */             
/* 185 */             permission = "thread group";
/* 186 */             CloneableSourceStreamAdapter.jmfSecurity.requestPermission(CloneableSourceStreamAdapter.this.m, CloneableSourceStreamAdapter.this.cl, CloneableSourceStreamAdapter.this.args, 32);
/* 187 */             CloneableSourceStreamAdapter.this.m[0].invoke(CloneableSourceStreamAdapter.this.cl[0], CloneableSourceStreamAdapter.this.args[0]);
/* 188 */           } else if (CloneableSourceStreamAdapter.jmfSecurity.getName().startsWith("internet")) {
/* 189 */             PolicyEngine.checkPermission(com.ms.security.PermissionID.THREAD);
/* 190 */             PolicyEngine.assertPermission(com.ms.security.PermissionID.THREAD);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         catch (Throwable e)
/*     */         {
/* 197 */           CloneableSourceStreamAdapter.access$402(false);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 204 */       if ((CloneableSourceStreamAdapter.jmfSecurity != null) && (CloneableSourceStreamAdapter.jmfSecurity.getName().startsWith("jdk12"))) {
/*     */         try {
/* 206 */           Constructor cons = com.sun.media.util.jdk12CreateThreadRunnableAction.cons;
/* 207 */           this.notifyingThread = ((MediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { MediaThread.class, this }) }));
/*     */ 
/*     */ 
/*     */         }
/*     */         catch (Exception e) {}
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 217 */         this.notifyingThread = new MediaThread(this);
/*     */       }
/* 219 */       if (this.notifyingThread != null) {
/* 220 */         if ((CloneableSourceStreamAdapter.this.master instanceof PushBufferStream)) {
/* 221 */           if ((((PushBufferStream)CloneableSourceStreamAdapter.this.master).getFormat() instanceof javax.media.format.VideoFormat)) {
/* 222 */             this.notifyingThread.useVideoPriority();
/*     */           } else
/* 224 */             this.notifyingThread.useAudioPriority();
/*     */         }
/* 226 */         this.notifyingThread.start();
/*     */       }
/*     */     }
/*     */     
/*     */     public synchronized void disconnect()
/*     */     {
/* 232 */       this.connected = false;
/* 233 */       notifyAll();
/*     */     }
/*     */     
/*     */     public abstract void run(); }
/*     */   
/* 238 */   class PushSourceStreamSlave extends CloneableSourceStreamAdapter.PushStreamSlave implements PushSourceStream, Runnable { PushSourceStreamSlave() { super(); }
/*     */     
/*     */ 
/*     */ 
/*     */     SourceTransferHandler handler;
/*     */     
/*     */     private byte[] buffer;
/*     */     
/*     */     synchronized void setBuffer(byte[] buffer)
/*     */     {
/* 248 */       this.buffer = buffer;
/* 249 */       notifyAll();
/*     */     }
/*     */     
/*     */     public synchronized int read(byte[] buffer, int offset, int length)
/*     */       throws IOException
/*     */     {
/* 255 */       if (length + offset > buffer.length) {
/* 256 */         throw new IOException("buffer is too small");
/*     */       }
/*     */       
/* 259 */       while ((this.buffer == null) && (this.connected)) {
/*     */         try {
/* 261 */           wait(50L);
/*     */         }
/*     */         catch (InterruptedException e) {
/* 264 */           System.out.println("Exception: " + e);
/*     */         }
/*     */       }
/*     */       
/* 268 */       if (!this.connected) {
/* 269 */         throw new IOException("DataSource is not connected");
/*     */       }
/* 271 */       int copyLength = length > this.buffer.length ? this.buffer.length : length;
/* 272 */       System.arraycopy(this.buffer, 0, buffer, offset, copyLength);
/* 273 */       this.buffer = null;
/*     */       
/* 275 */       return copyLength;
/*     */     }
/*     */     
/*     */     public int getMinimumTransferSize()
/*     */     {
/* 280 */       return ((PushSourceStream)CloneableSourceStreamAdapter.this.master).getMinimumTransferSize();
/*     */     }
/*     */     
/*     */     public void setTransferHandler(SourceTransferHandler transferHandler)
/*     */     {
/* 285 */       this.handler = transferHandler;
/*     */     }
/*     */     
/*     */     SourceTransferHandler getTransferHandler()
/*     */     {
/* 290 */       return this.handler;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void run()
/*     */     {
/* 298 */       while ((!endOfStream()) && (this.connected)) {
/*     */         try {
/* 300 */           synchronized (this) {
/* 301 */             wait();
/*     */           }
/*     */         } catch (InterruptedException e) {
/* 304 */           System.out.println("Exception: " + e);
/*     */         }
/*     */         
/* 307 */         if ((this.connected) && (this.handler != null))
/* 308 */           this.handler.transferData(this);
/*     */       } } }
/*     */   
/*     */   class PushBufferStreamSlave extends CloneableSourceStreamAdapter.PushStreamSlave implements PushBufferStream, Runnable { BufferTransferHandler handler;
/*     */     private Buffer b;
/*     */     
/* 314 */     PushBufferStreamSlave() { super(); }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     synchronized void setBuffer(Buffer b)
/*     */     {
/* 324 */       this.b = b;
/* 325 */       notifyAll();
/*     */     }
/*     */     
/*     */     public Format getFormat()
/*     */     {
/* 330 */       return ((PushBufferStream)CloneableSourceStreamAdapter.this.master).getFormat();
/*     */     }
/*     */     
/*     */     public synchronized void read(Buffer buffer)
/*     */       throws IOException
/*     */     {
/* 336 */       while ((this.b == null) && (this.connected)) {
/*     */         try {
/* 338 */           wait(50L);
/*     */         }
/*     */         catch (InterruptedException e) {
/* 341 */           System.out.println("Exception: " + e);
/*     */         }
/*     */       }
/*     */       
/* 345 */       if (!this.connected) {
/* 346 */         throw new IOException("DataSource is not connected");
/*     */       }
/* 348 */       buffer.copy(this.b);
/* 349 */       this.b = null;
/*     */     }
/*     */     
/*     */     public int getMinimumTransferSize()
/*     */     {
/* 354 */       return ((PushSourceStream)CloneableSourceStreamAdapter.this.master).getMinimumTransferSize();
/*     */     }
/*     */     
/*     */     public void setTransferHandler(BufferTransferHandler transferHandler)
/*     */     {
/* 359 */       this.handler = transferHandler;
/*     */     }
/*     */     
/*     */     BufferTransferHandler getTransferHandler()
/*     */     {
/* 364 */       return this.handler;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void run()
/*     */     {
/* 372 */       while ((!endOfStream()) && (this.connected)) {
/*     */         try {
/* 374 */           synchronized (this) {
/* 375 */             wait();
/*     */           }
/*     */         } catch (InterruptedException e) {
/* 378 */           System.out.println("Exception: " + e);
/*     */         }
/* 380 */         if ((this.connected) && (this.handler != null))
/* 381 */           this.handler.transferData(this);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   class PullSourceStreamAdapter extends CloneableSourceStreamAdapter.SourceStreamAdapter implements PullSourceStream {
/* 387 */     PullSourceStreamAdapter() { super(); }
/*     */     
/*     */ 
/*     */     public boolean willReadBlock()
/*     */     {
/* 392 */       return ((PullSourceStream)CloneableSourceStreamAdapter.this.master).willReadBlock();
/*     */     }
/*     */     
/*     */     public int read(byte[] buffer, int offset, int length)
/*     */       throws IOException
/*     */     {
/* 398 */       return CloneableSourceStreamAdapter.this.copyAndRead(buffer, offset, length);
/*     */     }
/*     */   }
/*     */   
/*     */   class PullBufferStreamAdapter extends CloneableSourceStreamAdapter.SourceStreamAdapter implements PullBufferStream {
/* 403 */     PullBufferStreamAdapter() { super(); }
/*     */     
/*     */ 
/*     */     public boolean willReadBlock()
/*     */     {
/* 408 */       return ((PullBufferStream)CloneableSourceStreamAdapter.this.master).willReadBlock();
/*     */     }
/*     */     
/*     */     public void read(Buffer buffer) throws IOException
/*     */     {
/* 413 */       CloneableSourceStreamAdapter.this.copyAndRead(buffer);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 418 */     public Format getFormat() { return ((PullBufferStream)CloneableSourceStreamAdapter.this.master).getFormat(); }
/*     */   }
/*     */   
/*     */   class PushSourceStreamAdapter extends CloneableSourceStreamAdapter.SourceStreamAdapter implements PushSourceStream, SourceTransferHandler { SourceTransferHandler handler;
/*     */     
/* 423 */     PushSourceStreamAdapter() { super(); }
/*     */     
/*     */ 
/*     */ 
/*     */     public int read(byte[] buffer, int offset, int length)
/*     */       throws IOException
/*     */     {
/* 430 */       return CloneableSourceStreamAdapter.this.copyAndRead(buffer, offset, length);
/*     */     }
/*     */     
/*     */     public int getMinimumTransferSize()
/*     */     {
/* 435 */       return ((PushSourceStream)CloneableSourceStreamAdapter.this.master).getMinimumTransferSize();
/*     */     }
/*     */     
/*     */     public void setTransferHandler(SourceTransferHandler transferHandler)
/*     */     {
/* 440 */       this.handler = transferHandler;
/* 441 */       ((PushSourceStream)CloneableSourceStreamAdapter.this.master).setTransferHandler(this);
/*     */     }
/*     */     
/*     */     public void transferData(PushSourceStream stream)
/*     */     {
/* 446 */       if (this.handler != null)
/* 447 */         this.handler.transferData(this);
/*     */     } }
/*     */   
/*     */   class PushBufferStreamAdapter extends CloneableSourceStreamAdapter.SourceStreamAdapter implements PushBufferStream, BufferTransferHandler { BufferTransferHandler handler;
/*     */     
/* 452 */     PushBufferStreamAdapter() { super(); }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Format getFormat()
/*     */     {
/* 459 */       return ((PushBufferStream)CloneableSourceStreamAdapter.this.master).getFormat();
/*     */     }
/*     */     
/*     */     public void read(Buffer buffer) throws IOException
/*     */     {
/* 464 */       CloneableSourceStreamAdapter.this.copyAndRead(buffer);
/*     */     }
/*     */     
/*     */     public void setTransferHandler(BufferTransferHandler transferHandler)
/*     */     {
/* 469 */       this.handler = transferHandler;
/* 470 */       ((PushBufferStream)CloneableSourceStreamAdapter.this.master).setTransferHandler(this);
/*     */     }
/*     */     
/*     */     public void transferData(PushBufferStream stream)
/*     */     {
/* 475 */       if (this.handler != null) {
/* 476 */         this.handler.transferData(this);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\protocol\CloneableSourceStreamAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */