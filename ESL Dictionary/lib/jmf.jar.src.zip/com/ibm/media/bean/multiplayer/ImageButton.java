/*     */ package com.ibm.media.bean.multiplayer;
/*     */ 
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.AWTEventMulticaster;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.awt.image.FilteredImageSource;
/*     */ import java.awt.image.ImageFilter;
/*     */ import java.awt.image.ImageProducer;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageButton
/*     */   extends ImageLabel
/*     */ {
/*     */   protected static final int defaultBorderWidth = 4;
/*  58 */   protected static final Color defaultBorderColor = new Color(160, 160, 160);
/*     */   
/*     */   private char[] text;
/*     */   
/*  62 */   private boolean txtButton = false;
/*     */   
/*  64 */   private boolean mouseIsDown = false;
/*     */   
/*     */ 
/*     */   String actionCommand;
/*     */   
/*     */ 
/*     */   transient ActionListener actionListener;
/*     */   
/*     */ 
/*     */   transient MouseListener mouseListener;
/*     */   
/*     */ 
/*     */   transient MouseMotionListener mouseMotionListener;
/*     */   
/*     */ 
/*     */ 
/*     */   public ImageButton()
/*     */   {
/*  82 */     enableEvents(144L);
/*     */     
/*     */ 
/*  85 */     setBorders();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ImageButton(String text, boolean txt, int width, int height)
/*     */   {
/*  92 */     this.width = width;
/*  93 */     this.height = height;
/*  94 */     if (txt)
/*     */     {
/*  96 */       int length = text.length();
/*  97 */       this.text = new char[length];
/*  98 */       text.getChars(0, length, this.text, 0);
/*  99 */       this.txtButton = txt;
/*     */     }
/* 101 */     enableEvents(144L);
/*     */     
/*     */ 
/* 104 */     setBorders();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageButton(String imageURLString)
/*     */   {
/* 113 */     super(imageURLString);
/* 114 */     enableEvents(144L);
/*     */     
/* 116 */     setBorders();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageButton(URL imageURL)
/*     */   {
/* 125 */     super(imageURL);
/* 126 */     enableEvents(144L);
/*     */     
/* 128 */     setBorders();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageButton(URL imageDirectory, String imageFile)
/*     */   {
/* 138 */     super(imageDirectory, imageFile);
/* 139 */     enableEvents(144L);
/*     */     
/* 141 */     setBorders();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageButton(Image image)
/*     */   {
/* 150 */     super(image);
/* 151 */     enableEvents(144L);
/*     */     
/* 153 */     setBorders();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void waitForImage(boolean doLayout)
/*     */   {
/* 161 */     if (this.txtButton)
/*     */     {
/* 163 */       resize(this.width, this.height);
/* 164 */       this.doneLoading = true;
/* 165 */       return;
/*     */     }
/*     */     
/* 168 */     super.waitForImage(doLayout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void paint(Graphics g)
/*     */   {
/* 176 */     if (!this.doneLoading) {
/* 177 */       waitForImage(true);
/*     */ 
/*     */     }
/* 180 */     else if (!this.txtButton)
/*     */     {
/* 182 */       if (this.explicitSize) {
/* 183 */         g.drawImage(this.image, this.border, this.border, this.width - 2 * this.border, this.height - 2 * this.border, this);
/*     */       }
/*     */       else
/*     */       {
/* 187 */         g.drawImage(this.image, this.border, this.border, this); }
/* 188 */       drawRect(g, 0, 0, this.width - 1, this.height - 1, this.border, this.borderColor);
/*     */       
/*     */ 
/* 191 */       if (this.grayImage == null) {
/* 192 */         createGrayImage(g);
/*     */       }
/*     */     }
/*     */     else {
/* 196 */       int tsize = this.text.length * 9 / 2;
/* 197 */       g.drawChars(this.text, 0, this.text.length, this.width / 2 - tsize, this.height / 2 + 5);
/*     */     }
/*     */     
/* 200 */     drawBorder(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setActionCommand(String command)
/*     */   {
/* 214 */     this.actionCommand = command;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getActionCommand()
/*     */   {
/* 221 */     return this.actionCommand;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void addActionListener(ActionListener l)
/*     */   {
/* 234 */     debug("[addActionListener]: " + l);
/* 235 */     this.actionListener = AWTEventMulticaster.add(this.actionListener, l);
/* 236 */     this.newEventsOnly = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void removeActionListener(ActionListener l)
/*     */   {
/* 249 */     this.actionListener = AWTEventMulticaster.remove(this.actionListener, l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void processEvent(AWTEvent e)
/*     */   {
/* 264 */     debug("[processEvent]: " + e);
/* 265 */     if ((e instanceof ActionEvent)) {
/* 266 */       processActionEvent((ActionEvent)e);
/* 267 */       return;
/*     */     }
/* 269 */     if ((e instanceof MouseEvent)) {
/* 270 */       processMouseEvent((MouseEvent)e);
/* 271 */       return;
/*     */     }
/* 273 */     super.processEvent(e);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void processMouseEvent(MouseEvent e)
/*     */   {
/* 280 */     if (e.getID() == 502)
/*     */     {
/* 282 */       this.mouseIsDown = false;
/* 283 */       paint(getGraphics());
/* 284 */       processEvent(new ActionEvent(this, 1001, this.actionCommand));
/*     */     }
/* 286 */     else if (e.getID() == 501)
/*     */     {
/* 288 */       this.mouseIsDown = true;
/* 289 */       Graphics g = getGraphics();
/* 290 */       int border = getBorder();
/* 291 */       if (!this.txtButton)
/*     */       {
/* 293 */         if (hasExplicitSize()) {
/* 294 */           g.drawImage(getGrayImage(), border, border, getWidth() - 2 * border, getHeight() - 2 * border, this);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 299 */           g.drawImage(getGrayImage(), border, border, this); }
/*     */       }
/* 301 */       drawBorder(false);
/*     */     }
/* 303 */     else if (e.getID() == 505)
/*     */     {
/* 305 */       if (this.mouseIsDown)
/* 306 */         paint(getGraphics());
/*     */     }
/* 308 */     super.processMouseEvent(e);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void processActionEvent(ActionEvent e)
/*     */   {
/* 331 */     debug("Action Event occurred.");
/* 332 */     if (this.actionListener != null) {
/* 333 */       this.actionListener.actionPerformed(e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void setText(String t)
/*     */   {
/* 339 */     if (this.txtButton)
/*     */     {
/* 341 */       this.text = new char[t.length()];
/* 342 */       t.getChars(0, t.length(), this.text, 0);
/* 343 */       paint(getGraphics());
/* 344 */       validate();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDarkness()
/*     */   {
/* 354 */     return this.darkness;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDarkness(int darkness)
/*     */   {
/* 366 */     this.darkness = darkness;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 371 */   private int darkness = -5263441;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Image getGrayImage()
/*     */   {
/* 379 */     return this.grayImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGrayImage(Image grayImage)
/*     */   {
/* 387 */     this.grayImage = grayImage;
/*     */   }
/*     */   
/* 390 */   private Image grayImage = null;
/*     */   
/*     */ 
/*     */   public void drawBorder(boolean isUp)
/*     */   {
/* 395 */     Graphics g = getGraphics();
/* 396 */     if (g == null) return;
/* 397 */     g.setColor(getBorderColor());
/* 398 */     int left = 0;
/* 399 */     int top = 0;
/* 400 */     int width = getWidth();
/* 401 */     int height = getHeight();
/* 402 */     int border = getBorder();
/* 403 */     for (int i = 0; i < border; i++) {
/* 404 */       g.draw3DRect(left, top, width, height, isUp);
/* 405 */       left++;
/* 406 */       top++;
/* 407 */       width -= 2;
/* 408 */       height -= 2;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void setBorders()
/*     */   {
/* 415 */     setBorder(4);
/* 416 */     setBorderColor(defaultBorderColor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void createGrayImage(Graphics g)
/*     */   {
/* 426 */     ImageFilter filter = new GrayFilter(this.darkness);
/* 427 */     ImageProducer producer = new FilteredImageSource(getImage().getSource(), filter);
/*     */     
/*     */ 
/* 430 */     this.grayImage = createImage(producer);
/* 431 */     int border = getBorder();
/* 432 */     if (hasExplicitSize()) {
/* 433 */       prepareImage(this.grayImage, getWidth() - 2 * border, getHeight() - 2 * border, this);
/*     */     }
/*     */     else
/* 436 */       prepareImage(this.grayImage, this);
/* 437 */     super.paint(g);
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\bean\multiplayer\ImageButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */