/*    */ package com.ibm.media.bean.multiplayer;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ButtonPositionEditor
/*    */   extends PropertyEditorSupport
/*    */ {
/* 37 */   String[] positionArr = { JMFUtil.getString("NORTH"), JMFUtil.getString("SOUTH"), JMFUtil.getString("EAST"), JMFUtil.getString("WEST"), JMFUtil.getString("NONE") };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getJavaInitializationString()
/*    */   {
/* 57 */     String result = null;
/*    */     
/* 59 */     String propertyValue = getAsText();
/*    */     
/* 61 */     for (int i = 0; i < this.positionArr.length; i++)
/*    */     {
/* 63 */       if (propertyValue.equals(this.positionArr[i]))
/*    */       {
/* 65 */         return "new java.lang.String(\"" + this.positionArr[i] + "\")";
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 70 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String[] getTags()
/*    */   {
/* 83 */     return this.positionArr;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\bean\multiplayer\ButtonPositionEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */