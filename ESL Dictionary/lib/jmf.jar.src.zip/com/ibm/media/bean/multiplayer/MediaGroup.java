/*     */ package com.ibm.media.bean.multiplayer;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import javax.media.bean.playerbean.MediaPlayer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaGroup
/*     */ {
/*     */   public String mediaName;
/*     */   public String gifName;
/*  69 */   boolean isButtonGif = true;
/*     */   int index;
/*     */   String caption;
/*  72 */   MediaPlayer player = null;
/*  73 */   ImageButton button = null;
/*  74 */   Vector related = null;
/*  75 */   private MultiPlayerBean owner = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int buttonWidth;
/*     */   
/*     */ 
/*     */ 
/*     */   int buttonHeight;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaGroup(String media, String gif, String caption, MultiPlayerBean o)
/*     */   {
/*  91 */     this.mediaName = media;
/*  92 */     this.gifName = gif;
/*  93 */     this.owner = o;
/*  94 */     this.index = (this.owner.numOfMGroups++);
/*  95 */     this.owner.doDebug("Creating " + media + ", " + gif);
/*  96 */     if ((gif == null) || (gif.compareTo("") == 0)) {
/*  97 */       this.button = this.owner.formButton(this.owner.numOfMGroups);
/*     */     } else
/*  99 */       this.button = this.owner.formButton(this.owner.getURL(gif), this.owner.numOfMGroups);
/* 100 */     this.buttonWidth = this.button.width;
/* 101 */     this.buttonHeight = this.button.height;
/* 102 */     this.caption = caption;
/* 103 */     this.owner.doDebug("Created: " + media + "\nNext Index: " + this.owner.numOfMGroups);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaGroup(String media, String gif, boolean isGif, String caption, MultiPlayerBean o)
/*     */   {
/* 120 */     this.mediaName = media;
/* 121 */     this.gifName = gif;
/* 122 */     this.caption = caption;
/* 123 */     this.isButtonGif = isGif;
/* 124 */     this.owner = o;
/* 125 */     this.index = (this.owner.numOfMGroups++);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void finalize()
/*     */     throws Throwable
/*     */   {
/* 135 */     super.finalize();
/* 136 */     this.button = null;
/* 137 */     this.owner = null;
/* 138 */     this.player = null;
/* 139 */     this.related = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPlayer(MediaPlayer pb)
/*     */   {
/* 148 */     this.player = pb;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MediaPlayer getPlayer()
/*     */   {
/* 160 */     return this.player;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setButton(ImageButton b)
/*     */   {
/* 172 */     this.button = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageButton getButton()
/*     */   {
/* 184 */     return this.button;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIsButtonGif(boolean b)
/*     */   {
/* 195 */     this.isButtonGif = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isButtonGif()
/*     */   {
/* 206 */     return this.isButtonGif;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void delete()
/*     */   {
/* 217 */     this.owner.deleteMGroup(this.index);
/*     */     try {
/* 219 */       finalize();
/*     */     }
/*     */     catch (Throwable e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRelated(RelatedLink l)
/*     */   {
/* 232 */     this.owner.doDebug("setRelated: link=" + l.link);
/* 233 */     if (this.related == null)
/*     */     {
/* 235 */       this.related = new Vector();
/*     */     }
/*     */     
/* 238 */     int i = this.related.size() - 1;
/* 239 */     int j = 0;
/* 240 */     boolean insert = false;
/* 241 */     while ((j < i) && (!insert))
/*     */     {
/* 243 */       if (l.startTime > ((RelatedLink)this.related.elementAt(j)).startTime)
/* 244 */         insert = true;
/*     */     }
/* 246 */     this.related.insertElementAt(l, j);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIndex(int i)
/*     */   {
/* 258 */     this.index = i;
/* 259 */     if (this.button != null)
/*     */     {
/* 261 */       this.button.setText(Integer.toString(i + 1));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIndex()
/*     */   {
/* 274 */     return this.index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Vector getRelated()
/*     */   {
/* 286 */     return this.related;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\ibm\media\bean\multiplayer\MediaGroup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */