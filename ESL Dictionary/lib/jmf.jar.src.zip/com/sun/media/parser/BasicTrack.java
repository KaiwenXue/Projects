/*     */ package com.sun.media.parser;
/*     */ 
/*     */ import com.sun.media.Log;
/*     */ import java.io.IOException;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Demultiplexer;
/*     */ import javax.media.Format;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.TrackListener;
/*     */ import javax.media.protocol.CachedStream;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.media.protocol.Seekable;
/*     */ import javax.media.protocol.SourceStream;
/*     */ 
/*     */ 
/*     */ public class BasicTrack
/*     */   implements Track
/*     */ {
/*     */   private Format format;
/*  21 */   private boolean enabled = true;
/*     */   protected Time duration;
/*     */   private Time startTime;
/*     */   private int numBuffers;
/*     */   private int dataSize;
/*     */   private PullSourceStream stream;
/*     */   private long minLocation;
/*     */   private long maxLocation;
/*     */   private long maxStartLocation;
/*     */   private BasicPullParser parser;
/*  31 */   private long sequenceNumber = 0L;
/*     */   private TrackListener listener;
/*  33 */   private long seekLocation = -1L;
/*  34 */   private long mediaSizeAtEOM = -1L;
/*  35 */   private boolean warnedUserOfReadPastEOM = false;
/*     */   
/*     */ 
/*     */   public BasicTrack(BasicPullParser parser, Format format, boolean enabled, Time duration, Time startTime, int numBuffers, int dataSize, PullSourceStream stream)
/*     */   {
/*  40 */     this(parser, format, enabled, duration, startTime, numBuffers, dataSize, stream, 0L, Long.MAX_VALUE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BasicTrack(BasicPullParser parser, Format format, boolean enabled, Time duration, Time startTime, int numBuffers, int dataSize, PullSourceStream stream, long minLocation, long maxLocation)
/*     */   {
/*  55 */     this.parser = parser;
/*     */     
/*  57 */     this.format = format;
/*  58 */     this.enabled = enabled;
/*  59 */     this.duration = duration;
/*  60 */     this.startTime = startTime;
/*  61 */     this.numBuffers = numBuffers;
/*  62 */     this.dataSize = dataSize;
/*  63 */     this.stream = stream;
/*  64 */     this.minLocation = minLocation;
/*  65 */     this.maxLocation = maxLocation;
/*  66 */     this.maxStartLocation = (maxLocation - dataSize);
/*     */   }
/*     */   
/*     */   public Format getFormat() {
/*  70 */     return this.format;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean t)
/*     */   {
/*  75 */     this.enabled = t;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/*  79 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public Time getDuration() {
/*  83 */     return this.duration;
/*     */   }
/*     */   
/*     */   public Time getStartTime()
/*     */   {
/*  88 */     return this.startTime;
/*     */   }
/*     */   
/*     */   public void setTrackListener(TrackListener l)
/*     */   {
/*  93 */     this.listener = l;
/*     */   }
/*     */   
/*     */   public synchronized void setSeekLocation(long location)
/*     */   {
/*  98 */     this.seekLocation = location;
/*     */   }
/*     */   
/*     */   public synchronized long getSeekLocation() {
/* 102 */     return this.seekLocation;
/*     */   }
/*     */   
/*     */   public void readFrame(Buffer buffer)
/*     */   {
/* 107 */     if (buffer == null) {
/* 108 */       return;
/*     */     }
/* 110 */     if (!this.enabled) {
/* 111 */       buffer.setDiscard(true);
/* 112 */       return;
/*     */     }
/*     */     
/* 115 */     buffer.setFormat(this.format);
/* 116 */     Object obj = buffer.getData();
/*     */     
/*     */     long location;
/*     */     
/*     */     boolean needToSeek;
/* 121 */     synchronized (this) {
/* 122 */       if (this.seekLocation != -1L) {
/* 123 */         location = this.seekLocation;
/* 124 */         if (this.seekLocation < this.maxLocation)
/* 125 */           this.seekLocation = -1L;
/* 126 */         needToSeek = true;
/*     */       } else {
/* 128 */         location = this.parser.getLocation(this.stream);
/* 129 */         needToSeek = false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 136 */     if (location < this.minLocation)
/*     */     {
/* 138 */       buffer.setDiscard(true);
/* 139 */       return; }
/* 140 */     if (location >= this.maxLocation) {
/* 141 */       buffer.setLength(0);
/* 142 */       buffer.setEOM(true); return; }
/*     */     int needDataSize;
/* 144 */     if (location > this.maxStartLocation) {
/* 145 */       needDataSize = this.dataSize - (int)(location - this.maxStartLocation);
/*     */     } else {
/* 147 */       needDataSize = this.dataSize;
/*     */     }
/*     */     
/*     */     byte[] data;
/* 151 */     if ((obj == null) || (!(obj instanceof byte[])) || (((byte[])obj).length < needDataSize))
/*     */     {
/*     */ 
/*     */ 
/* 155 */       data = new byte[needDataSize];
/* 156 */       buffer.setData(data);
/*     */     } else {
/* 158 */       data = (byte[])obj;
/*     */     }
/*     */     try {
/* 161 */       if ((this.parser.cacheStream != null) && (this.listener != null) && 
/* 162 */         (this.parser.cacheStream.willReadBytesBlock(location, needDataSize)))
/*     */       {
/*     */ 
/* 165 */         this.listener.readHasBlocked(this);
/*     */       }
/*     */       
/* 168 */       if (needToSeek)
/*     */       {
/*     */ 
/* 171 */         long pos = ((Seekable)this.stream).seek(location);
/* 172 */         if (pos == -2L) {
/* 173 */           buffer.setDiscard(true);
/* 174 */           return;
/*     */         }
/*     */       }
/* 177 */       if (this.parser.getMediaTime() != null) {
/* 178 */         buffer.setTimeStamp(this.parser.getMediaTime().getNanoseconds());
/*     */       } else
/* 180 */         buffer.setTimeStamp(-1L);
/* 181 */       buffer.setDuration(-1L);
/*     */       
/* 183 */       int actualBytesRead = this.parser.readBytes(this.stream, data, needDataSize);
/* 184 */       buffer.setOffset(0);
/* 185 */       buffer.setLength(actualBytesRead);
/*     */       
/* 187 */       buffer.setSequenceNumber(++this.sequenceNumber);
/*     */     }
/*     */     catch (IOException e) {
/* 190 */       if (this.maxLocation != Long.MAX_VALUE)
/*     */       {
/*     */ 
/* 193 */         if (!this.warnedUserOfReadPastEOM) {
/* 194 */           Log.warning("Warning: Attempt to read past End of Media");
/* 195 */           Log.warning("This typically happens if the duration is not known or");
/* 196 */           Log.warning("if the media file has incorrect header info");
/* 197 */           this.warnedUserOfReadPastEOM = true;
/*     */         }
/* 199 */         buffer.setLength(0);
/* 200 */         buffer.setEOM(true);
/*     */       }
/*     */       else
/*     */       {
/* 204 */         long length = this.parser.streams[0].getContentLength();
/* 205 */         if (length != -1L)
/*     */         {
/*     */ 
/*     */ 
/* 209 */           this.maxLocation = length;
/* 210 */           this.maxStartLocation = (this.maxLocation - this.dataSize);
/* 211 */           this.mediaSizeAtEOM = (this.maxLocation - this.minLocation);
/* 212 */           buffer.setLength(0);
/* 213 */           buffer.setDiscard(true);
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 220 */           this.maxLocation = this.parser.getLocation(this.stream);
/* 221 */           this.maxStartLocation = (this.maxLocation - this.dataSize);
/* 222 */           this.mediaSizeAtEOM = (this.maxLocation - this.minLocation);
/* 223 */           buffer.setLength(0);
/* 224 */           buffer.setEOM(true);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int mapTimeToFrame(Time t)
/*     */   {
/* 237 */     return Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */   public Time mapFrameToTime(int frameNumber) {
/* 241 */     return Track.TIME_UNKNOWN;
/*     */   }
/*     */   
/*     */   public long getMediaSizeAtEOM()
/*     */   {
/* 246 */     return this.mediaSizeAtEOM;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\parser\BasicTrack.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */