/*      */ package com.sun.media.parser.video;
/*      */ 
/*      */ import com.sun.media.parser.BasicPullParser;
/*      */ import com.sun.media.util.SettableTime;
/*      */ import java.awt.Dimension;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import javax.media.BadHeaderException;
/*      */ import javax.media.Buffer;
/*      */ import javax.media.Duration;
/*      */ import javax.media.Format;
/*      */ import javax.media.IncompatibleSourceException;
/*      */ import javax.media.Time;
/*      */ import javax.media.Track;
/*      */ import javax.media.TrackListener;
/*      */ import javax.media.format.AudioFormat;
/*      */ import javax.media.format.RGBFormat;
/*      */ import javax.media.format.VideoFormat;
/*      */ import javax.media.format.YUVFormat;
/*      */ import javax.media.protocol.CachedStream;
/*      */ import javax.media.protocol.ContentDescriptor;
/*      */ import javax.media.protocol.DataSource;
/*      */ import javax.media.protocol.PullSourceStream;
/*      */ import javax.media.protocol.Seekable;
/*      */ import javax.media.protocol.SourceStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class QuicktimeParser
/*      */   extends BasicPullParser
/*      */ {
/*   34 */   private final boolean enableHintTrackSupport = true;
/*      */   
/*   36 */   private static ContentDescriptor[] supportedFormat = { new ContentDescriptor("video.quicktime") };
/*   37 */   private PullSourceStream stream = null;
/*      */   private Track[] tracks;
/*      */   private Seekable seekableStream;
/*   40 */   private boolean mdatAtomPresent = false;
/*   41 */   private boolean moovAtomPresent = false;
/*      */   
/*      */   public static final int MVHD_ATOM_SIZE = 100;
/*      */   
/*      */   public static final int TKHD_ATOM_SIZE = 84;
/*      */   
/*      */   public static final int MDHD_ATOM_SIZE = 24;
/*      */   
/*      */   public static final int MIN_HDLR_ATOM_SIZE = 24;
/*      */   public static final int MIN_STSD_ATOM_SIZE = 8;
/*      */   public static final int MIN_STTS_ATOM_SIZE = 8;
/*      */   public static final int MIN_STSC_ATOM_SIZE = 8;
/*      */   public static final int MIN_STSZ_ATOM_SIZE = 8;
/*      */   public static final int MIN_STCO_ATOM_SIZE = 8;
/*      */   public static final int MIN_STSS_ATOM_SIZE = 8;
/*      */   public static final int MIN_VIDEO_SAMPLE_DATA_SIZE = 70;
/*      */   public static final int MIN_AUDIO_SAMPLE_DATA_SIZE = 20;
/*      */   public static final int TRACK_ENABLED = 1;
/*      */   public static final int TRACK_IN_MOVIE = 2;
/*      */   public static final int TRACK_IN_PREVIEW = 4;
/*      */   public static final int TRACK_IN_POSTER = 8;
/*      */   public static final String VIDEO = "vide";
/*      */   public static final String AUDIO = "soun";
/*      */   public static final String HINT = "hint";
/*      */   private static final int DATA_SELF_REFERENCE_FLAG = 1;
/*      */   private static final int HINT_NOP_IGNORE = 0;
/*      */   private static final int HINT_IMMEDIATE_DATA = 1;
/*      */   private static final int HINT_SAMPLE_DATA = 2;
/*      */   private static final int HINT_SAMPLE_DESCRIPTION = 3;
/*   70 */   private MovieHeader movieHeader = new MovieHeader(null);
/*      */   
/*   72 */   private int numTracks = 0;
/*   73 */   private int numSupportedTracks = 0;
/*   74 */   private int numberOfHintTracks = 0;
/*      */   
/*   76 */   private static int MAX_TRACKS_SUPPORTED = 100;
/*   77 */   private TrakList[] trakList = new TrakList[MAX_TRACKS_SUPPORTED];
/*      */   private TrakList currentTrack;
/*   79 */   private int keyFrameTrack = -1;
/*   80 */   private SettableTime mediaTime = new SettableTime(0L);
/*      */   
/*   82 */   private int hintAudioTrackNum = -1;
/*      */   
/*   84 */   private boolean debug = false;
/*   85 */   private boolean debug1 = false;
/*   86 */   private boolean debug2 = false;
/*      */   
/*      */ 
/*      */ 
/*   90 */   private Object seekSync = new Object();
/*      */   
/*      */ 
/*   93 */   private int tmpIntBufferSize = 16384;
/*   94 */   private byte[] tmpBuffer = new byte[this.tmpIntBufferSize * 4];
/*      */   
/*      */ 
/*      */ 
/*      */   protected boolean supports(SourceStream[] s)
/*      */   {
/*  100 */     return this.seekable;
/*      */   }
/*      */   
/*      */   public void setSource(DataSource source)
/*      */     throws IOException, IncompatibleSourceException
/*      */   {
/*  106 */     super.setSource(source);
/*  107 */     this.stream = ((PullSourceStream)this.streams[0]);
/*  108 */     this.seekableStream = ((Seekable)this.streams[0]);
/*      */   }
/*      */   
/*      */   private CachedStream getCacheStream() {
/*  112 */     return this.cacheStream;
/*      */   }
/*      */   
/*      */   public ContentDescriptor[] getSupportedInputContentDescriptors() {
/*  116 */     return supportedFormat;
/*      */   }
/*      */   
/*      */   public Track[] getTracks() throws IOException, BadHeaderException {
/*  120 */     if (this.tracks != null) {
/*  121 */       return this.tracks;
/*      */     }
/*  123 */     if (this.seekableStream == null) {
/*  124 */       return new Track[0];
/*      */     }
/*      */     
/*  127 */     if (this.cacheStream != null)
/*      */     {
/*  129 */       this.cacheStream.setEnabledBuffering(false);
/*      */     }
/*  131 */     readHeader();
/*  132 */     if (this.cacheStream != null) {
/*  133 */       this.cacheStream.setEnabledBuffering(true);
/*      */     }
/*      */     
/*  136 */     this.tracks = new Track[this.numSupportedTracks];
/*      */     
/*      */ 
/*      */ 
/*  140 */     int index = 0;
/*  141 */     for (int i = 0; i < this.numSupportedTracks; i++) {
/*  142 */       TrakList trakInfo = this.trakList[i];
/*  143 */       if (trakInfo.trackType.equals("soun")) {
/*  144 */         this.tracks[i] = new AudioTrack(trakInfo);
/*      */ 
/*      */       }
/*  147 */       else if (trakInfo.trackType.equals("vide")) {
/*  148 */         this.tracks[i] = new VideoTrack(trakInfo);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  153 */     for (int i = 0; i < this.numSupportedTracks; i++) {
/*  154 */       TrakList trakInfo = this.trakList[i];
/*  155 */       if (trakInfo.trackType.equals("hint")) {
/*  156 */         int trackBeingHinted = trakInfo.trackIdOfTrackBeingHinted;
/*  157 */         for (int j = 0; j < this.numTracks; j++) {
/*  158 */           if (trackBeingHinted == this.trakList[j].id) {
/*  159 */             trakInfo.indexOfTrackBeingHinted = j;
/*  160 */             String hintedTrackType = this.trakList[j].trackType;
/*  161 */             String encodingOfHintedTrack = this.trakList[trakInfo.indexOfTrackBeingHinted].media.encoding;
/*      */             
/*      */ 
/*  164 */             if (encodingOfHintedTrack.equals("agsm")) {
/*  165 */               encodingOfHintedTrack = "gsm";
/*      */             }
/*  167 */             String rtpEncoding = encodingOfHintedTrack + "/rtp";
/*  168 */             if (hintedTrackType.equals("soun"))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  174 */               Audio audio = (Audio)this.trakList[j].media;
/*      */               
/*  176 */               this.hintAudioTrackNum = i;
/*      */               
/*  178 */               int channels = audio.channels;
/*  179 */               int frameSizeInBytes = audio.frameSizeInBits / 8;
/*  180 */               int samplesPerBlock = audio.samplesPerBlock;
/*  181 */               int sampleRate = audio.sampleRate;
/*      */               
/*  183 */               ((Hint)trakInfo.media).format = new AudioFormat(rtpEncoding, sampleRate, 8, channels);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  189 */               this.tracks[i] = new HintAudioTrack(trakInfo, channels, rtpEncoding, frameSizeInBytes, samplesPerBlock, sampleRate); break;
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  198 */             if (!hintedTrackType.equals("vide"))
/*      */               break;
/*  200 */             int indexOfTrackBeingHinted = trakInfo.indexOfTrackBeingHinted;
/*  201 */             TrakList sampleTrakInfo = null;
/*  202 */             if (indexOfTrackBeingHinted >= 0) {
/*  203 */               sampleTrakInfo = this.trakList[indexOfTrackBeingHinted];
/*      */             }
/*      */             
/*  206 */             int width = 0;
/*  207 */             int height = 0;
/*  208 */             if (sampleTrakInfo != null) {
/*  209 */               Video sampleTrakVideo = (Video)sampleTrakInfo.media;
/*  210 */               width = sampleTrakVideo.width;
/*  211 */               height = sampleTrakVideo.height;
/*      */             }
/*      */             
/*  214 */             if ((width > 0) && (height > 0)) {
/*  215 */               ((Hint)trakInfo.media).format = new VideoFormat(rtpEncoding, new Dimension(width, height), -1, null, -1.0F);
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  224 */             HintVideoTrack hintVideoTrack = new HintVideoTrack(trakInfo);
/*      */             
/*  226 */             this.tracks[i] = hintVideoTrack; break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  236 */     return this.tracks;
/*      */   }
/*      */   
/*      */ 
/*      */   private void readHeader()
/*      */     throws IOException, BadHeaderException
/*      */   {
/*  243 */     while (parseAtom()) {}
/*  244 */     if (!this.moovAtomPresent) {
/*  245 */       throw new BadHeaderException("moov atom not present");
/*      */     }
/*  247 */     if (!this.mdatAtomPresent) {
/*  248 */       throw new BadHeaderException("mdat atom not present");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  253 */     for (int i = 0; i < this.numSupportedTracks; i++) {
/*  254 */       TrakList trak = this.trakList[i];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  266 */       if (trak.buildSyncTable()) {
/*  267 */         this.keyFrameTrack = i;
/*      */       }
/*      */       
/*  270 */       trak.buildSamplePerChunkTable();
/*      */       
/*      */ 
/*  273 */       if (!trak.trackType.equals("soun")) {
/*  274 */         trak.buildSampleOffsetTable();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  280 */         trak.buildStartTimeAndDurationTable();
/*      */         
/*  282 */         float frameRate = (float)(trak.numberOfSamples / trak.duration.getSeconds());
/*      */         
/*      */ 
/*  285 */         trak.media.frameRate = frameRate;
/*      */       }
/*      */       
/*      */ 
/*  289 */       trak.buildCumulativeSamplePerChunkTable();
/*  290 */       trak.media.createFormat();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Time setPosition(Time where, int rounding)
/*      */   {
/*  301 */     double time = where.getSeconds();
/*  302 */     if (time < 0.0D) {
/*  303 */       time = 0.0D;
/*      */     }
/*      */     
/*      */     int keyT;
/*      */     
/*  308 */     if ((((keyT = this.keyFrameTrack) != -1) && (this.tracks[this.keyFrameTrack].isEnabled())) || (((keyT = this.hintAudioTrackNum) != -1) && (this.tracks[this.hintAudioTrackNum].isEnabled())))
/*      */     {
/*      */ 
/*      */ 
/*  312 */       TrakList trakInfo = this.trakList[keyT];
/*  313 */       int index = trakInfo.time2Index(time);
/*      */       
/*  315 */       if (index < 0) {
/*  316 */         ((MediaTrack)this.tracks[keyT]).setSampleIndex(trakInfo.numberOfSamples + 1);
/*      */       }
/*      */       else {
/*      */         int syncIndex;
/*  320 */         if (keyT == this.keyFrameTrack) {
/*  321 */           if (index >= trakInfo.syncSampleMapping.length) {
/*  322 */             index = trakInfo.syncSampleMapping.length - 1;
/*      */           }
/*  324 */           if (trakInfo.syncSampleMapping != null) {
/*  325 */             syncIndex = trakInfo.syncSampleMapping[index];
/*  326 */             double newtime = trakInfo.index2TimeAndDuration(syncIndex).startTime;
/*  327 */             time = newtime;
/*      */           }
/*      */           else
/*      */           {
/*  331 */             syncIndex = index;
/*      */           }
/*      */         } else {
/*  334 */           syncIndex = index;
/*  335 */           double newtime = trakInfo.index2TimeAndDuration(syncIndex).startTime;
/*  336 */           time = newtime;
/*      */         }
/*  338 */         ((MediaTrack)this.tracks[keyT]).setSampleIndex(syncIndex);
/*      */       }
/*      */     }
/*      */     
/*  342 */     for (int i = 0; i < this.numSupportedTracks; i++) {
/*  343 */       if (i != keyT)
/*      */       {
/*      */ 
/*      */ 
/*  347 */         if (this.tracks[i].isEnabled())
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  353 */           ??? = this.trakList[i];
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  358 */           int index = ???.time2Index(time);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  363 */           if ((???.trackType.equals("vide")) || ((???.trackType.equals("hint")) && ((this.tracks[i] instanceof HintVideoTrack))))
/*      */           {
/*      */ 
/*      */ 
/*  367 */             if (index < 0) {
/*  368 */               ((MediaTrack)this.tracks[i]).setSampleIndex(???.numberOfSamples + 1);
/*      */             } else {
/*      */               int syncIndex;
/*  371 */               if (???.syncSampleMapping != null) {
/*  372 */                 syncIndex = ???.syncSampleMapping[index];
/*      */               } else
/*  374 */                 syncIndex = index;
/*  375 */               ((MediaTrack)this.tracks[i]).setSampleIndex(syncIndex);
/*      */             }
/*      */             
/*      */           }
/*  379 */           else if (index < 0) {
/*  380 */             ((MediaTrack)this.tracks[i]).setChunkNumber(???.numberOfChunks + 1);
/*      */           }
/*      */           else
/*      */           {
/*  384 */             ((MediaTrack)this.tracks[i]).setSampleIndex(index);
/*      */             
/*      */ 
/*  387 */             int chunkNumber = ???.index2Chunk(index);
/*      */             int sampleOffsetInChunk;
/*  389 */             if (chunkNumber != 0) {
/*  390 */               if (???.constantSamplesPerChunk == -1)
/*      */               {
/*      */ 
/*  393 */                 sampleOffsetInChunk = index - ???.samplesPerChunk[(chunkNumber - 1)];
/*      */               }
/*      */               else
/*      */               {
/*  397 */                 sampleOffsetInChunk = index - chunkNumber * ???.constantSamplesPerChunk;
/*      */               }
/*      */               
/*      */             }
/*      */             else {
/*  402 */               sampleOffsetInChunk = index;
/*      */             }
/*  404 */             ((AudioTrack)this.tracks[i]).setChunkNumberAndSampleOffset(chunkNumber, sampleOffsetInChunk);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  409 */     if (this.cacheStream != null) {
/*  410 */       synchronized (this) {
/*  411 */         this.cacheStream.abortRead();
/*      */       }
/*      */     }
/*  414 */     synchronized (this.mediaTime) {
/*  415 */       this.mediaTime.set(time);
/*      */     }
/*  417 */     return this.mediaTime;
/*      */   }
/*      */   
/*      */   public Time getMediaTime()
/*      */   {
/*  422 */     return null;
/*      */   }
/*      */   
/*      */   public Time getDuration() {
/*  426 */     return this.movieHeader.duration;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */   {
/*  435 */     return "Parser for quicktime file format";
/*      */   }
/*      */   
/*      */   private boolean parseAtom() throws BadHeaderException {
/*  439 */     boolean readSizeField = false;
/*      */     try
/*      */     {
/*  442 */       int atomSize = readInt(this.stream);
/*      */       
/*  444 */       readSizeField = true;
/*      */       
/*  446 */       String atom = readString(this.stream);
/*      */       
/*      */ 
/*  449 */       if (atomSize < 8) {
/*  450 */         throw new BadHeaderException(atom + ": Bad Atom size " + atomSize);
/*      */       }
/*  452 */       if (atom.equals("moov"))
/*  453 */         return parseMOOV(atomSize - 8);
/*  454 */       if (atom.equals("mdat"))
/*  455 */         return parseMDAT(atomSize - 8);
/*  456 */       skipAtom(atom + " [not implemented]", atomSize - 8);
/*  457 */       return true;
/*      */     }
/*      */     catch (IOException e) {
/*  460 */       if (!readSizeField)
/*      */       {
/*  462 */         return false;
/*      */       }
/*  464 */       throw new BadHeaderException("Unexpected End of Media");
/*      */     }
/*      */   }
/*      */   
/*      */   private void skipAtom(String atom, int size) throws IOException {
/*  469 */     if (this.debug2)
/*  470 */       System.out.println("skip unsupported atom " + atom);
/*  471 */     skip(this.stream, size);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean parseMOOV(int moovSize)
/*      */     throws BadHeaderException
/*      */   {
/*  480 */     boolean trakAtomPresent = false;
/*      */     try
/*      */     {
/*  483 */       this.moovAtomPresent = true;
/*  484 */       long moovMax = getLocation(this.stream) + moovSize;
/*  485 */       int remainingSize = moovSize;
/*      */       
/*      */ 
/*  488 */       int atomSize = readInt(this.stream);
/*  489 */       String atom = readString(this.stream);
/*      */       
/*  491 */       if (atomSize < 8) {
/*  492 */         throw new BadHeaderException(atom + ": Bad Atom size " + atomSize);
/*      */       }
/*  494 */       if (!atom.equals("mvhd")) {
/*  495 */         if (atom.equals("cmov")) {
/*  496 */           throw new BadHeaderException("Compressed movie headers are not supported");
/*      */         }
/*  498 */         throw new BadHeaderException("Expected mvhd atom but got " + atom);
/*      */       }
/*  500 */       parseMVHD(atomSize - 8);
/*      */       
/*      */ 
/*  503 */       remainingSize -= atomSize;
/*      */       
/*      */ 
/*      */ 
/*  507 */       while (remainingSize > 0) {
/*  508 */         atomSize = readInt(this.stream);
/*  509 */         atom = readString(this.stream);
/*  510 */         if (atom.equals("trak")) {
/*  511 */           if (this.trakList[this.numSupportedTracks] == null) {
/*  512 */             this.trakList[this.numSupportedTracks] = (this.currentTrack = new TrakList(null));
/*      */           }
/*  514 */           if (parseTRAK(atomSize - 8)) {
/*  515 */             this.numSupportedTracks += 1;
/*      */           }
/*  517 */           trakAtomPresent = true;
/*  518 */           this.numTracks += 1;
/*  519 */         } else if (atom.equals("ctab")) {
/*  520 */           parseCTAB(atomSize - 8);
/*      */         } else {
/*  522 */           skipAtom(atom + " [atom in moov: not implemented]", atomSize - 8);
/*      */         }
/*  524 */         remainingSize -= atomSize;
/*      */       }
/*      */       
/*  527 */       if (!trakAtomPresent) {
/*  528 */         throw new BadHeaderException("trak atom not present in trak atom container");
/*      */       }
/*  530 */       return !this.mdatAtomPresent;
/*      */     } catch (IOException e) {
/*  532 */       throw new BadHeaderException("IOException when parsing the header");
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean parseMDAT(int size) throws BadHeaderException {
/*      */     try {
/*  538 */       this.mdatAtomPresent = true;
/*  539 */       this.movieHeader.mdatStart = getLocation(this.stream);
/*  540 */       this.movieHeader.mdatSize = size;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  555 */       if (!this.moovAtomPresent) {
/*  556 */         skip(this.stream, size);
/*  557 */         return true;
/*      */       }
/*  559 */       return false;
/*      */     } catch (IOException e) {
/*  561 */       throw new BadHeaderException("Got IOException when seeking past MDAT atom");
/*      */     }
/*      */   }
/*      */   
/*      */   private void parseMVHD(int size)
/*      */     throws BadHeaderException
/*      */   {
/*      */     try
/*      */     {
/*  570 */       if (size != 100) {
/*  571 */         throw new BadHeaderException("mvhd atom: header size is incorrect");
/*      */       }
/*      */       
/*      */ 
/*  575 */       skip(this.stream, 12);
/*      */       
/*  577 */       this.movieHeader.timeScale = readInt(this.stream);
/*  578 */       int duration = readInt(this.stream);
/*  579 */       this.movieHeader.duration = new Time(duration / this.movieHeader.timeScale);
/*      */       
/*  581 */       int preferredRate = readInt(this.stream);
/*  582 */       int preferredVolume = readShort(this.stream);
/*      */       
/*  584 */       skip(this.stream, 10);
/*  585 */       skip(this.stream, 36);
/*      */       
/*  587 */       int previewTime = readInt(this.stream);
/*  588 */       int previewDuration = readInt(this.stream);
/*  589 */       int posterTime = readInt(this.stream);
/*  590 */       int selectionTime = readInt(this.stream);
/*  591 */       int selectionDuration = readInt(this.stream);
/*  592 */       int currentTime = readInt(this.stream);
/*  593 */       nextTrackID = readInt(this.stream);
/*      */     } catch (IOException e) { int nextTrackID;
/*  595 */       throw new BadHeaderException("Got IOException when seeking past MVHD atom");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean parseTRAK(int trakSize)
/*      */     throws BadHeaderException
/*      */   {
/*  604 */     boolean mdiaAtomPresent = false;
/*  605 */     boolean supported = false;
/*      */     try {
/*  607 */       int remainingSize = trakSize;
/*  608 */       int atomSize = readInt(this.stream);
/*  609 */       String atom = readString(this.stream);
/*      */       
/*  611 */       if (atomSize < 8) {
/*  612 */         throw new BadHeaderException(atom + ": Bad Atom size " + atomSize);
/*      */       }
/*  614 */       if (!atom.equals("tkhd")) {
/*  615 */         throw new BadHeaderException("Expected tkhd atom but got " + atom);
/*      */       }
/*  617 */       parseTKHD(atomSize - 8);
/*  618 */       remainingSize -= atomSize;
/*      */       
/*      */ 
/*  621 */       while (remainingSize > 0) {
/*  622 */         atomSize = readInt(this.stream);
/*  623 */         atom = readString(this.stream);
/*  624 */         if (atom.equals("mdia")) {
/*  625 */           supported = parseMDIA(atomSize - 8);
/*  626 */           mdiaAtomPresent = true;
/*  627 */         } else if (atom.equals("tref")) {
/*  628 */           parseTREF(atomSize - 8);
/*      */         } else {
/*  630 */           skipAtom(atom + " [atom in trak: not implemented]", atomSize - 8);
/*      */         }
/*  632 */         remainingSize -= atomSize;
/*      */       }
/*      */     } catch (IOException e) {
/*  635 */       throw new BadHeaderException("Got IOException when seeking past TRAK atom");
/*      */     }
/*  637 */     if (!mdiaAtomPresent) {
/*  638 */       throw new BadHeaderException("mdia atom not present in trak atom container");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  645 */     if ((supported) && (this.currentTrack.media == null))
/*      */     {
/*  647 */       supported = false;
/*      */     }
/*  649 */     return supported;
/*      */   }
/*      */   
/*      */   private void parseCTAB(int ctabSize) throws BadHeaderException
/*      */   {
/*      */     try
/*      */     {
/*  656 */       skip(this.stream, ctabSize);
/*      */     }
/*      */     catch (IOException e) {
/*  659 */       throw new BadHeaderException("....");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void parseTKHD(int tkhdSize)
/*      */     throws BadHeaderException
/*      */   {
/*      */     try
/*      */     {
/*  669 */       if (tkhdSize != 84) {
/*  670 */         throw new BadHeaderException("mvhd atom: header size is incorrect");
/*      */       }
/*  672 */       int iVersionPlusFlag = readInt(this.stream);
/*  673 */       this.currentTrack.flag = (iVersionPlusFlag & 0xFFFFFF);
/*  674 */       skip(this.stream, 8);
/*  675 */       this.currentTrack.id = readInt(this.stream);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  683 */       skip(this.stream, 4);
/*  684 */       int duration = readInt(this.stream);
/*  685 */       this.currentTrack.duration = new Time(duration / this.movieHeader.timeScale);
/*      */       
/*  687 */       skip(this.stream, tkhdSize - 4 - 8 - 4 - 4 - 4);
/*      */     } catch (IOException e) {
/*  689 */       throw new BadHeaderException("Got IOException when seeking past TKHD atom");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean parseMDIA(int mdiaSize)
/*      */     throws BadHeaderException
/*      */   {
/*  703 */     boolean hdlrAtomPresent = false;
/*  704 */     boolean minfAtomPresent = false;
/*      */     try
/*      */     {
/*  707 */       this.currentTrack.trackType = null;
/*  708 */       int remainingSize = mdiaSize;
/*  709 */       int atomSize = readInt(this.stream);
/*  710 */       String atom = readString(this.stream);
/*      */       
/*  712 */       if (atomSize < 8) {
/*  713 */         throw new BadHeaderException(atom + ": Bad Atom size " + atomSize);
/*      */       }
/*  715 */       if (!atom.equals("mdhd")) {
/*  716 */         throw new BadHeaderException("Expected mdhd atom but got " + atom);
/*      */       }
/*  718 */       parseMDHD(atomSize - 8);
/*  719 */       remainingSize -= atomSize;
/*      */       
/*      */ 
/*  722 */       while (remainingSize > 0) {
/*  723 */         atomSize = readInt(this.stream);
/*  724 */         atom = readString(this.stream);
/*  725 */         if (atom.equals("hdlr")) {
/*  726 */           parseHDLR(atomSize - 8);
/*  727 */           hdlrAtomPresent = true;
/*  728 */         } else if (atom.equals("minf")) {
/*  729 */           if (this.currentTrack.trackType == null) {
/*  730 */             throw new BadHeaderException("In MDIA atom container minf atom appears before hdlr");
/*      */           }
/*  732 */           if (this.currentTrack.supported) {
/*  733 */             parseMINF(atomSize - 8);
/*      */           } else {
/*  735 */             skipAtom(atom + " [atom in mdia] as trackType " + this.currentTrack.trackType + " is not supported", atomSize - 8);
/*      */           }
/*      */           
/*      */ 
/*  739 */           minfAtomPresent = true;
/*      */         } else {
/*  741 */           skipAtom(atom + " [atom in mdia: not implemented]", atomSize - 8);
/*      */         }
/*  743 */         remainingSize -= atomSize;
/*      */       }
/*  745 */       if (!hdlrAtomPresent)
/*  746 */         throw new BadHeaderException("hdlr atom not present in mdia atom container");
/*  747 */       if (!minfAtomPresent) {
/*  748 */         throw new BadHeaderException("minf atom not present in mdia atom container");
/*      */       }
/*  750 */       return this.currentTrack.supported;
/*      */     } catch (IOException e) {
/*  752 */       throw new BadHeaderException("Got IOException when seeking past MDIA atom");
/*      */     }
/*      */   }
/*      */   
/*      */   private void parseMDHD(int mdhdSize)
/*      */     throws BadHeaderException
/*      */   {
/*      */     try
/*      */     {
/*  761 */       if (mdhdSize != 24) {
/*  762 */         throw new BadHeaderException("mdhd atom: header size is incorrect");
/*      */       }
/*      */       
/*      */ 
/*  766 */       skip(this.stream, 12);
/*  767 */       int timeScale = readInt(this.stream);
/*  768 */       int duration = readInt(this.stream);
/*  769 */       this.currentTrack.mediaDuration = new Time(duration / timeScale);
/*  770 */       this.currentTrack.mediaTimeScale = timeScale;
/*  771 */       skip(this.stream, 4);
/*      */     } catch (IOException e) {
/*  773 */       throw new BadHeaderException("Got IOException when seeking past MDHD atom");
/*      */     }
/*      */   }
/*      */   
/*      */   private void parseHDLR(int hdlrSize)
/*      */     throws BadHeaderException
/*      */   {
/*      */     try
/*      */     {
/*  782 */       if (hdlrSize < 24) {
/*  783 */         throw new BadHeaderException("hdlr atom: header size is incorrect");
/*      */       }
/*      */       
/*      */ 
/*  787 */       skip(this.stream, 8);
/*  788 */       this.currentTrack.trackType = readString(this.stream);
/*      */       
/*  790 */       this.currentTrack.supported = isSupported(this.currentTrack.trackType);
/*      */       
/*      */ 
/*      */ 
/*  794 */       skip(this.stream, hdlrSize - 8 - 4);
/*      */     } catch (IOException e) {
/*  796 */       throw new BadHeaderException("Got IOException when seeking past HDLR atom");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void parseTREF(int size)
/*      */     throws BadHeaderException
/*      */   {
/*      */     try
/*      */     {
/*  806 */       int childAtomSize = readInt(this.stream);
/*  807 */       size -= 4;
/*      */       
/*      */ 
/*  810 */       String atom = readString(this.stream);
/*  811 */       size -= 4;
/*      */       
/*  813 */       if (atom.equalsIgnoreCase("hint")) {
/*  814 */         this.currentTrack.trackIdOfTrackBeingHinted = readInt(this.stream);
/*  815 */         size -= 4;
/*      */       }
/*      */       
/*  818 */       skip(this.stream, size);
/*      */     } catch (IOException e) {
/*  820 */       throw new BadHeaderException("Got IOException when seeking past HDLR atom");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseMINF(int minfSize)
/*      */     throws BadHeaderException
/*      */   {
/*  834 */     boolean hdlrAtomPresent = false;
/*      */     try {
/*  836 */       int remainingSize = minfSize;
/*  837 */       int atomSize = readInt(this.stream);
/*  838 */       String atom = readString(this.stream);
/*      */       
/*  840 */       if (atomSize < 8) {
/*  841 */         throw new BadHeaderException(atom + ": Bad Atom size " + atomSize);
/*      */       }
/*  843 */       if (!atom.endsWith("hd")) {
/*  844 */         throw new BadHeaderException("Expected media information header atom but got " + atom);
/*      */       }
/*  846 */       skipAtom(atom + " [atom in minf: not implemented]", atomSize - 8);
/*      */       
/*  848 */       remainingSize -= atomSize;
/*      */       
/*      */ 
/*  851 */       while (remainingSize > 0) {
/*  852 */         atomSize = readInt(this.stream);
/*  853 */         atom = readString(this.stream);
/*  854 */         if (atom.equals("hdlr")) {
/*  855 */           skipAtom(atom + " [atom in minf: not implemented]", atomSize - 8);
/*  856 */           hdlrAtomPresent = true;
/*  857 */         } else if (atom.equals("dinf")) {
/*  858 */           parseDINF(atomSize - 8);
/*  859 */         } else if (atom.equals("stbl")) {
/*  860 */           parseSTBL(atomSize - 8);
/*      */         } else {
/*  862 */           skipAtom(atom + " [atom in minf: not implemented]", atomSize - 8);
/*      */         }
/*  864 */         remainingSize -= atomSize;
/*      */       }
/*  866 */       if (!hdlrAtomPresent) {
/*  867 */         throw new BadHeaderException("hdlr atom not present in minf atom container");
/*      */       }
/*      */     } catch (IOException e) {
/*  870 */       throw new BadHeaderException("Got IOException when seeking past MINF atom");
/*      */     }
/*      */   }
/*      */   
/*      */   private void parseDINF(int dinfSize) throws BadHeaderException
/*      */   {
/*      */     try {
/*  877 */       int remainingSize = dinfSize;
/*      */       
/*      */ 
/*  880 */       while (remainingSize > 0) {
/*  881 */         int atomSize = readInt(this.stream);
/*  882 */         String atom = readString(this.stream);
/*      */         
/*      */ 
/*  885 */         if (atom.equals("dref")) {
/*  886 */           parseDREF(atomSize - 8);
/*      */         } else {
/*  888 */           skipAtom(atom + " [Unknown atom in dinf]", atomSize - 8);
/*      */         }
/*  890 */         remainingSize -= atomSize;
/*      */       }
/*      */     } catch (IOException e) {
/*  893 */       throw new BadHeaderException("Got IOException when seeking past DIMF atom");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseDREF(int drefSize)
/*      */     throws BadHeaderException
/*      */   {
/*      */     try
/*      */     {
/*  906 */       skip(this.stream, 4);
/*  907 */       int numEntries = readInt(this.stream);
/*      */       
/*      */ 
/*  910 */       for (int i = 0; i < numEntries; i++) {
/*  911 */         int drefEntrySize = readInt(this.stream);
/*      */         
/*  913 */         int type = readInt(this.stream);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  926 */         int versionPlusFlag = readInt(this.stream);
/*      */         
/*  928 */         skip(this.stream, drefEntrySize - 12);
/*  929 */         if ((versionPlusFlag & 0x1) <= 0) {
/*  930 */           throw new BadHeaderException("Only self contained Quicktime movies are supported");
/*      */         }
/*      */       }
/*      */     } catch (IOException e) {
/*  934 */       throw new BadHeaderException("Got IOException when seeking past DREF atom");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void parseSTBL(int stblSize)
/*      */     throws BadHeaderException
/*      */   {
/*      */     try
/*      */     {
/*  944 */       int remainingSize = stblSize;
/*      */       
/*  946 */       while (remainingSize > 0) {
/*  947 */         int atomSize = readInt(this.stream);
/*  948 */         String atom = readString(this.stream);
/*  949 */         if (atom.equals("stsd")) {
/*  950 */           parseSTSD(atomSize - 8);
/*  951 */         } else if (atom.equals("stts")) {
/*  952 */           parseSTTS(atomSize - 8);
/*  953 */         } else if (atom.equals("stss")) {
/*  954 */           parseSTSS(atomSize - 8);
/*  955 */         } else if (atom.equals("stsc")) {
/*  956 */           parseSTSC(atomSize - 8);
/*  957 */         } else if (atom.equals("stsz")) {
/*  958 */           parseSTSZ(atomSize - 8);
/*  959 */         } else if (atom.equals("stco")) {
/*  960 */           parseSTCO(atomSize - 8);
/*  961 */         } else if (atom.equals("stsh"))
/*      */         {
/*  963 */           skipAtom(atom + " [not implemented]", atomSize - 8);
/*      */         } else {
/*  965 */           skipAtom(atom + " [UNKNOWN atom in stbl: ignored]", atomSize - 8);
/*      */         }
/*  967 */         remainingSize -= atomSize;
/*      */       }
/*      */     } catch (IOException e) {
/*  970 */       throw new BadHeaderException("Got IOException when seeking past STBL atom");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseSTSD(int stsdSize)
/*      */     throws BadHeaderException
/*      */   {
/*      */     try
/*      */     {
/*  982 */       if (stsdSize < 8) {
/*  983 */         throw new BadHeaderException("stsd atom: header size is incorrect");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  990 */       skip(this.stream, 4);
/*      */       
/*  992 */       int numEntries = readInt(this.stream);
/*      */       
/*      */ 
/*  995 */       if (numEntries > 1) {}
/*      */       
/*      */ 
/*  998 */       for (int i = 0; i < numEntries; i++) {
/*  999 */         int sampleDescriptionSize = readInt(this.stream);
/*      */         
/*      */ 
/* 1002 */         String encoding = readString(this.stream);
/*      */         
/*      */ 
/* 1005 */         if (i != 0) {
/* 1006 */           skip(this.stream, sampleDescriptionSize - 8);
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1011 */           skip(this.stream, 6);
/*      */           
/*      */ 
/* 1014 */           if (this.currentTrack.trackType.equals("vide")) {
/* 1015 */             this.currentTrack.media = parseVideoSampleData(encoding, sampleDescriptionSize - 4 - 4 - 6);
/*      */ 
/*      */           }
/* 1018 */           else if (this.currentTrack.trackType.equals("soun")) {
/* 1019 */             this.currentTrack.media = parseAudioSampleData(encoding, sampleDescriptionSize - 4 - 4 - 6);
/*      */ 
/*      */           }
/* 1022 */           else if (this.currentTrack.trackType.equals("hint")) {
/* 1023 */             this.numberOfHintTracks += 1;
/* 1024 */             this.currentTrack.media = parseHintSampleData(encoding, sampleDescriptionSize - 4 - 4 - 6);
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */ 
/* 1032 */             skip(this.stream, sampleDescriptionSize - 4 - 4 - 6);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 1039 */       throw new BadHeaderException("Got IOException when seeking past STSD atom");
/*      */     }
/*      */   }
/*      */   
/*      */   private Video parseVideoSampleData(String encoding, int dataSize)
/*      */     throws IOException, BadHeaderException
/*      */   {
/* 1046 */     skip(this.stream, 2);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1051 */     skip(this.stream, 16);
/*      */     
/* 1053 */     Video video = new Video(null);
/* 1054 */     video.encoding = encoding;
/*      */     
/* 1056 */     video.width = readShort(this.stream);
/* 1057 */     video.height = readShort(this.stream);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1064 */     skip(this.stream, 14);
/*      */     
/* 1066 */     skip(this.stream, 32);
/* 1067 */     video.pixelDepth = readShort(this.stream);
/* 1068 */     video.colorTableID = readShort(this.stream);
/*      */     
/* 1070 */     int colorTableSize = 0;
/* 1071 */     if (video.colorTableID == 0)
/*      */     {
/* 1073 */       colorTableSize = readInt(this.stream);
/* 1074 */       skip(this.stream, colorTableSize - 4);
/*      */     }
/*      */     
/* 1077 */     skip(this.stream, dataSize - 2 - 70 - -colorTableSize);
/*      */     
/* 1079 */     return video;
/*      */   }
/*      */   
/*      */   private Audio parseAudioSampleData(String encoding, int dataSize)
/*      */     throws IOException, BadHeaderException
/*      */   {
/* 1085 */     skip(this.stream, 2);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1091 */     skip(this.stream, 8);
/*      */     
/* 1093 */     Audio audio = new Audio(null);
/* 1094 */     audio.encoding = encoding;
/* 1095 */     audio.channels = readShort(this.stream);
/* 1096 */     audio.bitsPerSample = readShort(this.stream);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1102 */     skip(this.stream, 4);
/* 1103 */     int sampleRate = readInt(this.stream);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1115 */     audio.sampleRate = this.currentTrack.mediaTimeScale;
/*      */     
/*      */ 
/* 1118 */     skip(this.stream, dataSize - 2 - 20);
/* 1119 */     return audio;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Hint parseHintSampleData(String encoding, int dataSize)
/*      */     throws IOException, BadHeaderException
/*      */   {
/* 1128 */     if (!encoding.equals("rtp ")) {
/* 1129 */       System.err.println("Hint track Data Format is not rtp");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1134 */     Hint hint = new Hint(null);
/*      */     
/* 1136 */     int dataReferenceIndex = readShort(this.stream);
/* 1137 */     int hintTrackVersion = readShort(this.stream);
/*      */     
/* 1139 */     if (hintTrackVersion == 0) {
/* 1140 */       System.err.println("Hint Track version #0 is not supported");
/* 1141 */       System.err.println("Use QuickTimePro to convert it to version #1");
/* 1142 */       this.currentTrack.supported = false;
/* 1143 */       if (dataSize - 2 - 2 > 0)
/* 1144 */         skip(this.stream, dataSize - 2 - 2);
/* 1145 */       return hint;
/*      */     }
/*      */     
/* 1148 */     int lastCompatibleHintTrackVersion = readShort(this.stream);
/*      */     
/*      */ 
/* 1151 */     int maxPacketSize = readInt(this.stream);
/* 1152 */     this.currentTrack.maxPacketSize = maxPacketSize;
/* 1153 */     int remaining = dataSize - 2 - 2 - 2 - 4;
/*      */     
/* 1155 */     if (this.debug1) {
/* 1156 */       System.out.println("dataReferenceIndex is " + dataReferenceIndex);
/* 1157 */       System.out.println("hintTrackVersion is " + hintTrackVersion);
/* 1158 */       System.out.println("lastCompatibleHintTrackVersion is " + lastCompatibleHintTrackVersion);
/* 1159 */       System.out.println("maxPacketSize is " + maxPacketSize);
/* 1160 */       System.out.println("remaining is " + remaining);
/*      */     }
/*      */     
/* 1163 */     while (remaining > 8)
/*      */     {
/*      */ 
/* 1166 */       int entryLength = readInt(this.stream);
/* 1167 */       remaining -= 4;
/* 1168 */       if (entryLength > 8) {
/* 1169 */         if (this.debug2) {
/* 1170 */           System.out.println("entryLength is " + entryLength);
/*      */         }
/* 1172 */         String dataTag = readString(this.stream);
/* 1173 */         if (this.debug2)
/* 1174 */           System.out.println("dataTag is " + dataTag);
/* 1175 */         remaining -= 4;
/*      */         
/*      */ 
/* 1178 */         if (dataTag.equals("tims"))
/*      */         {
/*      */ 
/* 1181 */           int rtpTimeScale = readInt(this.stream);
/*      */           
/*      */ 
/*      */ 
/* 1185 */           remaining -= 4;
/* 1186 */         } else if (dataTag.equals("tsro"))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1192 */           System.out.println("QuicktimeParser: rtp: tsro dataTag not supported");
/* 1193 */           int rtpTimeStampOffset = readInt(this.stream);
/* 1194 */           remaining -= 4;
/* 1195 */         } else if (dataTag.equals("snro"))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1201 */           System.out.println("QuicktimeParser: rtp: snro dataTag not supported");
/* 1202 */           int rtpSequenceNumberOffset = readInt(this.stream);
/*      */           
/* 1204 */           remaining -= 4;
/* 1205 */         } else if (dataTag.equals("rely"))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1212 */           System.out.println("QuicktimeParser: rtp: rely dataTag not supported");
/* 1213 */           int rtpReliableTransportFlag = readByte(this.stream);
/*      */           
/* 1215 */           remaining--;
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/* 1221 */           skip(this.stream, remaining);
/* 1222 */           remaining = 0;
/*      */         }
/*      */       } else {
/* 1225 */         skip(this.stream, remaining);
/* 1226 */         remaining = 0;
/* 1227 */         break;
/*      */       }
/*      */     }
/* 1230 */     if (remaining > 0)
/* 1231 */       skip(this.stream, remaining);
/* 1232 */     return hint;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseSTTS(int sttsSize)
/*      */     throws BadHeaderException
/*      */   {
/* 1241 */     if (this.debug2) {
/* 1242 */       System.out.println("parseSTTS: " + sttsSize);
/*      */     }
/*      */     try {
/* 1245 */       if (sttsSize < 8) {
/* 1246 */         throw new BadHeaderException("stts atom: header size is incorrect");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1252 */       skip(this.stream, 4);
/* 1253 */       int numEntries = readInt(this.stream);
/*      */       
/* 1255 */       if (this.debug2)
/* 1256 */         System.out.println("numEntries is " + numEntries);
/* 1257 */       int requiredSize = sttsSize - 8 - numEntries * 8;
/* 1258 */       if (requiredSize < 0) {
/* 1259 */         throw new BadHeaderException("stts atom: inconsistent number_of_entries field");
/*      */       }
/* 1261 */       int totalNumSamples = 0;
/*      */       
/* 1263 */       double timeScaleFactor = 1.0D / this.currentTrack.mediaTimeScale;
/* 1264 */       if (numEntries == 1) {
/* 1265 */         totalNumSamples = readInt(this.stream);
/* 1266 */         this.currentTrack.durationOfSamples = (readInt(this.stream) * timeScaleFactor);
/*      */       } else {
/* 1268 */         int[] timeToSampleIndices = new int[numEntries];
/* 1269 */         double[] durations = new double[numEntries];
/*      */         
/* 1271 */         timeToSampleIndices[0] = readInt(this.stream);
/* 1272 */         totalNumSamples += timeToSampleIndices[0];
/* 1273 */         durations[0] = (readInt(this.stream) * timeScaleFactor * timeToSampleIndices[0]);
/*      */         
/*      */ 
/* 1276 */         int remaining = numEntries - 1;
/*      */         
/* 1278 */         int numIntsWrittenPerLoop = 2;
/*      */         
/* 1280 */         int maxEntriesPerLoop = this.tmpIntBufferSize / numIntsWrittenPerLoop;
/* 1281 */         int i = 1;
/* 1282 */         while (remaining > 0) {
/* 1283 */           int numEntriesPerLoop = remaining > maxEntriesPerLoop ? maxEntriesPerLoop : remaining;
/*      */           
/*      */ 
/* 1286 */           readBytes(this.stream, this.tmpBuffer, numEntriesPerLoop * numIntsWrittenPerLoop * 4);
/*      */           
/*      */ 
/*      */ 
/* 1290 */           int offset = 0;
/* 1291 */           for (int ii = 1; ii <= numEntriesPerLoop; i++) {
/* 1292 */             timeToSampleIndices[i] = parseIntFromArray(this.tmpBuffer, offset, true);
/*      */             
/* 1294 */             offset += 4;
/* 1295 */             int value = parseIntFromArray(this.tmpBuffer, offset, true);
/* 1296 */             offset += 4;
/* 1297 */             durations[i] += value * timeScaleFactor * timeToSampleIndices[i] + durations[(i - 1)];
/*      */             
/*      */ 
/* 1300 */             totalNumSamples += timeToSampleIndices[i];
/* 1301 */             timeToSampleIndices[i] = totalNumSamples;ii++;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1303 */           remaining -= numEntriesPerLoop;
/*      */         }
/* 1305 */         this.currentTrack.timeToSampleIndices = timeToSampleIndices;
/* 1306 */         this.currentTrack.cumulativeDurationOfSamples = durations;
/*      */       }
/*      */       
/* 1309 */       if (this.currentTrack.numberOfSamples == 0) {
/* 1310 */         this.currentTrack.numberOfSamples = totalNumSamples;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1316 */       skip(this.stream, requiredSize);
/*      */     } catch (IOException e) {
/* 1318 */       throw new BadHeaderException("Got IOException when seeking past STTS atom");
/*      */     }
/*      */   }
/*      */   
/*      */   private void parseSTSC(int stscSize) throws BadHeaderException {
/*      */     try {
/* 1324 */       if (stscSize < 8) {
/* 1325 */         throw new BadHeaderException("stsc atom: header size is incorrect");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1331 */       skip(this.stream, 4);
/* 1332 */       int numEntries = readInt(this.stream);
/* 1333 */       int requiredSize = stscSize - 8 - numEntries * 12;
/* 1334 */       if (requiredSize < 0) {
/* 1335 */         throw new BadHeaderException("stsc atom: inconsistent number_of_entries field");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1342 */       int[] compactSamplesChunkNum = new int[numEntries];
/* 1343 */       int[] compactSamplesPerChunk = new int[numEntries];
/* 1344 */       byte[] tmpBuf = new byte[numEntries * 4 * 3];
/* 1345 */       readBytes(this.stream, tmpBuf, numEntries * 4 * 3);
/* 1346 */       int offset = 0;
/* 1347 */       for (int i = 0; i < numEntries; i++) {
/* 1348 */         compactSamplesChunkNum[i] = parseIntFromArray(tmpBuf, offset, true);
/* 1349 */         offset += 4;
/* 1350 */         compactSamplesPerChunk[i] = parseIntFromArray(tmpBuf, offset, true);
/* 1351 */         offset += 4;
/*      */         
/* 1353 */         offset += 4;
/*      */       }
/* 1355 */       tmpBuf = null;
/* 1356 */       this.currentTrack.compactSamplesChunkNum = compactSamplesChunkNum;
/* 1357 */       this.currentTrack.compactSamplesPerChunk = compactSamplesPerChunk;
/* 1358 */       skip(this.stream, requiredSize);
/*      */     } catch (IOException e) {
/* 1360 */       throw new BadHeaderException("Got IOException when seeking past STSC atom");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void parseSTSZ(int stszSize)
/*      */     throws BadHeaderException
/*      */   {
/* 1369 */     if (this.debug2)
/* 1370 */       System.out.println("parseSTSZ: " + stszSize);
/*      */     try {
/* 1372 */       if (stszSize < 8) {
/* 1373 */         throw new BadHeaderException("stsz atom: header size is incorrect");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1379 */       skip(this.stream, 4);
/* 1380 */       this.currentTrack.sampleSize = readInt(this.stream);
/* 1381 */       if (this.currentTrack.sampleSize != 0)
/*      */       {
/* 1383 */         skip(this.stream, stszSize - 8);
/* 1384 */         this.currentTrack.media.maxSampleSize = this.currentTrack.sampleSize;
/* 1385 */         return;
/*      */       }
/*      */       
/*      */ 
/* 1389 */       if (stszSize - 8 < 4) {
/* 1390 */         throw new BadHeaderException("stsz atom: incorrect atom size");
/*      */       }
/*      */       
/* 1393 */       int numEntries = readInt(this.stream);
/* 1394 */       if (this.currentTrack.numberOfSamples == 0) {
/* 1395 */         this.currentTrack.numberOfSamples = numEntries;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1400 */       int requiredSize = stszSize - 8 - 4 - numEntries * 4;
/*      */       
/*      */ 
/* 1403 */       if (requiredSize < 0) {
/* 1404 */         throw new BadHeaderException("stsz atom: inconsistent number_of_entries field");
/*      */       }
/* 1406 */       int[] sampleSizeArray = new int[numEntries];
/* 1407 */       int maxSampleSize = Integer.MIN_VALUE;
/*      */       
/*      */ 
/* 1410 */       int remaining = numEntries;
/*      */       
/* 1412 */       int numIntsWrittenPerLoop = 1;
/* 1413 */       int maxEntriesPerLoop = this.tmpIntBufferSize / numIntsWrittenPerLoop;
/* 1414 */       int i = 0;
/* 1415 */       while (remaining > 0) {
/* 1416 */         int numEntriesPerLoop = remaining > maxEntriesPerLoop ? maxEntriesPerLoop : remaining;
/*      */         
/*      */ 
/* 1419 */         readBytes(this.stream, this.tmpBuffer, numEntriesPerLoop * numIntsWrittenPerLoop * 4);
/*      */         
/* 1421 */         int offset = 0;
/* 1422 */         for (int ii = 1; ii <= numEntriesPerLoop; i++) {
/* 1423 */           int value = parseIntFromArray(this.tmpBuffer, offset, true);
/* 1424 */           offset += 4;
/* 1425 */           if (value > maxSampleSize)
/* 1426 */             maxSampleSize = value;
/* 1427 */           sampleSizeArray[i] = value;ii++;
/*      */         }
/* 1429 */         remaining -= numEntriesPerLoop;
/*      */       }
/* 1431 */       this.currentTrack.sampleSizeArray = sampleSizeArray;
/* 1432 */       this.currentTrack.media.maxSampleSize = maxSampleSize;
/* 1433 */       skip(this.stream, requiredSize);
/*      */     } catch (IOException e) {
/* 1435 */       throw new BadHeaderException("Got IOException when seeking past STSZ atom");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void parseSTCO(int stcoSize)
/*      */     throws BadHeaderException
/*      */   {
/* 1444 */     if (this.debug2) {
/* 1445 */       System.out.println("rtp:parseSTCO: " + stcoSize);
/*      */     }
/*      */     try {
/* 1448 */       if (stcoSize < 8) {
/* 1449 */         throw new BadHeaderException("stco atom: header size is incorrect");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1455 */       skip(this.stream, 4);
/*      */       
/* 1457 */       int numEntries = readInt(this.stream);
/* 1458 */       this.currentTrack.numberOfChunks = numEntries;
/* 1459 */       int[] chunkOffsets = new int[numEntries];
/* 1460 */       int requiredSize = stcoSize - 8 - numEntries * 4;
/* 1461 */       if (requiredSize < 0) {
/* 1462 */         throw new BadHeaderException("stco atom: inconsistent number_of_entries field");
/*      */       }
/*      */       
/* 1465 */       int remaining = numEntries;
/*      */       
/* 1467 */       int numIntsWrittenPerLoop = 1;
/* 1468 */       int maxEntriesPerLoop = this.tmpIntBufferSize / numIntsWrittenPerLoop;
/* 1469 */       int i = 0;
/* 1470 */       while (remaining > 0) {
/* 1471 */         int numEntriesPerLoop = remaining > maxEntriesPerLoop ? maxEntriesPerLoop : remaining;
/*      */         
/*      */ 
/* 1474 */         readBytes(this.stream, this.tmpBuffer, numEntriesPerLoop * numIntsWrittenPerLoop * 4);
/*      */         
/* 1476 */         int offset = 0;
/* 1477 */         for (int ii = 1; ii <= numEntriesPerLoop; i++) {
/* 1478 */           chunkOffsets[i] = parseIntFromArray(this.tmpBuffer, offset, true);
/* 1479 */           offset += 4;ii++;
/*      */         }
/*      */         
/* 1481 */         remaining -= numEntriesPerLoop;
/*      */       }
/* 1483 */       this.currentTrack.chunkOffsets = chunkOffsets;
/* 1484 */       skip(this.stream, requiredSize);
/*      */     } catch (IOException e) {
/* 1486 */       throw new BadHeaderException("Got IOException when seeking past STCO atom");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void parseSTSS(int stssSize)
/*      */     throws BadHeaderException
/*      */   {
/*      */     try
/*      */     {
/* 1496 */       if (stssSize < 8) {
/* 1497 */         throw new BadHeaderException("stss atom: header size is incorrect");
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1503 */       skip(this.stream, 4);
/* 1504 */       int numEntries = readInt(this.stream);
/*      */       
/* 1506 */       int requiredSize = stssSize - 8 - numEntries * 4;
/* 1507 */       if (requiredSize < 0) {
/* 1508 */         throw new BadHeaderException("stss atom: inconsistent number_of_entries field");
/*      */       }
/*      */       
/* 1511 */       if (numEntries < 1) {
/* 1512 */         skip(this.stream, requiredSize);
/* 1513 */         return;
/*      */       }
/*      */       
/* 1516 */       int[] syncSamples = new int[numEntries];
/*      */       
/* 1518 */       int remaining = numEntries;
/*      */       
/* 1520 */       int numIntsWrittenPerLoop = 1;
/* 1521 */       int maxEntriesPerLoop = this.tmpIntBufferSize / numIntsWrittenPerLoop;
/* 1522 */       int i = 0;
/* 1523 */       while (remaining > 0) {
/* 1524 */         int numEntriesPerLoop = remaining > maxEntriesPerLoop ? maxEntriesPerLoop : remaining;
/*      */         
/*      */ 
/* 1527 */         readBytes(this.stream, this.tmpBuffer, numEntriesPerLoop * numIntsWrittenPerLoop * 4);
/*      */         
/* 1529 */         int offset = 0;
/* 1530 */         for (int ii = 1; ii <= numEntriesPerLoop; i++) {
/* 1531 */           syncSamples[i] = parseIntFromArray(this.tmpBuffer, offset, true);
/* 1532 */           offset += 4;ii++;
/*      */         }
/*      */         
/* 1534 */         remaining -= numEntriesPerLoop;
/*      */       }
/* 1536 */       this.currentTrack.syncSamples = syncSamples;
/* 1537 */       skip(this.stream, requiredSize);
/*      */     } catch (IOException e) {
/* 1539 */       throw new BadHeaderException("Got IOException when seeking past STSS atom");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean isSupported(String trackType)
/*      */   {
/* 1546 */     return (trackType.equals("vide")) || (trackType.equals("soun")) || (trackType.equals("hint"));
/*      */   }
/*      */   
/*      */ 
/*      */   private class MovieHeader
/*      */   {
/*      */     int timeScale;
/*      */     
/*      */     private MovieHeader() {}
/*      */     
/*      */     MovieHeader(QuicktimeParser.1 x1)
/*      */     {
/* 1558 */       this();
/*      */     }
/*      */     
/* 1561 */     Time duration = Duration.DURATION_UNKNOWN;
/*      */     long mdatStart;
/*      */     long mdatSize; }
/*      */   
/*      */   private abstract class Media { private Media() {}
/*      */     
/*      */     abstract Format createFormat();
/* 1568 */     Media(QuicktimeParser.1 x1) { this(); }
/*      */     
/*      */     String encoding;
/*      */     int maxSampleSize;
/*      */     float frameRate;
/*      */   }
/*      */   
/*      */   private class Audio extends QuicktimeParser.Media { int channels;
/*      */     
/* 1577 */     private Audio() { super(null); } Audio(QuicktimeParser.1 x1) { this(); }
/*      */     
/*      */ 
/*      */     int bitsPerSample;
/*      */     
/*      */     int sampleRate;
/* 1583 */     AudioFormat format = null;
/*      */     int frameSizeInBits;
/* 1585 */     int samplesPerBlock = 1;
/*      */     
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1590 */       String info = "Audio: " + this.format + "\n";
/* 1591 */       info = info + "encoding is " + this.encoding + "\n";
/* 1592 */       info = info + "Number of channels " + this.channels + "\n";
/* 1593 */       info = info + "Bits per sample " + this.bitsPerSample + "\n";
/* 1594 */       info = info + "sampleRate " + this.sampleRate + "\n";
/* 1595 */       return info;
/*      */     }
/*      */     
/*      */     Format createFormat()
/*      */     {
/* 1600 */       if (this.format != null) {
/* 1601 */         return this.format;
/*      */       }
/* 1603 */       String encodingString = null;
/* 1604 */       boolean signed = true;
/* 1605 */       boolean bigEndian = true;
/*      */       
/*      */ 
/* 1608 */       if ((this.encoding.equals("ulaw")) || (this.encoding.equals("alaw")))
/*      */       {
/* 1610 */         this.bitsPerSample = 8;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1615 */       this.frameSizeInBits = (this.channels * this.bitsPerSample);
/*      */       
/* 1617 */       if (this.encoding.equals("ulaw")) {
/* 1618 */         encodingString = "ULAW";
/* 1619 */         signed = false;
/* 1620 */       } else if (this.encoding.equals("alaw")) {
/* 1621 */         encodingString = "alaw";
/* 1622 */         signed = false;
/* 1623 */       } else if (this.encoding.equals("twos"))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1631 */         encodingString = "LINEAR";
/* 1632 */       } else if (this.encoding.equals("ima4")) {
/* 1633 */         encodingString = "ima4";
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1641 */         this.samplesPerBlock = 64;
/* 1642 */         this.frameSizeInBits = (34 * this.channels * 8);
/* 1643 */       } else if (this.encoding.equals("raw "))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1651 */         encodingString = "LINEAR";
/* 1652 */         signed = false;
/*      */       }
/* 1654 */       else if (this.encoding.equals("agsm")) {
/* 1655 */         encodingString = "gsm";
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1660 */         this.samplesPerBlock = 33;
/* 1661 */         this.frameSizeInBits = 264;
/* 1662 */       } else if (this.encoding.equals("mac3")) {
/* 1663 */         encodingString = "MAC3";
/* 1664 */       } else if (this.encoding.equals("mac6")) {
/* 1665 */         encodingString = "MAC6";
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1672 */         encodingString = this.encoding;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1682 */       this.format = new AudioFormat(encodingString, this.sampleRate, this.bitsPerSample, this.channels, bigEndian ? 1 : 0, signed ? 1 : 0, this.frameSizeInBits, -1.0D, Format.byteArray);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1692 */       return this.format; } }
/*      */   
/*      */   private class Video extends QuicktimeParser.Media { int width;
/*      */     
/* 1696 */     private Video() { super(null); } Video(QuicktimeParser.1 x1) { this(); }
/*      */     
/*      */ 
/*      */     int height;
/*      */     
/*      */     int pixelDepth;
/*      */     int colorTableID;
/*      */     VideoFormat format;
/*      */     Format createFormat()
/*      */     {
/* 1706 */       if (this.format != null) {
/* 1707 */         return this.format;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1727 */       if (this.encoding.toLowerCase().startsWith("raw")) {
/* 1728 */         this.encoding = "rgb";
/* 1729 */         if (this.pixelDepth == 24) {
/* 1730 */           this.format = new RGBFormat(new Dimension(this.width, this.height), -1, Format.byteArray, this.frameRate, this.pixelDepth, 1, 2, 3, 3, this.width * 3, 0, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/* 1740 */         else if (this.pixelDepth == 16) {
/* 1741 */           this.format = new RGBFormat(new Dimension(this.width, this.height), -1, Format.byteArray, this.frameRate, this.pixelDepth, 31744, 992, 31, 2, this.width * 2, 0, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/* 1753 */         else if (this.pixelDepth == 32) {
/* 1754 */           this.encoding = "rgb";
/*      */           
/*      */ 
/* 1757 */           this.format = new RGBFormat(new Dimension(this.width, this.height), -1, Format.byteArray, this.frameRate, this.pixelDepth, 2, 3, 4, 4, this.width * 4, 0, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 1768 */       else if (this.encoding.toLowerCase().equals("8bps"))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1775 */         this.format = new VideoFormat(this.encoding, new Dimension(this.width, this.height), this.maxSampleSize, Format.byteArray, this.frameRate);
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 1780 */       else if (this.encoding.toLowerCase().equals("yuv2"))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1786 */         this.format = new YUVFormat(new Dimension(this.width, this.height), -1, Format.byteArray, this.frameRate, 96, this.width * 2, this.width * 2, 0, 1, 3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1798 */         this.format = new VideoFormat(this.encoding, new Dimension(this.width, this.height), this.maxSampleSize, Format.byteArray, this.frameRate);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1803 */       return this.format;
/*      */     }
/*      */     
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1809 */       String info = "Video: " + this.format + "\n";
/* 1810 */       info = info + "encoding is " + this.encoding + "\n";
/*      */       
/*      */ 
/* 1813 */       info = info + "pixelDepth is " + this.pixelDepth + "\n";
/*      */       
/*      */ 
/* 1816 */       return info;
/*      */     }
/*      */   }
/*      */   
/*      */   private class Hint extends QuicktimeParser.Media {
/* 1821 */     private Hint() { super(null); } Hint(QuicktimeParser.1 x1) { this(); }
/* 1822 */     Format format = null;
/*      */     
/*      */     Format createFormat() {
/* 1825 */       return this.format;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private class TrakList
/*      */   {
/*      */     int flag;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     int id;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     TrakList(QuicktimeParser.1 x1)
/*      */     {
/* 1872 */       this();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1881 */     Time duration = Duration.DURATION_UNKNOWN;
/*      */     
/*      */     int mediaTimeScale;
/*      */     
/* 1885 */     Time mediaDuration = Duration.DURATION_UNKNOWN;
/*      */     
/*      */ 
/*      */     String trackType;
/*      */     
/*      */     int numberOfSamples;
/*      */     
/* 1892 */     int sampleSize = 0;
/*      */     
/*      */ 
/*      */     int[] sampleSizeArray;
/*      */     
/*      */ 
/*      */     boolean supported;
/*      */     
/*      */ 
/*      */     QuicktimeParser.Media media;
/*      */     
/*      */     int numberOfChunks;
/*      */     
/* 1905 */     int[] chunkOffsets = new int[0];
/*      */     
/*      */ 
/* 1908 */     int[] compactSamplesChunkNum = new int[0];
/* 1909 */     int[] compactSamplesPerChunk = new int[0];
/*      */     
/*      */ 
/*      */ 
/* 1913 */     int constantSamplesPerChunk = -1;
/*      */     
/*      */ 
/*      */     int[] samplesPerChunk;
/*      */     
/* 1918 */     double durationOfSamples = -1.0D;
/*      */     
/* 1920 */     int[] timeToSampleIndices = new int[0];
/* 1921 */     double[] cumulativeDurationOfSamples = new double[0];
/* 1922 */     double[] startTimeOfSampleArray = new double[0];
/* 1923 */     double[] durationOfSampleArray = new double[0];
/*      */     
/*      */     long[] sampleOffsetTable;
/*      */     
/*      */     int[] syncSamples;
/*      */     
/*      */     int[] syncSampleMapping;
/* 1930 */     QuicktimeParser.TimeAndDuration timeAndDuration = new QuicktimeParser.TimeAndDuration(QuicktimeParser.this, null);
/*      */     
/* 1932 */     int trackIdOfTrackBeingHinted = -1;
/* 1933 */     int indexOfTrackBeingHinted = -1;
/* 1934 */     int maxPacketSize = -1;
/*      */     
/*      */     void buildSamplePerChunkTable()
/*      */     {
/* 1938 */       if (this.numberOfChunks <= 0)
/* 1939 */         return;
/* 1940 */       if (this.compactSamplesPerChunk.length == 1) {
/* 1941 */         this.constantSamplesPerChunk = this.compactSamplesPerChunk[0];
/*      */         
/* 1943 */         return;
/*      */       }
/*      */       
/* 1946 */       this.samplesPerChunk = new int[this.numberOfChunks];
/* 1947 */       int i = 1;
/* 1948 */       for (int j = 0; j < this.compactSamplesChunkNum.length - 1; j++) {
/* 1949 */         int numSamples = this.compactSamplesPerChunk[j];
/*      */         
/* 1951 */         while (i != this.compactSamplesChunkNum[(j + 1)]) {
/* 1952 */           this.samplesPerChunk[(i - 1)] = numSamples;
/* 1953 */           i++;
/*      */         }
/*      */       }
/* 1956 */       for (; i <= this.numberOfChunks; i++) {
/* 1957 */         this.samplesPerChunk[(i - 1)] = this.compactSamplesPerChunk[j];
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void buildCumulativeSamplePerChunkTable()
/*      */     {
/* 1967 */       if (this.constantSamplesPerChunk == -1) {
/* 1968 */         for (int i = 1; i < this.numberOfChunks; i++) {
/* 1969 */           this.samplesPerChunk[i] += this.samplesPerChunk[(i - 1)];
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void buildSampleOffsetTable()
/*      */     {
/* 1978 */       this.sampleOffsetTable = new long[this.numberOfSamples];
/*      */       
/* 1980 */       int index = 0;
/*      */       int i;
/*      */       long offset;
/*      */       int j;
/* 1984 */       if (this.sampleSize != 0)
/*      */       {
/*      */ 
/* 1987 */         if (this.constantSamplesPerChunk != -1) {
/* 1988 */           for (i = 0; i < this.numberOfChunks; i++) {
/* 1989 */             offset = this.chunkOffsets[i];
/* 1990 */             for (j = 0; j < this.constantSamplesPerChunk; j++) {
/* 1991 */               this.sampleOffsetTable[(index++)] = (offset + j * this.sampleSize);
/*      */             }
/*      */           }
/*      */         } else {
/* 1995 */           for (i = 0; i < this.numberOfChunks; i++) {
/* 1996 */             offset = this.chunkOffsets[i];
/* 1997 */             for (j = 0; j < this.samplesPerChunk[i]; j++) {
/* 1998 */               this.sampleOffsetTable[(index++)] = (offset + j * this.sampleSize);
/*      */             }
/*      */           }
/*      */         }
/*      */       } else {
/* 2003 */         int numSamplesInChunk = 0;
/* 2004 */         if (this.constantSamplesPerChunk != -1)
/* 2005 */           numSamplesInChunk = this.constantSamplesPerChunk;
/* 2006 */         for (i = 0; i < this.numberOfChunks; i++) {
/* 2007 */           offset = this.chunkOffsets[i];
/*      */           
/*      */ 
/* 2010 */           this.sampleOffsetTable[index] = offset;
/* 2011 */           index++;
/*      */           
/* 2013 */           if (this.constantSamplesPerChunk == -1) {
/* 2014 */             numSamplesInChunk = this.samplesPerChunk[i];
/*      */           }
/* 2016 */           for (j = 1; j < numSamplesInChunk; j++) {
/* 2017 */             this.sampleOffsetTable[index] = (this.sampleOffsetTable[(index - 1)] + this.sampleSizeArray[(index - 1)]);
/*      */             
/* 2019 */             index++;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     boolean buildSyncTable()
/*      */     {
/* 2027 */       if (this.syncSamples == null) {
/* 2028 */         return false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2044 */       if (!this.trackType.equals("vide")) {
/* 2045 */         return false;
/*      */       }
/* 2047 */       int numEntries = this.syncSamples.length;
/* 2048 */       if (numEntries == this.numberOfSamples)
/*      */       {
/*      */ 
/* 2051 */         this.syncSamples = null;
/* 2052 */         return false;
/*      */       }
/*      */       
/* 2055 */       this.syncSampleMapping = new int[this.numberOfSamples];
/* 2056 */       int index = 0;
/*      */       int previous;
/* 2058 */       if (this.syncSamples[0] != 1)
/*      */       {
/*      */ 
/* 2061 */         previous = this.syncSampleMapping[0] = 0;
/*      */       } else {
/* 2063 */         previous = this.syncSampleMapping[0] = 0;
/* 2064 */         index++;
/*      */       }
/* 2067 */       for (; 
/* 2067 */           index < this.syncSamples.length; index++) {
/* 2068 */         int next = this.syncSamples[index] - 1;
/* 2069 */         this.syncSampleMapping[next] = next;
/* 2070 */         int range = next - previous - 1;
/* 2071 */         for (int j = previous + 1; j < next; j++)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2080 */           this.syncSampleMapping[j] = previous;
/*      */         }
/* 2082 */         previous = next;
/*      */       }
/* 2084 */       int lastSyncFrame = this.syncSamples[(this.syncSamples.length - 1)] - 1;
/* 2085 */       for (index = lastSyncFrame + 1; index < this.numberOfSamples; index++) {
/* 2086 */         this.syncSampleMapping[index] = lastSyncFrame;
/*      */       }
/*      */       
/* 2089 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     int time2Index(double time)
/*      */     {
/* 2098 */       if (time < 0.0D) {
/* 2099 */         time = 0.0D;
/*      */       }
/* 2101 */       int length = this.timeToSampleIndices.length;
/*      */       
/*      */ 
/*      */ 
/* 2105 */       if (length == 0) {
/* 2106 */         sampleIndex = (int)(time / this.mediaDuration.getSeconds() * this.numberOfSamples + 0.5D);
/*      */         
/* 2108 */         if (sampleIndex >= this.numberOfSamples)
/* 2109 */           return -1;
/* 2110 */         return sampleIndex;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2117 */       int approxLocation = (int)(time / this.mediaDuration.getSeconds() * length);
/*      */       
/*      */ 
/* 2120 */       if (approxLocation == length) {
/* 2121 */         approxLocation--;
/*      */       }
/* 2123 */       if (approxLocation >= this.cumulativeDurationOfSamples.length) {
/* 2124 */         return -1;
/*      */       }
/*      */       int i;
/*      */       int foundIndex;
/* 2128 */       if (this.cumulativeDurationOfSamples[approxLocation] < time)
/*      */       {
/* 2130 */         for (i = approxLocation + 1; i < length; i++) {
/* 2131 */           if (this.cumulativeDurationOfSamples[i] >= time) {
/*      */             break;
/*      */           }
/*      */         }
/* 2135 */         foundIndex = i;
/* 2136 */       } else if (this.cumulativeDurationOfSamples[approxLocation] > time)
/*      */       {
/* 2138 */         for (i = approxLocation - 1; i >= 0; i--) {
/* 2139 */           if (this.cumulativeDurationOfSamples[i] < time) {
/*      */             break;
/*      */           }
/*      */         }
/* 2143 */         foundIndex = i + 1;
/*      */       } else {
/* 2145 */         foundIndex = approxLocation;
/*      */       }
/*      */       
/* 2148 */       if (foundIndex == length) {
/* 2149 */         foundIndex--;
/*      */       }
/* 2151 */       double delta = this.cumulativeDurationOfSamples[foundIndex] - time;
/*      */       int samples;
/*      */       double duration;
/* 2154 */       if (foundIndex == 0) {
/* 2155 */         sampleIndex = this.timeToSampleIndices[foundIndex];
/* 2156 */         samples = sampleIndex;
/* 2157 */         duration = this.cumulativeDurationOfSamples[foundIndex];
/*      */       } else {
/* 2159 */         sampleIndex = this.timeToSampleIndices[foundIndex];
/* 2160 */         samples = sampleIndex - this.timeToSampleIndices[(foundIndex - 1)];
/*      */         
/* 2162 */         duration = this.cumulativeDurationOfSamples[foundIndex] - this.cumulativeDurationOfSamples[(foundIndex - 1)];
/*      */       }
/*      */       
/* 2165 */       double fraction = delta / duration;
/* 2166 */       int sampleIndex = (int)(sampleIndex - samples * fraction);
/* 2167 */       return sampleIndex;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     int index2Chunk(int index)
/*      */     {
/*      */       int chunk;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2212 */       if (this.constantSamplesPerChunk != -1) {
/* 2213 */         chunk = index / this.constantSamplesPerChunk;
/* 2214 */         return chunk;
/*      */       }
/* 2216 */       int length = this.samplesPerChunk.length;
/* 2217 */       int approxChunk = (int)(index / this.numberOfSamples * length);
/* 2218 */       if (approxChunk == length) {
/* 2219 */         approxChunk--;
/*      */       }
/*      */       
/*      */       int i;
/* 2223 */       if (this.samplesPerChunk[approxChunk] < index)
/*      */       {
/* 2225 */         for (i = approxChunk + 1; i < length; i++) {
/* 2226 */           if (this.samplesPerChunk[i] >= index) {
/*      */             break;
/*      */           }
/*      */         }
/* 2230 */         chunk = i;
/* 2231 */       } else if (this.samplesPerChunk[approxChunk] > index)
/*      */       {
/* 2233 */         for (i = approxChunk - 1; i >= 0; i--) {
/* 2234 */           if (this.samplesPerChunk[i] < index) {
/*      */             break;
/*      */           }
/*      */         }
/* 2238 */         chunk = i + 1;
/*      */       } else {
/* 2240 */         chunk = approxChunk;
/*      */       }
/* 2242 */       return chunk;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     long index2Offset(int index)
/*      */     {
/* 2253 */       int chunk = index2Chunk(index + 1);
/* 2254 */       if (QuicktimeParser.this.debug) {
/* 2255 */         System.out.println(" index2Chunk chunk is " + chunk);
/*      */       }
/* 2257 */       if (chunk >= this.chunkOffsets.length)
/*      */       {
/*      */ 
/* 2260 */         return -2L;
/*      */       }
/*      */       
/* 2263 */       long offset = this.chunkOffsets[chunk];
/*      */       
/* 2265 */       if (QuicktimeParser.this.debug1) {
/* 2266 */         System.out.println("index2Offset: index, chunk, chunkOffset " + index + " : " + chunk + " : " + offset);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       int sampleNumInChunk;
/*      */       
/*      */ 
/*      */ 
/*      */       int start;
/*      */       
/*      */ 
/*      */ 
/* 2279 */       if (this.constantSamplesPerChunk != -1) {
/* 2280 */         sampleNumInChunk = index % this.constantSamplesPerChunk;
/* 2281 */         start = chunk * this.constantSamplesPerChunk;
/*      */       } else {
/* 2283 */         if (chunk == 0) {
/* 2284 */           start = 0;
/*      */         } else
/* 2286 */           start = this.samplesPerChunk[(chunk - 1)];
/* 2287 */         sampleNumInChunk = index - start;
/* 2288 */         if (QuicktimeParser.this.debug1) {
/* 2289 */           System.out.println("index, start, sampleNumInChunk " + index + " : " + start + " : " + sampleNumInChunk);
/*      */           
/*      */ 
/* 2292 */           System.out.println("sampleSize is " + this.sampleSize);
/*      */         }
/*      */       }
/* 2295 */       if (QuicktimeParser.this.debug1)
/* 2296 */         System.out.println("sampleSize is " + this.sampleSize);
/* 2297 */       if (this.sampleSize != 0)
/*      */       {
/* 2299 */         offset += this.sampleSize * sampleNumInChunk;
/*      */       } else {
/* 2301 */         for (int i = 0; i < sampleNumInChunk; i++)
/* 2302 */           offset += this.sampleSizeArray[(start++)];
/*      */       }
/* 2304 */       return offset;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void buildStartTimeAndDurationTable()
/*      */     {
/* 2311 */       if (QuicktimeParser.this.debug2) {
/* 2312 */         System.out.println("buildStartTimeAndDurationTable");
/*      */       }
/* 2314 */       int length = this.timeToSampleIndices.length;
/*      */       
/*      */ 
/* 2317 */       if (length == 0) {
/* 2318 */         return;
/*      */       }
/* 2320 */       this.startTimeOfSampleArray = new double[this.numberOfSamples];
/* 2321 */       this.durationOfSampleArray = new double[this.numberOfSamples];
/* 2322 */       int previousSamples = 0;
/* 2323 */       double previousDuration = 0.0D;
/* 2324 */       double time = 0.0D;
/* 2325 */       int index = 0;
/* 2326 */       for (int i = 0; i < length; i++) {
/* 2327 */         int numSamples = this.timeToSampleIndices[i];
/* 2328 */         double duration = (this.cumulativeDurationOfSamples[i] - previousDuration) / (numSamples - previousSamples);
/*      */         
/*      */ 
/*      */ 
/* 2332 */         for (int j = 0; j < numSamples - previousSamples; j++) {
/* 2333 */           this.startTimeOfSampleArray[index] = time;
/* 2334 */           this.durationOfSampleArray[index] = duration;
/* 2335 */           index++;
/* 2336 */           time += duration;
/*      */         }
/* 2338 */         previousSamples = numSamples;
/* 2339 */         previousDuration = this.cumulativeDurationOfSamples[i];
/*      */       }
/*      */     }
/*      */     
/*      */     public String toString() {
/* 2344 */       String info = "";
/*      */       
/* 2346 */       info = info + "track id is " + this.id + "\n";
/* 2347 */       info = info + "duration itrack is " + this.duration.getSeconds() + "\n";
/* 2348 */       info = info + "duration of media is " + this.mediaDuration.getSeconds() + "\n";
/* 2349 */       info = info + "trackType is " + this.trackType + "\n";
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2354 */       info = info + this.media;
/*      */       
/* 2356 */       return info;
/*      */     }
/*      */     
/*      */     private TrakList() {}
/*      */     
/*      */     /* Error */
/*      */     QuicktimeParser.TimeAndDuration index2TimeAndDuration(int index)
/*      */     {
/*      */       // Byte code:
/*      */       //   0: dconst_0
/*      */       //   1: dstore_2
/*      */       //   2: dconst_0
/*      */       //   3: dstore 4
/*      */       //   5: iload_1
/*      */       //   6: ifge +8 -> 14
/*      */       //   9: iconst_0
/*      */       //   10: istore_1
/*      */       //   11: goto +18 -> 29
/*      */       //   14: iload_1
/*      */       //   15: aload_0
/*      */       //   16: getfield 27	com/sun/media/parser/video/QuicktimeParser$TrakList:numberOfSamples	I
/*      */       //   19: if_icmplt +10 -> 29
/*      */       //   22: aload_0
/*      */       //   23: getfield 27	com/sun/media/parser/video/QuicktimeParser$TrakList:numberOfSamples	I
/*      */       //   26: iconst_1
/*      */       //   27: isub
/*      */       //   28: istore_1
/*      */       //   29: aload_0
/*      */       //   30: getfield 15	com/sun/media/parser/video/QuicktimeParser$TrakList:timeToSampleIndices	[I
/*      */       //   33: arraylength
/*      */       //   34: istore 6
/*      */       //   36: iload 6
/*      */       //   38: ifne +18 -> 56
/*      */       //   41: aload_0
/*      */       //   42: getfield 14	com/sun/media/parser/video/QuicktimeParser$TrakList:durationOfSamples	D
/*      */       //   45: dstore 4
/*      */       //   47: dload 4
/*      */       //   49: iload_1
/*      */       //   50: i2d
/*      */       //   51: dmul
/*      */       //   52: dstore_2
/*      */       //   53: goto +54 -> 107
/*      */       //   56: aload_0
/*      */       //   57: getfield 17	com/sun/media/parser/video/QuicktimeParser$TrakList:startTimeOfSampleArray	[D
/*      */       //   60: arraylength
/*      */       //   61: iload_1
/*      */       //   62: if_icmplt +21 -> 83
/*      */       //   65: aload_0
/*      */       //   66: getfield 18	com/sun/media/parser/video/QuicktimeParser$TrakList:durationOfSampleArray	[D
/*      */       //   69: iload_1
/*      */       //   70: daload
/*      */       //   71: dstore 4
/*      */       //   73: aload_0
/*      */       //   74: getfield 17	com/sun/media/parser/video/QuicktimeParser$TrakList:startTimeOfSampleArray	[D
/*      */       //   77: iload_1
/*      */       //   78: daload
/*      */       //   79: dstore_2
/*      */       //   80: goto +27 -> 107
/*      */       //   83: iload 6
/*      */       //   85: i2f
/*      */       //   86: aload_0
/*      */       //   87: getfield 27	com/sun/media/parser/video/QuicktimeParser$TrakList:numberOfSamples	I
/*      */       //   90: i2f
/*      */       //   91: fdiv
/*      */       //   92: fstore 7
/*      */       //   94: iload_1
/*      */       //   95: i2f
/*      */       //   96: fload 7
/*      */       //   98: fmul
/*      */       //   99: f2i
/*      */       //   100: istore 8
/*      */       //   102: dconst_0
/*      */       //   103: dstore 4
/*      */       //   105: dconst_0
/*      */       //   106: dstore_2
/*      */       //   107: jsr +14 -> 121
/*      */       //   110: goto +59 -> 169
/*      */       //   113: astore 9
/*      */       //   115: jsr +6 -> 121
/*      */       //   118: aload 9
/*      */       //   120: athrow
/*      */       //   121: astore 10
/*      */       //   123: aload_0
/*      */       //   124: getfield 21	com/sun/media/parser/video/QuicktimeParser$TrakList:timeAndDuration	Lcom/sun/media/parser/video/QuicktimeParser$TimeAndDuration;
/*      */       //   127: astore 11
/*      */       //   129: aload 11
/*      */       //   131: monitorenter
/*      */       //   132: aload_0
/*      */       //   133: getfield 21	com/sun/media/parser/video/QuicktimeParser$TrakList:timeAndDuration	Lcom/sun/media/parser/video/QuicktimeParser$TimeAndDuration;
/*      */       //   136: dload_2
/*      */       //   137: putfield 38	com/sun/media/parser/video/QuicktimeParser$TimeAndDuration:startTime	D
/*      */       //   140: aload_0
/*      */       //   141: getfield 21	com/sun/media/parser/video/QuicktimeParser$TrakList:timeAndDuration	Lcom/sun/media/parser/video/QuicktimeParser$TimeAndDuration;
/*      */       //   144: dload 4
/*      */       //   146: putfield 39	com/sun/media/parser/video/QuicktimeParser$TimeAndDuration:duration	D
/*      */       //   149: aload_0
/*      */       //   150: getfield 21	com/sun/media/parser/video/QuicktimeParser$TrakList:timeAndDuration	Lcom/sun/media/parser/video/QuicktimeParser$TimeAndDuration;
/*      */       //   153: astore 12
/*      */       //   155: aload 11
/*      */       //   157: monitorexit
/*      */       //   158: aload 12
/*      */       //   160: areturn
/*      */       //   161: astore 13
/*      */       //   163: aload 11
/*      */       //   165: monitorexit
/*      */       //   166: aload 13
/*      */       //   168: athrow
/*      */       //   169: return
/*      */       // Line number table:
/*      */       //   Java source line #2173	-> byte code offset #0
/*      */       //   Java source line #2174	-> byte code offset #2
/*      */       //   Java source line #2177	-> byte code offset #5
/*      */       //   Java source line #2178	-> byte code offset #9
/*      */       //   Java source line #2179	-> byte code offset #14
/*      */       //   Java source line #2180	-> byte code offset #22
/*      */       //   Java source line #2182	-> byte code offset #29
/*      */       //   Java source line #2184	-> byte code offset #36
/*      */       //   Java source line #2186	-> byte code offset #41
/*      */       //   Java source line #2187	-> byte code offset #47
/*      */       //   Java source line #2188	-> byte code offset #56
/*      */       //   Java source line #2189	-> byte code offset #65
/*      */       //   Java source line #2190	-> byte code offset #73
/*      */       //   Java source line #2193	-> byte code offset #83
/*      */       //   Java source line #2194	-> byte code offset #94
/*      */       //   Java source line #2195	-> byte code offset #102
/*      */       //   Java source line #2196	-> byte code offset #105
/*      */       //   Java source line #2199	-> byte code offset #113
/*      */       //   Java source line #2200	-> byte code offset #132
/*      */       //   Java source line #2201	-> byte code offset #140
/*      */       //   Java source line #2202	-> byte code offset #149
/*      */       //   Java source line #2203	-> byte code offset #161
/*      */       //   Java source line #2205	-> byte code offset #169
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	signature
/*      */       //   0	170	0	this	TrakList
/*      */       //   0	170	1	index	int
/*      */       //   1	136	2	startTime	double
/*      */       //   3	142	4	duration	double
/*      */       //   34	50	6	length	int
/*      */       //   92	5	7	factor	float
/*      */       //   100	3	8	location	int
/*      */       //   113	6	9	localObject1	Object
/*      */       //   121	1	10	localObject2	Object
/*      */       //   153	6	12	localTimeAndDuration2	QuicktimeParser.TimeAndDuration
/*      */       //   161	6	13	localObject3	Object
/*      */       // Exception table:
/*      */       //   from	to	target	type
/*      */       //   5	113	113	finally
/*      */       //   132	161	161	finally
/*      */     }
/*      */   }
/*      */   
/*      */   private abstract class MediaTrack
/*      */     implements Track
/*      */   {
/*      */     QuicktimeParser.TrakList trakInfo;
/* 2364 */     boolean enabled = true;
/* 2365 */     int numBuffers = 4;
/*      */     Format format;
/* 2367 */     long sequenceNumber = 0L;
/* 2368 */     int chunkNumber = 0;
/* 2369 */     int sampleIndex = 0;
/* 2370 */     int useChunkNumber = 0;
/* 2371 */     int useSampleIndex = 0;
/* 2372 */     QuicktimeParser parser = QuicktimeParser.this;
/* 2373 */     CachedStream cacheStream = this.parser.getCacheStream();
/*      */     int constantSamplesPerChunk;
/*      */     int[] samplesPerChunk;
/*      */     protected TrackListener listener;
/*      */     
/*      */     MediaTrack(QuicktimeParser.TrakList trakInfo) {
/* 2379 */       this.trakInfo = trakInfo;
/* 2380 */       if (trakInfo != null) {
/* 2381 */         this.enabled = ((trakInfo.flag & 0x1) != 0);
/* 2382 */         this.format = trakInfo.media.createFormat();
/* 2383 */         this.samplesPerChunk = trakInfo.samplesPerChunk;
/* 2384 */         this.constantSamplesPerChunk = trakInfo.constantSamplesPerChunk;
/*      */       }
/*      */     }
/*      */     
/*      */     public void setTrackListener(TrackListener l)
/*      */     {
/* 2390 */       this.listener = l;
/*      */     }
/*      */     
/*      */     public Format getFormat() {
/* 2394 */       return this.format;
/*      */     }
/*      */     
/*      */     public void setEnabled(boolean t)
/*      */     {
/* 2399 */       this.enabled = t;
/*      */     }
/*      */     
/*      */     public boolean isEnabled() {
/* 2403 */       return this.enabled;
/*      */     }
/*      */     
/*      */     public Time getDuration() {
/* 2407 */       return this.trakInfo.duration;
/*      */     }
/*      */     
/*      */     public Time getStartTime()
/*      */     {
/* 2412 */       return new Time(0L);
/*      */     }
/*      */     
/*      */     synchronized void setSampleIndex(int index) {
/* 2416 */       this.sampleIndex = index;
/*      */     }
/*      */     
/*      */     synchronized void setChunkNumber(int number) {
/* 2420 */       this.chunkNumber = number;
/*      */     }
/*      */     
/*      */     public void readFrame(Buffer buffer) {
/* 2424 */       if (buffer == null) {
/* 2425 */         return;
/*      */       }
/* 2427 */       if (!this.enabled) {
/* 2428 */         buffer.setDiscard(true);
/* 2429 */         return;
/*      */       }
/*      */       
/*      */ 
/* 2433 */       synchronized (this) {
/* 2434 */         this.useChunkNumber = this.chunkNumber;
/* 2435 */         this.useSampleIndex = this.sampleIndex;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2444 */       if ((this.useChunkNumber >= this.trakInfo.numberOfChunks) || (this.useChunkNumber < 0))
/*      */       {
/* 2446 */         buffer.setEOM(true);
/* 2447 */         return;
/*      */       }
/*      */       
/* 2450 */       buffer.setFormat(this.format);
/* 2451 */       doReadFrame(buffer);
/*      */     }
/*      */     
/*      */     abstract void doReadFrame(Buffer paramBuffer);
/*      */     
/*      */     public int mapTimeToFrame(Time t) {
/* 2457 */       return Integer.MAX_VALUE;
/*      */     }
/*      */     
/*      */     public Time mapFrameToTime(int frameNumber) {
/* 2461 */       return Track.TIME_UNKNOWN;
/*      */     }
/*      */   }
/*      */   
/*      */   private class AudioTrack extends QuicktimeParser.MediaTrack {
/*      */     String encoding;
/*      */     int channels;
/* 2468 */     int sampleOffsetInChunk = -1;
/* 2469 */     int useSampleOffsetInChunk = 0;
/*      */     
/*      */     int frameSizeInBytes;
/*      */     
/*      */     int samplesPerBlock;
/*      */     
/*      */     int sampleRate;
/*      */     
/*      */ 
/*      */     AudioTrack(QuicktimeParser.TrakList trakInfo, int channels, String encoding, int frameSizeInBytes, int samplesPerBlock, int sampleRate)
/*      */     {
/* 2480 */       super(trakInfo);
/* 2481 */       this.channels = channels;
/* 2482 */       this.encoding = encoding;
/* 2483 */       this.frameSizeInBytes = frameSizeInBytes;
/* 2484 */       this.samplesPerBlock = samplesPerBlock;
/* 2485 */       this.sampleRate = sampleRate;
/*      */     }
/*      */     
/*      */     AudioTrack(QuicktimeParser.TrakList trakInfo)
/*      */     {
/* 2490 */       super(trakInfo);
/* 2491 */       if (trakInfo != null) {
/* 2492 */         this.channels = ((QuicktimeParser.Audio)trakInfo.media).channels;
/* 2493 */         this.encoding = trakInfo.media.encoding;
/* 2494 */         this.frameSizeInBytes = (((QuicktimeParser.Audio)trakInfo.media).frameSizeInBits / 8);
/* 2495 */         this.samplesPerBlock = ((QuicktimeParser.Audio)trakInfo.media).samplesPerBlock;
/* 2496 */         this.sampleRate = ((QuicktimeParser.Audio)trakInfo.media).sampleRate;
/*      */       }
/*      */     }
/*      */     
/*      */     synchronized void setChunkNumberAndSampleOffset(int number, int offset) {
/* 2501 */       this.chunkNumber = number;
/* 2502 */       this.sampleOffsetInChunk = offset;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void doReadFrame(Buffer buffer)
/*      */     {
/* 2513 */       synchronized (this) {
/* 2514 */         if (this.sampleOffsetInChunk == -1) {
/* 2515 */           this.useSampleOffsetInChunk = 0;
/*      */         } else {
/* 2517 */           this.useSampleOffsetInChunk = this.sampleOffsetInChunk;
/* 2518 */           this.sampleOffsetInChunk = -1;
/*      */         }
/*      */       }
/*      */       
/*      */       int samples;
/*      */       
/*      */       long samplesPlayed;
/*      */       
/* 2526 */       if (this.constantSamplesPerChunk != -1) {
/* 2527 */         samples = this.constantSamplesPerChunk;
/* 2528 */         samplesPlayed = this.constantSamplesPerChunk * this.useChunkNumber;
/* 2529 */       } else if (this.useChunkNumber > 0) {
/* 2530 */         samples = this.samplesPerChunk[this.useChunkNumber] - this.samplesPerChunk[(this.useChunkNumber - 1)];
/*      */         
/* 2532 */         samplesPlayed = this.samplesPerChunk[this.useChunkNumber];
/*      */       } else {
/* 2534 */         samples = this.samplesPerChunk[this.useChunkNumber];
/* 2535 */         samplesPlayed = 0L;
/*      */       }
/*      */       
/*      */       int byteOffsetFromSampleOffset;
/* 2539 */       if (this.samplesPerBlock > 1) {
/* 2540 */         int skipBlocks = this.useSampleOffsetInChunk / this.samplesPerBlock;
/* 2541 */         this.useSampleOffsetInChunk = (skipBlocks * this.samplesPerBlock);
/* 2542 */         byteOffsetFromSampleOffset = this.frameSizeInBytes * skipBlocks;
/*      */       } else {
/* 2544 */         byteOffsetFromSampleOffset = this.useSampleOffsetInChunk * this.frameSizeInBytes;
/*      */       }
/*      */       
/* 2547 */       samples -= this.useSampleOffsetInChunk;
/* 2548 */       samplesPlayed += this.useSampleOffsetInChunk;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       int needBufferSize;
/*      */       
/*      */ 
/*      */ 
/* 2557 */       if (this.encoding.equals("ima4"))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2566 */         needBufferSize = samples / this.samplesPerBlock * 34 * this.channels;
/* 2567 */       } else if (this.encoding.equals("agsm"))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2573 */         needBufferSize = samples / 160 * this.samplesPerBlock;
/*      */       } else {
/* 2575 */         needBufferSize = samples * ((AudioFormat)this.format).getSampleSizeInBits() / 8 * this.channels;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2580 */       Object obj = buffer.getData();
/*      */       
/*      */       byte[] data;
/* 2583 */       if ((obj == null) || (!(obj instanceof byte[])) || (((byte[])obj).length < needBufferSize))
/*      */       {
/*      */ 
/* 2586 */         data = new byte[needBufferSize];
/* 2587 */         buffer.setData(data);
/*      */       } else {
/* 2589 */         data = (byte[])obj;
/*      */       }
/*      */       try
/*      */       {
/*      */         int actualBytesRead;
/* 2594 */         synchronized (QuicktimeParser.this.seekSync) {
/* 2595 */           int offset = this.trakInfo.chunkOffsets[this.useChunkNumber];
/*      */           
/*      */ 
/* 2598 */           if (this.sampleIndex != this.useSampleIndex)
/*      */           {
/* 2600 */             buffer.setDiscard(true);
/* 2601 */             return;
/*      */           }
/*      */           
/*      */ 
/* 2605 */           if ((this.cacheStream != null) && (this.listener != null))
/*      */           {
/* 2607 */             if (this.cacheStream.willReadBytesBlock(offset + byteOffsetFromSampleOffset, needBufferSize))
/*      */             {
/* 2609 */               this.listener.readHasBlocked(this);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2618 */           long pos = QuicktimeParser.this.seekableStream.seek(offset + byteOffsetFromSampleOffset);
/* 2619 */           if (pos == -2L) {
/* 2620 */             buffer.setDiscard(true);
/* 2621 */             return;
/*      */           }
/* 2623 */           actualBytesRead = this.parser.readBytes(QuicktimeParser.this.stream, data, needBufferSize);
/*      */           
/* 2625 */           if (actualBytesRead == -2) {
/* 2626 */             buffer.setDiscard(true);
/* 2627 */             return;
/*      */           }
/*      */         }
/* 2630 */         buffer.setLength(actualBytesRead);
/*      */         
/* 2632 */         buffer.setSequenceNumber(++this.sequenceNumber);
/* 2633 */         if (this.sampleRate > 0) {
/* 2634 */           long timeStamp = samplesPlayed * 1000000000L / this.sampleRate;
/*      */           
/*      */ 
/* 2637 */           buffer.setTimeStamp(timeStamp);
/* 2638 */           buffer.setDuration(-1L);
/*      */         }
/*      */       }
/*      */       catch (IOException actualBytesRead) {
/* 2642 */         buffer.setLength(0);
/* 2643 */         buffer.setEOM(true);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2649 */       synchronized (this) {
/* 2650 */         if (this.chunkNumber == this.useChunkNumber)
/*      */         {
/* 2652 */           this.chunkNumber += 1; }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private class VideoTrack extends QuicktimeParser.MediaTrack {
/*      */     int needBufferSize;
/* 2659 */     boolean variableSampleSize = true;
/*      */     
/*      */     VideoTrack(QuicktimeParser.TrakList trakInfo)
/*      */     {
/* 2663 */       super(trakInfo);
/* 2664 */       if ((trakInfo != null) && 
/* 2665 */         (trakInfo.sampleSize != 0)) {
/* 2666 */         this.variableSampleSize = false;
/* 2667 */         this.needBufferSize = trakInfo.sampleSize;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void doReadFrame(Buffer buffer)
/*      */     {
/* 2678 */       if (this.useSampleIndex >= this.trakInfo.numberOfSamples) {
/* 2679 */         buffer.setLength(0);
/* 2680 */         buffer.setEOM(true);
/* 2681 */         return;
/*      */       }
/* 2683 */       if (this.variableSampleSize) {
/* 2684 */         if (this.useSampleIndex >= this.trakInfo.sampleSizeArray.length) {
/* 2685 */           buffer.setLength(0);
/* 2686 */           buffer.setEOM(true);
/* 2687 */           return;
/*      */         }
/* 2689 */         this.needBufferSize = this.trakInfo.sampleSizeArray[this.useSampleIndex];
/*      */       }
/*      */       
/*      */ 
/* 2693 */       long offset = this.trakInfo.sampleOffsetTable[this.useSampleIndex];
/* 2694 */       Object obj = buffer.getData();
/*      */       
/*      */       byte[] data;
/* 2697 */       if ((obj == null) || (!(obj instanceof byte[])) || (((byte[])obj).length < this.needBufferSize))
/*      */       {
/*      */ 
/* 2700 */         data = new byte[this.needBufferSize];
/* 2701 */         buffer.setData(data);
/*      */       } else {
/* 2703 */         data = (byte[])obj;
/*      */       }
/*      */       try {
/*      */         int actualBytesRead;
/* 2707 */         synchronized (QuicktimeParser.this.seekSync)
/*      */         {
/*      */ 
/* 2710 */           if (this.sampleIndex != this.useSampleIndex)
/*      */           {
/* 2712 */             buffer.setDiscard(true);
/* 2713 */             return;
/*      */           }
/*      */           
/*      */ 
/* 2717 */           if ((this.cacheStream != null) && (this.listener != null) && 
/* 2718 */             (this.cacheStream.willReadBytesBlock(offset, this.needBufferSize)))
/*      */           {
/*      */ 
/* 2721 */             this.listener.readHasBlocked(this);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2730 */           long pos = QuicktimeParser.this.seekableStream.seek(offset);
/*      */           
/* 2732 */           if (pos == -2L) {
/* 2733 */             buffer.setDiscard(true);
/* 2734 */             return;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2790 */           actualBytesRead = this.parser.readBytes(QuicktimeParser.this.stream, data, this.needBufferSize);
/*      */           
/* 2792 */           if (actualBytesRead == -2) {
/* 2793 */             buffer.setDiscard(true);
/* 2794 */             return;
/*      */           }
/*      */         }
/*      */         
/* 2798 */         buffer.setLength(actualBytesRead);
/*      */         
/* 2800 */         int[] syncSampleMapping = this.trakInfo.syncSampleMapping;
/* 2801 */         boolean keyFrame = true;
/* 2802 */         if (syncSampleMapping != null) {
/* 2803 */           keyFrame = syncSampleMapping[this.useSampleIndex] == this.useSampleIndex;
/*      */         }
/*      */         
/* 2806 */         if (keyFrame) {
/* 2807 */           buffer.setFlags(buffer.getFlags() | 0x10);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 2812 */         buffer.setSequenceNumber(++this.sequenceNumber);
/* 2813 */         QuicktimeParser.TimeAndDuration td = this.trakInfo.index2TimeAndDuration(this.useSampleIndex);
/*      */         
/*      */ 
/* 2816 */         buffer.setTimeStamp((td.startTime * 1.0E9D));
/* 2817 */         buffer.setDuration((td.duration * 1.0E9D));
/*      */       }
/*      */       catch (IOException actualBytesRead)
/*      */       {
/* 2821 */         buffer.setLength(0);
/* 2822 */         buffer.setEOM(true);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2828 */       synchronized (this) {
/* 2829 */         if (this.sampleIndex == this.useSampleIndex)
/* 2830 */           this.sampleIndex += 1;
/*      */       }
/*      */     }
/*      */     
/*      */     public int mapTimeToFrame(Time t) {
/* 2835 */       double time = t.getSeconds();
/*      */       
/* 2837 */       if (time < 0.0D) {
/* 2838 */         return Integer.MAX_VALUE;
/*      */       }
/* 2840 */       int index = this.trakInfo.time2Index(time);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2848 */       if (index < 0) {
/* 2849 */         return this.trakInfo.numberOfSamples - 1;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2856 */       return index;
/*      */     }
/*      */     
/*      */     public Time mapFrameToTime(int frameNumber) {
/* 2860 */       if ((frameNumber < 0) || (frameNumber >= this.trakInfo.numberOfSamples)) {
/* 2861 */         return Track.TIME_UNKNOWN;
/*      */       }
/*      */       
/*      */ 
/* 2865 */       double time = frameNumber / ((QuicktimeParser.Video)this.trakInfo.media).frameRate;
/*      */       
/*      */ 
/* 2868 */       return new Time(time);
/*      */     }
/*      */   }
/*      */   
/*      */   private class HintAudioTrack
/*      */     extends QuicktimeParser.AudioTrack
/*      */   {
/*      */     int hintSampleSize;
/* 2876 */     int indexOfTrackBeingHinted = this.trakInfo.indexOfTrackBeingHinted;
/*      */     int maxPacketSize;
/* 2878 */     int currentPacketNumber = 0;
/* 2879 */     int numPacketsInSample = -1;
/* 2880 */     long offsetToStartOfPacketInfo = -1L;
/*      */     QuicktimeParser.TrakList sampleTrakInfo;
/* 2882 */     boolean variableSampleSize = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     HintAudioTrack(QuicktimeParser.TrakList trakInfo, int channels, String encoding, int frameSizeInBytes, int samplesPerBlock, int sampleRate)
/*      */     {
/* 2890 */       super(trakInfo, channels, encoding, frameSizeInBytes, samplesPerBlock, sampleRate);
/*      */       
/* 2892 */       this.format = ((QuicktimeParser.Hint)trakInfo.media).format;
/*      */       
/* 2894 */       this.maxPacketSize = trakInfo.maxPacketSize;
/*      */       
/* 2896 */       if (this.indexOfTrackBeingHinted >= 0) {
/* 2897 */         this.sampleTrakInfo = QuicktimeParser.this.trakList[this.indexOfTrackBeingHinted];
/*      */       }
/* 2899 */       else if (QuicktimeParser.this.debug) {
/* 2900 */         System.out.println("sampleTrakInfo is not set " + this.indexOfTrackBeingHinted);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2910 */       if (trakInfo.sampleSize != 0) {
/* 2911 */         this.variableSampleSize = false;
/* 2912 */         this.hintSampleSize = trakInfo.sampleSize;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void readFrame(Buffer buffer)
/*      */     {
/* 2924 */       if (buffer == null) {
/* 2925 */         return;
/*      */       }
/* 2927 */       if (!this.enabled) {
/* 2928 */         buffer.setDiscard(true);
/* 2929 */         return;
/*      */       }
/*      */       
/* 2932 */       synchronized (this) {
/* 2933 */         this.useChunkNumber = this.chunkNumber;
/* 2934 */         this.useSampleIndex = this.sampleIndex;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2945 */       buffer.setFormat(this.format);
/* 2946 */       doReadFrame(buffer);
/*      */     }
/*      */     
/*      */     synchronized void setSampleIndex(int index)
/*      */     {
/* 2951 */       this.chunkNumber = index;
/* 2952 */       this.sampleIndex = index;
/*      */     }
/*      */     
/*      */ 
/*      */     void doReadFrame(Buffer buffer)
/*      */     {
/* 2958 */       if (QuicktimeParser.this.debug1) {
/* 2959 */         System.out.println("audio: hint doReadFrame: " + this.useChunkNumber + " : " + this.sampleOffsetInChunk);
/*      */       }
/*      */       
/*      */ 
/* 2963 */       boolean rtpMarkerSet = false;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2969 */       if (this.indexOfTrackBeingHinted < 0) {
/* 2970 */         buffer.setDiscard(true);
/* 2971 */         return;
/*      */       }
/*      */       
/* 2974 */       int rtpOffset = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2981 */       if (this.variableSampleSize) {
/* 2982 */         if (this.useSampleIndex >= this.trakInfo.sampleSizeArray.length) {
/* 2983 */           this.hintSampleSize = this.trakInfo.sampleSizeArray[(this.trakInfo.sampleSizeArray.length - 1)];
/*      */         } else {
/* 2985 */           this.hintSampleSize = this.trakInfo.sampleSizeArray[this.useSampleIndex];
/*      */         }
/*      */       }
/*      */       
/* 2989 */       int remainingHintSampleSize = this.hintSampleSize;
/*      */       
/* 2991 */       if (QuicktimeParser.this.debug1) {
/* 2992 */         System.out.println("hintSampleSize is " + this.hintSampleSize);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2997 */       Object obj = buffer.getData();
/*      */       
/*      */       byte[] data;
/* 3000 */       if ((obj == null) || (!(obj instanceof byte[])) || (((byte[])obj).length < this.maxPacketSize))
/*      */       {
/*      */ 
/* 3003 */         data = new byte[this.maxPacketSize];
/* 3004 */         buffer.setData(data);
/*      */       } else {
/* 3006 */         data = (byte[])obj;
/*      */       }
/*      */       try {
/*      */         int rtpSequenceNumber;
/*      */         int actualBytesRead;
/* 3011 */         synchronized (QuicktimeParser.this.seekSync)
/*      */         {
/*      */ 
/* 3014 */           if (this.sampleIndex != this.useSampleIndex)
/*      */           {
/*      */ 
/* 3017 */             buffer.setDiscard(true);
/* 3018 */             this.currentPacketNumber = 0;
/* 3019 */             this.numPacketsInSample = -1;
/* 3020 */             this.offsetToStartOfPacketInfo = -1L;
/* 3021 */             rtpOffset = 0;
/* 3022 */             return;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 3027 */           long offset = this.trakInfo.index2Offset(this.useChunkNumber);
/* 3028 */           if (QuicktimeParser.this.debug) {
/* 3029 */             System.out.println("audio: Calling index2Offset on hint track with arg " + this.useChunkNumber);
/*      */             
/* 3031 */             System.out.println("offset is " + offset);
/*      */           }
/*      */           
/*      */ 
/* 3035 */           if (offset == -2L) {
/* 3036 */             buffer.setLength(0);
/* 3037 */             buffer.setEOM(true);
/* 3038 */             return;
/*      */           }
/*      */           
/* 3041 */           if ((this.cacheStream != null) && (this.listener != null))
/*      */           {
/* 3043 */             if (this.cacheStream.willReadBytesBlock(offset, this.hintSampleSize))
/*      */             {
/*      */ 
/* 3046 */               this.listener.readHasBlocked(this);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3054 */           if (QuicktimeParser.this.debug1)
/* 3055 */             System.out.println("currentPacketNumber is " + this.currentPacketNumber);
/*      */           long pos;
/* 3057 */           if (this.offsetToStartOfPacketInfo < 0L) {
/* 3058 */             if (QuicktimeParser.this.debug1) {
/* 3059 */               System.out.println("NEW SEEK");
/*      */             }
/* 3061 */             pos = QuicktimeParser.this.seekableStream.seek(offset);
/*      */             
/* 3063 */             if (pos == -2L) {
/* 3064 */               buffer.setDiscard(true);
/* 3065 */               return;
/*      */             }
/*      */             
/* 3068 */             this.numPacketsInSample = this.parser.readShort(QuicktimeParser.this.stream);
/* 3069 */             if (QuicktimeParser.this.debug) {
/* 3070 */               System.out.println("num packets in sample " + this.numPacketsInSample);
/*      */             }
/*      */             
/* 3073 */             if (this.numPacketsInSample < 1) {
/* 3074 */               buffer.setDiscard(true);
/* 3075 */               return;
/*      */             }
/*      */             
/* 3078 */             remainingHintSampleSize -= 2;
/* 3079 */             this.parser.readShort(QuicktimeParser.this.stream);
/* 3080 */             remainingHintSampleSize -= 2;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 3086 */             pos = QuicktimeParser.this.seekableStream.seek(this.offsetToStartOfPacketInfo);
/* 3087 */             if (pos == -2L) {
/* 3088 */               buffer.setDiscard(true);
/* 3089 */               return;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 3095 */           int relativeTransmissionTime = this.parser.readInt(QuicktimeParser.this.stream);
/* 3096 */           remainingHintSampleSize -= 4;
/*      */           
/*      */ 
/* 3099 */           int rtpHeaderInfo = this.parser.readShort(QuicktimeParser.this.stream);
/* 3100 */           if (QuicktimeParser.this.debug) {
/* 3101 */             System.out.println("rtpHeaderInfo is " + Integer.toHexString(rtpHeaderInfo));
/*      */           }
/*      */           
/* 3104 */           rtpMarkerSet = (rtpHeaderInfo & 0x80) > 0;
/*      */           
/*      */ 
/* 3107 */           remainingHintSampleSize -= 2;
/* 3108 */           rtpSequenceNumber = this.parser.readShort(QuicktimeParser.this.stream);
/* 3109 */           remainingHintSampleSize -= 2;
/*      */           
/* 3111 */           boolean paddingPresent = (rtpHeaderInfo & 0x2000) > 0;
/* 3112 */           boolean extensionHeaderPresent = (rtpHeaderInfo & 0x1000) > 0;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 3117 */           if ((!paddingPresent) || 
/*      */           
/*      */ 
/*      */ 
/* 3121 */             (extensionHeaderPresent)) {}
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 3126 */           int flags = this.parser.readShort(QuicktimeParser.this.stream);
/*      */           
/* 3128 */           if (QuicktimeParser.this.debug)
/*      */           {
/*      */ 
/*      */ 
/* 3132 */             System.out.println("rtp marker present? " + rtpMarkerSet);
/* 3133 */             System.out.println("rtp payload type " + (rtpHeaderInfo & 0x7F));
/*      */             
/*      */ 
/* 3136 */             System.out.println("padding? " + paddingPresent);
/* 3137 */             System.out.println("extension header? " + extensionHeaderPresent);
/* 3138 */             System.out.println("audio hint: flags is " + Integer.toHexString(flags));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 3144 */           remainingHintSampleSize -= 2;
/*      */           
/* 3146 */           int entriesInDataTable = this.parser.readShort(QuicktimeParser.this.stream);
/* 3147 */           remainingHintSampleSize -= 2;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3157 */           boolean extraInfoTLVPresent = (flags & 0x4) > 0;
/*      */           
/* 3159 */           if (extraInfoTLVPresent) {
/* 3160 */             int tlvTableSize = this.parser.readInt(QuicktimeParser.this.stream);
/*      */             
/* 3162 */             QuicktimeParser.this.skip(QuicktimeParser.this.stream, tlvTableSize - 4);
/*      */             
/* 3164 */             if (QuicktimeParser.this.debug) {
/* 3165 */               System.err.println("audio: extraInfoTLVPresent: Skipped");
/* 3166 */               System.out.println("tlvTableSize is " + tlvTableSize);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 3172 */           if (QuicktimeParser.this.debug) {
/* 3173 */             System.out.println("Packet # " + this.currentPacketNumber);
/* 3174 */             System.out.println("  relativeTransmissionTime is " + relativeTransmissionTime);
/*      */             
/* 3176 */             System.out.println("  rtpSequenceNumber is " + rtpSequenceNumber);
/* 3177 */             System.out.println("  entriesInDataTable is " + entriesInDataTable);
/*      */           }
/*      */           
/* 3180 */           for (int j = 0; j < entriesInDataTable; j++) {
/* 3181 */             int dataBlockSource = this.parser.readByte(QuicktimeParser.this.stream);
/* 3182 */             remainingHintSampleSize--;
/* 3183 */             if (QuicktimeParser.this.debug1) {
/* 3184 */               System.out.println("    dataBlockSource is " + dataBlockSource);
/*      */             }
/*      */             
/* 3187 */             if (dataBlockSource == 1) {
/* 3188 */               int length = this.parser.readByte(QuicktimeParser.this.stream);
/*      */               
/*      */ 
/* 3191 */               remainingHintSampleSize--;
/*      */               
/*      */ 
/* 3194 */               this.parser.readBytes(QuicktimeParser.this.stream, data, rtpOffset, length);
/* 3195 */               rtpOffset += length;
/* 3196 */               this.parser.skip(QuicktimeParser.this.stream, 14 - length);
/* 3197 */               remainingHintSampleSize -= 14;
/* 3198 */             } else if (dataBlockSource == 2) {
/* 3199 */               int trackRefIndex = this.parser.readByte(QuicktimeParser.this.stream);
/* 3200 */               if (QuicktimeParser.this.debug1) {
/* 3201 */                 System.out.println("     audio:trackRefIndex is " + trackRefIndex);
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 3207 */               if (trackRefIndex > 0) {
/* 3208 */                 System.err.println("     Currently we don't support hint tracks that refer to multiple media tracks: " + trackRefIndex);
/* 3209 */                 buffer.setDiscard(true);
/* 3210 */                 return;
/*      */               }
/*      */               
/* 3213 */               int numBytesToCopy = this.parser.readShort(QuicktimeParser.this.stream);
/* 3214 */               int sampleNumber = this.parser.readInt(QuicktimeParser.this.stream);
/* 3215 */               int byteOffset = this.parser.readInt(QuicktimeParser.this.stream);
/* 3216 */               int bytesPerCompresionBlock = this.parser.readShort(QuicktimeParser.this.stream);
/* 3217 */               int samplesPerCompresionBlock = this.parser.readShort(QuicktimeParser.this.stream);
/*      */               
/* 3219 */               if (QuicktimeParser.this.debug1) {
/* 3220 */                 System.out.println("     sample Number is " + sampleNumber);
/* 3221 */                 System.out.println("     numBytesToCopy is " + numBytesToCopy);
/* 3222 */                 System.out.println("     byteOffset is " + byteOffset);
/* 3223 */                 System.out.println("     bytesPerCompresionBlock is " + bytesPerCompresionBlock);
/* 3224 */                 System.out.println("     samplesPerCompresionBlock is " + samplesPerCompresionBlock);
/*      */               }
/* 3226 */               remainingHintSampleSize -= 15;
/* 3227 */               long saveCurrentPos = this.parser.getLocation(QuicktimeParser.this.stream);
/*      */               
/*      */               QuicktimeParser.TrakList useTrakInfo;
/*      */               
/* 3231 */               if (trackRefIndex == 0) {
/* 3232 */                 useTrakInfo = this.sampleTrakInfo;
/* 3233 */                 if (QuicktimeParser.this.debug2) {
/* 3234 */                   System.out.println("set useTrakInfo as sampleTrakInfo");
/*      */                 }
/*      */                 
/*      */ 
/*      */               }
/*      */               else
/*      */               {
/* 3241 */                 useTrakInfo = this.trakInfo;
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 3247 */               if (QuicktimeParser.this.debug1) {
/* 3248 */                 System.out.println("useTrakInfo is " + useTrakInfo);
/* 3249 */                 System.out.println("useTrakInfo.sampleOffsetTable is " + useTrakInfo.sampleOffsetTable);
/*      */               }
/*      */               
/*      */               long sampleOffset;
/*      */               
/* 3254 */               if (useTrakInfo.sampleOffsetTable == null)
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3262 */                 sampleOffset = useTrakInfo.index2Offset(sampleNumber - 1);
/* 3263 */                 if (QuicktimeParser.this.debug1) {
/* 3264 */                   System.out.println("chunkOffsets size is " + useTrakInfo.chunkOffsets.length);
/*      */                   
/* 3266 */                   System.out.println("sampleOffset from index2Offset " + sampleOffset);
/*      */                 }
/*      */               }
/*      */               else {
/* 3270 */                 sampleOffset = useTrakInfo.sampleOffsetTable[(sampleNumber - 1)];
/*      */               }
/*      */               
/*      */ 
/*      */ 
/* 3275 */               sampleOffset += byteOffset;
/*      */               
/*      */ 
/* 3278 */               pos = QuicktimeParser.this.seekableStream.seek(sampleOffset);
/* 3279 */               if (pos == -2L) {
/* 3280 */                 buffer.setDiscard(true);
/*      */                 
/* 3282 */                 this.offsetToStartOfPacketInfo = -1L;
/* 3283 */                 return;
/*      */               }
/*      */               
/* 3286 */               if (QuicktimeParser.this.debug1) {
/* 3287 */                 System.out.println("Audio: Seek to " + sampleOffset + " and read " + numBytesToCopy + " bytes into buffer with offset " + rtpOffset);
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3302 */               this.parser.readBytes(QuicktimeParser.this.stream, data, rtpOffset, numBytesToCopy);
/* 3303 */               rtpOffset += numBytesToCopy;
/*      */               
/*      */ 
/* 3306 */               pos = QuicktimeParser.this.seekableStream.seek(saveCurrentPos);
/* 3307 */               if (pos == -2L) {
/* 3308 */                 buffer.setDiscard(true);
/*      */                 
/* 3310 */                 this.offsetToStartOfPacketInfo = -1L;
/* 3311 */                 return;
/*      */               }
/* 3313 */             } else if (dataBlockSource == 0)
/*      */             {
/* 3315 */               int length = this.parser.readByte(QuicktimeParser.this.stream);
/* 3316 */               this.parser.skip(QuicktimeParser.this.stream, length);
/* 3317 */               remainingHintSampleSize -= length;
/*      */             }
/*      */             else
/*      */             {
/* 3321 */               System.err.println("DISCARD: dataBlockSource " + dataBlockSource + " not supported");
/*      */               
/* 3323 */               buffer.setDiscard(true);
/* 3324 */               this.offsetToStartOfPacketInfo = -1L;
/* 3325 */               return;
/*      */             }
/*      */           }
/* 3328 */           actualBytesRead = rtpOffset;
/* 3329 */           if (QuicktimeParser.this.debug1) {
/* 3330 */             System.out.println("Actual size of packet sent " + rtpOffset);
/*      */           }
/* 3332 */           rtpOffset = 0;
/*      */           
/*      */ 
/*      */ 
/* 3336 */           this.offsetToStartOfPacketInfo = this.parser.getLocation(QuicktimeParser.this.stream);
/*      */           
/*      */ 
/*      */ 
/* 3340 */           if (actualBytesRead == -2)
/*      */           {
/*      */ 
/* 3343 */             buffer.setDiscard(true);
/* 3344 */             return;
/*      */           }
/*      */         }
/* 3347 */         buffer.setLength(actualBytesRead);
/*      */         
/* 3349 */         if (rtpMarkerSet) {
/* 3350 */           if (QuicktimeParser.this.debug)
/* 3351 */             System.out.println("rtpMarkerSet: true");
/* 3352 */           buffer.setFlags(buffer.getFlags() | 0x800);
/*      */         } else {
/* 3354 */           if (QuicktimeParser.this.debug)
/* 3355 */             System.out.println("rtpMarkerSet: false");
/* 3356 */           buffer.setFlags(buffer.getFlags() & 0xF7FF);
/*      */         }
/* 3358 */         buffer.setSequenceNumber(rtpSequenceNumber);
/*      */         
/*      */ 
/* 3361 */         double startTime = this.trakInfo.index2TimeAndDuration(this.useChunkNumber).startTime;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3366 */         long timeStamp = (startTime * 1.0E9D);
/*      */         
/* 3368 */         buffer.setTimeStamp(timeStamp);
/*      */         
/* 3370 */         buffer.setDuration(-1L);
/*      */       }
/*      */       catch (IOException actualBytesRead) {
/* 3373 */         buffer.setLength(0);
/* 3374 */         buffer.setEOM(true);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3380 */       synchronized (this) {
/* 3381 */         if (this.chunkNumber != this.useChunkNumber)
/*      */         {
/*      */ 
/*      */ 
/* 3385 */           this.currentPacketNumber = 0;
/* 3386 */           this.numPacketsInSample = -1;
/* 3387 */           this.offsetToStartOfPacketInfo = -1L;
/* 3388 */           rtpOffset = 0;
/*      */         }
/*      */         else
/*      */         {
/* 3392 */           this.currentPacketNumber += 1;
/* 3393 */           if (this.currentPacketNumber >= this.numPacketsInSample) {
/* 3394 */             this.chunkNumber += 1;
/* 3395 */             this.currentPacketNumber = 0;
/* 3396 */             this.numPacketsInSample = -1;
/* 3397 */             this.offsetToStartOfPacketInfo = -1L;
/* 3398 */             rtpOffset = 0;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private class HintVideoTrack
/*      */     extends QuicktimeParser.VideoTrack
/*      */   {
/*      */     int hintSampleSize;
/*      */     
/*      */ 
/* 3413 */     int indexOfTrackBeingHinted = this.trakInfo.indexOfTrackBeingHinted;
/*      */     int maxPacketSize;
/* 3415 */     int currentPacketNumber = 0;
/* 3416 */     int numPacketsInSample = -1;
/* 3417 */     long offsetToStartOfPacketInfo = -1L;
/* 3418 */     QuicktimeParser.TrakList sampleTrakInfo = null;
/*      */     
/*      */     HintVideoTrack(QuicktimeParser.TrakList trakInfo) {
/* 3421 */       super(trakInfo);
/* 3422 */       this.format = ((QuicktimeParser.Hint)trakInfo.media).format;
/* 3423 */       this.hintSampleSize = this.needBufferSize;
/* 3424 */       this.maxPacketSize = trakInfo.maxPacketSize;
/*      */       
/* 3426 */       if (QuicktimeParser.this.debug1) {
/* 3427 */         System.out.println("HintVideoTrack: Index of hinted track: " + trakInfo.indexOfTrackBeingHinted);
/*      */         
/* 3429 */         System.out.println("HintVideoTrack: packet size is " + this.maxPacketSize);
/*      */       }
/*      */       
/* 3432 */       if (this.indexOfTrackBeingHinted >= 0) {
/* 3433 */         this.sampleTrakInfo = QuicktimeParser.this.trakList[this.indexOfTrackBeingHinted];
/*      */       }
/* 3435 */       else if (QuicktimeParser.this.debug) {
/* 3436 */         System.out.println("sampleTrakInfo is not set " + this.indexOfTrackBeingHinted);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void doReadFrame(Buffer buffer)
/*      */     {
/* 3444 */       boolean rtpMarkerSet = false;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3450 */       if (this.indexOfTrackBeingHinted < 0) {
/* 3451 */         buffer.setDiscard(true);
/* 3452 */         return;
/*      */       }
/*      */       
/* 3455 */       if (this.useSampleIndex >= this.trakInfo.numberOfSamples) {
/* 3456 */         buffer.setLength(0);
/* 3457 */         buffer.setEOM(true);
/*      */         
/* 3459 */         return;
/*      */       }
/* 3461 */       int rtpOffset = 0;
/*      */       
/*      */ 
/* 3464 */       if (this.variableSampleSize) {
/* 3465 */         this.hintSampleSize = this.trakInfo.sampleSizeArray[this.useSampleIndex];
/*      */       }
/* 3467 */       int remainingHintSampleSize = this.hintSampleSize;
/* 3468 */       long offset = this.trakInfo.sampleOffsetTable[this.useSampleIndex];
/*      */       
/* 3470 */       if (QuicktimeParser.this.debug1) {
/* 3471 */         System.out.println("hintSampleSize is " + this.hintSampleSize);
/* 3472 */         System.out.println("useSampleIndex, offset " + this.useSampleIndex + " : " + offset);
/*      */       }
/*      */       
/*      */ 
/* 3476 */       Object obj = buffer.getData();
/*      */       
/*      */       byte[] data;
/* 3479 */       if ((obj == null) || (!(obj instanceof byte[])) || (((byte[])obj).length < this.maxPacketSize))
/*      */       {
/*      */ 
/* 3482 */         data = new byte[this.maxPacketSize];
/* 3483 */         buffer.setData(data);
/*      */       } else {
/* 3485 */         data = (byte[])obj;
/*      */       }
/*      */       try {
/*      */         int rtpSequenceNumber;
/*      */         int actualBytesRead;
/* 3490 */         synchronized (QuicktimeParser.this.seekSync)
/*      */         {
/* 3492 */           if (this.sampleIndex != this.useSampleIndex)
/*      */           {
/* 3494 */             buffer.setDiscard(true);
/* 3495 */             this.currentPacketNumber = 0;
/* 3496 */             this.numPacketsInSample = -1;
/* 3497 */             this.offsetToStartOfPacketInfo = -1L;
/* 3498 */             rtpOffset = 0;
/* 3499 */             return;
/*      */           }
/*      */           
/*      */ 
/* 3503 */           if ((this.cacheStream != null) && (this.listener != null) && 
/* 3504 */             (this.cacheStream.willReadBytesBlock(offset, this.hintSampleSize)))
/*      */           {
/*      */ 
/* 3507 */             this.listener.readHasBlocked(this);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */           long pos;
/*      */           
/*      */ 
/* 3515 */           if (this.offsetToStartOfPacketInfo < 0L) {
/* 3516 */             pos = QuicktimeParser.this.seekableStream.seek(offset);
/*      */             
/* 3518 */             if (pos == -2L) {
/* 3519 */               buffer.setDiscard(true);
/* 3520 */               return;
/*      */             }
/*      */             
/* 3523 */             this.numPacketsInSample = this.parser.readShort(QuicktimeParser.this.stream);
/* 3524 */             if (QuicktimeParser.this.debug) {
/* 3525 */               System.out.println("video: num packets in sample " + this.numPacketsInSample);
/*      */             }
/*      */             
/* 3528 */             if (this.numPacketsInSample < 1) {
/* 3529 */               buffer.setDiscard(true);
/* 3530 */               return;
/*      */             }
/*      */             
/* 3533 */             remainingHintSampleSize -= 2;
/* 3534 */             this.parser.readShort(QuicktimeParser.this.stream);
/* 3535 */             remainingHintSampleSize -= 2;
/*      */           }
/*      */           else {
/* 3538 */             pos = QuicktimeParser.this.seekableStream.seek(this.offsetToStartOfPacketInfo);
/* 3539 */             if (pos == -2L) {
/* 3540 */               buffer.setDiscard(true);
/* 3541 */               return;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 3547 */           int relativeTransmissionTime = this.parser.readInt(QuicktimeParser.this.stream);
/* 3548 */           remainingHintSampleSize -= 4;
/*      */           
/* 3550 */           int rtpHeaderInfo = (short)this.parser.readShort(QuicktimeParser.this.stream);
/* 3551 */           rtpMarkerSet = (rtpHeaderInfo & 0x80) > 0;
/* 3552 */           remainingHintSampleSize -= 2;
/* 3553 */           rtpSequenceNumber = this.parser.readShort(QuicktimeParser.this.stream);
/* 3554 */           remainingHintSampleSize -= 2;
/*      */           
/* 3556 */           boolean paddingPresent = (rtpHeaderInfo & 0x2000) > 0;
/* 3557 */           boolean extensionHeaderPresent = (rtpHeaderInfo & 0x1000) > 0;
/*      */           
/* 3559 */           if ((!paddingPresent) || 
/*      */           
/*      */ 
/*      */ 
/* 3563 */             (extensionHeaderPresent)) {}
/*      */           
/*      */ 
/*      */ 
/* 3567 */           int flags = this.parser.readShort(QuicktimeParser.this.stream);
/*      */           
/* 3569 */           if (QuicktimeParser.this.debug)
/*      */           {
/*      */ 
/* 3572 */             System.out.println("rtp marker present? " + rtpMarkerSet);
/* 3573 */             System.out.println("rtp payload type " + (rtpHeaderInfo & 0x7F));
/*      */             
/*      */ 
/* 3576 */             System.out.println("padding? " + paddingPresent);
/* 3577 */             System.out.println("extension header? " + extensionHeaderPresent);
/*      */             
/*      */ 
/* 3580 */             System.out.println("video hint: flags is " + Integer.toHexString(flags));
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 3585 */           remainingHintSampleSize -= 2;
/*      */           
/* 3587 */           int entriesInDataTable = this.parser.readShort(QuicktimeParser.this.stream);
/* 3588 */           remainingHintSampleSize -= 2;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3598 */           boolean extraInfoTLVPresent = (flags & 0x4) > 0;
/* 3599 */           if (extraInfoTLVPresent) {
/* 3600 */             int tlvTableSize = this.parser.readInt(QuicktimeParser.this.stream);
/*      */             
/* 3602 */             QuicktimeParser.this.skip(QuicktimeParser.this.stream, tlvTableSize - 4);
/* 3603 */             if (QuicktimeParser.this.debug) {
/* 3604 */               System.err.println("video: extraInfoTLVPresent: Skipped");
/* 3605 */               System.out.println("tlvTableSize is " + tlvTableSize);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/* 3610 */           if (QuicktimeParser.this.debug) {
/* 3611 */             System.out.println("Packet # " + this.currentPacketNumber);
/* 3612 */             System.out.println("  relativeTransmissionTime is " + relativeTransmissionTime);
/*      */             
/* 3614 */             System.out.println("$$$ relativeTransmissionTime is in timescale " + this.trakInfo.mediaTimeScale);
/*      */             
/*      */ 
/* 3617 */             System.out.println("  rtpSequenceNumber is " + rtpSequenceNumber);
/* 3618 */             System.out.println("  entriesInDataTable is " + entriesInDataTable);
/*      */           }
/*      */           
/* 3621 */           for (int j = 0; j < entriesInDataTable; j++) {
/* 3622 */             int dataBlockSource = this.parser.readByte(QuicktimeParser.this.stream);
/* 3623 */             remainingHintSampleSize--;
/* 3624 */             if (QuicktimeParser.this.debug1) {
/* 3625 */               System.out.println("    dataBlockSource is " + dataBlockSource);
/*      */             }
/*      */             
/* 3628 */             if (dataBlockSource == 1) {
/* 3629 */               int length = this.parser.readByte(QuicktimeParser.this.stream);
/*      */               
/*      */ 
/* 3632 */               remainingHintSampleSize--;
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 3637 */               this.parser.readBytes(QuicktimeParser.this.stream, data, rtpOffset, length);
/* 3638 */               rtpOffset += length;
/* 3639 */               this.parser.skip(QuicktimeParser.this.stream, 14 - length);
/* 3640 */               remainingHintSampleSize -= 14;
/* 3641 */             } else if (dataBlockSource == 2) {
/* 3642 */               int trackRefIndex = this.parser.readByte(QuicktimeParser.this.stream);
/* 3643 */               if (QuicktimeParser.this.debug1) {
/* 3644 */                 System.out.println("     video: trackRefIndex is " + trackRefIndex);
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 3650 */               if (trackRefIndex > 0) {
/* 3651 */                 System.err.println("     Currently we don't support hint tracks that refer to multiple media tracks");
/* 3652 */                 buffer.setDiscard(true);
/* 3653 */                 return;
/*      */               }
/*      */               
/* 3656 */               int numBytesToCopy = this.parser.readShort(QuicktimeParser.this.stream);
/* 3657 */               int sampleNumber = this.parser.readInt(QuicktimeParser.this.stream);
/* 3658 */               int byteOffset = this.parser.readInt(QuicktimeParser.this.stream);
/* 3659 */               int bytesPerCompresionBlock = this.parser.readShort(QuicktimeParser.this.stream);
/* 3660 */               int samplesPerCompresionBlock = this.parser.readShort(QuicktimeParser.this.stream);
/*      */               
/* 3662 */               if (QuicktimeParser.this.debug1) {
/* 3663 */                 System.out.println("     sample Number is " + sampleNumber);
/* 3664 */                 System.out.println("     numBytesToCopy is " + numBytesToCopy);
/* 3665 */                 System.out.println("     byteOffset is " + byteOffset);
/* 3666 */                 System.out.println("     bytesPerCompresionBlock is " + bytesPerCompresionBlock);
/* 3667 */                 System.out.println("     samplesPerCompresionBlock is " + samplesPerCompresionBlock);
/*      */               }
/* 3669 */               remainingHintSampleSize -= 15;
/* 3670 */               long saveCurrentPos = this.parser.getLocation(QuicktimeParser.this.stream);
/*      */               
/*      */               QuicktimeParser.TrakList useTrakInfo;
/*      */               
/* 3674 */               if (trackRefIndex == 0) {
/* 3675 */                 useTrakInfo = this.sampleTrakInfo;
/*      */ 
/*      */ 
/*      */               }
/*      */               else
/*      */               {
/*      */ 
/* 3682 */                 useTrakInfo = this.trakInfo;
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3691 */               long sampleOffset = useTrakInfo.sampleOffsetTable[(sampleNumber - 1)];
/*      */               
/*      */ 
/* 3694 */               sampleOffset += byteOffset;
/*      */               
/*      */ 
/* 3697 */               pos = QuicktimeParser.this.seekableStream.seek(sampleOffset);
/* 3698 */               if (pos == -2L) {
/* 3699 */                 buffer.setDiscard(true);
/* 3700 */                 this.offsetToStartOfPacketInfo = -1L;
/* 3701 */                 return;
/*      */               }
/*      */               
/* 3704 */               if (QuicktimeParser.this.debug1) {
/* 3705 */                 System.out.println("     read " + numBytesToCopy + " bytes from offset " + rtpOffset);
/*      */               }
/* 3707 */               this.parser.readBytes(QuicktimeParser.this.stream, data, rtpOffset, numBytesToCopy);
/* 3708 */               rtpOffset += numBytesToCopy;
/*      */               
/*      */ 
/* 3711 */               pos = QuicktimeParser.this.seekableStream.seek(saveCurrentPos);
/* 3712 */               if (pos == -2L) {
/* 3713 */                 buffer.setDiscard(true);
/* 3714 */                 this.offsetToStartOfPacketInfo = -1L;
/* 3715 */                 return;
/*      */               }
/*      */               
/*      */             }
/*      */             else
/*      */             {
/* 3721 */               buffer.setDiscard(true);
/* 3722 */               this.offsetToStartOfPacketInfo = -1L;
/* 3723 */               return;
/*      */             }
/*      */           }
/* 3726 */           actualBytesRead = rtpOffset;
/* 3727 */           if (QuicktimeParser.this.debug1) {
/* 3728 */             System.out.println("Actual size of packet sent " + rtpOffset);
/*      */           }
/* 3730 */           rtpOffset = 0;
/*      */           
/*      */ 
/*      */ 
/* 3734 */           this.offsetToStartOfPacketInfo = this.parser.getLocation(QuicktimeParser.this.stream);
/*      */           
/* 3736 */           if (actualBytesRead == -2) {
/* 3737 */             buffer.setDiscard(true);
/* 3738 */             return;
/*      */           }
/*      */         }
/* 3741 */         buffer.setLength(actualBytesRead);
/*      */         
/* 3743 */         if (rtpMarkerSet) {
/* 3744 */           if (QuicktimeParser.this.debug)
/* 3745 */             System.out.println("rtpMarkerSet: true");
/* 3746 */           buffer.setFlags(buffer.getFlags() | 0x800);
/*      */         } else {
/* 3748 */           if (QuicktimeParser.this.debug)
/* 3749 */             System.out.println("rtpMarkerSet: false");
/* 3750 */           buffer.setFlags(buffer.getFlags() & 0xF7FF);
/*      */         }
/* 3752 */         buffer.setSequenceNumber(rtpSequenceNumber);
/*      */         
/*      */ 
/* 3755 */         QuicktimeParser.TimeAndDuration td = this.trakInfo.index2TimeAndDuration(this.useSampleIndex);
/* 3756 */         double startTime = td.startTime;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3775 */         long timeStamp = (startTime * 1.0E9D);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3780 */         buffer.setTimeStamp(timeStamp);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3789 */         buffer.setDuration((td.duration * 1.0E9D));
/*      */       }
/*      */       catch (IOException actualBytesRead) {
/* 3792 */         buffer.setLength(0);
/* 3793 */         buffer.setEOM(true);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3799 */       synchronized (this) {
/* 3800 */         if (this.sampleIndex != this.useSampleIndex) {
/* 3801 */           this.currentPacketNumber = 0;
/* 3802 */           this.numPacketsInSample = -1;
/* 3803 */           this.offsetToStartOfPacketInfo = -1L;
/* 3804 */           rtpOffset = 0;
/*      */         }
/*      */         else
/*      */         {
/* 3808 */           this.currentPacketNumber += 1;
/*      */           
/*      */ 
/*      */ 
/* 3812 */           if (this.currentPacketNumber >= this.numPacketsInSample) {
/* 3813 */             this.sampleIndex += 1;
/* 3814 */             this.currentPacketNumber = 0;
/* 3815 */             this.numPacketsInSample = -1;
/* 3816 */             this.offsetToStartOfPacketInfo = -1L;
/* 3817 */             rtpOffset = 0;
/*      */           }
/*      */         } } } }
/*      */   
/*      */   private class TimeAndDuration { double startTime;
/*      */     double duration;
/*      */     
/*      */     private TimeAndDuration() {}
/*      */     
/* 3826 */     TimeAndDuration(QuicktimeParser.1 x1) { this(); }
/*      */   }
/*      */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\parser\video\QuicktimeParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */