/*     */ package com.sun.media.parser;
/*     */ 
/*     */ import com.sun.media.CircularBuffer;
/*     */ import java.io.IOException;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Demultiplexer;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.TrackListener;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PushDataSource;
/*     */ import javax.media.protocol.PushSourceStream;
/*     */ import javax.media.protocol.SourceStream;
/*     */ 
/*     */ public class RawStreamParser extends RawParser
/*     */ {
/*     */   protected SourceStream[] streams;
/*  20 */   protected Track[] tracks = null;
/*     */   static final String NAME = "Raw stream parser";
/*     */   
/*     */   public String getName()
/*     */   {
/*  25 */     return "Raw stream parser";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSource(DataSource source)
/*     */     throws IOException, IncompatibleSourceException
/*     */   {
/*  34 */     if (!(source instanceof PushDataSource)) {
/*  35 */       throw new IncompatibleSourceException("DataSource not supported: " + source);
/*     */     }
/*  37 */     this.streams = ((PushDataSource)source).getStreams();
/*     */     
/*     */ 
/*     */ 
/*  41 */     if (this.streams == null) {
/*  42 */       throw new IOException("Got a null stream from the DataSource");
/*     */     }
/*     */     
/*  45 */     if (this.streams.length == 0) {
/*  46 */       throw new IOException("Got a empty stream array from the DataSource");
/*     */     }
/*     */     
/*  49 */     if (!supports(this.streams)) {
/*  50 */       throw new IncompatibleSourceException("DataSource not supported: " + source);
/*     */     }
/*  52 */     this.source = source;
/*  53 */     this.streams = this.streams;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean supports(SourceStream[] streams)
/*     */   {
/*  63 */     return (streams[0] != null) && ((streams[0] instanceof PushSourceStream));
/*     */   }
/*     */   
/*     */   public Track[] getTracks()
/*     */   {
/*  68 */     return this.tracks;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open()
/*     */   {
/*  78 */     if (this.tracks != null)
/*  79 */       return;
/*  80 */     this.tracks = new Track[this.streams.length];
/*  81 */     for (int i = 0; i < this.streams.length; i++) {
/*  82 */       this.tracks[i] = new FrameTrack(this, (PushSourceStream)this.streams[i], 5);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/*  93 */     if (this.source != null) {
/*     */       try {
/*  95 */         this.source.stop();
/*     */         
/*     */ 
/*  98 */         for (int i = 0; i < this.tracks.length; i++) {
/*  99 */           ((FrameTrack)this.tracks[i]).stop();
/*     */         }
/* 101 */         this.source.disconnect();
/*     */       }
/*     */       catch (IOException e) {}
/*     */       
/* 105 */       this.source = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void start()
/*     */     throws IOException
/*     */   {
/* 113 */     this.source.start();
/* 114 */     for (int i = 0; i < this.tracks.length; i++) {
/* 115 */       ((FrameTrack)this.tracks[i]).start();
/*     */     }
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/*     */     try
/*     */     {
/* 123 */       this.source.stop();
/*     */       
/* 125 */       for (int i = 0; i < this.tracks.length; i++) {
/* 126 */         ((FrameTrack)this.tracks[i]).stop();
/*     */       }
/*     */     }
/*     */     catch (IOException e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   class FrameTrack
/*     */     implements Track, javax.media.protocol.SourceTransferHandler
/*     */   {
/*     */     Demultiplexer parser;
/*     */     
/*     */     PushSourceStream pss;
/*     */     
/* 141 */     boolean enabled = true;
/*     */     CircularBuffer bufferQ;
/* 143 */     Format format = null;
/*     */     TrackListener listener;
/* 145 */     Integer stateReq = new Integer(0);
/* 146 */     boolean stopped = true;
/*     */     
/*     */     public FrameTrack(Demultiplexer parser, PushSourceStream pss, int numOfBufs)
/*     */     {
/* 150 */       this.pss = pss;
/* 151 */       pss.setTransferHandler(this);
/* 152 */       this.bufferQ = new CircularBuffer(numOfBufs);
/*     */     }
/*     */     
/*     */     public Format getFormat() {
/* 156 */       return this.format;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean t) {
/* 160 */       if (t) {
/* 161 */         this.pss.setTransferHandler(this);
/*     */       } else
/* 163 */         this.pss.setTransferHandler(null);
/* 164 */       this.enabled = t;
/*     */     }
/*     */     
/*     */     public boolean isEnabled() {
/* 168 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public Time getDuration() {
/* 172 */       return this.parser.getDuration();
/*     */     }
/*     */     
/*     */     public Time getStartTime() {
/* 176 */       return new Time(0L);
/*     */     }
/*     */     
/*     */     public void setTrackListener(TrackListener l) {
/* 180 */       this.listener = l;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void readFrame(Buffer buffer)
/*     */     {
/* 187 */       synchronized (this.stateReq) {
/* 188 */         if (this.stopped) {
/* 189 */           buffer.setDiscard(true);
/* 190 */           buffer.setFormat(this.format); return;
/*     */         }
/*     */       }
/*     */       Buffer filled;
/* 194 */       synchronized (this.bufferQ) {
/* 195 */         while (!this.bufferQ.canRead()) {
/*     */           try {
/* 197 */             this.bufferQ.wait();
/* 198 */             synchronized (this.stateReq) {
/* 199 */               if (this.stopped) {
/* 200 */                 buffer.setDiscard(true);
/* 201 */                 buffer.setFormat(this.format);
/* 202 */                 return;
/*     */               }
/*     */             }
/*     */           } catch (Exception e) {}
/*     */         }
/* 207 */         filled = this.bufferQ.read();
/* 208 */         this.bufferQ.notifyAll();
/*     */       }
/*     */       
/*     */ 
/* 212 */       byte[] data = (byte[])filled.getData();
/* 213 */       filled.setData(buffer.getData());
/* 214 */       buffer.setData(data);
/* 215 */       buffer.setLength(filled.getLength());
/* 216 */       buffer.setFormat(this.format);
/* 217 */       buffer.setTimeStamp(-1L);
/*     */       
/* 219 */       synchronized (this.bufferQ) {
/* 220 */         this.bufferQ.readReport();
/* 221 */         this.bufferQ.notifyAll();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void stop()
/*     */     {
/* 229 */       synchronized (this.stateReq) {
/* 230 */         this.stopped = true;
/*     */       }
/* 232 */       synchronized (this.bufferQ) {
/* 233 */         this.bufferQ.notifyAll();
/*     */       }
/*     */     }
/*     */     
/*     */     public void start()
/*     */     {
/* 239 */       synchronized (this.stateReq) {
/* 240 */         this.stopped = false;
/*     */       }
/* 242 */       synchronized (this.bufferQ) {
/* 243 */         this.bufferQ.notifyAll();
/*     */       }
/*     */     }
/*     */     
/*     */     public int mapTimeToFrame(Time t) {
/* 248 */       return -1;
/*     */     }
/*     */     
/*     */     public Time mapFrameToTime(int frameNumber) {
/* 252 */       return new Time(0L);
/*     */     }
/*     */     
/*     */ 
/*     */     public void transferData(PushSourceStream pss)
/*     */     {
/*     */       Buffer buffer;
/* 259 */       synchronized (this.bufferQ) {
/* 260 */         while (!this.bufferQ.canWrite()) {
/*     */           try {
/* 262 */             this.bufferQ.wait();
/*     */           } catch (Exception e) {}
/*     */         }
/* 265 */         buffer = this.bufferQ.getEmptyBuffer();
/* 266 */         this.bufferQ.notifyAll();
/*     */       }
/*     */       
/* 269 */       int size = pss.getMinimumTransferSize();
/*     */       byte[] data;
/* 271 */       if (((data = (byte[])buffer.getData()) == null) || (data.length < size))
/*     */       {
/* 273 */         data = new byte[size];
/* 274 */         buffer.setData(data);
/*     */       }
/*     */       try
/*     */       {
/* 278 */         int len = pss.read(data, 0, size);
/* 279 */         buffer.setLength(len);
/*     */       } catch (IOException len) {
/* 281 */         buffer.setDiscard(true);
/*     */       }
/*     */       
/*     */ 
/* 285 */       synchronized (this.bufferQ) {
/* 286 */         this.bufferQ.writeReport();
/* 287 */         this.bufferQ.notifyAll();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\parser\RawStreamParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */