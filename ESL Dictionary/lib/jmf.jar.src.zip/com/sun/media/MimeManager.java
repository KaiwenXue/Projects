/*     */ package com.sun.media;
/*     */ 
/*     */ import com.sun.media.util.Registry;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MimeManager
/*     */ {
/*  15 */   private static Hashtable additionalMimeTable = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  25 */   protected static final Hashtable defaultHashTable = new Hashtable();
/*  26 */   private static MimeTable mimeTable = new MimeTable();
/*  27 */   protected static final Hashtable extTable = new Hashtable();
/*     */   
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  33 */     mimeTable.doPut("mov", "video/quicktime");
/*  34 */     defaultHashTable.put("mov", "video/quicktime");
/*     */     
/*  36 */     mimeTable.doPut("avi", "video/x_msvideo");
/*  37 */     defaultHashTable.put("avi", "video/x_msvideo");
/*     */     
/*  39 */     mimeTable.doPut("mpg", "video/mpeg");
/*  40 */     defaultHashTable.put("mpg", "video/mpeg");
/*     */     
/*  42 */     mimeTable.doPut("mpv", "video/mpeg");
/*  43 */     defaultHashTable.put("mpv", "video/mpeg");
/*     */     
/*  45 */     mimeTable.doPut("viv", "video/vivo");
/*  46 */     defaultHashTable.put("viv", "video/vivo");
/*     */     
/*  48 */     mimeTable.doPut("au", "audio/basic");
/*  49 */     defaultHashTable.put("au", "audio/basic");
/*     */     
/*  51 */     mimeTable.doPut("wav", "audio/x_wav");
/*  52 */     defaultHashTable.put("wav", "audio/x_wav");
/*     */     
/*  54 */     mimeTable.doPut("aiff", "audio/x_aiff");
/*  55 */     defaultHashTable.put("aiff", "audio/x_aiff");
/*     */     
/*  57 */     mimeTable.doPut("aif", "audio/x_aiff");
/*  58 */     defaultHashTable.put("aif", "audio/x_aiff");
/*     */     
/*  60 */     mimeTable.doPut("mid", "audio/midi");
/*  61 */     defaultHashTable.put("mid", "audio/midi");
/*     */     
/*  63 */     mimeTable.doPut("midi", "audio/midi");
/*  64 */     defaultHashTable.put("midi", "audio/midi");
/*     */     
/*  66 */     mimeTable.doPut("rmf", "audio/rmf");
/*  67 */     defaultHashTable.put("rmf", "audio/rmf");
/*     */     
/*  69 */     mimeTable.doPut("gsm", "audio/x_gsm");
/*  70 */     defaultHashTable.put("gsm", "audio/x_gsm");
/*     */     
/*  72 */     mimeTable.doPut("mp2", "audio/mpeg");
/*  73 */     defaultHashTable.put("mp2", "audio/mpeg");
/*     */     
/*  75 */     mimeTable.doPut("mp3", "audio/mpeg");
/*  76 */     defaultHashTable.put("mp3", "audio/mpeg");
/*     */     
/*  78 */     mimeTable.doPut("mpa", "audio/mpeg");
/*  79 */     defaultHashTable.put("mpa", "audio/mpeg");
/*     */     
/*  81 */     mimeTable.doPut("g728", "audio/g728");
/*  82 */     defaultHashTable.put("g728", "audio/g728");
/*     */     
/*  84 */     mimeTable.doPut("g729", "audio/g729");
/*  85 */     defaultHashTable.put("g729", "audio/g729");
/*     */     
/*  87 */     mimeTable.doPut("g729a", "audio/g729a");
/*  88 */     defaultHashTable.put("g729a", "audio/g729a");
/*     */     
/*  90 */     mimeTable.doPut("cda", "audio/cdaudio");
/*  91 */     defaultHashTable.put("cda", "audio/cdaudio");
/*     */     
/*  93 */     mimeTable.doPut("mvr", "application/mvr");
/*  94 */     defaultHashTable.put("mvr", "application/mvr");
/*     */     
/*  96 */     mimeTable.doPut("swf", "application/x-shockwave-flash");
/*  97 */     defaultHashTable.put("swf", "application/x-shockwave-flash");
/*     */     
/*  99 */     mimeTable.doPut("spl", "application/futuresplash");
/* 100 */     defaultHashTable.put("spl", "application/futuresplash");
/*     */     
/* 102 */     mimeTable.doPut("jmx", "application/x_jmx");
/* 103 */     defaultHashTable.put("jmx", "application/x_jmx");
/*     */     
/*     */ 
/* 106 */     Object t = Registry.get("additionalMimeTable");
/* 107 */     if ((t != null) && ((t instanceof Hashtable))) {
/* 108 */       additionalMimeTable = (Hashtable)t;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 113 */     if ((additionalMimeTable != null) && (!additionalMimeTable.isEmpty())) {
/* 114 */       Enumeration e = additionalMimeTable.keys();
/* 115 */       while (e.hasMoreElements()) {
/* 116 */         String ext = (String)e.nextElement();
/* 117 */         if (defaultHashTable.containsKey(ext)) {
/* 118 */           additionalMimeTable.remove(ext);
/*     */         } else {
/* 120 */           mimeTable.doPut(ext, (String)additionalMimeTable.get(ext));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */   private static MimeTable defaultMimeTable = (MimeTable)mimeTable.clone();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean addMimeType(String fileExtension, String mimeType)
/*     */   {
/* 149 */     if (additionalMimeTable == null) {
/* 150 */       additionalMimeTable = new Hashtable();
/*     */     }
/* 152 */     if (mimeTable.doPut(fileExtension, mimeType)) {
/* 153 */       additionalMimeTable.put(fileExtension, mimeType);
/* 154 */       return true;
/*     */     }
/* 156 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean removeMimeType(String fileExtension)
/*     */   {
/* 167 */     if (mimeTable.doRemove(fileExtension)) {
/* 168 */       if (additionalMimeTable != null)
/* 169 */         additionalMimeTable.remove(fileExtension);
/* 170 */       return true;
/*     */     }
/* 172 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public static final String getMimeType(String fileExtension)
/*     */   {
/* 178 */     return (String)mimeTable.get(fileExtension);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Hashtable getMimeTable()
/*     */   {
/* 187 */     return mimeTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Hashtable getDefaultMimeTable()
/*     */   {
/* 196 */     return defaultMimeTable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String getDefaultExtension(String mimeType)
/*     */   {
/* 208 */     return (String)extTable.get(mimeType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void commit()
/*     */   {
/* 217 */     Registry.set("additionalMimeTable", additionalMimeTable);
/*     */     try {
/* 219 */       Registry.commit();
/*     */     } catch (IOException e) {
/* 221 */       System.err.println("IOException on commit " + e.getMessage());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\MimeManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */