package com.sun.media.controls;

public abstract interface VideoFrameControl
  extends GroupControl
{}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\VideoFrameControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */