/*     */ package com.sun.media.controls;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.media.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorControlAdapter
/*     */   extends AtomicControlAdapter
/*     */   implements ColorControl
/*     */ {
/*     */   NumericControl brightness;
/*     */   NumericControl contrast;
/*     */   NumericControl saturation;
/*     */   NumericControl hue;
/*     */   BooleanControl grayscale;
/*     */   Control[] controls;
/*     */   
/*     */   public ColorControlAdapter(NumericControl b, NumericControl c, NumericControl s, NumericControl h, BooleanControl g, Component comp, boolean def, Control parent)
/*     */   {
/*  47 */     super(comp, def, parent);
/*     */     
/*  49 */     this.brightness = b;
/*  50 */     this.contrast = c;
/*  51 */     this.saturation = s;
/*  52 */     this.hue = h;
/*  53 */     this.grayscale = g;
/*     */     
/*  55 */     int n = 0;
/*  56 */     n += (b == null ? 0 : 1);
/*  57 */     n += (c == null ? 0 : 1);
/*  58 */     n += (s == null ? 0 : 1);
/*  59 */     n += (h == null ? 0 : 1);
/*  60 */     n += (g == null ? 0 : 1);
/*  61 */     this.controls = new Control[n];
/*     */     
/*  63 */     n = 0;
/*  64 */     if (b != null)
/*  65 */       this.controls[(n++)] = b;
/*  66 */     if (c != null)
/*  67 */       this.controls[(n++)] = c;
/*  68 */     if (s != null)
/*  69 */       this.controls[(n++)] = s;
/*  70 */     if (h != null)
/*  71 */       this.controls[(n++)] = h;
/*  72 */     if (g != null) {
/*  73 */       this.controls[(n++)] = g;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Control[] getControls()
/*     */   {
/*  81 */     return this.controls;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NumericControl getBrightness()
/*     */   {
/*  92 */     return this.brightness;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public NumericControl getContrast()
/*     */   {
/*  99 */     return this.contrast;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public NumericControl getSaturation()
/*     */   {
/* 106 */     return this.saturation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public NumericControl getHue()
/*     */   {
/* 113 */     return this.hue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BooleanControl getGrayscale()
/*     */   {
/* 121 */     return this.grayscale;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\ColorControlAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */