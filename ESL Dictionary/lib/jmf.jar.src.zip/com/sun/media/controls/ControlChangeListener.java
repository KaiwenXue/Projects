package com.sun.media.controls;

public abstract interface ControlChangeListener
{
  public abstract void controlChanged(ControlChangeEvent paramControlChangeEvent);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\ControlChangeListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */