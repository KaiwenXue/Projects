package com.sun.media.controls;

public abstract interface ActionControl
  extends AtomicControl
{
  public abstract boolean performAction();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\ActionControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */