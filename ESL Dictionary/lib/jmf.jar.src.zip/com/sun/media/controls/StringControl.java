package com.sun.media.controls;

public abstract interface StringControl
  extends AtomicControl
{
  public abstract String setValue(String paramString);
  
  public abstract String getValue();
  
  public abstract String setTitle(String paramString);
  
  public abstract String getTitle();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\StringControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */