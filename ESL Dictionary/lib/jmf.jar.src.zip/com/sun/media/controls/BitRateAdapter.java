/*    */ package com.sun.media.controls;
/*    */ 
/*    */ import com.sun.media.ui.BasicComp;
/*    */ import com.sun.media.ui.TextComp;
/*    */ import java.awt.Component;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.media.control.BitRateControl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BitRateAdapter
/*    */   implements BitRateControl, ActionListener
/*    */ {
/*    */   protected int value;
/*    */   protected int min;
/*    */   protected int max;
/*    */   protected boolean settable;
/*    */   protected TextComp textComp;
/*    */   
/*    */   public BitRateAdapter(int initialBitRate, int minBitRate, int maxBitRate, boolean settable)
/*    */   {
/* 26 */     this.value = initialBitRate;
/* 27 */     this.min = minBitRate;
/* 28 */     this.max = maxBitRate;
/* 29 */     this.settable = settable;
/*    */   }
/*    */   
/*    */   public int getBitRate() {
/* 33 */     return this.value;
/*    */   }
/*    */   
/*    */   public int setBitRate(int newValue) {
/* 37 */     if (this.settable) {
/* 38 */       if (newValue < this.min)
/* 39 */         newValue = this.min;
/* 40 */       if (newValue > this.max) {
/* 41 */         newValue = this.max;
/*    */       }
/* 43 */       this.value = newValue;
/* 44 */       if (this.textComp != null) {
/* 45 */         this.textComp.setValue(Integer.toString(newValue));
/*    */       }
/* 47 */       return this.value;
/*    */     }
/* 49 */     return -1;
/*    */   }
/*    */   
/*    */   public int getMinSupportedBitRate() {
/* 53 */     return this.min;
/*    */   }
/*    */   
/*    */   public int getMaxSupportedBitRate() {
/* 57 */     return this.max;
/*    */   }
/*    */   
/*    */   protected String getName() {
/* 61 */     return "Bit Rate";
/*    */   }
/*    */   
/*    */   public Component getControlComponent() {
/* 65 */     if (this.textComp == null) {
/* 66 */       this.textComp = new TextComp(getName(), Integer.toString(this.value), 7, this.settable);
/*    */       
/* 68 */       this.textComp.setActionListener(this);
/*    */     }
/* 70 */     return this.textComp;
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent ae) {
/* 74 */     if (this.textComp != null) {
/* 75 */       setBitRate(this.textComp.getIntValue());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\BitRateAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */