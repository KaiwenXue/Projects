/*    */ package com.sun.media.controls;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.media.control.RtspControl;
/*    */ import javax.media.rtp.RTPManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RtspAdapter
/*    */   implements RtspControl
/*    */ {
/*    */   private RTPManager[] managers;
/*    */   private String[] mediaTypes;
/*    */   
/*    */   public void setRTPManagers(RTPManager[] managers)
/*    */   {
/* 18 */     this.managers = managers;
/*    */   }
/*    */   
/*    */   public RTPManager[] getRTPManagers() {
/* 22 */     return this.managers;
/*    */   }
/*    */   
/*    */   public void setMediaTypes(String[] mediaTypes) {
/* 26 */     this.mediaTypes = mediaTypes;
/*    */   }
/*    */   
/*    */   public String[] getMediaTypes() {
/* 30 */     return this.mediaTypes;
/*    */   }
/*    */   
/*    */   public Component getControlComponent() {
/* 34 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\RtspAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */