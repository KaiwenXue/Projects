package com.sun.media.controls;

public abstract interface PlaybackControl
  extends GroupControl
{
  public abstract BooleanControl getPlay();
  
  public abstract BooleanControl getStop();
  
  public abstract ActionControl getStepForward();
  
  public abstract ActionControl getStepBackward();
  
  public abstract NumericControl getPlayRate();
  
  public abstract NumericControl getSeek();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\PlaybackControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */