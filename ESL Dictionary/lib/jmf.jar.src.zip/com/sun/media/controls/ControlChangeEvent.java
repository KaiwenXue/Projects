/*    */ package com.sun.media.controls;
/*    */ 
/*    */ import javax.media.Control;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ControlChangeEvent
/*    */ {
/*    */   private Control c;
/*    */   
/*    */   public ControlChangeEvent(Control c)
/*    */   {
/* 24 */     this.c = c;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Control getControl()
/*    */   {
/* 31 */     return this.c;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\ControlChangeEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */