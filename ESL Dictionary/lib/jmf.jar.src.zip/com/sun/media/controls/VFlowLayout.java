/*     */ package com.sun.media.controls;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VFlowLayout
/*     */   implements LayoutManager
/*     */ {
/*  32 */   private int minWidth = 0; private int minHeight = 0;
/*  33 */   private int preferredWidth = 0; private int preferredHeight = 0;
/*  34 */   private boolean sizeUnknown = true;
/*     */   public static final String a_copyright_notice = "(c) Copyright IBM Corporation 1997,1999.";
/*     */   private int gap;
/*     */   
/*  38 */   public VFlowLayout() { this(0); }
/*     */   
/*     */ 
/*     */   public VFlowLayout(int v)
/*     */   {
/*  43 */     this.gap = v;
/*     */   }
/*     */   
/*     */ 
/*     */   public void addLayoutComponent(String name, Component comp) {}
/*     */   
/*     */ 
/*     */   public void removeLayoutComponent(Component comp) {}
/*     */   
/*     */ 
/*     */   private void setSizes(Container parent)
/*     */   {
/*  55 */     int nComps = parent.countComponents();
/*  56 */     Dimension d = null;
/*     */     
/*     */ 
/*  59 */     this.preferredWidth = 0;
/*  60 */     this.preferredHeight = 0;
/*  61 */     this.minWidth = 0;
/*  62 */     this.minHeight = 0;
/*     */     
/*  64 */     for (int i = 0; i < nComps; i++) {
/*  65 */       Component c = parent.getComponent(i);
/*  66 */       if (c.isVisible()) {
/*  67 */         d = c.preferredSize();
/*     */         
/*  69 */         this.minWidth = Math.max(c.minimumSize().width, this.minWidth);
/*  70 */         this.preferredWidth = Math.max(c.preferredSize().width, this.preferredWidth);
/*     */         
/*  72 */         this.minHeight += c.minimumSize().height + this.gap;
/*  73 */         this.preferredHeight += c.preferredSize().height + this.gap;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Dimension preferredLayoutSize(Container parent)
/*     */   {
/*  82 */     Dimension dim = new Dimension(0, 0);
/*  83 */     int nComps = parent.countComponents();
/*     */     
/*  85 */     setSizes(parent);
/*     */     
/*     */ 
/*  88 */     Insets insets = parent.insets();
/*  89 */     dim.width = (this.preferredWidth + insets.left + insets.right);
/*  90 */     dim.height = (this.preferredHeight + insets.top + insets.bottom);
/*     */     
/*  92 */     this.sizeUnknown = false;
/*     */     
/*  94 */     return dim;
/*     */   }
/*     */   
/*     */   public Dimension minimumLayoutSize(Container parent)
/*     */   {
/*  99 */     Dimension dim = new Dimension(0, 0);
/* 100 */     int nComps = parent.countComponents();
/*     */     
/* 102 */     setSizes(parent);
/*     */     
/*     */ 
/* 105 */     Insets insets = parent.insets();
/* 106 */     dim.width = (this.minWidth + insets.left + insets.right);
/* 107 */     dim.height = (this.minHeight + insets.top + insets.bottom);
/*     */     
/* 109 */     this.sizeUnknown = false;
/*     */     
/* 111 */     return dim;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void layoutContainer(Container parent)
/*     */   {
/* 121 */     Insets insets = parent.insets();
/* 122 */     int maxWidth = parent.size().width - (insets.left + insets.right);
/*     */     
/* 124 */     int maxHeight = parent.size().height - (insets.top + insets.bottom);
/*     */     
/* 126 */     int nComps = parent.countComponents();
/*     */     
/*     */ 
/*     */ 
/* 130 */     if (this.sizeUnknown) {
/* 131 */       setSizes(parent);
/*     */     }
/*     */     
/* 134 */     int previousWidth = 0;int previousHeight = 0;
/* 135 */     int x = 0;int y = insets.top + this.gap / 2;
/* 136 */     int rowh = 0;int start = 0;
/* 137 */     int yFudge = 0;
/* 138 */     boolean oneColumn = false;
/*     */     
/*     */ 
/*     */ 
/* 142 */     if (this.sizeUnknown) {
/* 143 */       setSizes(parent);
/*     */     }
/*     */     
/* 146 */     if (maxHeight > this.preferredHeight) {
/* 147 */       yFudge = (maxHeight - this.preferredHeight) / nComps;
/*     */     }
/*     */     
/* 150 */     for (int i = 0; i < nComps; i++) {
/* 151 */       Component c = parent.getComponent(i);
/* 152 */       if (c.isVisible()) {
/* 153 */         Dimension d = c.preferredSize();
/*     */         
/* 155 */         if (i != 0) {
/* 156 */           y += previousHeight + yFudge + this.gap;
/*     */         } else {
/* 158 */           y += previousHeight + (yFudge + this.gap) / 2;
/*     */         }
/*     */         
/* 161 */         c.reshape(0, y, maxWidth, d.height);
/*     */         
/* 163 */         previousWidth = d.width;
/* 164 */         previousHeight = d.height;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 170 */     return getClass().getName() + "[gap=" + this.gap + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\VFlowLayout.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */