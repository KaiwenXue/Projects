/*    */ package com.sun.media.controls;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Component;
/*    */ import java.awt.Container;
/*    */ import java.awt.Label;
/*    */ import java.awt.Panel;
/*    */ import java.awt.TextComponent;
/*    */ import java.awt.TextField;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.io.PrintStream;
/*    */ import javax.media.Codec;
/*    */ 
/*    */ public class PacketSizeAdapter implements javax.media.control.PacketSizeControl
/*    */ {
/* 17 */   protected Codec owner = null;
/*    */   protected boolean isSetable;
/*    */   protected int packetSize;
/* 20 */   Component component = null;
/* 21 */   String CONTROL_STRING = "Packet Size";
/*    */   
/*    */   public PacketSizeAdapter(Codec newOwner, int newPacketSize, boolean newIsSetable)
/*    */   {
/* 25 */     this.packetSize = newPacketSize;
/* 26 */     this.owner = newOwner;
/* 27 */     this.isSetable = newIsSetable;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int setPacketSize(int numBytes)
/*    */   {
/* 40 */     return this.packetSize;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getPacketSize()
/*    */   {
/* 48 */     return this.packetSize;
/*    */   }
/*    */   
/*    */   public Component getControlComponent() {
/* 52 */     if (this.component == null) {
/* 53 */       Panel componentPanel = new Panel();
/* 54 */       componentPanel.setLayout(new BorderLayout());
/* 55 */       componentPanel.add("Center", new Label(this.CONTROL_STRING, 1));
/* 56 */       TextField tf = new TextField(this.packetSize + "", 5);
/* 57 */       tf.setEditable(this.isSetable);
/*    */       
/* 59 */       tf.addActionListener(new PacketSizeListner(tf));
/*    */       
/* 61 */       componentPanel.add("East", tf);
/* 62 */       componentPanel.invalidate();
/* 63 */       this.component = componentPanel;
/*    */     }
/*    */     
/* 66 */     return this.component;
/*    */   }
/*    */   
/*    */   class PacketSizeListner implements ActionListener {
/*    */     TextField tf;
/*    */     
/* 72 */     public PacketSizeListner(TextField source) { this.tf = source; }
/*    */     
/*    */     public void actionPerformed(ActionEvent e)
/*    */     {
/*    */       try {
/* 77 */         int newPacketSize = Integer.parseInt(this.tf.getText());
/* 78 */         System.out.println("newPacketSize " + newPacketSize);
/*    */         
/* 80 */         PacketSizeAdapter.this.setPacketSize(newPacketSize);
/*    */       }
/*    */       catch (Exception exception) {}
/*    */       
/* 84 */       this.tf.setText(PacketSizeAdapter.this.packetSize + "");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\PacketSizeAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */