package com.sun.media.controls;

public abstract interface ColorControl
  extends GroupControl
{
  public abstract NumericControl getBrightness();
  
  public abstract NumericControl getContrast();
  
  public abstract NumericControl getSaturation();
  
  public abstract NumericControl getHue();
  
  public abstract BooleanControl getGrayscale();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\ColorControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */