package com.sun.media.controls;

public abstract interface BooleanControl
  extends AtomicControl
{
  public abstract boolean getValue();
  
  public abstract boolean setValue(boolean paramBoolean);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\BooleanControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */