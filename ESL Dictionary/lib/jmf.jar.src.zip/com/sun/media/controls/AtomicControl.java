package com.sun.media.controls;

import javax.media.Control;

public abstract interface AtomicControl
  extends Control
{
  public abstract boolean isDefault();
  
  public abstract void setVisible(boolean paramBoolean);
  
  public abstract boolean getVisible();
  
  public abstract void setEnabled(boolean paramBoolean);
  
  public abstract boolean getEnabled();
  
  public abstract Control getParent();
  
  public abstract void addControlChangeListener(ControlChangeListener paramControlChangeListener);
  
  public abstract void removeControlChangeListener(ControlChangeListener paramControlChangeListener);
  
  public abstract boolean isReadOnly();
  
  public abstract String getTip();
  
  public abstract void setTip(String paramString);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\AtomicControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */