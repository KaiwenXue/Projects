package com.sun.media.controls;

public abstract interface SliderRegionControl
  extends AtomicControl
{
  public abstract long setMaxValue(long paramLong);
  
  public abstract long getMaxValue();
  
  public abstract long setMinValue(long paramLong);
  
  public abstract long getMinValue();
  
  public abstract boolean isEnable();
  
  public abstract void setEnable(boolean paramBoolean);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\SliderRegionControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */