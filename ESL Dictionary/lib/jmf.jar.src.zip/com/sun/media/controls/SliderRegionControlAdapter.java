/*    */ package com.sun.media.controls;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.media.Control;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SliderRegionControlAdapter
/*    */   extends AtomicControlAdapter
/*    */   implements SliderRegionControl
/*    */ {
/*    */   long min;
/*    */   long max;
/*    */   boolean enable;
/*    */   
/*    */   public SliderRegionControlAdapter()
/*    */   {
/* 20 */     super(null, true, null);
/* 21 */     this.enable = true;
/*    */   }
/*    */   
/*    */   public SliderRegionControlAdapter(Component c, boolean def, Control parent)
/*    */   {
/* 26 */     super(c, def, parent);
/*    */   }
/*    */   
/*    */   public long setMinValue(long value)
/*    */   {
/* 31 */     this.min = value;
/* 32 */     informListeners();
/* 33 */     return this.min;
/*    */   }
/*    */   
/*    */   public long getMinValue() {
/* 37 */     return this.min;
/*    */   }
/*    */   
/*    */   public long setMaxValue(long value)
/*    */   {
/* 42 */     this.max = value;
/* 43 */     informListeners();
/* 44 */     return this.max;
/*    */   }
/*    */   
/*    */   public long getMaxValue() {
/* 48 */     return this.max;
/*    */   }
/*    */   
/*    */   public boolean isEnable() {
/* 52 */     return this.enable;
/*    */   }
/*    */   
/*    */   public void setEnable(boolean f) {
/* 56 */     this.enable = f;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\SliderRegionControlAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */