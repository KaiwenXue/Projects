package com.sun.media.controls;

public abstract interface AudioControl
  extends GroupControl
{
  public abstract AtomicControl getOutputPort();
  
  public abstract NumericControl getTreble();
  
  public abstract NumericControl getBass();
  
  public abstract NumericControl getBalance();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\AudioControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */