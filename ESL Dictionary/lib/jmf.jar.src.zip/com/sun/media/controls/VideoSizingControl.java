package com.sun.media.controls;

import java.awt.Dimension;
import java.awt.Rectangle;
import javax.media.Control;

public abstract interface VideoSizingControl
  extends Control
{
  public abstract boolean supportsAnyScale();
  
  public abstract Dimension setVideoSize(Dimension paramDimension);
  
  public abstract Dimension getVideoSize();
  
  public abstract Dimension getInputVideoSize();
  
  public abstract boolean supportsZoom();
  
  public abstract float[] getValidZoomFactors();
  
  public abstract NumericControl getZoomControl();
  
  public abstract boolean supportsClipping();
  
  public abstract Rectangle setClipRegion(Rectangle paramRectangle);
  
  public abstract Rectangle getClipRegion();
  
  public abstract BooleanControl getVideoMute();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\VideoSizingControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */