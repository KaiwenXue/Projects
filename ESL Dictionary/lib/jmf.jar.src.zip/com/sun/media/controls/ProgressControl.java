package com.sun.media.controls;

public abstract interface ProgressControl
  extends GroupControl
{
  public abstract StringControl getFrameRate();
  
  public abstract StringControl getBitRate();
  
  public abstract StringControl getVideoProperties();
  
  public abstract StringControl getVideoCodec();
  
  public abstract StringControl getAudioCodec();
  
  public abstract StringControl getAudioProperties();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\ProgressControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */