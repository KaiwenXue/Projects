package com.sun.media.controls;

public abstract interface NumericControl
  extends AtomicControl
{
  public abstract float getLowerLimit();
  
  public abstract float getUpperLimit();
  
  public abstract float getValue();
  
  public abstract float setValue(float paramFloat);
  
  public abstract float getDefaultValue();
  
  public abstract float setDefaultValue(float paramFloat);
  
  public abstract float getGranularity();
  
  public abstract boolean isLogarithmic();
  
  public abstract float getLogarithmicBase();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\controls\NumericControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */