package com.sun.media;

import javax.media.Format;

public abstract interface Connector
{
  public static final int ProtocolPush = 0;
  public static final int ProtocolSafe = 1;
  
  public abstract void setFormat(Format paramFormat);
  
  public abstract Format getFormat();
  
  public abstract void setSize(int paramInt);
  
  public abstract int getSize();
  
  public abstract void reset();
  
  public abstract String getName();
  
  public abstract void setName(String paramString);
  
  public abstract void setProtocol(int paramInt);
  
  public abstract int getProtocol();
  
  public abstract Object getCircularBuffer();
  
  public abstract void setCircularBuffer(Object paramObject);
  
  public abstract void setModule(Module paramModule);
  
  public abstract Module getModule();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\Connector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */