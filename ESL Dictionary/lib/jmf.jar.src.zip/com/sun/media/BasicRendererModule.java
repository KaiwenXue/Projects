/*      */ package com.sun.media;
/*      */ 
/*      */ import com.ms.security.PermissionID;
/*      */ import com.ms.security.PolicyEngine;
/*      */ import com.sun.media.renderer.audio.AudioRenderer;
/*      */ import com.sun.media.rtp.util.RTPTimeBase;
/*      */ import com.sun.media.rtp.util.RTPTimeReporter;
/*      */ import com.sun.media.util.ElapseTime;
/*      */ import com.sun.media.util.LoopThread;
/*      */ import com.sun.media.util.jdk12;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Method;
/*      */ import javax.media.Buffer;
/*      */ import javax.media.Clock;
/*      */ import javax.media.Controls;
/*      */ import javax.media.Drainable;
/*      */ import javax.media.Format;
/*      */ import javax.media.PlugIn;
/*      */ import javax.media.Prefetchable;
/*      */ import javax.media.Renderer;
/*      */ import javax.media.ResourceUnavailableException;
/*      */ import javax.media.format.AudioFormat;
/*      */ import javax.media.format.VideoFormat;
/*      */ import javax.media.renderer.VideoRenderer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BasicRendererModule
/*      */   extends BasicSinkModule
/*      */   implements RTPTimeReporter
/*      */ {
/*      */   protected PlaybackEngine engine;
/*      */   protected Renderer renderer;
/*      */   protected InputConnector ic;
/*   43 */   protected int framesPlayed = 0;
/*   44 */   protected float frameRate = 30.0F;
/*   45 */   protected boolean framesWereBehind = false;
/*   46 */   protected boolean prefetching = false;
/*   47 */   protected boolean started = false;
/*   48 */   private boolean opened = false;
/*      */   
/*   50 */   private int chunkSize = Integer.MAX_VALUE;
/*   51 */   private long prefetchedAudioDuration = 0L;
/*   52 */   private long lastDuration = 0L;
/*      */   
/*   54 */   private RTPTimeBase rtpTimeBase = null;
/*      */   
/*   56 */   private String rtpCNAME = null;
/*      */   
/*      */   RenderThread renderThread;
/*      */   
/*   60 */   private static JMFSecurity jmfSecurity = null;
/*   61 */   private static boolean securityPrivelege = false;
/*   62 */   private Method[] m = new Method[1];
/*   63 */   private Class[] cl = new Class[1];
/*   64 */   private Object[][] args = new Object[1][0];
/*   65 */   private Object prefetchSync = new Object();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   74 */   private ElapseTime elapseTime = new ElapseTime();
/*      */   
/*      */   static {
/*      */     try {
/*   78 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*   79 */       securityPrivelege = true;
/*      */     }
/*      */     catch (SecurityException e) {}
/*      */   }
/*      */   
/*      */   protected BasicRendererModule(Renderer r) {
/*   85 */     setRenderer(r);
/*   86 */     this.ic = new BasicInputConnector();
/*   87 */     if ((r instanceof VideoRenderer)) {
/*   88 */       this.ic.setSize(4);
/*      */     } else
/*   90 */       this.ic.setSize(1);
/*   91 */     this.ic.setModule(this);
/*   92 */     registerInputConnector("input", this.ic);
/*   93 */     setProtocol(1);
/*      */   }
/*      */   
/*      */   public boolean isThreaded() {
/*   97 */     return true;
/*      */   }
/*      */   
/*      */   public boolean doRealize() {
/*  101 */     this.chunkSize = computeChunkSize(this.ic.getFormat());
/*      */     
/*  103 */     if (jmfSecurity != null) {
/*  104 */       String permission = null;
/*      */       try {
/*  106 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  107 */           permission = "thread";
/*  108 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*  109 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*      */           
/*  111 */           permission = "thread group";
/*  112 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/*  113 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*  114 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/*  115 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/*  116 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       catch (Throwable e)
/*      */       {
/*  123 */         securityPrivelege = false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  129 */     if ((jmfSecurity != null) && (jmfSecurity.getName().startsWith("jdk12"))) {
/*      */       try
/*      */       {
/*  132 */         Constructor cons = CreateWorkThreadAction.cons;
/*  133 */         this.renderThread = ((RenderThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { RenderThread.class, BasicRendererModule.class, this }) }));
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (Exception e) {}
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  145 */       this.renderThread = new RenderThread(this);
/*      */     }
/*      */     
/*  148 */     this.engine = ((PlaybackEngine)getController());
/*      */     
/*  150 */     return true;
/*      */   }
/*      */   
/*      */   public boolean doPrefetch() {
/*  154 */     super.doPrefetch();
/*  155 */     if (!this.opened) {
/*      */       try {
/*  157 */         this.renderer.open();
/*      */       } catch (ResourceUnavailableException e) {
/*  159 */         this.prefetchFailed = true;
/*  160 */         return false;
/*      */       }
/*  162 */       this.prefetchFailed = false;
/*  163 */       this.opened = true;
/*      */     }
/*      */     
/*      */ 
/*  167 */     if (!((PlaybackEngine)this.controller).prefetchEnabled) {
/*  168 */       return true;
/*      */     }
/*  170 */     this.prefetching = true;
/*      */     
/*      */ 
/*      */ 
/*  174 */     this.renderThread.start();
/*      */     
/*  176 */     return true;
/*      */   }
/*      */   
/*      */   public void doFailedPrefetch() {
/*  180 */     this.renderThread.pause();
/*  181 */     this.renderer.close();
/*  182 */     this.opened = false;
/*  183 */     this.prefetching = false;
/*      */   }
/*      */   
/*      */   public void abortPrefetch() {
/*  187 */     this.renderThread.pause();
/*  188 */     this.renderer.close();
/*  189 */     this.prefetching = false;
/*  190 */     this.opened = false;
/*      */   }
/*      */   
/*      */   public void doStart() {
/*  194 */     super.doStart();
/*      */     
/*  196 */     if (!(this.renderer instanceof Clock))
/*  197 */       this.renderer.start();
/*  198 */     this.prerolling = false;
/*  199 */     this.started = true;
/*      */     
/*  201 */     synchronized (this.prefetchSync) {
/*  202 */       this.prefetching = false;
/*  203 */       this.renderThread.start();
/*      */     }
/*      */   }
/*      */   
/*      */   public void doStop() {
/*  208 */     this.started = false;
/*  209 */     this.prefetching = true;
/*  210 */     super.doStop();
/*      */     
/*  212 */     if ((this.renderer != null) && (!(this.renderer instanceof Clock)))
/*  213 */       this.renderer.stop();
/*      */   }
/*      */   
/*      */   public void doDealloc() {
/*  217 */     this.renderer.close();
/*      */   }
/*      */   
/*      */   public void doClose() {
/*  221 */     this.renderThread.kill();
/*  222 */     if (this.renderer != null)
/*  223 */       this.renderer.close();
/*  224 */     if (this.rtpTimeBase != null) {
/*  225 */       RTPTimeBase.remove(this, this.rtpCNAME);
/*  226 */       this.rtpTimeBase = null;
/*      */     }
/*      */   }
/*      */   
/*      */   public void reset() {
/*  231 */     super.reset();
/*  232 */     this.prefetching = false;
/*      */   }
/*      */   
/*      */   public void triggerReset() {
/*  236 */     if (this.renderer != null) {
/*  237 */       this.renderer.reset();
/*      */     }
/*  239 */     synchronized (this.prefetchSync) {
/*  240 */       this.prefetching = false;
/*      */       
/*      */ 
/*      */ 
/*  244 */       if (this.resetted)
/*  245 */         this.renderThread.start();
/*      */     }
/*      */   }
/*      */   
/*      */   public void doneReset() {
/*  250 */     this.renderThread.pause();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected boolean reinitRenderer(Format input)
/*      */   {
/*  257 */     if ((this.renderer != null) && 
/*  258 */       (this.renderer.setInputFormat(input) != null))
/*      */     {
/*  260 */       return true;
/*      */     }
/*      */     
/*      */ 
/*  264 */     if (this.started) {
/*  265 */       this.renderer.stop();
/*  266 */       this.renderer.reset();
/*      */     }
/*      */     
/*  269 */     this.renderer.close();
/*  270 */     this.renderer = null;
/*      */     
/*      */     Renderer r;
/*  273 */     if ((r = SimpleGraphBuilder.findRenderer(input)) == null) {
/*  274 */       return false;
/*      */     }
/*  276 */     setRenderer(r);
/*  277 */     if (this.started) {
/*  278 */       this.renderer.start();
/*      */     }
/*  280 */     this.chunkSize = computeChunkSize(input);
/*      */     
/*  282 */     return true;
/*      */   }
/*      */   
/*      */   protected void setRenderer(Renderer r) {
/*  286 */     this.renderer = r;
/*  287 */     if ((this.renderer instanceof Clock))
/*  288 */       setClock((Clock)this.renderer);
/*      */   }
/*      */   
/*      */   public Renderer getRenderer() {
/*  292 */     return this.renderer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  301 */   private long LEEWAY = 10L;
/*  302 */   private long lastRendered = 0L;
/*  303 */   private boolean failed = false;
/*  304 */   private boolean notToDropNext = false;
/*  305 */   private Buffer storedBuffer = null;
/*      */   
/*  307 */   private boolean checkRTP = false;
/*  308 */   private boolean noSync = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean doProcess()
/*      */   {
/*  318 */     if (((this.started) || (this.prefetching)) && (this.stopTime > -1L) && (this.elapseTime.value >= this.stopTime))
/*      */     {
/*  320 */       if ((this.renderer instanceof Drainable))
/*  321 */         ((Drainable)this.renderer).drain();
/*  322 */       doStop();
/*  323 */       if (this.moduleListener != null) {
/*  324 */         this.moduleListener.stopAtTime(this);
/*      */       }
/*      */     }
/*      */     
/*      */     Buffer buffer;
/*  329 */     if (this.storedBuffer != null) {
/*  330 */       buffer = this.storedBuffer;
/*      */     } else {
/*  332 */       buffer = this.ic.getValidBuffer();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  343 */     if (!this.checkRTP)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  350 */       if ((buffer.getFlags() & 0x1000) != 0)
/*      */       {
/*  352 */         String key = this.engine.getCNAME();
/*  353 */         if (key != null) {
/*  354 */           this.rtpTimeBase = RTPTimeBase.find(this, key);
/*  355 */           this.rtpCNAME = key;
/*      */           
/*  357 */           if ((this.ic.getFormat() instanceof AudioFormat)) {
/*  358 */             Log.comment("RTP master time set: " + this.renderer + "\n");
/*      */             
/*  360 */             this.rtpTimeBase.setMaster(this);
/*      */           }
/*  362 */           this.checkRTP = true;
/*  363 */           this.noSync = false;
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  368 */           this.noSync = true;
/*      */         }
/*      */       } else {
/*  371 */         this.checkRTP = true;
/*      */       }
/*      */     }
/*  374 */     this.lastTimeStamp = buffer.getTimeStamp();
/*      */     
/*      */ 
/*  377 */     if ((this.failed) || (this.resetted))
/*      */     {
/*      */ 
/*      */ 
/*  381 */       if ((buffer.getFlags() & 0x200) != 0) {
/*  382 */         this.resetted = false;
/*  383 */         this.renderThread.pause();
/*      */         
/*      */ 
/*  386 */         if (this.moduleListener != null) {
/*  387 */           this.moduleListener.resetted(this);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  392 */       this.storedBuffer = null;
/*  393 */       this.ic.readReport();
/*  394 */       return true;
/*      */     }
/*      */     
/*  397 */     if (PlaybackEngine.DEBUG) { this.jmd.moduleIn(this, 0, buffer, true);
/*      */     }
/*      */     
/*  400 */     boolean rtn = scheduleBuffer(buffer);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  405 */     if ((this.storedBuffer == null) && (buffer.isEOM()))
/*      */     {
/*  407 */       if (this.prefetching) {
/*  408 */         donePrefetch();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  414 */       if (((buffer.getFlags() & 0x40) == 0) && (buffer.getTimeStamp() > 0L) && (buffer.getDuration() > 0L) && (buffer.getFormat() != null) && (!(buffer.getFormat() instanceof AudioFormat)) && (!this.noSync))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  419 */         waitForPT(buffer.getTimeStamp() + this.lastDuration);
/*      */       }
/*      */       
/*  422 */       this.storedBuffer = null;
/*  423 */       this.ic.readReport();
/*      */       
/*  425 */       if (PlaybackEngine.DEBUG) this.jmd.moduleIn(this, 0, buffer, false);
/*  426 */       doStop();
/*  427 */       if (this.moduleListener != null) {
/*  428 */         this.moduleListener.mediaEnded(this);
/*      */       }
/*  430 */       return true;
/*      */     }
/*      */     
/*      */ 
/*  434 */     if (this.storedBuffer == null) {
/*  435 */       this.ic.readReport();
/*      */     }
/*  437 */     if (PlaybackEngine.DEBUG) { this.jmd.moduleIn(this, 0, buffer, false);
/*      */     }
/*  439 */     return rtn;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean scheduleBuffer(Buffer buf)
/*      */   {
/*  450 */     int rc = 0;
/*      */     
/*  452 */     Format format = buf.getFormat();
/*      */     
/*  454 */     if (format == null)
/*      */     {
/*      */ 
/*  457 */       format = this.ic.getFormat();
/*  458 */       buf.setFormat(format);
/*      */     }
/*      */     
/*      */ 
/*  462 */     if ((format != this.ic.getFormat()) && (!format.equals(this.ic.getFormat())) && (!buf.isDiscard()))
/*      */     {
/*      */ 
/*  465 */       if (!handleFormatChange(format)) {
/*  466 */         return false;
/*      */       }
/*      */     }
/*      */     
/*  470 */     if (((buf.getFlags() & 0x400) != 0) && (this.moduleListener != null))
/*      */     {
/*  472 */       this.moduleListener.markedDataArrived(this, buf);
/*  473 */       buf.setFlags(buf.getFlags() & 0xFBFF);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  480 */     if ((this.prefetching) || ((format instanceof AudioFormat)) || (buf.getTimeStamp() <= 0L) || ((buf.getFlags() & 0x60) == 96) || (this.noSync))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  498 */       if (!buf.isDiscard()) {
/*  499 */         rc = processBuffer(buf);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  506 */       long mt = getSyncTime(buf.getTimeStamp());
/*      */       
/*      */ 
/*  509 */       long lateBy = mt / 1000000L - buf.getTimeStamp() / 1000000L - getLatency() / 1000000L;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  520 */       if ((this.storedBuffer == null) && (lateBy > 0L))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  525 */         if (buf.isDiscard())
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  532 */           this.notToDropNext = true;
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  537 */           if (buf.isEOM())
/*      */           {
/*      */ 
/*  540 */             this.notToDropNext = true;
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*  545 */           else if ((this.moduleListener != null) && ((format instanceof VideoFormat)))
/*      */           {
/*  547 */             float fb = (float)lateBy * this.frameRate / 1000.0F;
/*  548 */             if (fb < 1.0F)
/*  549 */               fb = 1.0F;
/*  550 */             this.moduleListener.framesBehind(this, fb, this.ic);
/*  551 */             this.framesWereBehind = true;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  556 */           if ((buf.getFlags() & 0x20) != 0)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  561 */             rc = processBuffer(buf);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*  568 */           else if ((lateBy < this.LEEWAY) || (this.notToDropNext) || (buf.getTimeStamp() - this.lastRendered > 1000000000L))
/*      */           {
/*      */ 
/*  571 */             rc = processBuffer(buf);
/*  572 */             this.lastRendered = buf.getTimeStamp();
/*  573 */             this.notToDropNext = false;
/*      */ 
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*  590 */         if ((this.moduleListener != null) && (this.framesWereBehind) && ((format instanceof VideoFormat)))
/*      */         {
/*  592 */           this.moduleListener.framesBehind(this, 0.0F, this.ic);
/*  593 */           this.framesWereBehind = false;
/*      */         }
/*      */         
/*      */ 
/*  597 */         if (!buf.isDiscard())
/*      */         {
/*      */ 
/*  600 */           if ((buf.getFlags() & 0x40) == 0) {
/*  601 */             waitForPT(buf.getTimeStamp());
/*      */           }
/*  603 */           if (!this.resetted) {
/*  604 */             rc = processBuffer(buf);
/*  605 */             this.lastRendered = buf.getTimeStamp();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  613 */     if ((rc & 0x1) != 0) {
/*  614 */       this.storedBuffer = null;
/*  615 */     } else if ((rc & 0x2) != 0)
/*      */     {
/*      */ 
/*  618 */       this.storedBuffer = buf;
/*      */     }
/*      */     else {
/*  621 */       this.storedBuffer = null;
/*  622 */       if (buf.getDuration() >= 0L) {
/*  623 */         this.lastDuration = buf.getDuration();
/*      */       }
/*      */     }
/*  626 */     return true;
/*      */   }
/*      */   
/*      */ 
/*  630 */   final float MAX_RATE = 1.05F;
/*  631 */   final float RATE_INCR = 0.01F;
/*  632 */   final int FLOW_LIMIT = 20;
/*  633 */   boolean overMsg = false;
/*  634 */   int overflown = 10;
/*  635 */   float rate = 1.0F;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int processBuffer(Buffer buffer)
/*      */   {
/*  642 */     int remain = buffer.getLength();
/*  643 */     int offset = buffer.getOffset();
/*  644 */     int rc = 0;
/*  645 */     boolean isEOM = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  651 */     if ((this.renderer instanceof Clock)) {
/*  652 */       if ((buffer.getFlags() & 0x2000) != 0) {
/*  653 */         this.overflown += 1;
/*      */       } else {
/*  655 */         this.overflown -= 1;
/*      */       }
/*  657 */       if (this.overflown > 20)
/*      */       {
/*  659 */         if (this.rate < 1.05F) {
/*  660 */           this.rate += 0.01F;
/*  661 */           this.renderer.stop();
/*  662 */           ((Clock)this.renderer).setRate(this.rate);
/*  663 */           this.renderer.start();
/*  664 */           if (!this.overMsg) {
/*  665 */             Log.comment("Data buffers overflown.  Adjust rendering speed up to 5 % to compensate");
/*  666 */             this.overMsg = true;
/*      */           }
/*      */         }
/*      */         
/*  670 */         this.overflown = 10;
/*      */       }
/*  672 */       else if (this.overflown <= 0)
/*      */       {
/*  674 */         if (this.rate > 1.0F) {
/*  675 */           this.rate -= 0.01F;
/*  676 */           this.renderer.stop();
/*  677 */           ((Clock)this.renderer).setRate(this.rate);
/*  678 */           this.renderer.start();
/*      */         }
/*      */         
/*  681 */         this.overflown = 10;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     do
/*      */     {
/*  694 */       if ((this.stopTime > -1L) && (this.elapseTime.value >= this.stopTime)) {
/*  695 */         if (this.prefetching)
/*  696 */           donePrefetch();
/*  697 */         return 2;
/*      */       }
/*      */       
/*      */       int len;
/*      */       
/*  702 */       if ((remain <= this.chunkSize) || (this.prerolling)) {
/*  703 */         if (isEOM) {
/*  704 */           isEOM = false;
/*  705 */           buffer.setEOM(true);
/*      */         }
/*  707 */         len = remain;
/*      */       } else {
/*  709 */         if (buffer.isEOM()) {
/*  710 */           isEOM = true;
/*  711 */           buffer.setEOM(false);
/*      */         }
/*  713 */         len = this.chunkSize;
/*      */       }
/*      */       
/*  716 */       buffer.setLength(len);
/*  717 */       buffer.setOffset(offset);
/*      */       
/*  719 */       if ((this.prerolling) && (!handlePreroll(buffer))) {
/*  720 */         offset += len;
/*  721 */         remain -= len;
/*      */       }
/*      */       else
/*      */       {
/*      */         try
/*      */         {
/*  727 */           rc = this.renderer.process(buffer);
/*      */         }
/*      */         catch (Throwable e) {
/*  730 */           Log.dumpStack(e);
/*  731 */           if (this.moduleListener != null) {
/*  732 */             this.moduleListener.internalErrorOccurred(this);
/*      */           }
/*      */         }
/*  735 */         if ((rc & 0x8) != 0) {
/*  736 */           this.failed = true;
/*  737 */           if (this.moduleListener != null)
/*  738 */             this.moduleListener.pluginTerminated(this);
/*  739 */           return rc;
/*      */         }
/*      */         
/*  742 */         if ((rc & 0x1) != 0) {
/*  743 */           buffer.setDiscard(true);
/*  744 */           if (this.prefetching)
/*  745 */             donePrefetch();
/*  746 */           return rc;
/*      */         }
/*      */         
/*      */ 
/*  750 */         if ((rc & 0x2) != 0)
/*      */         {
/*  752 */           len -= buffer.getLength();
/*      */         }
/*      */         
/*  755 */         offset += len;
/*  756 */         remain -= len;
/*      */         
/*      */ 
/*      */ 
/*  760 */         if ((this.prefetching) && ((!(this.renderer instanceof Prefetchable)) || (((Prefetchable)this.renderer).isPrefetched())))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  765 */           isEOM = false;
/*  766 */           buffer.setEOM(false);
/*  767 */           donePrefetch();
/*  768 */           break;
/*      */         }
/*      */         
/*  771 */         this.elapseTime.update(len, buffer.getTimeStamp(), buffer.getFormat());
/*      */       }
/*  773 */     } while ((remain > 0) && (!this.resetted));
/*      */     
/*      */ 
/*  776 */     if (isEOM) {
/*  777 */       buffer.setEOM(true);
/*      */     }
/*  779 */     buffer.setLength(remain);
/*  780 */     buffer.setOffset(offset);
/*      */     
/*  782 */     if (rc == 0) {
/*  783 */       this.framesPlayed += 1;
/*      */     }
/*  785 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean handleFormatChange(Format format)
/*      */   {
/*  794 */     if (!reinitRenderer(format))
/*      */     {
/*  796 */       this.storedBuffer = null;
/*  797 */       this.failed = true;
/*  798 */       if (this.moduleListener != null)
/*  799 */         this.moduleListener.formatChangedFailure(this, this.ic.getFormat(), format);
/*  800 */       return false;
/*      */     }
/*      */     
/*  803 */     Format oldFormat = this.ic.getFormat();
/*  804 */     this.ic.setFormat(format);
/*  805 */     if (this.moduleListener != null) {
/*  806 */       this.moduleListener.formatChanged(this, oldFormat, format);
/*      */     }
/*  808 */     if ((format instanceof VideoFormat)) {
/*  809 */       float fr = ((VideoFormat)format).getFrameRate();
/*  810 */       if (fr != -1.0F) {
/*  811 */         this.frameRate = fr;
/*      */       }
/*      */     }
/*  814 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void donePrefetch()
/*      */   {
/*  823 */     synchronized (this.prefetchSync) {
/*  824 */       if ((!this.started) && (this.prefetching))
/*  825 */         this.renderThread.pause();
/*  826 */       this.prefetching = false;
/*      */     }
/*      */     
/*  829 */     if (this.moduleListener != null) {
/*  830 */       this.moduleListener.bufferPrefetched(this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setPreroll(long wanted, long actual)
/*      */   {
/*  838 */     super.setPreroll(wanted, actual);
/*  839 */     this.elapseTime.setValue(actual);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected boolean handlePreroll(Buffer buf)
/*      */   {
/*  849 */     if ((buf.getFormat() instanceof AudioFormat))
/*      */     {
/*  851 */       if (!hasReachAudioPrerollTarget(buf)) {
/*  852 */         return false;
/*      */       }
/*  854 */     } else if (((buf.getFlags() & 0x60) == 0) && (buf.getTimeStamp() >= 0L))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  860 */       if (buf.getTimeStamp() < getSyncTime(buf.getTimeStamp()))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  865 */         return false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  876 */     this.prerolling = false;
/*      */     
/*  878 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean hasReachAudioPrerollTarget(Buffer buf)
/*      */   {
/*  889 */     long target = getSyncTime(buf.getTimeStamp());
/*      */     
/*  891 */     this.elapseTime.update(buf.getLength(), buf.getTimeStamp(), buf.getFormat());
/*      */     
/*  893 */     if (this.elapseTime.value >= target) {
/*  894 */       long remain = ElapseTime.audioTimeToLen(this.elapseTime.value - target, (AudioFormat)buf.getFormat());
/*      */       
/*      */ 
/*  897 */       int offset = buf.getOffset() + buf.getLength() - (int)remain;
/*  898 */       if (offset >= 0) {
/*  899 */         buf.setOffset(offset);
/*  900 */         buf.setLength((int)remain);
/*      */       }
/*      */       
/*  903 */       this.elapseTime.setValue(target);
/*      */       
/*  905 */       return true;
/*      */     }
/*      */     
/*  908 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  914 */   long systemErr = 0L;
/*      */   
/*      */   static final long RTP_TIME_MARGIN = 2000000000L;
/*      */   
/*      */ 
/*      */   private boolean waitForPT(long pt)
/*      */   {
/*  921 */     long mt = getSyncTime(pt);
/*  922 */     long lastAheadBy = -1L;
/*      */     
/*      */ 
/*  925 */     int beenHere = 0;
/*      */     
/*  927 */     long aheadBy = (pt - mt) / 1000000L;
/*  928 */     if (this.rate != 1.0F) {
/*  929 */       aheadBy = ((float)aheadBy / this.rate);
/*      */     }
/*  931 */     while ((aheadBy > this.systemErr) && (!this.resetted))
/*      */     {
/*  933 */       if (aheadBy == lastAheadBy)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  940 */         interval = aheadBy + 5 * beenHere;
/*  941 */         if (interval > 33L) {
/*  942 */           interval = 33L;
/*      */         } else {
/*  944 */           beenHere++;
/*      */         }
/*      */       } else {
/*  947 */         interval = aheadBy;
/*  948 */         beenHere = 0;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  953 */       long interval = interval > 125L ? 125L : interval;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  958 */       long before = System.currentTimeMillis();
/*      */       
/*      */ 
/*      */ 
/*  962 */       interval -= this.systemErr;
/*      */       try
/*      */       {
/*  965 */         if (interval > 0L) {
/*  966 */           Thread.currentThread();Thread.sleep(interval);
/*      */         }
/*      */       } catch (InterruptedException e) {}
/*  969 */       long slept = System.currentTimeMillis() - before;
/*      */       
/*      */ 
/*      */ 
/*  973 */       this.systemErr = ((slept - interval + this.systemErr) / 2L);
/*      */       
/*      */ 
/*  976 */       if (this.systemErr < 0L) {
/*  977 */         this.systemErr = 0L;
/*  978 */       } else if (this.systemErr > interval) {
/*  979 */         this.systemErr = interval;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  984 */       mt = getSyncTime(pt);
/*      */       
/*  986 */       lastAheadBy = aheadBy;
/*  987 */       aheadBy = (pt - mt) / 1000000L;
/*  988 */       if (this.rate != 1.0F) {
/*  989 */         aheadBy = ((float)aheadBy / this.rate);
/*      */       }
/*  991 */       if (getState() != 600)
/*      */         break;
/*      */     }
/*  994 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*  999 */   boolean rtpErrMsg = false;
/*      */   long lastTimeStamp;
/*      */   
/* 1002 */   private long getSyncTime(long pts) { if (this.rtpTimeBase != null)
/*      */     {
/*      */ 
/* 1005 */       if (this.rtpTimeBase.getMaster() == getController())
/* 1006 */         return pts;
/* 1007 */       long ts = this.rtpTimeBase.getNanoseconds();
/*      */       
/* 1009 */       if ((ts > pts + 2000000000L) || (ts < pts - 2000000000L))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1016 */         if (!this.rtpErrMsg) {
/* 1017 */           Log.comment("Cannot perform RTP sync beyond a difference of: " + (ts - pts) / 1000000L + " msecs.\n");
/* 1018 */           this.rtpErrMsg = true;
/*      */         }
/*      */         
/* 1021 */         return pts;
/*      */       }
/* 1023 */       return ts;
/*      */     }
/* 1025 */     return getMediaNanoseconds();
/*      */   }
/*      */   
/*      */   public long getRTPTime()
/*      */   {
/* 1030 */     if ((this.ic.getFormat() instanceof AudioFormat)) {
/* 1031 */       if ((this.renderer instanceof AudioRenderer))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1039 */         return this.lastTimeStamp - ((AudioRenderer)this.renderer).getLatency();
/*      */       }
/*      */       
/* 1042 */       return this.lastTimeStamp;
/*      */     }
/*      */     
/*      */ 
/* 1046 */     return this.lastTimeStamp;
/*      */   }
/*      */   
/*      */   public Object[] getControls()
/*      */   {
/* 1051 */     return this.renderer.getControls();
/*      */   }
/*      */   
/*      */   public Object getControl(String s) {
/* 1055 */     return this.renderer.getControl(s);
/*      */   }
/*      */   
/*      */   public void setFormat(Connector connector, Format format) {
/* 1059 */     this.renderer.setInputFormat(format);
/* 1060 */     if ((format instanceof VideoFormat)) {
/* 1061 */       float fr = ((VideoFormat)format).getFrameRate();
/* 1062 */       if (fr != -1.0F)
/* 1063 */         this.frameRate = fr;
/*      */     }
/*      */   }
/*      */   
/*      */   public int getFramesPlayed() {
/* 1068 */     return this.framesPlayed;
/*      */   }
/*      */   
/*      */   public void resetFramesPlayed() {
/* 1072 */     this.framesPlayed = 0;
/*      */   }
/*      */   
/*      */   static final int MAX_CHUNK_SIZE = 16;
/* 1076 */   AudioFormat ulawFormat = new AudioFormat("ULAW");
/* 1077 */   AudioFormat linearFormat = new AudioFormat("LINEAR");
/*      */   
/*      */   private int computeChunkSize(Format format)
/*      */   {
/* 1081 */     if (((format instanceof AudioFormat)) && ((this.ulawFormat.matches(format)) || (this.linearFormat.matches(format))))
/*      */     {
/*      */ 
/* 1084 */       AudioFormat af = (AudioFormat)format;
/* 1085 */       int units = af.getSampleSizeInBits() * af.getChannels() / 8;
/* 1086 */       if (units == 0)
/* 1087 */         units = 1;
/* 1088 */       int chunks = (int)af.getSampleRate() * units / 16;
/*      */       
/*      */ 
/* 1091 */       return chunks / units * units;
/*      */     }
/*      */     
/* 1094 */     return Integer.MAX_VALUE;
/*      */   }
/*      */   
/*      */   protected void process() {}
/*      */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\BasicRendererModule.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */