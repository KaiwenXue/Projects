package com.sun.media.datasink;

public abstract interface RandomAccess
{
  public abstract void setEnabled(boolean paramBoolean);
  
  public abstract boolean write(long paramLong, int paramInt);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\datasink\RandomAccess.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */