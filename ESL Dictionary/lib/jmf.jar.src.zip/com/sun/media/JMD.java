package com.sun.media;

import javax.media.Buffer;
import javax.media.Control;

public abstract interface JMD
  extends Control
{
  public abstract void setVisible(boolean paramBoolean);
  
  public abstract void initGraph(BasicModule paramBasicModule);
  
  public abstract void moduleIn(BasicModule paramBasicModule, int paramInt, Buffer paramBuffer, boolean paramBoolean);
  
  public abstract void moduleOut(BasicModule paramBasicModule, int paramInt, Buffer paramBuffer, boolean paramBoolean);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\JMD.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */