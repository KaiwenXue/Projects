/*     */ package com.sun.media.processor.rtsp;
/*     */ 
/*     */ import com.sun.media.BasicController;
/*     */ import com.sun.media.BasicPlayer;
/*     */ import com.sun.media.BasicProcessor;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.content.rtsp.RtspUtil;
/*     */ import java.awt.Component;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Vector;
/*     */ import javax.media.Clock;
/*     */ import javax.media.Control;
/*     */ import javax.media.Controller;
/*     */ import javax.media.ControllerClosedEvent;
/*     */ import javax.media.ControllerErrorEvent;
/*     */ import javax.media.ControllerEvent;
/*     */ import javax.media.ControllerListener;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.Manager;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.NotConfiguredError;
/*     */ import javax.media.NotRealizedError;
/*     */ import javax.media.Player;
/*     */ import javax.media.Processor;
/*     */ import javax.media.SystemTimeBase;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.control.BufferControl;
/*     */ import javax.media.control.TrackControl;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.rtp.RTPControl;
/*     */ import javax.media.rtp.RTPManager;
/*     */ import javax.media.rtp.RTPStream;
/*     */ import javax.media.rtp.ReceiveStream;
/*     */ import javax.media.rtp.ReceiveStreamListener;
/*     */ import javax.media.rtp.SessionAddress;
/*     */ import javax.media.rtp.event.NewReceiveStreamEvent;
/*     */ import javax.media.rtp.event.RTPEvent;
/*     */ import javax.media.rtp.event.ReceiveStreamEvent;
/*     */ import javax.media.rtp.event.RemotePayloadChangeEvent;
/*     */ 
/*     */ public class Handler extends BasicProcessor implements ReceiveStreamListener
/*     */ {
/*  51 */   private final int INITIALIZED = 0;
/*  52 */   private final int REALIZED = 1;
/*  53 */   private final int PLAYING = 2;
/*  54 */   private final int PAUSING = 3;
/*     */   
/*     */   private javax.media.protocol.DataSource[] data_sources;
/*     */   
/*  58 */   Processor processor = null;
/*  59 */   Format[] formats = null;
/*  60 */   Vector locators = null;
/*     */   
/*  62 */   Object dataLock = new Object();
/*  63 */   boolean dataReady = false;
/*     */   
/*  65 */   private boolean closed = false;
/*  66 */   private boolean audioEnabled = false;
/*  67 */   private boolean videoEnabled = false;
/*     */   
/*  69 */   private static JMFSecurity jmfSecurity = null;
/*  70 */   private static boolean securityPrivelege = false;
/*  71 */   private Method[] m = new Method[1];
/*  72 */   private Class[] cl = new Class[1];
/*  73 */   private Object[][] args = new Object[1][0];
/*     */   
/*  75 */   private boolean first_pass = true;
/*     */   RtspUtil rtspUtil;
/*     */   
/*     */   public Handler()
/*     */   {
/*  80 */     this.framePositioning = false;
/*     */     
/*  82 */     this.rtspUtil = new RtspUtil(this);
/*     */     
/*  84 */     this.locators = new Vector();
/*     */   }
/*     */   
/*  87 */   String sessionError = "cannot create and initialize the RTP Session.";
/*     */   
/*     */   protected synchronized boolean doConfigure() {
/*  90 */     boolean configured = super.doConfigure();
/*     */     
/*  92 */     if (configured) {
/*  93 */       configured = initRtspSession();
/*     */     }
/*     */     
/*  96 */     return configured;
/*     */   }
/*     */   
/*     */   private boolean initRtspSession() {
/* 100 */     boolean realized = false;
/*     */     
/* 102 */     MediaLocator ml = (MediaLocator)this.locators.elementAt(0);
/*     */     
/* 104 */     this.rtspUtil.setUrl(ml.toString());
/*     */     
/* 106 */     String ipAddress = this.rtspUtil.getServerIpAddress();
/*     */     
/* 108 */     if (ipAddress == null) {
/* 109 */       System.out.println("Invalid server address.");
/*     */       
/* 111 */       realized = false;
/*     */     } else {
/* 113 */       this.rtspUtil.setUrl(ml.toString());
/*     */       
/* 115 */       realized = this.rtspUtil.createConnection();
/*     */       
/* 117 */       if (realized) {
/* 118 */         realized = this.rtspUtil.rtspSetup();
/*     */         try
/*     */         {
/* 121 */           InetAddress destaddr = InetAddress.getByName(ipAddress);
/*     */           
/* 123 */           int[] server_ports = this.rtspUtil.getServerPorts();
/*     */           
/* 125 */           for (int i = 0; i < this.rtspUtil.getNumberOfTracks(); i++) {
/* 126 */             SessionAddress remoteAddress = new SessionAddress(destaddr, server_ports[i]);
/*     */             
/*     */ 
/*     */ 
/* 130 */             this.rtspUtil.getRTPManager(i).addTarget(remoteAddress);
/*     */             
/*     */ 
/* 133 */             BufferControl bc = (BufferControl)this.rtspUtil.getRTPManager(i).getControl("javax.media.control.BufferControl");
/*     */             
/* 135 */             String mediaType = this.rtspUtil.getMediaType(i);
/*     */             
/* 137 */             if (mediaType.equals("audio")) {
/* 138 */               bc.setBufferLength(250L);
/* 139 */               bc.setMinimumThreshold(125L);
/* 140 */             } else if (mediaType.equals("video")) {
/* 141 */               bc.setBufferLength(1500L);
/* 142 */               bc.setMinimumThreshold(250L);
/*     */             }
/*     */           }
/*     */         } catch (Exception e) {
/* 146 */           Log.error(e.getMessage());
/*     */           
/* 148 */           return realized;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 153 */     if (realized) {
/* 154 */       this.state = 1;
/*     */       
/* 156 */       int size = this.rtspUtil.getNumberOfTracks();
/*     */       
/* 158 */       this.data_sources = new javax.media.protocol.DataSource[size];
/* 159 */       this.formats = new Format[size];
/*     */       
/*     */ 
/* 162 */       if (!this.rtspUtil.rtspStart()) {
/* 163 */         if ((this.first_pass) && (this.rtspUtil.getStatusCode() == 454))
/*     */         {
/*     */ 
/*     */ 
/* 167 */           this.first_pass = false;
/*     */           
/* 169 */           return initRtspSession();
/*     */         }
/*     */         
/* 172 */         return false;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 177 */       waitForData();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 195 */     return realized;
/*     */   }
/*     */   
/*     */   private synchronized boolean waitForData() {
/*     */     try {
/* 200 */       synchronized (this.dataLock) {
/* 201 */         while (!this.dataReady) {
/* 202 */           this.dataLock.wait();
/*     */         }
/*     */       }
/*     */     } catch (InterruptedException e) {
/* 206 */       e.printStackTrace();
/*     */     }
/*     */     
/* 209 */     return this.dataReady;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void completeConfigure()
/*     */   {
/* 254 */     this.state = 180;
/* 255 */     super.completeConfigure();
/*     */   }
/*     */   
/*     */   protected void doFailedConfigure() {
/* 259 */     closeSessions();
/* 260 */     super.doFailedConfigure();
/*     */   }
/*     */   
/*     */   private void closeSessions() {
/* 264 */     RTPManager[] mgrs = this.rtspUtil.getRTPManagers();
/*     */     
/* 266 */     for (int i = 0; i < mgrs.length; i++) {
/* 267 */       if (mgrs[i] != null) {
/* 268 */         mgrs[i].removeTargets("Closing session from the RTP Handler");
/* 269 */         mgrs[i].dispose();
/*     */       }
/*     */       
/* 272 */       mgrs[i] = null;
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean doRealize() {
/* 277 */     return waitForRealize(this.processor);
/*     */   }
/*     */   
/*     */   protected void completeRealize() {
/* 281 */     this.state = 300;
/* 282 */     super.completeRealize();
/*     */   }
/*     */   
/*     */   protected void doFailedRealize() {
/* 286 */     closeSessions();
/* 287 */     super.doFailedRealize();
/*     */   }
/*     */   
/*     */   protected void doStart() {
/* 291 */     super.doStart();
/* 292 */     waitForStart(this.processor);
/*     */   }
/*     */   
/*     */   protected void doStop() {
/* 296 */     super.doStop();
/* 297 */     waitForStop(this.processor);
/*     */   }
/*     */   
/*     */   protected void doDeallocate() {
/* 301 */     this.processor.deallocate();
/* 302 */     synchronized (this.dataLock) {
/* 303 */       this.dataLock.notifyAll();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void doClose() {
/* 308 */     this.closed = true;
/*     */     
/* 310 */     synchronized (this.dataLock) {
/* 311 */       this.dataLock.notify();
/*     */     }
/*     */     
/* 314 */     stop();
/* 315 */     this.processor.close();
/* 316 */     closeSessions();
/* 317 */     super.doClose();
/*     */   }
/*     */   
/*     */   public void setTimeBase(TimeBase tb) throws IncompatibleTimeBaseException
/*     */   {}
/*     */   
/*     */   protected TimeBase getMasterTimeBase() {
/* 324 */     return new SystemTimeBase();
/*     */   }
/*     */   
/*     */   protected boolean audioEnabled() {
/* 328 */     return this.audioEnabled;
/*     */   }
/*     */   
/*     */   protected boolean videoEnabled() {
/* 332 */     return this.videoEnabled;
/*     */   }
/*     */   
/*     */   private void sendMyEvent(ControllerEvent e) {
/* 336 */     super.sendEvent(e);
/*     */   }
/*     */   
/*     */   public void update(ReceiveStreamEvent event) {
/* 340 */     RTPManager mgr = (RTPManager)event.getSource();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 346 */     if (this.data_sources == null) {
/* 347 */       return;
/*     */     }
/*     */     
/* 350 */     RTPManager[] mgrs = this.rtspUtil.getRTPManagers();
/*     */     
/* 352 */     for (int idx = 0; idx < mgrs.length; idx++) {
/* 353 */       if (mgrs[idx] == mgr) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/* 358 */     if (idx >= mgrs.length)
/*     */     {
/* 360 */       System.err.println("Unknown manager: " + mgr);
/* 361 */       return;
/*     */     }
/*     */     
/* 364 */     if ((event instanceof RemotePayloadChangeEvent)) {
/* 365 */       Log.comment("Received an RTP PayloadChangeEvent");
/* 366 */       Log.error("The RTP processor cannot handle mid-stream payload change.\n");
/* 367 */       sendEvent(new ControllerErrorEvent(this, "Cannot handle mid-stream payload change."));
/* 368 */       close();
/*     */     }
/*     */     
/* 371 */     if ((event instanceof NewReceiveStreamEvent)) {
/* 372 */       if (this.data_sources[idx] != null)
/*     */       {
/* 374 */         return;
/*     */       }
/*     */       
/* 377 */       ReceiveStream stream = null;
/*     */       
/*     */       try
/*     */       {
/* 381 */         stream = ((NewReceiveStreamEvent)event).getReceiveStream();
/* 382 */         this.data_sources[idx] = stream.getDataSource();
/*     */         
/* 384 */         RTPControl ctl = (RTPControl)this.data_sources[idx].getControl("javax.media.rtp.RTPControl");
/* 385 */         if (ctl != null) {
/* 386 */           this.formats[idx] = ctl.getFormat();
/*     */           
/* 388 */           if ((this.formats[idx] instanceof AudioFormat)) {
/* 389 */             this.audioEnabled = true;
/*     */           }
/*     */           
/* 392 */           if ((this.formats[idx] instanceof VideoFormat)) {
/* 393 */             this.videoEnabled = true;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 406 */         for (int i = 0; i < this.data_sources.length; i++)
/*     */         {
/* 408 */           if (this.data_sources[i] == null) {
/*     */             return;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */         javax.media.protocol.DataSource mixDS;
/*     */         
/*     */         try
/*     */         {
/* 418 */           mixDS = Manager.createMergingDataSource(this.data_sources);
/*     */         } catch (Exception e) {
/* 420 */           System.err.println("Cannot merge data sources.");
/* 421 */           return;
/*     */         }
/*     */         try
/*     */         {
/* 425 */           this.processor = Manager.createProcessor(mixDS);
/*     */         } catch (Exception e) {
/* 427 */           System.err.println("Cannot create the mix processor.");
/* 428 */           return;
/*     */         }
/*     */         
/* 431 */         if (!waitForConfigure(this.processor)) {
/* 432 */           return;
/*     */         }
/*     */         
/*     */ 
/* 436 */         synchronized (this.dataLock) {
/* 437 */           this.dataReady = true;
/* 438 */           this.dataLock.notifyAll();
/*     */         }
/*     */       } catch (Exception e) {
/* 441 */         System.err.println("NewReceiveStreamEvent exception " + e.getMessage());
/* 442 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setSource(javax.media.protocol.DataSource source)
/*     */     throws IOException, IncompatibleSourceException
/*     */   {
/* 450 */     super.setSource(source);
/*     */     
/* 452 */     if ((source instanceof com.sun.media.protocol.rtsp.DataSource)) {
/* 453 */       MediaLocator ml = source.getLocator();
/*     */       
/* 455 */       this.locators.addElement(ml);
/*     */     } else {
/* 457 */       throw new IncompatibleSourceException();
/*     */     }
/*     */   }
/*     */   
/*     */   private void invalidateComp() {
/* 462 */     this.controlComp = null;
/* 463 */     this.controls = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Component getVisualComponent()
/*     */   {
/* 474 */     super.getVisualComponent();
/* 475 */     return this.processor.getVisualComponent();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Control[] getControls()
/*     */   {
/* 484 */     return this.processor.getControls();
/*     */   }
/*     */   
/*     */   public void updateStats() {
/* 488 */     if (this.processor != null) {
/* 489 */       ((BasicProcessor)this.processor).updateStats();
/*     */     }
/*     */   }
/*     */   
/*     */   public TrackControl[] getTrackControls()
/*     */     throws NotConfiguredError
/*     */   {
/* 496 */     super.getTrackControls();
/* 497 */     return this.processor.getTrackControls();
/*     */   }
/*     */   
/*     */   public ContentDescriptor[] getSupportedContentDescriptors() throws NotConfiguredError
/*     */   {
/* 502 */     super.getSupportedContentDescriptors();
/* 503 */     return this.processor.getSupportedContentDescriptors();
/*     */   }
/*     */   
/*     */   public ContentDescriptor setContentDescriptor(ContentDescriptor ocd) throws NotConfiguredError
/*     */   {
/* 508 */     super.setContentDescriptor(ocd);
/* 509 */     return this.processor.setContentDescriptor(ocd);
/*     */   }
/*     */   
/*     */   public ContentDescriptor getContentDescriptor() throws NotConfiguredError
/*     */   {
/* 514 */     super.getContentDescriptor();
/* 515 */     return this.processor.getContentDescriptor();
/*     */   }
/*     */   
/*     */   public javax.media.protocol.DataSource getDataOutput() throws NotRealizedError {
/* 519 */     super.getDataOutput();
/* 520 */     return this.processor.getDataOutput();
/*     */   }
/*     */   
/*     */   private boolean waitForConfigure(Processor p) {
/* 524 */     return new StateWaiter().waitForConfigure(p);
/*     */   }
/*     */   
/*     */   private boolean waitForRealize(Processor p) {
/* 528 */     return new StateWaiter().waitForRealize(p);
/*     */   }
/*     */   
/*     */   private void waitForStart(Player p) {
/* 532 */     new StateWaiter().waitForStart(p, true);
/*     */   }
/*     */   
/*     */   private void waitForStop(Player p) {
/* 536 */     new StateWaiter().waitForStart(p, false);
/*     */   }
/*     */   
/*     */ 
/* 540 */   private void waitForClose(Player p) { new StateWaiter().waitForClose(p); }
/*     */   
/*     */   class StateWaiter implements ControllerListener { StateWaiter() {}
/*     */     
/* 544 */     boolean closeDown = false;
/* 545 */     Object stateLock = new Object();
/*     */     
/*     */     public boolean waitForConfigure(Processor p) {
/* 548 */       p.addControllerListener(this);
/* 549 */       p.configure();
/*     */       
/* 551 */       synchronized (this.stateLock) {
/*     */         do {
/*     */           try {
/* 554 */             this.stateLock.wait(1000L);
/*     */           }
/*     */           catch (InterruptedException ie)
/*     */           {
/*     */             break;
/*     */           }
/* 552 */           if (p.getState() == 180) break; } while (!this.closeDown);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 561 */       p.removeControllerListener(this);
/* 562 */       return !this.closeDown;
/*     */     }
/*     */     
/*     */     public boolean waitForRealize(Processor p) {
/* 566 */       p.addControllerListener(this);
/* 567 */       p.realize();
/*     */       
/* 569 */       synchronized (this.stateLock) {
/*     */         do {
/*     */           try {
/* 572 */             this.stateLock.wait(1000L);
/*     */           }
/*     */           catch (InterruptedException ie)
/*     */           {
/*     */             break;
/*     */           }
/* 570 */           if (p.getState() == 300) break; } while (!this.closeDown);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 579 */       p.removeControllerListener(this);
/*     */       
/* 581 */       return !this.closeDown;
/*     */     }
/*     */     
/*     */     public void waitForStart(Player p, boolean startOn) {
/* 585 */       p.addControllerListener(this);
/* 586 */       if (startOn) {
/* 587 */         p.start();
/*     */       } else
/* 589 */         p.stop();
/* 590 */       synchronized (this.stateLock)
/*     */       {
/*     */         do
/*     */         {
/*     */           try {
/* 595 */             this.stateLock.wait(1000L);
/*     */           }
/*     */           catch (InterruptedException ie)
/*     */           {
/*     */             break;
/*     */           }
/* 592 */           if (((!startOn) || (p.getState() == 600)) && ((startOn) || (p.getState() != 600))) break; } while (!this.closeDown);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 601 */       p.removeControllerListener(this);
/*     */     }
/*     */     
/*     */     public void waitForClose(Player p) {
/* 605 */       p.addControllerListener(this);
/* 606 */       p.close();
/* 607 */       synchronized (this.stateLock) {
/* 608 */         while (!this.closeDown) {
/*     */           try {
/* 610 */             this.stateLock.wait(1000L);
/*     */           } catch (InterruptedException ie) {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/* 616 */       p.removeControllerListener(this);
/*     */     }
/*     */     
/*     */     public void controllerUpdate(ControllerEvent ce) {
/* 620 */       if (((ce instanceof ControllerClosedEvent)) || ((ce instanceof ControllerErrorEvent)))
/*     */       {
/* 622 */         this.closeDown = true;
/*     */       }
/* 624 */       synchronized (this.stateLock) {
/* 625 */         this.stateLock.notify();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\processor\rtsp\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */