/*     */ package com.sun.media.processor.rtp;
/*     */ 
/*     */ import com.sun.media.BasicController;
/*     */ import com.sun.media.BasicPlayer;
/*     */ import com.sun.media.BasicProcessor;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.rtp.RTPMediaLocator;
/*     */ import com.sun.media.rtp.RTPSessionMgr;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Vector;
/*     */ import javax.media.Clock;
/*     */ import javax.media.Controller;
/*     */ import javax.media.ControllerClosedEvent;
/*     */ import javax.media.ControllerErrorEvent;
/*     */ import javax.media.ControllerEvent;
/*     */ import javax.media.ControllerListener;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.Manager;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.NotConfiguredError;
/*     */ import javax.media.Player;
/*     */ import javax.media.Processor;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.control.TrackControl;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.rtp.RTPControl;
/*     */ import javax.media.rtp.RTPManager;
/*     */ import javax.media.rtp.RTPPushDataSource;
/*     */ import javax.media.rtp.RTPSocket;
/*     */ import javax.media.rtp.RTPStream;
/*     */ import javax.media.rtp.ReceiveStream;
/*     */ import javax.media.rtp.ReceiveStreamListener;
/*     */ import javax.media.rtp.SessionAddress;
/*     */ import javax.media.rtp.event.NewReceiveStreamEvent;
/*     */ import javax.media.rtp.event.ReceiveStreamEvent;
/*     */ import javax.media.rtp.event.RemotePayloadChangeEvent;
/*     */ 
/*     */ public class Handler extends BasicProcessor implements ReceiveStreamListener
/*     */ {
/*  46 */   RTPSessionMgr[] mgrs = null;
/*  47 */   javax.media.protocol.DataSource[] sources = null;
/*  48 */   Processor processor = null;
/*  49 */   Format[] formats = null;
/*  50 */   Vector locators = null;
/*     */   
/*  52 */   Object dataLock = new Object();
/*  53 */   boolean dataReady = false;
/*     */   
/*  55 */   private boolean closed = false;
/*  56 */   private boolean audioEnabled = false;
/*  57 */   private boolean videoEnabled = false;
/*     */   
/*  59 */   private static com.sun.media.JMFSecurity jmfSecurity = null;
/*  60 */   private static boolean securityPrivelege = false;
/*  61 */   private Method[] m = new Method[1];
/*  62 */   private Class[] cl = new Class[1];
/*  63 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   public Handler()
/*     */   {
/*  67 */     this.framePositioning = false;
/*     */   }
/*     */   
/*  70 */   String sessionError = "cannot create and initialize the RTP Session.";
/*     */   
/*     */   protected synchronized boolean doConfigure()
/*     */   {
/*  74 */     super.doConfigure();
/*     */     try
/*     */     {
/*  77 */       if ((this.source instanceof RTPSocket))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*  82 */         this.mgrs = new RTPSessionMgr[1];
/*     */         
/*  84 */         this.mgrs[1] = new RTPSessionMgr((RTPSocket)this.source);
/*  85 */         this.mgrs[1].addReceiveStreamListener(this);
/*     */         
/*  87 */         this.sources = new javax.media.protocol.DataSource[1];
/*  88 */         this.sources[0] = this.source;
/*  89 */         this.formats = new Format[1];
/*  90 */         this.dataReady = false;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*  96 */         SessionAddress localAddr = new SessionAddress();
/*     */         
/*     */ 
/*  99 */         this.mgrs = new RTPSessionMgr[this.locators.size()];
/* 100 */         this.sources = new javax.media.protocol.DataSource[this.locators.size()];
/* 101 */         this.formats = new Format[this.locators.size()];
/* 102 */         this.dataReady = false;
/*     */         
/* 104 */         for (int i = 0; i < this.locators.size(); i++) {
/* 105 */           RTPMediaLocator rml = (RTPMediaLocator)this.locators.elementAt(i);
/*     */           
/* 107 */           this.mgrs[i] = ((RTPSessionMgr)RTPManager.newInstance());
/* 108 */           this.mgrs[i].addReceiveStreamListener(this);
/*     */           
/* 110 */           InetAddress ipAddr = InetAddress.getByName(rml.getSessionAddress());
/*     */           SessionAddress destAddr;
/* 112 */           if (ipAddr.isMulticastAddress())
/*     */           {
/* 114 */             localAddr = new SessionAddress(ipAddr, rml.getSessionPort(), rml.getTTL());
/*     */             
/*     */ 
/*     */ 
/* 118 */             destAddr = new SessionAddress(ipAddr, rml.getSessionPort(), rml.getTTL());
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 123 */             localAddr = new SessionAddress(InetAddress.getLocalHost(), rml.getSessionPort());
/*     */             
/*     */ 
/* 126 */             destAddr = new SessionAddress(ipAddr, rml.getSessionPort());
/*     */           }
/*     */           
/*     */ 
/* 130 */           this.mgrs[i].initialize(localAddr);
/* 131 */           this.mgrs[i].addTarget(destAddr);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception rml) {
/* 136 */       Log.error("Cannot create the RTP Session: " + ???.getMessage());
/* 137 */       this.processError = this.sessionError;
/* 138 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 144 */       synchronized (this.dataLock) {
/*     */         do {
/* 146 */           this.dataLock.wait();
/* 145 */           if ((this.dataReady) || (isInterrupted())) break; } while (!this.closed);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/*     */ 
/* 151 */     if ((this.closed) || (isInterrupted())) {
/* 152 */       resetInterrupt();
/* 153 */       this.processError = "no RTP data was received.";
/* 154 */       return false;
/*     */     }
/*     */     
/* 157 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void completeConfigure()
/*     */   {
/* 163 */     this.state = 180;
/* 164 */     super.completeConfigure();
/*     */   }
/*     */   
/*     */   protected void doFailedConfigure()
/*     */   {
/* 169 */     closeSessions();
/* 170 */     super.doFailedConfigure();
/*     */   }
/*     */   
/*     */ 
/* 174 */   Object closeSync = new Object();
/*     */   
/*     */   private void closeSessions() {
/* 177 */     synchronized (this.closeSync) {
/* 178 */       for (int i = 0; i < this.mgrs.length; i++) {
/* 179 */         if (this.mgrs[i] != null) {
/* 180 */           this.mgrs[i].removeTargets("Closing session from the RTP Handler");
/* 181 */           this.mgrs[i].dispose();
/* 182 */           this.mgrs[i] = null;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean doRealize()
/*     */   {
/* 190 */     return waitForRealize(this.processor);
/*     */   }
/*     */   
/*     */   protected void completeRealize()
/*     */   {
/* 195 */     this.state = 300;
/* 196 */     super.completeRealize();
/*     */   }
/*     */   
/*     */   protected void doFailedRealize()
/*     */   {
/* 201 */     closeSessions();
/* 202 */     super.doFailedRealize();
/*     */   }
/*     */   
/*     */   protected void doStart()
/*     */   {
/* 207 */     super.doStart();
/* 208 */     waitForStart(this.processor);
/*     */   }
/*     */   
/*     */   protected void doStop()
/*     */   {
/* 213 */     super.doStop();
/* 214 */     waitForStop(this.processor);
/*     */   }
/*     */   
/*     */   protected void doDeallocate()
/*     */   {
/* 219 */     this.processor.deallocate();
/* 220 */     synchronized (this.dataLock) {
/* 221 */       this.dataLock.notifyAll();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void doClose() {
/* 226 */     this.closed = true;
/*     */     
/* 228 */     synchronized (this.dataLock) {
/* 229 */       this.dataLock.notify();
/*     */     }
/*     */     
/* 232 */     stop();
/*     */     
/* 234 */     if (this.processor != null) {
/* 235 */       this.processor.close();
/*     */     }
/*     */     
/* 238 */     closeSessions();
/*     */     
/* 240 */     super.doClose();
/*     */   }
/*     */   
/*     */   public void setTimeBase(TimeBase tb) throws IncompatibleTimeBaseException
/*     */   {}
/*     */   
/*     */   protected TimeBase getMasterTimeBase() {
/* 247 */     return new javax.media.SystemTimeBase();
/*     */   }
/*     */   
/*     */   protected boolean audioEnabled() {
/* 251 */     return this.audioEnabled;
/*     */   }
/*     */   
/*     */   protected boolean videoEnabled() {
/* 255 */     return this.videoEnabled;
/*     */   }
/*     */   
/*     */   private void sendMyEvent(ControllerEvent e) {
/* 259 */     super.sendEvent(e);
/*     */   }
/*     */   
/*     */   public void update(ReceiveStreamEvent event)
/*     */   {
/* 264 */     RTPSessionMgr mgr = (RTPSessionMgr)event.getSource();
/*     */     
/*     */ 
/* 267 */     for (int idx = 0; idx < this.mgrs.length; idx++) {
/* 268 */       if (this.mgrs[idx] == mgr) {
/*     */         break;
/*     */       }
/*     */     }
/* 272 */     if (idx >= this.mgrs.length)
/*     */     {
/* 274 */       System.err.println("Unknown manager: " + mgr);
/* 275 */       return;
/*     */     }
/*     */     
/* 278 */     if ((event instanceof RemotePayloadChangeEvent))
/*     */     {
/* 280 */       Log.comment("Received an RTP PayloadChangeEvent");
/* 281 */       Log.error("The RTP processor cannot handle mid-stream payload change.\n");
/* 282 */       sendEvent(new ControllerErrorEvent(this, "Cannot handle mid-stream payload change."));
/* 283 */       close();
/*     */     }
/*     */     
/*     */ 
/* 287 */     if ((event instanceof NewReceiveStreamEvent))
/*     */     {
/* 289 */       if (this.sources[idx] != null)
/*     */       {
/* 291 */         return;
/*     */       }
/*     */       
/* 294 */       ReceiveStream stream = null;
/*     */       try
/*     */       {
/* 297 */         stream = ((NewReceiveStreamEvent)event).getReceiveStream();
/* 298 */         this.sources[idx] = stream.getDataSource();
/*     */         
/* 300 */         RTPControl ctl = (RTPControl)this.sources[idx].getControl("javax.media.rtp.RTPControl");
/* 301 */         if (ctl != null) {
/* 302 */           this.formats[idx] = ctl.getFormat();
/* 303 */           if ((this.formats[idx] instanceof AudioFormat))
/* 304 */             this.audioEnabled = true;
/* 305 */           if ((this.formats[idx] instanceof VideoFormat)) {
/* 306 */             this.videoEnabled = true;
/*     */           }
/*     */         }
/* 309 */         if ((this.source instanceof RTPSocket)) {
/* 310 */           ((RTPSocket)this.source).setChild(this.sources[idx]);
/*     */         } else {
/* 312 */           ((com.sun.media.protocol.rtp.DataSource)this.source).setChild((com.sun.media.protocol.rtp.DataSource)this.sources[idx]);
/*     */         }
/*     */         
/* 315 */         for (int i = 0; i < this.sources.length; i++)
/*     */         {
/* 317 */           if (this.sources[i] == null) {
/*     */             return;
/*     */           }
/*     */         }
/*     */         
/*     */         javax.media.protocol.DataSource mixDS;
/*     */         
/*     */         try
/*     */         {
/* 326 */           mixDS = Manager.createMergingDataSource(this.sources);
/*     */         } catch (Exception e) {
/* 328 */           System.err.println("Cannot merge data sources.");
/* 329 */           return;
/*     */         }
/*     */         try
/*     */         {
/* 333 */           this.processor = Manager.createProcessor(mixDS);
/*     */         } catch (Exception e) {
/* 335 */           System.err.println("Cannot create the mix processor.");
/* 336 */           return;
/*     */         }
/*     */         
/* 339 */         if (!waitForConfigure(this.processor)) {
/* 340 */           return;
/*     */         }
/*     */         
/* 343 */         synchronized (this.dataLock) {
/* 344 */           this.dataReady = true;
/* 345 */           this.dataLock.notifyAll();
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 349 */         System.err.println("NewReceiveStreamEvent exception " + e.getMessage());
/*     */         
/* 351 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSource(javax.media.protocol.DataSource source)
/*     */     throws java.io.IOException, IncompatibleSourceException
/*     */   {
/* 361 */     super.setSource(source);
/* 362 */     if ((source instanceof com.sun.media.protocol.rtp.DataSource)) {
/* 363 */       MediaLocator ml = source.getLocator();
/* 364 */       String mlStr = ml.getRemainder();
/*     */       
/*     */ 
/*     */ 
/* 368 */       int start = 0;
/* 369 */       while (mlStr.charAt(start) == '/')
/* 370 */         start++;
/* 371 */       this.locators = new Vector();
/*     */       try {
/*     */         String str;
/*     */         int idx;
/* 375 */         while ((start < mlStr.length()) && ((idx = mlStr.indexOf("&", start)) != -1)) { int i;
/* 376 */           str = mlStr.substring(start, i);
/* 377 */           rml = new RTPMediaLocator("rtp://" + str);
/* 378 */           this.locators.addElement(rml);
/* 379 */           start = i + 1;
/*     */         }
/* 381 */         if (start != 0) {
/* 382 */           str = mlStr.substring(start);
/*     */         } else
/* 384 */           str = mlStr;
/* 385 */         RTPMediaLocator rml = new RTPMediaLocator("rtp://" + str);
/* 386 */         this.locators.addElement(rml);
/*     */       }
/*     */       catch (Exception e) {
/* 389 */         throw new IncompatibleSourceException();
/*     */       }
/*     */     }
/* 392 */     else if (!(source instanceof RTPSocket)) {
/* 393 */       throw new IncompatibleSourceException();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 398 */     RTPControl ctl = (RTPControl)source.getControl("javax.media.rtp.RTPControl");
/*     */     
/* 400 */     if (ctl != null) {
/* 401 */       ctl.addFormat(new AudioFormat("dvi/rtp", 44100.0D, 4, 1), 18);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void invalidateComp()
/*     */   {
/* 409 */     this.controlComp = null;
/* 410 */     this.controls = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public java.awt.Component getVisualComponent()
/*     */   {
/* 422 */     super.getVisualComponent();
/* 423 */     return this.processor.getVisualComponent();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public javax.media.Control[] getControls()
/*     */   {
/* 432 */     return this.processor.getControls();
/*     */   }
/*     */   
/*     */   public void updateStats() {
/* 436 */     if (this.processor != null) {
/* 437 */       ((BasicProcessor)this.processor).updateStats();
/*     */     }
/*     */   }
/*     */   
/*     */   public TrackControl[] getTrackControls() throws NotConfiguredError {
/* 442 */     super.getTrackControls();
/* 443 */     return this.processor.getTrackControls();
/*     */   }
/*     */   
/*     */   public ContentDescriptor[] getSupportedContentDescriptors() throws NotConfiguredError
/*     */   {
/* 448 */     super.getSupportedContentDescriptors();
/* 449 */     return this.processor.getSupportedContentDescriptors();
/*     */   }
/*     */   
/*     */   public ContentDescriptor setContentDescriptor(ContentDescriptor ocd) throws NotConfiguredError
/*     */   {
/* 454 */     super.setContentDescriptor(ocd);
/* 455 */     return this.processor.setContentDescriptor(ocd);
/*     */   }
/*     */   
/*     */   public ContentDescriptor getContentDescriptor() throws NotConfiguredError
/*     */   {
/* 460 */     super.getContentDescriptor();
/* 461 */     return this.processor.getContentDescriptor();
/*     */   }
/*     */   
/*     */   public javax.media.protocol.DataSource getDataOutput() throws javax.media.NotRealizedError {
/* 465 */     super.getDataOutput();
/* 466 */     return this.processor.getDataOutput();
/*     */   }
/*     */   
/*     */   private boolean waitForConfigure(Processor p) {
/* 470 */     return new StateWaiter().waitForConfigure(p);
/*     */   }
/*     */   
/*     */   private boolean waitForRealize(Processor p) {
/* 474 */     return new StateWaiter().waitForRealize(p);
/*     */   }
/*     */   
/*     */   private void waitForStart(Player p) {
/* 478 */     new StateWaiter().waitForStart(p, true);
/*     */   }
/*     */   
/*     */   private void waitForStop(Player p) {
/* 482 */     new StateWaiter().waitForStart(p, false);
/*     */   }
/*     */   
/*     */ 
/* 486 */   private void waitForClose(Player p) { new StateWaiter().waitForClose(p); }
/*     */   
/*     */   class StateWaiter implements ControllerListener { StateWaiter() {}
/*     */     
/* 490 */     boolean closeDown = false;
/* 491 */     Object stateLock = new Object();
/*     */     
/*     */     public boolean waitForConfigure(Processor p) {
/* 494 */       p.addControllerListener(this);
/* 495 */       p.configure();
/* 496 */       synchronized (this.stateLock) {
/*     */         do {
/*     */           try {
/* 499 */             this.stateLock.wait(1000L);
/*     */           }
/*     */           catch (InterruptedException ie)
/*     */           {
/*     */             break;
/*     */           }
/* 497 */           if (p.getState() == 180) break; } while (!this.closeDown);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 505 */       p.removeControllerListener(this);
/* 506 */       return !this.closeDown;
/*     */     }
/*     */     
/*     */     public boolean waitForRealize(Processor p) {
/* 510 */       p.addControllerListener(this);
/* 511 */       p.realize();
/* 512 */       synchronized (this.stateLock) {
/*     */         do {
/*     */           try {
/* 515 */             this.stateLock.wait(1000L);
/*     */           }
/*     */           catch (InterruptedException ie)
/*     */           {
/*     */             break;
/*     */           }
/* 513 */           if (p.getState() == 300) break; } while (!this.closeDown);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 521 */       p.removeControllerListener(this);
/* 522 */       return !this.closeDown;
/*     */     }
/*     */     
/*     */     public void waitForStart(Player p, boolean startOn) {
/* 526 */       p.addControllerListener(this);
/* 527 */       if (startOn) {
/* 528 */         p.start();
/*     */       } else
/* 530 */         p.stop();
/* 531 */       synchronized (this.stateLock)
/*     */       {
/*     */         do
/*     */         {
/*     */           try {
/* 536 */             this.stateLock.wait(1000L);
/*     */           }
/*     */           catch (InterruptedException ie)
/*     */           {
/*     */             break;
/*     */           }
/* 533 */           if (((!startOn) || (p.getState() == 600)) && ((startOn) || (p.getState() != 600))) break; } while (!this.closeDown);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 542 */       p.removeControllerListener(this);
/*     */     }
/*     */     
/*     */     public void waitForClose(Player p) {
/* 546 */       p.addControllerListener(this);
/* 547 */       p.close();
/* 548 */       synchronized (this.stateLock) {
/* 549 */         while (!this.closeDown) {
/*     */           try {
/* 551 */             this.stateLock.wait(1000L);
/*     */           } catch (InterruptedException ie) {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/* 557 */       p.removeControllerListener(this);
/*     */     }
/*     */     
/*     */     public void controllerUpdate(ControllerEvent ce) {
/* 561 */       if (((ce instanceof ControllerClosedEvent)) || ((ce instanceof ControllerErrorEvent)))
/*     */       {
/* 563 */         this.closeDown = true;
/*     */       }
/* 565 */       synchronized (this.stateLock) {
/* 566 */         this.stateLock.notify();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\processor\rtp\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */