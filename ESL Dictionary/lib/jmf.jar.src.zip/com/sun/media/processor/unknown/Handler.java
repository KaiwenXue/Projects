package com.sun.media.processor.unknown;

import com.sun.media.MediaProcessor;

public class Handler
  extends MediaProcessor
{}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\processor\unknown\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */