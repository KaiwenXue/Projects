/*     */ package com.sun.media;
/*     */ 
/*     */ import javax.media.NotConfiguredError;
/*     */ import javax.media.NotRealizedError;
/*     */ import javax.media.Processor;
/*     */ import javax.media.control.TrackControl;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.DataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BasicProcessor
/*     */   extends BasicPlayer
/*     */   implements Processor
/*     */ {
/*  22 */   static String NOT_CONFIGURED_ERROR = "cannot be called before the Processor is configured";
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isConfigurable()
/*     */   {
/*  28 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TrackControl[] getTrackControls()
/*     */     throws NotConfiguredError
/*     */   {
/*  44 */     if (getState() < 180)
/*  45 */       throw new NotConfiguredError("getTrackControls " + NOT_CONFIGURED_ERROR);
/*  46 */     return new TrackControl[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentDescriptor[] getSupportedContentDescriptors()
/*     */     throws NotConfiguredError
/*     */   {
/*  61 */     if (getState() < 180)
/*  62 */       throw new NotConfiguredError("getSupportedContentDescriptors " + NOT_CONFIGURED_ERROR);
/*  63 */     return new ContentDescriptor[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentDescriptor setContentDescriptor(ContentDescriptor ocd)
/*     */     throws NotConfiguredError
/*     */   {
/*  79 */     if (getState() < 180)
/*  80 */       throw new NotConfiguredError("setContentDescriptor " + NOT_CONFIGURED_ERROR);
/*  81 */     return ocd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentDescriptor getContentDescriptor()
/*     */     throws NotConfiguredError
/*     */   {
/*  92 */     if (getState() < 180)
/*  93 */       throw new NotConfiguredError("getContentDescriptor " + NOT_CONFIGURED_ERROR);
/*  94 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataSource getDataOutput()
/*     */     throws NotRealizedError
/*     */   {
/* 106 */     if (getState() < 300)
/* 107 */       throw new NotRealizedError("getDataOutput cannot be called before the Processor is realized");
/* 108 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\BasicProcessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */