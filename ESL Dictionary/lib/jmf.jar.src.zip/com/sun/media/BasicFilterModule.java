/*     */ package com.sun.media;
/*     */ 
/*     */ import java.awt.Frame;
/*     */ import java.awt.Window;
/*     */ import java.io.PrintStream;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Codec;
/*     */ import javax.media.Controls;
/*     */ import javax.media.Format;
/*     */ import javax.media.PlugIn;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.control.FrameProcessingControl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicFilterModule
/*     */   extends BasicModule
/*     */ {
/*     */   protected Codec codec;
/*     */   protected InputConnector ic;
/*     */   protected OutputConnector oc;
/*  27 */   protected FrameProcessingControl frameControl = null;
/*  28 */   protected float curFramesBehind = 0.0F;
/*  29 */   protected float prevFramesBehind = 0.0F;
/*     */   
/*     */   protected Frame controlFrame;
/*  32 */   protected final boolean VERBOSE_CONTROL = false;
/*     */   protected Buffer storedInputBuffer;
/*     */   
/*  35 */   public BasicFilterModule(Codec c) { this.ic = new BasicInputConnector();
/*  36 */     registerInputConnector("input", this.ic);
/*  37 */     this.oc = new BasicOutputConnector();
/*  38 */     registerOutputConnector("output", this.oc);
/*  39 */     setCodec(c);
/*  40 */     this.protocol = 0;
/*  41 */     Object control = c.getControl("javax.media.control.FrameProcessingControl");
/*  42 */     if ((control instanceof FrameProcessingControl))
/*  43 */       this.frameControl = ((FrameProcessingControl)control);
/*     */   }
/*     */   
/*     */   public boolean doRealize() {
/*  47 */     if (this.codec != null) {
/*     */       try {
/*  49 */         this.codec.open();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (ResourceUnavailableException rue)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */         return false;
/*     */       }
/*     */     }
/*     */     
/*  70 */     return true;
/*     */   }
/*     */   
/*     */   public boolean doPrefetch() {
/*  74 */     return super.doPrefetch();
/*     */   }
/*     */   
/*     */   public void doClose() {
/*  78 */     if (this.codec != null) {
/*  79 */       this.codec.close();
/*     */     }
/*  81 */     if (this.controlFrame != null) {
/*  82 */       this.controlFrame.dispose();
/*  83 */       this.controlFrame = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormat(Connector c, Format f)
/*     */   {
/*  92 */     if (c == this.ic)
/*     */     {
/*  94 */       if (this.codec != null)
/*  95 */         this.codec.setInputFormat(f);
/*  96 */     } else if ((c == this.oc) && 
/*  97 */       (this.codec != null)) {
/*  98 */       this.codec.setOutputFormat(f);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setCodec(String codec)
/*     */   {
/* 108 */     return true;
/*     */   }
/*     */   
/*     */   public boolean setCodec(Codec codec) {
/* 112 */     this.codec = codec;
/* 113 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Codec getCodec()
/*     */   {
/* 121 */     return this.codec;
/*     */   }
/*     */   
/*     */   public boolean isThreaded() {
/* 125 */     if (getProtocol() == 1)
/* 126 */       return true;
/* 127 */     return false;
/*     */   }
/*     */   
/*     */   public Object[] getControls()
/*     */   {
/* 132 */     return this.codec.getControls();
/*     */   }
/*     */   
/*     */   public Object getControl(String s) {
/* 136 */     return this.codec.getControl(s);
/*     */   }
/*     */   
/*     */   protected void setFramesBehind(float framesBehind) {
/* 140 */     this.curFramesBehind = framesBehind;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Buffer storedOutputBuffer;
/*     */   
/*     */ 
/*     */   protected boolean reinitCodec(Format input)
/*     */   {
/* 150 */     if (this.codec != null) {
/* 151 */       if (this.codec.setInputFormat(input) != null)
/*     */       {
/* 153 */         return true;
/*     */       }
/*     */       
/* 156 */       this.codec.close();
/* 157 */       this.codec = null;
/*     */     }
/*     */     
/*     */     Codec c;
/*     */     
/* 162 */     if ((c = SimpleGraphBuilder.findCodec(input, null, null, null)) == null) {
/* 163 */       return false;
/*     */     }
/* 165 */     setCodec(c);
/* 166 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 171 */   protected boolean readPendingFlag = false;
/* 172 */   protected boolean writePendingFlag = false;
/* 173 */   private boolean failed = false;
/* 174 */   private boolean markerSet = false;
/*     */   
/* 176 */   private Object lastHdr = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public void process()
/*     */   {
/*     */     do
/*     */     {
/*     */       Buffer inputBuffer;
/*     */       
/* 186 */       if (this.readPendingFlag) {
/* 187 */         inputBuffer = this.storedInputBuffer;
/*     */       }
/*     */       else {
/* 190 */         inputBuffer = this.ic.getValidBuffer();
/* 191 */         Format incomingFormat = inputBuffer.getFormat();
/*     */         
/* 193 */         if (incomingFormat == null)
/*     */         {
/*     */ 
/* 196 */           incomingFormat = this.ic.getFormat();
/* 197 */           inputBuffer.setFormat(incomingFormat);
/*     */         }
/*     */         
/* 200 */         if ((incomingFormat != this.ic.getFormat()) && (incomingFormat != null) && (!incomingFormat.equals(this.ic.getFormat())) && (!inputBuffer.isDiscard()))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 206 */           if (this.writePendingFlag)
/*     */           {
/* 208 */             this.storedOutputBuffer.setDiscard(true);
/* 209 */             this.oc.writeReport();
/* 210 */             this.writePendingFlag = false;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 215 */           if (!reinitCodec(inputBuffer.getFormat()))
/*     */           {
/* 217 */             inputBuffer.setDiscard(true);
/* 218 */             this.ic.readReport();
/* 219 */             this.failed = true;
/*     */             
/* 221 */             if (this.moduleListener != null) {
/* 222 */               this.moduleListener.formatChangedFailure(this, this.ic.getFormat(), inputBuffer.getFormat());
/*     */             }
/* 224 */             return;
/*     */           }
/*     */           
/* 227 */           Format oldFormat = this.ic.getFormat();
/* 228 */           this.ic.setFormat(inputBuffer.getFormat());
/* 229 */           if (this.moduleListener != null) {
/* 230 */             this.moduleListener.formatChanged(this, oldFormat, inputBuffer.getFormat());
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 240 */         if ((inputBuffer.getFlags() & 0x400) != 0) {
/* 241 */           this.markerSet = true;
/*     */         }
/*     */         
/* 244 */         if ((PlaybackEngine.DEBUG) && (inputBuffer != null))
/* 245 */           this.jmd.moduleIn(this, 0, inputBuffer, true);
/*     */       }
/*     */       Buffer outputBuffer;
/* 248 */       if (this.writePendingFlag) {
/* 249 */         outputBuffer = this.storedOutputBuffer;
/*     */       } else {
/* 251 */         outputBuffer = this.oc.getEmptyBuffer();
/* 252 */         if (outputBuffer != null) {
/* 253 */           if (PlaybackEngine.DEBUG)
/* 254 */             this.jmd.moduleOut(this, 0, outputBuffer, true);
/* 255 */           outputBuffer.setLength(0);
/* 256 */           outputBuffer.setOffset(0);
/* 257 */           this.lastHdr = outputBuffer.getHeader();
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 262 */       outputBuffer.setTimeStamp(inputBuffer.getTimeStamp());
/* 263 */       outputBuffer.setDuration(inputBuffer.getDuration());
/* 264 */       outputBuffer.setSequenceNumber(inputBuffer.getSequenceNumber());
/* 265 */       outputBuffer.setFlags(inputBuffer.getFlags());
/* 266 */       outputBuffer.setHeader(inputBuffer.getHeader());
/*     */       
/*     */ 
/* 269 */       if (this.resetted)
/*     */       {
/*     */ 
/*     */ 
/* 273 */         if ((inputBuffer.getFlags() & 0x200) != 0) {
/* 274 */           this.codec.reset();
/* 275 */           this.resetted = false;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 280 */         this.readPendingFlag = (this.writePendingFlag = 0);
/* 281 */         this.ic.readReport();
/* 282 */         this.oc.writeReport();
/* 283 */         return;
/*     */       }
/*     */       
/* 286 */       if ((this.failed) || (inputBuffer.isDiscard()))
/*     */       {
/*     */ 
/* 289 */         if (this.markerSet) {
/* 290 */           outputBuffer.setFlags(outputBuffer.getFlags() & 0xFBFF);
/*     */           
/* 292 */           this.markerSet = false;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 299 */         this.curFramesBehind = 0.0F;
/*     */         
/* 301 */         this.ic.readReport();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 306 */         if (!this.writePendingFlag) {
/* 307 */           this.oc.writeReport();
/*     */         }
/* 309 */         return;
/*     */       }
/*     */       
/* 312 */       if ((this.frameControl != null) && (this.curFramesBehind != this.prevFramesBehind) && ((inputBuffer.getFlags() & 0x20) == 0))
/*     */       {
/* 314 */         this.frameControl.setFramesBehind(this.curFramesBehind);
/* 315 */         this.prevFramesBehind = this.curFramesBehind;
/*     */       }
/*     */       
/* 318 */       int rc = 0;
/*     */       
/*     */       try
/*     */       {
/* 322 */         rc = this.codec.process(inputBuffer, outputBuffer);
/*     */       }
/*     */       catch (Throwable e) {
/* 325 */         Log.dumpStack(e);
/* 326 */         if (this.moduleListener != null) {
/* 327 */           this.moduleListener.internalErrorOccurred(this);
/*     */         }
/*     */       }
/* 330 */       if ((PlaybackEngine.TRACE_ON) && (!verifyBuffer(outputBuffer))) {
/* 331 */         System.err.println("verify buffer failed: " + this.codec);
/* 332 */         Thread.dumpStack();
/* 333 */         if (this.moduleListener != null) {
/* 334 */           this.moduleListener.internalErrorOccurred(this);
/*     */         }
/*     */       }
/* 337 */       if ((rc & 0x8) != 0) {
/* 338 */         this.failed = true;
/* 339 */         if (this.moduleListener != null)
/* 340 */           this.moduleListener.pluginTerminated(this);
/* 341 */         this.readPendingFlag = (this.writePendingFlag = 0);
/* 342 */         this.ic.readReport();
/* 343 */         this.oc.writeReport();
/* 344 */         return;
/*     */       }
/*     */       
/* 347 */       if ((this.curFramesBehind > 0.0F) && (outputBuffer.isDiscard()))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 356 */         this.curFramesBehind -= 1.0F;
/* 357 */         if (this.curFramesBehind < 0.0F) {
/* 358 */           this.curFramesBehind = 0.0F;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 365 */         rc &= (0x4 ^ 0xFFFFFFFF);
/*     */       }
/*     */       
/* 368 */       if ((rc & 0x1) != 0) {
/* 369 */         outputBuffer.setDiscard(true);
/*     */         
/* 371 */         if (this.markerSet) {
/* 372 */           outputBuffer.setFlags(outputBuffer.getFlags() & 0xFBFF);
/*     */           
/* 374 */           this.markerSet = false;
/*     */         }
/* 376 */         if (PlaybackEngine.DEBUG) this.jmd.moduleIn(this, 0, inputBuffer, false);
/* 377 */         this.ic.readReport();
/* 378 */         if (PlaybackEngine.DEBUG) this.jmd.moduleOut(this, 0, outputBuffer, false);
/* 379 */         this.oc.writeReport();
/* 380 */         this.readPendingFlag = (this.writePendingFlag = 0);
/* 381 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 386 */       if ((outputBuffer.isEOM()) && (((rc & 0x2) != 0) || ((rc & 0x4) != 0)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 391 */         outputBuffer.setEOM(false);
/*     */       }
/*     */       
/* 394 */       if ((rc & 0x4) != 0) {
/* 395 */         this.writePendingFlag = true;
/* 396 */         this.storedOutputBuffer = outputBuffer;
/*     */       } else {
/* 398 */         if (PlaybackEngine.DEBUG) this.jmd.moduleOut(this, 0, outputBuffer, false);
/* 399 */         if (this.markerSet) {
/* 400 */           outputBuffer.setFlags(outputBuffer.getFlags() | 0x400);
/*     */           
/* 402 */           this.markerSet = false;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 408 */         this.oc.writeReport();
/* 409 */         this.writePendingFlag = false;
/*     */       }
/*     */       
/*     */ 
/* 413 */       if (((rc & 0x2) != 0) || ((inputBuffer.isEOM()) && (!outputBuffer.isEOM())))
/*     */       {
/* 415 */         this.readPendingFlag = true;
/* 416 */         this.storedInputBuffer = inputBuffer;
/*     */       } else {
/* 418 */         if (PlaybackEngine.DEBUG) this.jmd.moduleIn(this, 0, inputBuffer, false);
/* 419 */         inputBuffer.setHeader(this.lastHdr);
/* 420 */         this.ic.readReport();
/* 421 */         this.readPendingFlag = false;
/*     */       }
/*     */       
/* 424 */     } while (this.readPendingFlag);
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\BasicFilterModule.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */