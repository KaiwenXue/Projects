/*     */ package com.sun.media.vfw;
/*     */ 
/*     */ import com.sun.media.format.AviVideoFormat;
/*     */ import java.awt.Dimension;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.RGBFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.format.YUVFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitMapInfo
/*     */ {
/*  16 */   public int biWidth = 0;
/*  17 */   public int biHeight = 0;
/*  18 */   public int biPlanes = 1;
/*  19 */   public int biBitCount = 24;
/*     */   
/*  21 */   public String fourcc = "";
/*  22 */   public int biSizeImage = 0;
/*  23 */   public int biXPelsPerMeter = 0;
/*  24 */   public int biYPelsPerMeter = 0;
/*  25 */   public int biClrUsed = 0;
/*  26 */   public int biClrImportant = 0;
/*  27 */   public int extraSize = 0;
/*  28 */   public byte[] extraBytes = null;
/*     */   
/*     */ 
/*     */   public BitMapInfo() {}
/*     */   
/*     */   public BitMapInfo(String fourcc, int width, int height)
/*     */   {
/*  35 */     this.biWidth = width;
/*  36 */     this.biHeight = height;
/*  37 */     this.fourcc = fourcc;
/*  38 */     if (fourcc.equals("RGB"))
/*  39 */       this.biSizeImage = (width * height * 3);
/*  40 */     if (fourcc.equals("MSVC")) {
/*  41 */       this.fourcc = "CRAM";
/*     */     }
/*     */   }
/*     */   
/*     */   public BitMapInfo(String fourcc, int width, int height, int planes, int bitcount, int sizeImage, int clrused, int clrimportant)
/*     */   {
/*  47 */     this(fourcc, width, height);
/*     */     
/*  49 */     this.biPlanes = planes;
/*  50 */     this.biBitCount = bitcount;
/*  51 */     this.biSizeImage = sizeImage;
/*  52 */     this.biClrUsed = clrused;
/*  53 */     this.biClrImportant = clrimportant;
/*     */   }
/*     */   
/*     */   public BitMapInfo(VideoFormat format) {
/*  57 */     Dimension size = format.getSize();
/*  58 */     if (size == null)
/*  59 */       size = new Dimension(320, 240);
/*  60 */     Class arrayType = format.getDataType();
/*  61 */     int elSize = arrayType == Format.intArray ? 4 : arrayType == Format.byteArray ? 1 : 2;
/*     */     
/*     */ 
/*  64 */     this.biWidth = size.width;
/*  65 */     this.biHeight = size.height;
/*  66 */     this.biPlanes = 1;
/*  67 */     this.biSizeImage = (format.getMaxDataLength() * elSize);
/*  68 */     this.fourcc = format.getEncoding();
/*  69 */     if (this.fourcc.equalsIgnoreCase("msvc")) {
/*  70 */       this.fourcc = "CRAM";
/*     */     }
/*  72 */     if ((format instanceof AviVideoFormat)) {
/*  73 */       AviVideoFormat avif = (AviVideoFormat)format;
/*  74 */       this.biPlanes = avif.getPlanes();
/*  75 */       this.biBitCount = avif.getBitsPerPixel();
/*  76 */       this.biXPelsPerMeter = avif.getXPelsPerMeter();
/*  77 */       this.biYPelsPerMeter = avif.getYPelsPerMeter();
/*  78 */       this.biClrUsed = avif.getClrUsed();
/*  79 */       this.biClrImportant = avif.getClrImportant();
/*  80 */       this.extraBytes = avif.getCodecSpecificHeader();
/*  81 */       if (this.extraBytes != null)
/*  82 */         this.extraSize = this.extraBytes.length;
/*  83 */     } else if ((format instanceof RGBFormat)) {
/*  84 */       RGBFormat rgb = (RGBFormat)format;
/*  85 */       this.fourcc = "RGB";
/*  86 */       this.biBitCount = rgb.getBitsPerPixel();
/*  87 */       if (rgb.getFlipped() == 0)
/*  88 */         this.biHeight = (-this.biHeight);
/*  89 */     } else if ((format instanceof YUVFormat)) {
/*  90 */       YUVFormat yuv = (YUVFormat)format;
/*  91 */       switch (yuv.getYuvType()) {
/*     */       case 2: 
/*  93 */         if (yuv.getOffsetU() < yuv.getOffsetV()) {
/*  94 */           this.fourcc = "I420";
/*     */         } else
/*  96 */           this.fourcc = "YV12";
/*     */       case 32: 
/*  98 */         if ((yuv.getOffsetY() == 0) && (yuv.getOffsetU() == 1)) {
/*  99 */           this.fourcc = "YUY2";
/* 100 */         } else if ((yuv.getOffsetY() == 0) && (yuv.getOffsetU() == 3)) {
/* 101 */           this.fourcc = "YVYU";
/* 102 */         } else if (yuv.getOffsetU() == 0)
/* 103 */           this.fourcc = "UYVY";
/*     */         break; }
/* 105 */       if ((this.fourcc.equalsIgnoreCase("yv12")) || (this.fourcc.equalsIgnoreCase("i420")) || (this.fourcc.equalsIgnoreCase("y411")))
/*     */       {
/*     */ 
/* 108 */         this.biBitCount = 12;
/* 109 */       } else if (this.fourcc.equalsIgnoreCase("yuy2")) {
/* 110 */         this.biBitCount = 16;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public VideoFormat createVideoFormat(Class arrayType) {
/* 116 */     return createVideoFormat(arrayType, -1.0F);
/*     */   }
/*     */   
/*     */   public VideoFormat createVideoFormat(Class arrayType, float frameRate) {
/*     */     VideoFormat format;
/* 121 */     if (this.fourcc.equalsIgnoreCase("rgb"))
/*     */     {
/* 123 */       int elSize = arrayType == Format.intArray ? 4 : arrayType == Format.byteArray ? 1 : 2;
/*     */       
/*     */ 
/* 126 */       int maxDataLength = this.biSizeImage / elSize;
/* 127 */       int rm = -1;int gm = -1;int bm = -1;
/* 128 */       if (this.biBitCount == 16) {
/* 129 */         rm = 31744;gm = 992;bm = 31;
/* 130 */       } else if (this.biBitCount == 32) {
/* 131 */         if (elSize == 4) {
/* 132 */           rm = 16711680;gm = 65280;bm = 255;
/*     */         } else {
/* 134 */           rm = 3;gm = 2;bm = 1;
/* 135 */         } } else if (this.biBitCount == 24) {
/* 136 */         rm = 3;gm = 2;bm = 1;
/*     */       }
/* 138 */       int bytesPerLine = this.biWidth * this.biBitCount / 8;
/* 139 */       int lineStride = bytesPerLine / elSize;
/* 140 */       int pixelStride = lineStride / this.biWidth;
/* 141 */       int actualHeight = this.biHeight;
/* 142 */       int flipped = 1;
/*     */       
/* 144 */       if (this.biHeight < 0) {
/* 145 */         actualHeight = -actualHeight;
/* 146 */         flipped = 0;
/*     */       }
/*     */       
/* 149 */       format = new RGBFormat(new Dimension(this.biWidth, actualHeight), maxDataLength, arrayType, frameRate, this.biBitCount, rm, gm, bm, pixelStride, lineStride, flipped, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 169 */     else if (this.fourcc.equalsIgnoreCase("yuy2")) {
/* 170 */       int ySize = this.biWidth * this.biHeight;
/*     */       
/* 172 */       format = new YUVFormat(new Dimension(this.biWidth, this.biHeight), this.biSizeImage, new byte[0].getClass(), frameRate, 32, this.biWidth * 2, this.biWidth * 2, 0, 1, 3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 180 */     else if (this.fourcc.equalsIgnoreCase("i420")) {
/* 181 */       int ySize = this.biWidth * this.biHeight;
/*     */       
/* 183 */       format = new YUVFormat(new Dimension(this.biWidth, this.biHeight), this.biSizeImage, new byte[0].getClass(), frameRate, 2, this.biWidth, this.biWidth / 2, 0, ySize, ySize + ySize / 4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 190 */     else if (this.fourcc.equalsIgnoreCase("yv12")) {
/* 191 */       int ySize = this.biWidth * this.biHeight;
/*     */       
/* 193 */       format = new YUVFormat(new Dimension(this.biWidth, this.biHeight), this.biSizeImage, new byte[0].getClass(), frameRate, 2, this.biWidth, this.biWidth / 2, 0, ySize + ySize / 4, ySize);
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/* 202 */       format = new AviVideoFormat(this.fourcc, new Dimension(this.biWidth, this.biHeight), this.biSizeImage, arrayType, frameRate, this.biPlanes, this.biBitCount, this.biSizeImage, this.biXPelsPerMeter, this.biYPelsPerMeter, this.biClrUsed, this.biClrImportant, this.extraBytes);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 214 */     return format;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 218 */     String s = "Size = " + this.biWidth + " x " + this.biHeight + "\t" + "Planes = " + this.biPlanes + "\t" + "BitCount = " + this.biBitCount + "\t" + "FourCC = " + this.fourcc + "\t" + "SizeImage = " + this.biSizeImage + "\n" + "ClrUsed = " + this.biClrUsed + "\n" + "ClrImportant = " + this.biClrImportant + "\n" + "ExtraSize = " + this.extraSize + "\n";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 226 */     if (this.extraSize > 0) {
/* 227 */       for (int i = 0; i < this.extraSize; i++)
/* 228 */         s = s + "\t" + i + " = " + this.extraBytes[i] + "\n";
/*     */     }
/* 230 */     return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\vfw\BitMapInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */