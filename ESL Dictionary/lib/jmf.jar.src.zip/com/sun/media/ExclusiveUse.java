package com.sun.media;

public abstract interface ExclusiveUse
{
  public abstract boolean isExclusive();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\ExclusiveUse.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */