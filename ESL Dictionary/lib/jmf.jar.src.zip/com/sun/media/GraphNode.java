/*     */ package com.sun.media;
/*     */ 
/*     */ import javax.media.Codec;
/*     */ import javax.media.Format;
/*     */ import javax.media.Multiplexer;
/*     */ import javax.media.PlugIn;
/*     */ import javax.media.Renderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GraphNode
/*     */ {
/*     */   Class clz;
/*     */   String cname;
/*     */   PlugIn plugin;
/*  26 */   int type = -1;
/*  27 */   Format input; Format output = null;
/*     */   Format[] supportedIns;
/*     */   Format[] supportedOuts;
/*     */   GraphNode prev;
/*  31 */   int level; boolean failed = false;
/*  32 */   boolean custom = false;
/*     */   
/*  34 */   static int ARRAY_INC = 30;
/*     */   
/*     */   GraphNode(PlugIn plugin, Format input, GraphNode prev, int level) {
/*  37 */     this(plugin == null ? null : plugin.getClass().getName(), plugin, input, prev, level);
/*     */   }
/*     */   
/*     */   GraphNode(String cname, PlugIn plugin, Format input, GraphNode prev, int level)
/*     */   {
/*  42 */     this.cname = cname;
/*  43 */     this.plugin = plugin;
/*  44 */     this.input = input;
/*  45 */     this.prev = prev;
/*  46 */     this.level = level;
/*     */   }
/*     */   
/*     */   GraphNode(GraphNode gn, Format input, GraphNode prev, int level) {
/*  50 */     this.cname = gn.cname;
/*  51 */     this.plugin = gn.plugin;
/*  52 */     this.type = gn.type;
/*  53 */     this.custom = gn.custom;
/*  54 */     this.input = input;
/*  55 */     this.prev = prev;
/*  56 */     this.level = level;
/*  57 */     this.supportedIns = gn.supportedIns;
/*  58 */     if (gn.input == input)
/*  59 */       this.supportedOuts = gn.supportedOuts;
/*     */   }
/*     */   
/*     */   Format[] getSupportedInputs() {
/*  63 */     if (this.supportedIns != null)
/*  64 */       return this.supportedIns;
/*  65 */     if (this.plugin == null)
/*  66 */       return null;
/*  67 */     if (((this.type == -1) || (this.type == 2)) && ((this.plugin instanceof Codec)))
/*     */     {
/*  69 */       this.supportedIns = ((Codec)this.plugin).getSupportedInputFormats();
/*  70 */     } else if (((this.type == -1) || (this.type == 4)) && ((this.plugin instanceof Renderer)))
/*     */     {
/*  72 */       this.supportedIns = ((Renderer)this.plugin).getSupportedInputFormats();
/*  73 */     } else if ((this.plugin instanceof Multiplexer))
/*  74 */       this.supportedIns = ((Multiplexer)this.plugin).getSupportedInputFormats();
/*  75 */     return this.supportedIns;
/*     */   }
/*     */   
/*     */   Format[] getSupportedOutputs(Format in) {
/*  79 */     if ((in == this.input) && (this.supportedOuts != null))
/*  80 */       return this.supportedOuts;
/*  81 */     if (this.plugin == null)
/*  82 */       return null;
/*  83 */     if (((this.type == -1) || (this.type == 4)) && ((this.plugin instanceof Renderer)))
/*     */     {
/*  85 */       return null; }
/*  86 */     if (((this.type == -1) || (this.type == 2)) && ((this.plugin instanceof Codec)))
/*     */     {
/*     */ 
/*  89 */       Format[] outs = ((Codec)this.plugin).getSupportedOutputFormats(in);
/*  90 */       if (this.input == in)
/*  91 */         this.supportedOuts = outs;
/*  92 */       return outs;
/*     */     }
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   public void resetAttempted() {
/*  98 */     this.attemptedIdx = 0;
/*  99 */     this.attempted = null;
/*     */   }
/*     */   
/* 102 */   int attemptedIdx = 0;
/* 103 */   Format[] attempted = null;
/*     */   
/*     */   boolean checkAttempted(Format input)
/*     */   {
/* 107 */     if (this.attempted == null) {
/* 108 */       this.attempted = new Format[ARRAY_INC];
/* 109 */       this.attempted[(this.attemptedIdx++)] = input;
/* 110 */       return false;
/*     */     }
/*     */     
/* 113 */     for (int j = 0; j < this.attemptedIdx; j++) {
/* 114 */       if (input.equals(this.attempted[j])) {
/* 115 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 119 */     if (this.attemptedIdx >= this.attempted.length)
/*     */     {
/* 121 */       Format[] newarray = new Format[this.attempted.length + ARRAY_INC];
/* 122 */       System.arraycopy(this.attempted, 0, newarray, 0, this.attempted.length);
/* 123 */       this.attempted = newarray;
/*     */     }
/* 125 */     this.attempted[(this.attemptedIdx++)] = input;
/* 126 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\GraphNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */