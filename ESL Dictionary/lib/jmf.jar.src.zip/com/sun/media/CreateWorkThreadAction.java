/*    */ package com.sun.media;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreateWorkThreadAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   private Class objclass;
/*    */   Class baseClass;
/*    */   Object arg;
/*    */   static Constructor cons;
/*    */   
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 30 */       cons = class$com$sun$media$CreateWorkThreadAction.getConstructor(new Class[] { Class.class, Class.class, Object.class });
/*    */     }
/*    */     catch (Throwable e) {}
/*    */   }
/*    */   
/*    */   public CreateWorkThreadAction(Class objclass, Class baseClass, Object arg)
/*    */   {
/*    */     try {
/* 38 */       this.objclass = objclass;
/* 39 */       this.baseClass = baseClass;
/* 40 */       this.arg = arg;
/*    */     }
/*    */     catch (Throwable e) {}
/*    */   }
/*    */   
/*    */   public Object run()
/*    */   {
/*    */     try {
/* 48 */       Constructor cons = this.objclass.getConstructor(new Class[] { this.baseClass });
/* 49 */       return cons.newInstance(new Object[] { this.arg });
/*    */     }
/*    */     catch (Throwable e) {}
/* 52 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\CreateWorkThreadAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */