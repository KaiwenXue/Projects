/*     */ package com.sun.media.content.audio.midi;
/*     */ 
/*     */ import com.sun.media.BasicController;
/*     */ import com.sun.media.BasicPlayer;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.controls.GainControlAdapter;
/*     */ import java.io.IOException;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Control;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.sound.midi.MidiChannel;
/*     */ import javax.sound.midi.MidiDevice;
/*     */ import javax.sound.midi.MidiUnavailableException;
/*     */ import javax.sound.midi.Sequencer;
/*     */ import javax.sound.midi.Synthesizer;
/*     */ 
/*     */ public class Handler extends BasicPlayer
/*     */ {
/*     */   private MidiController controller;
/*  23 */   protected DataSource datasource = null;
/*  24 */   private boolean closed = false;
/*  25 */   private int META_EVENT_END_OF_MEDIA = 47;
/*  26 */   private Control[] controls = null;
/*     */   
/*     */   public Handler() {
/*  29 */     this.controller = new MidiController();
/*  30 */     manageController(this.controller);
/*     */   }
/*     */   
/*     */   public void setSource(DataSource source)
/*     */     throws IOException, javax.media.IncompatibleSourceException
/*     */   {
/*  36 */     super.setSource(source);
/*  37 */     this.controller.setSource(source);
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean audioEnabled()
/*     */   {
/*  43 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean videoEnabled() {
/*  47 */     return false;
/*     */   }
/*     */   
/*     */   protected javax.media.TimeBase getMasterTimeBase()
/*     */   {
/*  52 */     return this.controller.getMasterTimeBase();
/*     */   }
/*     */   
/*     */ 
/*     */   public void updateStats() {}
/*     */   
/*     */ 
/*     */   class MidiController
/*     */     extends BasicController
/*     */     implements javax.sound.midi.MetaEventListener
/*     */   {
/*     */     private Handler.MidiParser midiParser;
/*  64 */     private Track track = null;
/*  65 */     private Buffer buffer = new Buffer();
/*     */     private PullSourceStream stream;
/*  67 */     private Sequencer sequencer = null;
/*  68 */     private Synthesizer synthesizer = null;
/*     */     protected MidiChannel[] channels;
/*  70 */     private javax.sound.midi.Sequence sequence = null;
/*  71 */     private byte[] mididata = null;
/*  72 */     private Handler.MidiFileInputStream is = null;
/*  73 */     private Time duration = javax.media.Duration.DURATION_UNKNOWN;
/*     */     
/*     */     MidiController() {}
/*     */     
/*  77 */     protected boolean isConfigurable() { return false; }
/*     */     
/*     */ 
/*     */ 
/*     */     public void setSource(DataSource source)
/*     */       throws IOException, javax.media.IncompatibleSourceException
/*     */     {
/*  84 */       this.midiParser = new Handler.MidiParser(Handler.this);
/*  85 */       this.midiParser.setSource(source);
/*  86 */       Handler.this.datasource = source;
/*     */     }
/*     */     
/*     */     protected javax.media.TimeBase getMasterTimeBase()
/*     */     {
/*  91 */       return new javax.media.SystemTimeBase();
/*     */     }
/*     */     
/*     */     protected boolean doRealize()
/*     */     {
/*  96 */       if (Handler.this.datasource == null) {
/*  97 */         return false;
/*     */       }
/*     */       try {
/* 100 */         Handler.this.datasource.start();
/*     */       } catch (IOException e) {
/* 102 */         return false;
/*     */       }
/* 104 */       this.stream = this.midiParser.getStream();
/*     */       
/* 106 */       long contentLength = this.stream.getContentLength();
/* 107 */       long minLocation = 0L;
/*     */       
/*     */ 
/*     */ 
/* 111 */       minLocation = 0L;
/* 112 */       long maxLocation; int bufferSize; if (contentLength != -1L)
/*     */       {
/* 114 */         maxLocation = contentLength;
/* 115 */         bufferSize = (int)contentLength;
/*     */       } else {
/* 117 */         maxLocation = Long.MAX_VALUE;
/* 118 */         bufferSize = (int)maxLocation;
/*     */       }
/*     */       
/* 121 */       int numBuffers = 1;
/* 122 */       this.track = new com.sun.media.parser.BasicTrack(this.midiParser, null, true, javax.media.Duration.DURATION_UNKNOWN, new Time(0L), numBuffers, bufferSize, this.stream, minLocation, maxLocation);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */       return true;
/*     */     }
/*     */     
/*     */     protected boolean doPrefetch()
/*     */     {
/* 139 */       if (this.track == null) {
/* 140 */         return false;
/*     */       }
/* 142 */       if (this.sequencer == null) {
/*     */         try {
/* 144 */           this.sequencer = javax.sound.midi.MidiSystem.getSequencer();
/*     */           
/*     */ 
/* 147 */           if ((this.sequencer instanceof Synthesizer)) {
/* 148 */             this.synthesizer = ((Synthesizer)this.sequencer);
/* 149 */             this.channels = this.synthesizer.getChannels();
/*     */           }
/*     */         }
/*     */         catch (MidiUnavailableException ???) {
/* 153 */           return false;
/*     */         }
/* 155 */         this.sequencer.addMetaEventListener(this);
/*     */       }
/*     */       
/* 158 */       if (this.buffer.getLength() == 0)
/*     */       {
/* 160 */         this.track.readFrame(this.buffer);
/*     */         
/* 162 */         if ((this.buffer.isDiscard()) || (this.buffer.isEOM())) {
/* 163 */           this.buffer.setLength(0);
/* 164 */           return false;
/*     */         }
/* 166 */         this.mididata = ((byte[])this.buffer.getData());
/*     */         
/* 168 */         this.is = new Handler.MidiFileInputStream(Handler.this, this.mididata, this.buffer.getLength());
/*     */       }
/*     */       
/*     */ 
/* 172 */       synchronized (this) {
/* 173 */         if (this.is != null) {
/*     */           try {
/* 175 */             this.is.rewind();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/*     */           catch (Exception e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 197 */           e = 0;return e;
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 202 */         this.sequencer.open();
/*     */       }
/*     */       catch (MidiUnavailableException e)
/*     */       {
/* 206 */         Log.error("Cannot open sequencer " + e + "\n");
/* 207 */         return false;
/*     */       } catch (Exception e) {
/* 209 */         Log.error("Cannot open sequencer " + e + "\n");
/* 210 */         return false;
/*     */       }
/*     */       try
/*     */       {
/* 214 */         this.sequencer.setSequence(new java.io.BufferedInputStream(this.is));
/* 215 */         long durationNano = this.sequencer.getMicrosecondLength() * 1000L;
/*     */         
/* 217 */         this.duration = new Time(durationNano);
/*     */       }
/*     */       catch (javax.sound.midi.InvalidMidiDataException e) {
/* 220 */         Log.error("Invalid Midi Data " + e + "\n");
/* 221 */         this.sequencer.close();
/* 222 */         return false;
/*     */       } catch (Exception e) {
/* 224 */         Log.error("Error setting sequence " + e + "\n");
/* 225 */         this.sequencer.close();
/* 226 */         return false;
/*     */       }
/*     */       
/* 229 */       return true;
/*     */     }
/*     */     
/*     */     protected void abortRealize() {}
/*     */     
/*     */     protected void abortPrefetch()
/*     */     {
/* 236 */       if ((this.sequencer != null) && (this.sequencer.isOpen())) {
/* 237 */         this.sequencer.close();
/*     */       }
/*     */     }
/*     */     
/*     */     protected void doStart() {
/* 242 */       if (this.sequencer == null) {
/* 243 */         return;
/*     */       }
/*     */       
/*     */ 
/* 247 */       if (!this.sequencer.isOpen())
/* 248 */         return;
/* 249 */       this.sequencer.start();
/*     */     }
/*     */     
/*     */     protected void doStop() {
/* 253 */       if (this.sequencer == null) {
/* 254 */         return;
/*     */       }
/* 256 */       this.sequencer.stop();
/*     */       
/* 258 */       sendEvent(new javax.media.StopByRequestEvent(this, 600, 500, getTargetState(), getMediaTime()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void doDeallocate()
/*     */     {
/* 267 */       if (this.sequencer == null) {
/* 268 */         return;
/*     */       }
/* 270 */       synchronized (this) {
/*     */         try {
/* 272 */           this.sequencer.close();
/*     */ 
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*     */ 
/* 278 */           Log.error("Exception when deallocating: " + e + "\n");
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     protected void doClose() {
/* 284 */       if (Handler.this.closed) {
/* 285 */         return;
/*     */       }
/* 287 */       doDeallocate();
/*     */       
/* 289 */       if (Handler.this.datasource != null) {
/* 290 */         Handler.this.datasource.disconnect();
/*     */       }
/* 292 */       Handler.this.datasource = null;
/* 293 */       this.sequencer.removeMetaEventListener(this);
/* 294 */       Handler.this.closed = true;
/* 295 */       super.doClose();
/*     */     }
/*     */     
/*     */     protected float doSetRate(float factor)
/*     */     {
/* 300 */       if (this.sequencer != null) {
/* 301 */         this.sequencer.setTempoFactor(factor);
/* 302 */         return this.sequencer.getTempoFactor();
/*     */       }
/* 304 */       return 1.0F;
/*     */     }
/*     */     
/*     */ 
/*     */     protected void doSetMediaTime(Time when)
/*     */     {
/* 310 */       if ((when != null) && (this.sequencer != null)) {
/* 311 */         this.sequencer.setMicrosecondPosition(when.getNanoseconds() / 1000L);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void meta(javax.sound.midi.MetaMessage me)
/*     */     {
/* 319 */       if (me.getType() != Handler.this.META_EVENT_END_OF_MEDIA) {
/* 320 */         return;
/*     */       }
/* 322 */       if ((this.sequencer != null) && (this.sequencer.isOpen()))
/*     */       {
/* 324 */         stopControllerOnly();
/* 325 */         this.sequencer.stop();
/* 326 */         if (this.duration == javax.media.Duration.DURATION_UNKNOWN) {
/* 327 */           this.duration = getMediaTime();
/* 328 */           sendEvent(new javax.media.DurationUpdateEvent(this, this.duration));
/*     */         }
/*     */         
/*     */ 
/* 332 */         sendEvent(new javax.media.EndOfMediaEvent(this, 600, 500, getTargetState(), getMediaTime()));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private GCA gc;
/*     */     
/*     */ 
/*     */     public Time getDuration()
/*     */     {
/* 344 */       return this.duration;
/*     */     }
/*     */     
/*     */     public Control[] getControls() {
/* 348 */       if (Handler.this.controls == null) {
/* 349 */         Handler.this.controls = new Control[1];
/* 350 */         this.gc = new GCA();
/* 351 */         Handler.this.controls[0] = this.gc;
/*     */       }
/* 353 */       return Handler.this.controls;
/*     */     }
/*     */     
/*     */     public void gainChange(float g) {
/* 357 */       if ((this.channels == null) || (this.gc == null)) {
/* 358 */         return;
/*     */       }
/* 360 */       float level = this.gc.getLevel();
/*     */       
/* 362 */       for (int i = 0; i < this.channels.length; i++) {
/* 363 */         this.channels[i].controlChange(7, (int)(level * 127.0D));
/*     */       }
/*     */     }
/*     */     
/*     */     public void muteChange(boolean muted) {
/* 368 */       if (this.channels == null) {
/* 369 */         return;
/*     */       }
/* 371 */       for (int i = 0; i < this.channels.length; i++) {
/* 372 */         this.channels[i].setMute(muted);
/*     */       }
/*     */     }
/*     */     
/*     */     class GCA extends GainControlAdapter
/*     */     {
/*     */       GCA() {
/* 379 */         super();
/*     */       }
/*     */       
/*     */       public void setMute(boolean mute) {
/* 383 */         super.setMute(mute);
/* 384 */         Handler.MidiController.this.muteChange(mute);
/*     */       }
/*     */       
/*     */       public float setLevel(float g) {
/* 388 */         float level = super.setLevel(g);
/* 389 */         Handler.MidiController.this.gainChange(g);
/* 390 */         return level;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   class MidiParser extends com.sun.media.parser.BasicPullParser {
/*     */     MidiParser() {}
/*     */     
/*     */     public javax.media.protocol.ContentDescriptor[] getSupportedInputContentDescriptors() {
/* 399 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public PullSourceStream getStream()
/*     */     {
/* 408 */       PullSourceStream stream = (PullSourceStream)this.streams[0];
/* 409 */       return stream;
/*     */     }
/*     */     
/*     */     public Track[] getTracks()
/*     */       throws IOException, javax.media.BadHeaderException
/*     */     {
/* 415 */       return null;
/*     */     }
/*     */     
/*     */     public Time setPosition(Time where, int rounding) {
/* 419 */       return null;
/*     */     }
/*     */     
/*     */     public Time getMediaTime() {
/* 423 */       return null;
/*     */     }
/*     */     
/*     */     public Time getDuration() {
/* 427 */       return null;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 431 */       return "Parser for MIDI file format";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   class MidiFileInputStream
/*     */     extends java.io.InputStream
/*     */   {
/*     */     private int length;
/* 440 */     private int index = 0;
/*     */     private byte[] data;
/* 442 */     private int markpos = 0;
/*     */     
/*     */     MidiFileInputStream(byte[] data, int length) {
/* 445 */       this.data = data;
/* 446 */       this.length = length;
/*     */     }
/*     */     
/*     */     public void rewind() {
/* 450 */       this.index = 0;
/* 451 */       this.markpos = 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int read()
/*     */       throws IOException
/*     */     {
/* 472 */       if (this.index >= this.length) {
/* 473 */         return -1;
/*     */       }
/* 475 */       return this.data[(this.index++)];
/*     */     }
/*     */     
/*     */     public int available() throws IOException
/*     */     {
/* 480 */       return this.length - this.index;
/*     */     }
/*     */     
/*     */     public int read(byte[] b) throws IOException
/*     */     {
/* 485 */       return read(b, 0, b.length);
/*     */     }
/*     */     
/*     */     public int read(byte[] b, int off, int len) throws IOException
/*     */     {
/* 490 */       if (len > available())
/* 491 */         len = available();
/* 492 */       if (len == 0)
/* 493 */         return -1;
/* 494 */       System.arraycopy(this.data, this.index, b, off, len);
/* 495 */       this.index += len;
/* 496 */       return len;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\content\audio\midi\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */