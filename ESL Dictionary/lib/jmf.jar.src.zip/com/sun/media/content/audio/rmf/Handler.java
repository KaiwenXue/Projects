package com.sun.media.content.audio.rmf;

public class Handler
  extends com.sun.media.content.audio.midi.Handler
{}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\content\audio\rmf\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */