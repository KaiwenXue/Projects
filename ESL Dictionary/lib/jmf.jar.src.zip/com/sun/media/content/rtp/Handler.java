/*     */ package com.sun.media.content.rtp;
/*     */ 
/*     */ import com.sun.media.BasicController;
/*     */ import com.sun.media.BasicPlayer;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.rtp.RTPMediaLocator;
/*     */ import com.sun.media.rtp.RTPSessionMgr;
/*     */ import java.awt.Component;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Vector;
/*     */ import javax.media.Clock;
/*     */ import javax.media.ClockStartedError;
/*     */ import javax.media.Control;
/*     */ import javax.media.Controller;
/*     */ import javax.media.ControllerClosedEvent;
/*     */ import javax.media.ControllerErrorEvent;
/*     */ import javax.media.ControllerEvent;
/*     */ import javax.media.ControllerListener;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.Manager;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.NotRealizedError;
/*     */ import javax.media.Owned;
/*     */ import javax.media.Player;
/*     */ import javax.media.RealizeCompleteEvent;
/*     */ import javax.media.SystemTimeBase;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.control.BufferControl;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.FormatChangeEvent;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.rtp.RTPControl;
/*     */ import javax.media.rtp.RTPManager;
/*     */ import javax.media.rtp.RTPPushDataSource;
/*     */ import javax.media.rtp.RTPSocket;
/*     */ import javax.media.rtp.RTPStream;
/*     */ import javax.media.rtp.ReceiveStream;
/*     */ import javax.media.rtp.ReceiveStreamListener;
/*     */ import javax.media.rtp.SessionAddress;
/*     */ import javax.media.rtp.event.NewReceiveStreamEvent;
/*     */ import javax.media.rtp.event.RTPEvent;
/*     */ import javax.media.rtp.event.ReceiveStreamEvent;
/*     */ import javax.media.rtp.event.RemotePayloadChangeEvent;
/*     */ 
/*     */ public class Handler extends BasicPlayer implements ReceiveStreamListener, com.sun.media.protocol.BufferListener
/*     */ {
/*  54 */   RTPSessionMgr[] mgrs = null;
/*  55 */   javax.media.protocol.DataSource[] sources = null;
/*  56 */   Player[] players = null;
/*  57 */   Format[] formats = null;
/*  58 */   Format[] formatChanged = null;
/*  59 */   boolean[] realized = null;
/*  60 */   boolean[] dataReady = null;
/*  61 */   Vector locators = null;
/*  62 */   ControllerListener listener = new PlayerListener(this);
/*     */   
/*  64 */   boolean playersRealized = false;
/*  65 */   Object realizedSync = new Object();
/*  66 */   Object closeSync = new Object();
/*  67 */   Object dataSync = new Object();
/*  68 */   Object stateLock = new Object();
/*  69 */   private boolean closed = false;
/*  70 */   private boolean audioEnabled = false;
/*  71 */   private boolean videoEnabled = false;
/*  72 */   private boolean prebuffer = false;
/*  73 */   private boolean dataAllReady = false;
/*     */   
/*  75 */   private static JMFSecurity jmfSecurity = null;
/*  76 */   private static boolean securityPrivelege = false;
/*  77 */   private Method[] m = new Method[1];
/*  78 */   private Class[] cl = new Class[1];
/*  79 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   public Handler() {
/*  82 */     this.framePositioning = false;
/*  83 */     this.bufferControl = new BC();
/*  84 */     this.stopThreadEnabled = true;
/*     */   }
/*     */   
/*  87 */   String sessionError = "cannot create and initialize the RTP session.";
/*     */   
/*     */   protected boolean doRealize()
/*     */   {
/*  91 */     super.doRealize();
/*     */     
/*     */     try
/*     */     {
/*  95 */       if ((this.source instanceof RTPSocket))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 100 */         this.mgrs = new RTPSessionMgr[1];
/*     */         
/* 102 */         this.mgrs[1] = new RTPSessionMgr((RTPSocket)this.source);
/* 103 */         this.mgrs[1].addReceiveStreamListener(this);
/*     */         
/* 105 */         this.sources = new javax.media.protocol.DataSource[1];
/* 106 */         this.players = new Player[1];
/* 107 */         this.formats = new Format[1];
/* 108 */         this.realized = new boolean[1];
/* 109 */         this.dataReady = new boolean[1];
/* 110 */         this.formatChanged = new Format[1];
/*     */         
/* 112 */         this.sources[0] = this.source;
/* 113 */         this.dataReady[0] = false;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 118 */         SessionAddress localAddr = new SessionAddress();
/*     */         
/*     */ 
/* 121 */         this.mgrs = new RTPSessionMgr[this.locators.size()];
/* 122 */         this.sources = new javax.media.protocol.DataSource[this.locators.size()];
/* 123 */         this.players = new Player[this.locators.size()];
/* 124 */         this.formats = new Format[this.locators.size()];
/* 125 */         this.realized = new boolean[this.locators.size()];
/* 126 */         this.dataReady = new boolean[this.locators.size()];
/* 127 */         this.formatChanged = new Format[this.locators.size()];
/*     */         
/* 129 */         for (int i = 0; i < this.locators.size(); i++) {
/* 130 */           RTPMediaLocator rml = (RTPMediaLocator)this.locators.elementAt(i);
/* 131 */           this.realized[i] = false;
/*     */           
/* 133 */           this.mgrs[i] = ((RTPSessionMgr)RTPManager.newInstance());
/* 134 */           this.mgrs[i].addReceiveStreamListener(this);
/*     */           
/* 136 */           InetAddress ipAddr = InetAddress.getByName(rml.getSessionAddress());
/*     */           SessionAddress destAddr;
/* 138 */           if (ipAddr.isMulticastAddress())
/*     */           {
/* 140 */             localAddr = new SessionAddress(ipAddr, rml.getSessionPort(), rml.getTTL());
/*     */             
/*     */ 
/*     */ 
/* 144 */             destAddr = new SessionAddress(ipAddr, rml.getSessionPort(), rml.getTTL());
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 149 */             localAddr = new SessionAddress(InetAddress.getLocalHost(), rml.getSessionPort());
/*     */             
/*     */ 
/* 152 */             destAddr = new SessionAddress(ipAddr, rml.getSessionPort());
/*     */           }
/*     */           
/*     */ 
/* 156 */           this.mgrs[i].initialize(localAddr);
/*     */           
/* 158 */           if (this.prebuffer) {
/* 159 */             BufferControl bc = (BufferControl)this.mgrs[i].getControl("javax.media.control.BufferControl");
/* 160 */             bc.setBufferLength(this.bufferControl.getBufferLength());
/* 161 */             bc.setMinimumThreshold(this.bufferControl.getMinimumThreshold());
/*     */           }
/*     */           
/* 164 */           this.mgrs[i].addTarget(destAddr);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception rml) {
/* 169 */       Log.error("Cannot create the RTP Session: " + ???.getMessage());
/* 170 */       this.processError = this.sessionError;
/* 171 */       return false;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 176 */       synchronized (this.realizedSync) {
/*     */         do {
/* 178 */           this.realizedSync.wait();
/* 177 */           if ((this.playersRealized) || (isInterrupted())) break; } while (!this.closed);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/*     */ 
/* 183 */     if ((this.closed) || (isInterrupted())) {
/* 184 */       resetInterrupt();
/* 185 */       this.processError = "no RTP data was received.";
/* 186 */       return false;
/*     */     }
/*     */     
/* 189 */     return true;
/*     */   }
/*     */   
/*     */   protected void completeRealize()
/*     */   {
/* 194 */     this.state = 300;
/* 195 */     super.completeRealize();
/*     */   }
/*     */   
/*     */   protected void doStart()
/*     */   {
/* 200 */     super.doStart();
/*     */     
/* 202 */     synchronized (this.dataSync) {
/* 203 */       if (this.prebuffer) {
/* 204 */         this.dataAllReady = false;
/* 205 */         for (int i = 0; i < this.dataReady.length; i++) {
/* 206 */           this.dataReady[i] = false;
/* 207 */           ((com.sun.media.protocol.rtp.DataSource)this.sources[i]).flush();
/* 208 */           ((com.sun.media.protocol.rtp.DataSource)this.sources[i]).prebuffer();
/*     */         }
/*     */         
/* 211 */         if ((!this.dataAllReady) && (!this.closed)) {
/*     */           try {
/* 213 */             this.dataSync.wait(3000L);
/*     */           }
/*     */           catch (Exception e) {}
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 221 */     for (int i = 0; i < this.players.length; i++) {
/*     */       try {
/* 223 */         if (this.players[i] != null) {
/* 224 */           waitForStart(this.players[i]);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */   }
/*     */   
/*     */   protected void doStop() {
/* 232 */     super.doStop();
/*     */     
/* 234 */     synchronized (this.dataSync) {
/* 235 */       if (this.prebuffer) {
/* 236 */         this.dataSync.notify();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 241 */     for (int i = 0; i < this.players.length; i++) {
/*     */       try {
/* 243 */         if (this.players[i] != null) {
/* 244 */           waitForStop(this.players[i]);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */   }
/*     */   
/*     */   protected void doDeallocate() {
/* 252 */     for (int i = 0; i < this.players.length; i++) {
/*     */       try {
/* 254 */         if (this.players[i] != null)
/* 255 */           this.players[i].deallocate();
/*     */       } catch (Exception ???) {}
/*     */     }
/* 258 */     synchronized (this.realizedSync) {
/* 259 */       this.realizedSync.notify();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void doFailedRealize()
/*     */   {
/* 266 */     synchronized (this.closeSync)
/*     */     {
/* 268 */       for (int i = 0; i < this.mgrs.length; i++) {
/* 269 */         if (this.mgrs[i] != null) {
/* 270 */           this.mgrs[i].removeTargets("Closing session from the RTP Handler");
/* 271 */           this.mgrs[i].dispose();
/* 272 */           this.mgrs[i] = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 277 */     super.doFailedRealize();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void doClose()
/*     */   {
/* 283 */     this.closed = true;
/*     */     
/* 285 */     synchronized (this.realizedSync) {
/* 286 */       this.realizedSync.notify();
/*     */     }
/*     */     
/* 289 */     synchronized (this.dataSync) {
/* 290 */       this.dataSync.notifyAll();
/*     */     }
/*     */     
/* 293 */     stop();
/* 294 */     for (int i = 0; i < this.players.length; i++) {
/*     */       try {
/* 296 */         if (this.players[i] != null) {
/* 297 */           this.players[i].close();
/*     */         }
/*     */       }
/*     */       catch (Exception ???) {}
/*     */     }
/* 302 */     synchronized (this.closeSync) {
/* 303 */       for (int i = 0; i < this.mgrs.length; i++) {
/* 304 */         if (this.mgrs[i] != null) {
/* 305 */           this.mgrs[i].removeTargets("Closing session from the RTP Handler");
/* 306 */           this.mgrs[i].dispose();
/* 307 */           this.mgrs[i] = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 312 */     super.doClose();
/*     */   }
/*     */   
/*     */   public void setTimeBase(TimeBase tb) throws IncompatibleTimeBaseException
/*     */   {}
/*     */   
/*     */   protected TimeBase getMasterTimeBase() {
/* 319 */     return new SystemTimeBase();
/*     */   }
/*     */   
/*     */   public float setRate(float rate) {
/* 323 */     if (getState() < 300) {
/* 324 */       throwError(new NotRealizedError("Cannot set rate on an unrealized Player."));
/*     */     }
/*     */     
/*     */ 
/* 328 */     return 1.0F;
/*     */   }
/*     */   
/*     */   public void setStopTime(Time t) {
/* 332 */     controllerSetStopTime(t);
/*     */   }
/*     */   
/*     */   protected void stopAtTime() {
/* 336 */     controllerStopAtTime();
/*     */   }
/*     */   
/*     */   public synchronized void addController(Controller newController) throws IncompatibleTimeBaseException
/*     */   {
/* 341 */     int playerState = getState();
/*     */     
/* 343 */     if (playerState == 600) {
/* 344 */       throwError(new ClockStartedError("Cannot add controller to a started player"));
/*     */     }
/*     */     
/* 347 */     if ((playerState == 100) || (playerState == 200)) {
/* 348 */       throwError(new NotRealizedError("A Controller cannot be added to an Unrealized Player"));
/*     */     }
/*     */     
/* 351 */     throw new IncompatibleTimeBaseException();
/*     */   }
/*     */   
/*     */   protected boolean audioEnabled() {
/* 355 */     return this.audioEnabled;
/*     */   }
/*     */   
/*     */   protected boolean videoEnabled()
/*     */   {
/* 360 */     return this.videoEnabled;
/*     */   }
/*     */   
/*     */   private void sendMyEvent(ControllerEvent e)
/*     */   {
/* 365 */     super.sendEvent(e);
/*     */   }
/*     */   
/*     */ 
/*     */   public void update(ReceiveStreamEvent event)
/*     */   {
/* 371 */     RTPSessionMgr mgr = (RTPSessionMgr)event.getSource();
/*     */     
/*     */ 
/* 374 */     for (int idx = 0; idx < this.mgrs.length; idx++) {
/* 375 */       if (this.mgrs[idx] == mgr) {
/*     */         break;
/*     */       }
/*     */     }
/* 379 */     if (idx >= this.mgrs.length)
/*     */     {
/* 381 */       System.err.println("Unknown manager: " + mgr);
/* 382 */       return;
/*     */     }
/*     */     
/* 385 */     if ((event instanceof RemotePayloadChangeEvent))
/*     */     {
/* 387 */       Log.comment("Received an RTP PayloadChangeEvent");
/* 388 */       RTPControl ctl = (RTPControl)this.sources[idx].getControl("javax.media.rtp.RTPControl");
/*     */       
/* 390 */       if (ctl != null) {
/* 391 */         this.formatChanged[idx] = ctl.getFormat();
/*     */       }
/*     */       
/*     */ 
/* 395 */       if (this.players[idx] != null)
/*     */       {
/*     */ 
/* 398 */         stop();
/*     */         
/*     */ 
/*     */ 
/* 402 */         waitForClose(this.players[idx]);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 409 */         this.sources[idx].connect();
/* 410 */         this.players[idx] = Manager.createPlayer(this.sources[idx]);
/*     */         
/* 412 */         if (this.players[idx] == null) {
/* 413 */           Log.error("Could not create player for the new RTP payload.");
/* 414 */           return;
/*     */         }
/* 416 */         this.players[idx].addControllerListener(this.listener);
/* 417 */         this.players[idx].realize();
/*     */       }
/*     */       catch (Exception e) {
/* 420 */         Log.error("Could not create player for the new payload.");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 425 */     if ((event instanceof NewReceiveStreamEvent))
/*     */     {
/* 427 */       if (this.players[idx] != null)
/*     */       {
/*     */ 
/*     */ 
/* 431 */         return;
/*     */       }
/*     */       
/* 434 */       ReceiveStream stream = null;
/*     */       try {
/* 436 */         stream = ((NewReceiveStreamEvent)event).getReceiveStream();
/* 437 */         this.sources[idx] = stream.getDataSource();
/*     */         
/* 439 */         RTPControl ctl = (RTPControl)this.sources[idx].getControl("javax.media.rtp.RTPControl");
/* 440 */         if (ctl != null) {
/* 441 */           this.formats[idx] = ctl.getFormat();
/* 442 */           if ((this.formats[idx] instanceof AudioFormat)) {
/* 443 */             this.audioEnabled = true;
/* 444 */           } else if ((this.formats[idx] instanceof VideoFormat)) {
/* 445 */             this.videoEnabled = true;
/*     */           }
/*     */         }
/* 448 */         if ((this.source instanceof RTPSocket)) {
/* 449 */           ((RTPSocket)this.source).setChild(this.sources[idx]);
/*     */         } else {
/* 451 */           ((com.sun.media.protocol.rtp.DataSource)this.source).setChild((com.sun.media.protocol.rtp.DataSource)this.sources[idx]);
/*     */         }
/*     */         
/* 454 */         this.players[idx] = Manager.createPlayer(this.sources[idx]);
/* 455 */         if (this.players[idx] == null) {
/* 456 */           return;
/*     */         }
/* 458 */         this.players[idx].addControllerListener(this.listener);
/* 459 */         this.players[idx].realize();
/*     */         
/* 461 */         if (this.prebuffer) {
/* 462 */           ((com.sun.media.protocol.rtp.DataSource)this.sources[idx]).setBufferListener(this);
/*     */         }
/*     */       } catch (Exception e) {
/* 465 */         Log.error("NewReceiveStreamEvent exception " + e.getMessage());
/* 466 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void waitForStart(Player p)
/*     */   {
/* 474 */     new StateWaiter().waitForStart(p, true);
/*     */   }
/*     */   
/*     */   private void waitForStop(Player p)
/*     */   {
/* 479 */     new StateWaiter().waitForStart(p, false);
/*     */   }
/*     */   
/*     */   private void waitForClose(Player p)
/*     */   {
/* 484 */     new StateWaiter().waitForClose(p);
/*     */   }
/*     */   
/*     */   class StateWaiter implements ControllerListener {
/*     */     StateWaiter() {}
/*     */     
/* 490 */     boolean closeDown = false;
/* 491 */     Object stateLock = new Object();
/*     */     
/*     */     public void waitForStart(Player p, boolean startOn) {
/* 494 */       p.addControllerListener(this);
/* 495 */       if (startOn) {
/* 496 */         p.start();
/*     */       } else
/* 498 */         p.stop();
/* 499 */       synchronized (this.stateLock)
/*     */       {
/*     */         do
/*     */         {
/*     */           try {
/* 504 */             this.stateLock.wait(1000L);
/*     */           }
/*     */           catch (InterruptedException ie)
/*     */           {
/*     */             break;
/*     */           }
/* 501 */           if (((!startOn) || (p.getState() == 600)) && ((startOn) || (p.getState() != 600))) break; } while (!this.closeDown);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 510 */       p.removeControllerListener(this);
/*     */     }
/*     */     
/*     */     public void waitForClose(Player p) {
/* 514 */       p.addControllerListener(this);
/* 515 */       p.close();
/* 516 */       synchronized (this.stateLock) {
/* 517 */         while (!this.closeDown) {
/*     */           try {
/* 519 */             this.stateLock.wait(1000L);
/*     */           } catch (InterruptedException ie) {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/* 525 */       p.removeControllerListener(this);
/*     */     }
/*     */     
/*     */     public void controllerUpdate(ControllerEvent ce) {
/* 529 */       if (((ce instanceof ControllerClosedEvent)) || ((ce instanceof ControllerErrorEvent)))
/*     */       {
/* 531 */         this.closeDown = true;
/*     */       }
/* 533 */       synchronized (this.stateLock) {
/* 534 */         this.stateLock.notify();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setSource(javax.media.protocol.DataSource source)
/*     */     throws IOException, IncompatibleSourceException
/*     */   {
/* 543 */     super.setSource(source);
/* 544 */     if ((source instanceof com.sun.media.protocol.rtp.DataSource)) {
/* 545 */       MediaLocator ml = source.getLocator();
/* 546 */       String mlStr = ml.getRemainder();
/*     */       
/*     */ 
/*     */ 
/* 550 */       int start = 0;
/* 551 */       while (mlStr.charAt(start) == '/')
/* 552 */         start++;
/* 553 */       this.locators = new Vector();
/*     */       try {
/*     */         String str;
/*     */         int idx;
/* 557 */         while ((start < mlStr.length()) && ((idx = mlStr.indexOf("&", start)) != -1)) { int i;
/* 558 */           str = mlStr.substring(start, i);
/* 559 */           rml = new RTPMediaLocator("rtp://" + str);
/* 560 */           this.locators.addElement(rml);
/* 561 */           start = i + 1;
/*     */         }
/* 563 */         if (start != 0) {
/* 564 */           str = mlStr.substring(start);
/*     */         } else
/* 566 */           str = mlStr;
/* 567 */         RTPMediaLocator rml = new RTPMediaLocator("rtp://" + str);
/* 568 */         this.locators.addElement(rml);
/*     */       }
/*     */       catch (Exception e) {
/* 571 */         throw new IncompatibleSourceException();
/*     */       }
/*     */       
/* 574 */       if (this.locators.size() > 1) {
/* 575 */         this.prebuffer = true;
/*     */       }
/* 577 */     } else if (!(source instanceof RTPSocket)) {
/* 578 */       throw new IncompatibleSourceException();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 583 */     RTPControl ctl = (RTPControl)source.getControl("javax.media.rtp.RTPControl");
/*     */     
/* 585 */     if (ctl != null) {
/* 586 */       ctl.addFormat(new AudioFormat("dvi/rtp", 44100.0D, 4, 1), 18);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void invalidateComp()
/*     */   {
/* 595 */     this.controlComp = null;
/* 596 */     this.controls = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Component getVisualComponent()
/*     */   {
/* 608 */     super.getVisualComponent();
/* 609 */     for (int i = 0; i < this.players.length; i++) {
/* 610 */       if ((this.players[i] != null) && (this.players[i].getVisualComponent() != null))
/* 611 */         return this.players[i].getVisualComponent();
/*     */     }
/* 613 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Control[] getControls()
/*     */   {
/* 623 */     if (this.controls != null) {
/* 624 */       return this.controls;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 630 */     Vector cv = new Vector();
/*     */     
/* 632 */     if (this.cachingControl != null) {
/* 633 */       cv.addElement(this.cachingControl);
/*     */     }
/* 635 */     if (this.bufferControl != null) {
/* 636 */       cv.addElement(this.bufferControl);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 641 */     int size = this.players.length;
/* 642 */     for (int i = 0; i < size; i++) {
/* 643 */       Controller ctrller = this.players[i];
/* 644 */       Object[] cs = ctrller.getControls();
/* 645 */       if (cs != null) {
/* 646 */         for (int j = 0; j < cs.length; j++) {
/* 647 */           cv.addElement(cs[j]);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 652 */     size = cv.size();
/* 653 */     Control[] ctrls = new Control[size];
/*     */     
/* 655 */     for (i = 0; i < size; i++) {
/* 656 */       ctrls[i] = ((Control)cv.elementAt(i));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 662 */     if (getState() >= 300) {
/* 663 */       this.controls = ctrls;
/*     */     }
/* 665 */     return ctrls;
/*     */   }
/*     */   
/*     */   public void updateStats()
/*     */   {
/* 670 */     for (int i = 0; i < this.players.length; i++) {
/* 671 */       if (this.players[i] != null) {
/* 672 */         ((BasicPlayer)this.players[i]).updateStats();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void minThresholdReached(javax.media.protocol.DataSource ds) {
/* 678 */     boolean ready = true;
/* 679 */     synchronized (this.dataSync) {
/* 680 */       for (int i = 0; i < this.sources.length; i++) {
/* 681 */         if (this.sources[i] == ds) {
/* 682 */           this.dataReady[i] = true;
/* 683 */         } else if (this.dataReady[i] == 0)
/* 684 */           ready = false;
/*     */       }
/* 686 */       if (!ready) {
/* 687 */         return;
/*     */       }
/* 689 */       this.dataAllReady = true;
/* 690 */       this.dataSync.notify();
/*     */     }
/*     */   }
/*     */   
/*     */   class PlayerListener implements ControllerListener
/*     */   {
/*     */     Handler handler;
/*     */     
/*     */     public PlayerListener(Handler handler)
/*     */     {
/* 700 */       this.handler = handler;
/*     */     }
/*     */     
/*     */     public synchronized void controllerUpdate(ControllerEvent ce)
/*     */     {
/* 705 */       Player p = (Player)ce.getSourceController();
/*     */       
/*     */ 
/* 708 */       if (p == null) {
/* 709 */         return;
/*     */       }
/* 711 */       for (int idx = 0; idx < Handler.this.players.length; idx++) {
/* 712 */         if (Handler.this.players[idx] == p) {
/*     */           break;
/*     */         }
/*     */       }
/* 716 */       if (idx >= Handler.this.players.length)
/*     */       {
/* 718 */         System.err.println("Unknown player: " + p);
/* 719 */         return;
/*     */       }
/*     */       
/* 722 */       if ((ce instanceof RealizeCompleteEvent))
/*     */       {
/*     */ 
/*     */ 
/* 726 */         if (Handler.this.formatChanged[idx] != null)
/*     */         {
/*     */           try
/*     */           {
/*     */ 
/* 731 */             Handler.this.invalidateComp();
/*     */             
/* 733 */             FormatChangeEvent f = new FormatChangeEvent(this.handler, Handler.this.formats[idx], Handler.this.formatChanged[idx]);
/*     */             
/*     */ 
/*     */ 
/* 737 */             this.handler.sendMyEvent(f);
/* 738 */             Handler.this.formats[idx] = Handler.this.formatChanged[idx];
/* 739 */             Handler.this.formatChanged[idx] = null;
/*     */ 
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/*     */ 
/* 745 */             e.getMessage();
/*     */           }
/*     */         }
/*     */         
/* 749 */         Handler.this.realized[idx] = true;
/*     */         
/*     */ 
/* 752 */         for (int i = 0; i < Handler.this.realized.length; i++) {
/* 753 */           if (Handler.this.realized[i] == 0) {
/* 754 */             return;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 759 */         synchronized (Handler.this.realizedSync) {
/* 760 */           Handler.this.playersRealized = true;
/* 761 */           Handler.this.realizedSync.notifyAll();
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 766 */       if ((ce instanceof ControllerErrorEvent)) {
/* 767 */         Handler.this.players[idx].removeControllerListener(this);
/* 768 */         Log.error("RTP Handler internal error: " + ce);
/* 769 */         Handler.this.players[idx] = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   class BC
/*     */     implements BufferControl, Owned
/*     */   {
/*     */     BC() {}
/*     */     
/*     */ 
/* 782 */     long len = -1L;
/* 783 */     long min = -1L;
/*     */     
/*     */     public long getBufferLength() {
/* 786 */       if (this.len < 0L)
/* 787 */         return Handler.this.prebuffer ? 750L : 125L;
/* 788 */       return this.len;
/*     */     }
/*     */     
/*     */     public long setBufferLength(long time) {
/* 792 */       this.len = time;
/* 793 */       Log.comment("RTP Handler buffer length set: " + this.len);
/* 794 */       return this.len;
/*     */     }
/*     */     
/*     */     public long getMinimumThreshold() {
/* 798 */       if (this.min < 0L)
/* 799 */         return Handler.this.prebuffer ? 125L : 0L;
/* 800 */       return this.min;
/*     */     }
/*     */     
/*     */     public long setMinimumThreshold(long time) {
/* 804 */       this.min = time;
/* 805 */       Log.comment("RTP Handler buffer minimum threshold: " + this.min);
/* 806 */       return this.min;
/*     */     }
/*     */     
/*     */     public void setEnabledThreshold(boolean b) {}
/*     */     
/*     */     public boolean getEnabledThreshold()
/*     */     {
/* 813 */       return getMinimumThreshold() > 0L;
/*     */     }
/*     */     
/*     */     public Component getControlComponent() {
/* 817 */       return null;
/*     */     }
/*     */     
/*     */     public Object getOwner() {
/* 821 */       return Handler.this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\content\rtp\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */