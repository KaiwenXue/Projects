/*     */ package com.sun.media.content.application.x_jmx;
/*     */ 
/*     */ import com.sun.media.BasicController;
/*     */ import com.sun.media.BasicPlayer;
/*     */ import com.sun.media.Log;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Panel;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Vector;
/*     */ import javax.media.Clock;
/*     */ import javax.media.Controller;
/*     */ import javax.media.ControllerErrorEvent;
/*     */ import javax.media.ControllerEvent;
/*     */ import javax.media.ControllerListener;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.Manager;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.Player;
/*     */ import javax.media.RealizeCompleteEvent;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PullDataSource;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.media.protocol.SourceStream;
/*     */ import javax.media.renderer.VisualContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Handler
/*     */   extends BasicPlayer
/*     */ {
/*  41 */   Player[] players = null;
/*  42 */   Player master = null;
/*  43 */   boolean[] realized = null;
/*  44 */   Vector locators = new Vector();
/*  45 */   ControllerListener listener = new PlayerListener(this);
/*     */   
/*  47 */   boolean playersRealized = false;
/*  48 */   Object realizedSync = new Object();
/*  49 */   private boolean closed = false;
/*  50 */   private boolean audioEnabled = false;
/*  51 */   private boolean videoEnabled = false;
/*     */   
/*     */   public Handler()
/*     */   {
/*  55 */     this.framePositioning = true;
/*     */   }
/*     */   
/*  58 */   String sessionError = "Cannot create a Player for: ";
/*     */   
/*     */   protected boolean doRealize()
/*     */   {
/*  62 */     super.doRealize();
/*     */     
/*  64 */     MediaLocator ml = null;
/*     */     
/*     */     try
/*     */     {
/*  68 */       this.players = new Player[this.locators.size()];
/*  69 */       this.realized = new boolean[this.locators.size()];
/*     */       
/*  71 */       for (int i = 0; i < this.locators.size(); i++) {
/*  72 */         ml = (MediaLocator)this.locators.elementAt(i);
/*  73 */         this.players[i] = Manager.createPlayer(ml);
/*  74 */         this.players[i].addControllerListener(this.listener);
/*  75 */         this.realized[i] = false;
/*  76 */         this.players[i].realize();
/*     */       }
/*     */     }
/*     */     catch (Exception i) {
/*  80 */       Log.error(this.sessionError + ml);
/*  81 */       this.processError = (this.sessionError + ml);
/*  82 */       return false;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  87 */       synchronized (this.realizedSync) {
/*     */         do {
/*  89 */           this.realizedSync.wait();
/*  88 */           if ((this.playersRealized) || (isInterrupted())) break; } while (!this.closed);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/*     */ 
/*  94 */     if ((this.closed) || (isInterrupted())) {
/*  95 */       resetInterrupt();
/*  96 */       this.processError = "Realize interrupted";
/*  97 */       return false;
/*     */     }
/*     */     try
/*     */     {
/* 101 */       this.master = this.players[0];
/* 102 */       for (int i = 1; i < this.players.length; i++) {
/* 103 */         this.master.addController(this.players[i]);
/*     */       }
/*     */     } catch (IncompatibleTimeBaseException e) {
/* 106 */       this.processError = "AddController failed";
/* 107 */       return false;
/*     */     }
/*     */     
/* 110 */     manageController(this.master);
/*     */     
/* 112 */     return true;
/*     */   }
/*     */   
/*     */   protected void completeRealize()
/*     */   {
/* 117 */     this.state = 300;
/* 118 */     super.completeRealize();
/*     */   }
/*     */   
/*     */   protected void doStart()
/*     */   {
/* 123 */     super.doStart();
/*     */   }
/*     */   
/*     */   protected void doStop()
/*     */   {
/* 128 */     super.doStop();
/*     */   }
/*     */   
/*     */   protected void doDeallocate()
/*     */   {
/* 133 */     synchronized (this.realizedSync) {
/* 134 */       this.realizedSync.notify();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void doClose()
/*     */   {
/* 141 */     this.closed = true;
/*     */     
/* 143 */     synchronized (this.realizedSync) {
/* 144 */       this.realizedSync.notify();
/*     */     }
/*     */     
/* 147 */     stop();
/*     */     
/* 149 */     super.doClose();
/*     */   }
/*     */   
/*     */   protected TimeBase getMasterTimeBase()
/*     */   {
/* 154 */     return this.master.getTimeBase();
/*     */   }
/*     */   
/*     */   protected boolean audioEnabled()
/*     */   {
/* 159 */     return this.audioEnabled;
/*     */   }
/*     */   
/*     */   protected boolean videoEnabled()
/*     */   {
/* 164 */     return this.videoEnabled;
/*     */   }
/*     */   
/*     */   private void sendMyEvent(ControllerEvent e)
/*     */   {
/* 169 */     super.sendEvent(e);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setSource(DataSource source)
/*     */     throws IOException, IncompatibleSourceException
/*     */   {
/* 176 */     super.setSource(source);
/*     */     
/* 178 */     if (!(source instanceof PullDataSource)) {
/* 179 */       throw new IncompatibleSourceException();
/*     */     }
/* 181 */     PullSourceStream[] pss = ((PullDataSource)source).getStreams();
/*     */     
/* 183 */     if (pss.length != 1) {
/* 184 */       throw new IncompatibleSourceException();
/*     */     }
/* 186 */     source.start();
/*     */     
/* 188 */     int len = (int)pss[0].getContentLength();
/*     */     
/* 190 */     if (len == -1L) {
/* 191 */       throw new IncompatibleSourceException();
/*     */     }
/* 193 */     byte[] barray = new byte[len];
/*     */     
/*     */     String content;
/*     */     try
/*     */     {
/* 198 */       len = pss[0].read(barray, 0, len);
/* 199 */       content = new String(barray);
/*     */     }
/*     */     catch (Exception e) {
/* 202 */       throw new IncompatibleSourceException();
/*     */     }
/*     */     
/*     */ 
/* 206 */     int start = 0;
/* 207 */     int size = content.length();
/*     */     
/* 209 */     String relPath = null;
/*     */     
/* 211 */     char ch = content.charAt(start);
/*     */     
/* 213 */     for (goto 353; start < size;)
/*     */     {
/*     */ 
/* 216 */       start++;
/* 215 */       while ((ch == ' ') || (ch == '\n'))
/*     */       {
/* 217 */         if (start >= size)
/*     */           break;
/* 219 */         ch = content.charAt(start);
/*     */       }
/*     */       
/* 222 */       if (start >= size) {
/*     */         break;
/*     */       }
/* 225 */       int idx = start;
/*     */       do
/*     */       {
/* 228 */         idx++;
/* 229 */         if (idx >= size)
/*     */           break;
/* 231 */         ch = content.charAt(idx);
/* 232 */       } while (ch != '\n');
/*     */       
/* 234 */       String str = content.substring(start, idx);
/*     */       
/* 236 */       if (str.indexOf(':') == -1)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 244 */         if (relPath == null) {
/* 245 */           MediaLocator loc = source.getLocator();
/* 246 */           if (loc == null)
/* 247 */             throw new IncompatibleSourceException();
/* 248 */           relPath = loc.toString();
/* 249 */           int i = relPath.lastIndexOf('/');
/* 250 */           if (i < 0)
/* 251 */             i = relPath.lastIndexOf(File.separator);
/* 252 */           relPath = relPath.substring(0, i + 1);
/*     */         }
/* 254 */         str = relPath + str;
/*     */       }
/*     */       
/* 257 */       this.locators.addElement(new MediaLocator(str));
/* 258 */       start = idx;
/*     */     }
/*     */     
/* 261 */     if (this.locators.size() < 1) {
/* 262 */       throw new IncompatibleSourceException();
/*     */     }
/*     */   }
/*     */   
/*     */   private void invalidateComp() {
/* 267 */     this.controlComp = null;
/* 268 */     this.controls = null;
/*     */   }
/*     */   
/*     */ 
/* 272 */   private Container container = null;
/*     */   
/*     */   public Component getVisualComponent() {
/* 275 */     Vector visuals = new Vector(1);
/*     */     
/* 277 */     for (int i = 0; i < this.players.length; i++) {
/* 278 */       Component comp = this.players[i].getVisualComponent();
/*     */       
/* 280 */       if (comp != null) {
/* 281 */         visuals.addElement(comp);
/*     */       }
/*     */     }
/*     */     
/* 285 */     if (visuals.size() == 0)
/* 286 */       return null;
/* 287 */     if (visuals.size() == 1) {
/* 288 */       return (Component)visuals.elementAt(0);
/*     */     }
/* 290 */     return createVisualContainer(visuals);
/*     */   }
/*     */   
/*     */ 
/*     */   protected Component createVisualContainer(Vector visuals)
/*     */   {
/* 296 */     Boolean hint = (Boolean)Manager.getHint(3);
/*     */     
/* 298 */     if (this.container == null) {
/* 299 */       if ((hint == null) || (!hint.booleanValue())) {
/* 300 */         this.container = new HeavyPanel(visuals);
/*     */       } else {
/* 302 */         this.container = new LightPanel(visuals);
/*     */       }
/*     */       
/* 305 */       this.container.setLayout(new FlowLayout());
/* 306 */       this.container.setBackground(Color.black);
/*     */       
/* 308 */       for (int i = 0; i < visuals.size(); i++) {
/* 309 */         Component c = (Component)visuals.elementAt(i);
/* 310 */         this.container.add(c);
/* 311 */         c.setSize(c.getPreferredSize());
/*     */       }
/*     */     }
/*     */     
/* 315 */     return this.container;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateStats()
/*     */   {
/* 332 */     for (int i = 0; i < this.players.length; i++) {
/* 333 */       if (this.players[i] != null) {
/* 334 */         ((BasicPlayer)this.players[i]).updateStats();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   class PlayerListener implements ControllerListener
/*     */   {
/*     */     Handler handler;
/*     */     
/*     */     public PlayerListener(Handler handler) {
/* 344 */       this.handler = handler;
/*     */     }
/*     */     
/*     */     public synchronized void controllerUpdate(ControllerEvent ce)
/*     */     {
/* 349 */       Player p = (Player)ce.getSourceController();
/*     */       
/*     */ 
/* 352 */       if (p == null) {
/* 353 */         return;
/*     */       }
/* 355 */       for (int idx = 0; idx < Handler.this.players.length; idx++) {
/* 356 */         if (Handler.this.players[idx] == p) {
/*     */           break;
/*     */         }
/*     */       }
/* 360 */       if (idx >= Handler.this.players.length)
/*     */       {
/* 362 */         System.err.println("Unknown player: " + p);
/* 363 */         return;
/*     */       }
/*     */       
/* 366 */       if ((ce instanceof RealizeCompleteEvent))
/*     */       {
/* 368 */         Handler.this.realized[idx] = true;
/*     */         
/*     */ 
/* 371 */         for (int i = 0; i < Handler.this.realized.length; i++) {
/* 372 */           if (Handler.this.realized[i] == 0) {
/* 373 */             return;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 378 */         synchronized (Handler.this.realizedSync) {
/* 379 */           Handler.this.playersRealized = true;
/* 380 */           Handler.this.realizedSync.notifyAll();
/*     */         }
/*     */       }
/*     */       
/* 384 */       if ((ce instanceof ControllerErrorEvent)) {
/* 385 */         Handler.this.players[idx].removeControllerListener(this);
/* 386 */         Log.error("Meta Handler internal error: " + ce);
/* 387 */         Handler.this.players[idx] = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   class LightPanel
/*     */     extends Container
/*     */     implements VisualContainer
/*     */   {
/*     */     public LightPanel(Vector visuals) {}
/*     */   }
/*     */   
/*     */   class HeavyPanel
/*     */     extends Panel
/*     */     implements VisualContainer
/*     */   {
/*     */     public HeavyPanel(Vector visuals) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\content\application\x_jmx\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */