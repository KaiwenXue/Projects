package com.sun.media.content.rtpraw;

public class Handler
  extends com.sun.media.content.rtp.Handler
{}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\content\rtpraw\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */