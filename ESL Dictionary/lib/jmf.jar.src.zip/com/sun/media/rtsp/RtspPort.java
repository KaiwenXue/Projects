/*    */ package com.sun.media.rtsp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RtspPort
/*    */ {
/*    */   public static final int RTSP_DEFAULT_PORT = 1554;
/*    */   
/*    */ 
/*    */ 
/* 12 */   public static int port = 1554;
/*    */   
/*    */   public static void setPort(int current_port) {
/* 15 */     port = current_port;
/*    */   }
/*    */   
/*    */   public static int getPort() {
/* 19 */     return port;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\RtspPort.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */