/*     */ package com.sun.media.rtsp;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.ConnectException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Connection
/*     */   extends Thread
/*     */   implements Runnable
/*     */ {
/*     */   public int connectionId;
/*     */   private Socket socket;
/*     */   private RtspManager rtspManager;
/*     */   private MessageProcessor mp;
/*     */   private boolean connectionIsAlive;
/*     */   
/*     */   public Connection(RtspManager rtspManager, int connectionId, byte[] dstAddress, int port)
/*     */     throws UnknownHostException, ConnectException
/*     */   {
/*  30 */     this.rtspManager = rtspManager;
/*  31 */     this.connectionId = connectionId;
/*     */     
/*  33 */     String domain = new String(dstAddress);
/*     */     
/*  35 */     InetAddress dst = InetAddress.getByName(domain);
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  40 */       this.socket = new Socket(dst, port);
/*     */       
/*     */ 
/*     */ 
/*  44 */       start();
/*     */     } catch (IOException e) {
/*  46 */       throw new ConnectException();
/*     */     }
/*     */   }
/*     */   
/*     */   public Connection(RtspManager rtspManager, int connectionId, Socket socket) {
/*  51 */     this.rtspManager = rtspManager;
/*  52 */     this.connectionId = connectionId;
/*  53 */     this.socket = socket;
/*     */     
/*  55 */     start();
/*     */   }
/*     */   
/*     */   public boolean sendData(byte[] message) {
/*  59 */     boolean success = false;
/*     */     try
/*     */     {
/*  62 */       OutputStream out = this.socket.getOutputStream();
/*     */       
/*  64 */       out.write(message);
/*     */       
/*  66 */       out.flush();
/*     */       
/*  68 */       success = true;
/*     */     }
/*     */     catch (IOException e) {}
/*     */     
/*     */ 
/*  73 */     return success;
/*     */   }
/*     */   
/*     */ 
/*     */   public void run()
/*     */   {
/*  79 */     this.connectionIsAlive = true;
/*     */     
/*  81 */     while (this.connectionIsAlive) {
/*     */       try {
/*  83 */         InputStream in = this.socket.getInputStream();
/*     */         
/*  85 */         DataInputStream din = new DataInputStream(in);
/*     */         
/*  87 */         byte ch = din.readByte();
/*     */         
/*  89 */         ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*     */         
/*     */ 
/*     */ 
/*  93 */         baos.write(ch);
/*     */         
/*  95 */         while (!eomReached(baos.toByteArray())) {
/*  96 */           baos.write(din.readByte());
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 101 */         int length = getContentLength(new String(baos.toByteArray()));
/*     */         
/* 103 */         for (int i = 0; i < length; i++) {
/* 104 */           baos.write(din.readByte());
/*     */         }
/*     */         
/* 107 */         if (this.mp == null) {
/* 108 */           this.mp = new MessageProcessor(this.connectionId, this.rtspManager);
/*     */         }
/*     */         
/* 111 */         this.mp.processMessage(baos.toByteArray());
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 116 */         this.connectionIsAlive = false;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean eomReached(byte[] buffer) {
/* 122 */     boolean endReached = false;
/*     */     
/* 124 */     int size = buffer.length;
/*     */     
/* 126 */     if ((size >= 4) && 
/* 127 */       (buffer[(size - 4)] == 13) && (buffer[(size - 3)] == 10) && (buffer[(size - 2)] == 13) && (buffer[(size - 1)] == 10))
/*     */     {
/* 129 */       endReached = true;
/*     */     }
/*     */     
/*     */ 
/* 133 */     return endReached;
/*     */   }
/*     */   
/*     */ 
/*     */   private int getContentLength(String msg_header)
/*     */   {
/* 139 */     int start = msg_header.indexOf("Content-length");
/*     */     
/* 141 */     if (start == -1)
/*     */     {
/* 143 */       start = msg_header.indexOf("Content-Length");
/*     */     }
/*     */     int length;
/* 146 */     if (start == -1) {
/* 147 */       length = 0;
/*     */     } else {
/* 149 */       start = msg_header.indexOf(':', start) + 2;
/*     */       
/* 151 */       int end = msg_header.indexOf('\r', start);
/*     */       
/* 153 */       String length_str = msg_header.substring(start, end);
/*     */       
/* 155 */       length = new Integer(length_str).intValue();
/*     */     }
/*     */     
/* 158 */     return length;
/*     */   }
/*     */   
/*     */   public void cleanup() {
/* 162 */     Debug.println("RTSP::Connection:cleanup, id=" + this.connectionId);
/*     */     
/* 164 */     close();
/*     */     
/* 166 */     this.rtspManager.removeConnection(this.connectionId);
/*     */   }
/*     */   
/*     */   public void close() {
/* 170 */     this.connectionIsAlive = false;
/*     */     try
/*     */     {
/* 173 */       if (this.socket != null)
/*     */       {
/*     */ 
/* 176 */         this.socket.close();
/*     */         
/* 178 */         this.socket = null;
/*     */       }
/*     */     } catch (IOException e) {
/* 181 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getIpAddress() {
/* 186 */     return this.socket.getInetAddress().getHostAddress();
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\Connection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */