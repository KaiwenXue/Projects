package com.sun.media.rtsp;

public abstract interface TimerListener
{
  public abstract void timerExpired();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\TimerListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */