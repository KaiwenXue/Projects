/*    */ package com.sun.media.rtsp;
/*    */ 
/*    */ import com.sun.media.Log;
/*    */ import com.sun.media.rtsp.protocol.Message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageProcessor
/*    */ {
/*    */   private int connectionId;
/*    */   private RtspManager rtspManager;
/*    */   private byte[] buffer;
/*    */   
/*    */   public MessageProcessor(int connectionId, RtspManager rtspManager)
/*    */   {
/* 18 */     this.connectionId = connectionId;
/* 19 */     this.rtspManager = rtspManager;
/*    */     
/* 21 */     this.buffer = new byte[0];
/*    */   }
/*    */   
/*    */   public void processMessage(byte[] data) {
/* 25 */     Log.comment("incoming msg:");
/* 26 */     Log.comment(new String(data));
/*    */     
/* 28 */     Message message = new Message(data);
/*    */     
/* 30 */     this.rtspManager.dataIndication(this.connectionId, message);
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\MessageProcessor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */