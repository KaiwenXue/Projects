/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResponseMessage
/*    */ {
/*    */   private byte[] data;
/*    */   private Response response;
/*    */   
/*    */   public ResponseMessage(byte[] data)
/*    */   {
/* 17 */     this.data = data;
/*    */     
/* 19 */     parseResponse();
/*    */   }
/*    */   
/*    */   private void parseResponse() {
/* 23 */     this.response = new Response(new ByteArrayInputStream(this.data));
/*    */   }
/*    */   
/*    */   public Response getResponse() {
/* 27 */     return this.response;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\protocol\ResponseMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */