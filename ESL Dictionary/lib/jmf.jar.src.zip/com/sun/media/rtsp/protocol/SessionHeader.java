/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionHeader
/*    */ {
/*    */   private String sessionId;
/*    */   
/*    */ 
/*    */ 
/*    */   private long timeout;
/*    */   
/*    */ 
/*    */ 
/*    */   public SessionHeader(String str)
/*    */   {
/* 18 */     int index = str.indexOf(';');
/*    */     
/* 20 */     if (index > 0) {
/* 21 */       this.sessionId = str.substring(0, index);
/*    */       
/* 23 */       str = str.substring(index);
/*    */       
/* 25 */       index = str.indexOf('=');
/*    */       
/* 27 */       String seconds = str.substring(index + 1);
/*    */       try
/*    */       {
/* 30 */         this.timeout = new Long(seconds).longValue();
/*    */       } catch (NumberFormatException e) {
/* 32 */         this.timeout = 60L;
/*    */       }
/*    */     } else {
/* 35 */       this.sessionId = str;
/*    */     }
/*    */   }
/*    */   
/*    */   public String getSessionId() {
/* 40 */     return this.sessionId;
/*    */   }
/*    */   
/*    */   public long getTimeoutValue() {
/* 44 */     return this.timeout;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\protocol\SessionHeader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */