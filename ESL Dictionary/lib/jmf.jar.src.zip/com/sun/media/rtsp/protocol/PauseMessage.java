/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PauseMessage
/*    */   extends RequestMessage
/*    */ {
/*    */   public PauseMessage(byte[] data)
/*    */   {
/* 14 */     super(data);
/*    */   }
/*    */   
/*    */   public PauseMessage(String url, int sequenceNumber, int sessionId) {
/* 18 */     String msg = "PAUSE " + url + "RTSP/1.0" + "\r\n" + "CSeq: " + sequenceNumber + "\r\n" + "Session: " + sessionId + "\r\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\protocol\PauseMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */