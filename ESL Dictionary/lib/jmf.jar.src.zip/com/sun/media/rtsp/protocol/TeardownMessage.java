/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TeardownMessage
/*    */   extends RequestMessage
/*    */ {
/*    */   public TeardownMessage(byte[] data)
/*    */   {
/* 14 */     super(data);
/*    */   }
/*    */   
/*    */   public TeardownMessage(String url, int sequenceNumber, int sessionId) {
/* 18 */     String msg = "TEARDOWN " + url + "RTSP/1.0" + "\r\n" + "CSeq: " + sequenceNumber + "\r\n" + "Session: " + sessionId + "\r\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\protocol\TeardownMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */