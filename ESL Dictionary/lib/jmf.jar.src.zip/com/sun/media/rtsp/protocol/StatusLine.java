/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatusLine
/*    */   extends Parser
/*    */ {
/*    */   private String protocol;
/*    */   private int code;
/*    */   private String reason;
/*    */   
/*    */   public StatusLine(String input)
/*    */   {
/* 18 */     ByteArrayInputStream bin = new ByteArrayInputStream(input.getBytes());
/*    */     
/* 20 */     String protocol = getToken(bin);
/*    */     
/* 22 */     Debug.println("protocol : " + protocol);
/*    */     
/* 24 */     this.code = new Integer(getToken(bin)).intValue();
/*    */     
/* 26 */     Debug.println("code     : " + this.code);
/*    */     
/* 28 */     this.reason = getStringToken(bin);
/*    */     
/* 30 */     Debug.println("reason   : " + this.reason);
/*    */   }
/*    */   
/*    */   public String getReason() {
/* 34 */     return this.reason;
/*    */   }
/*    */   
/*    */   public int getCode() {
/* 38 */     return this.code;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\protocol\StatusLine.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */