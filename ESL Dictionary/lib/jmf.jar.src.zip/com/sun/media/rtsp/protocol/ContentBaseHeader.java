/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentBaseHeader
/*    */ {
/*    */   private String contentBase;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ContentBaseHeader(String contentBase)
/*    */   {
/* 26 */     this.contentBase = contentBase;
/*    */   }
/*    */   
/*    */   public String getContentBase() {
/* 30 */     return this.contentBase;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\protocol\ContentBaseHeader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */