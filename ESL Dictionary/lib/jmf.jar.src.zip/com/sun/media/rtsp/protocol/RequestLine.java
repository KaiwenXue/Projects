/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequestLine
/*    */   extends Parser
/*    */ {
/*    */   private String url;
/*    */   private String version;
/*    */   
/*    */   public RequestLine(String input)
/*    */   {
/* 19 */     ByteArrayInputStream bin = new ByteArrayInputStream(input.getBytes());
/*    */     
/* 21 */     String method = getToken(bin);
/*    */     
/* 23 */     Debug.println("method  : " + method);
/*    */     
/* 25 */     this.url = getToken(bin);
/*    */     
/* 27 */     Debug.println("url     : " + this.url);
/*    */     
/* 29 */     this.version = getToken(bin);
/*    */     
/* 31 */     Debug.println("version : " + this.version);
/*    */   }
/*    */   
/*    */   public String getUrl() {
/* 35 */     return this.url;
/*    */   }
/*    */   
/*    */   public String getVersion() {
/* 39 */     return this.version;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\protocol\RequestLine.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */