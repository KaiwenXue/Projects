/*     */ package com.sun.media.rtsp.protocol;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Parser
/*     */ {
/*     */   private Vector buffer;
/*     */   
/*     */   public Parser()
/*     */   {
/*  16 */     init();
/*     */   }
/*     */   
/*     */   public int readChar(ByteArrayInputStream bin)
/*     */   {
/*     */     int ch;
/*  22 */     if (this.buffer.size() > 0) {
/*  23 */       ch = ((Integer)this.buffer.elementAt(0)).intValue();
/*     */       
/*  25 */       this.buffer.removeElementAt(0);
/*     */     } else {
/*  27 */       ch = bin.read();
/*     */     }
/*     */     
/*  30 */     return ch;
/*     */   }
/*     */   
/*     */   public String getToken(ByteArrayInputStream bin) {
/*  34 */     ByteArrayOutputStream bout = new ByteArrayOutputStream();
/*     */     
/*  36 */     skipWhitespace(bin);
/*     */     
/*  38 */     if (bin.available() > 0) {
/*  39 */       int ch = readChar(bin);
/*     */       
/*  41 */       while ((ch != 32) && (ch != 10) && (ch != 13) && (ch != -1)) {
/*  42 */         bout.write(ch);
/*     */         
/*  44 */         ch = readChar(bin);
/*     */       }
/*     */       
/*  47 */       ungetChar(ch);
/*     */     }
/*     */     
/*  50 */     String token = new String(bout.toByteArray());
/*     */     
/*  52 */     return token;
/*     */   }
/*     */   
/*     */   public void ungetChar(int ch) {
/*  56 */     this.buffer.insertElementAt(new Integer(ch), 0);
/*     */   }
/*     */   
/*     */   public String getLine(ByteArrayInputStream bin) {
/*  60 */     ByteArrayOutputStream bout = new ByteArrayOutputStream();
/*     */     
/*  62 */     int ch = readChar(bin);
/*     */     
/*  64 */     while ((ch != 10) && (ch != 13) && (ch != -1)) {
/*  65 */       bout.write(ch);
/*     */       
/*  67 */       ch = readChar(bin);
/*     */     }
/*     */     
/*  70 */     ch = readChar(bin);
/*     */     
/*  72 */     if (ch != 10) {
/*  73 */       ungetChar(ch);
/*     */     }
/*     */     
/*  76 */     String line = new String(bout.toByteArray());
/*     */     
/*  78 */     return line;
/*     */   }
/*     */   
/*     */   public String getStringToken(ByteArrayInputStream bin) {
/*  82 */     ByteArrayOutputStream bout = new ByteArrayOutputStream();
/*     */     
/*  84 */     skipWhitespace(bin);
/*     */     
/*  86 */     int ch = readChar(bin);
/*     */     
/*  88 */     while ((ch != 10) && (ch != 13) && (ch != -1)) {
/*  89 */       bout.write(ch);
/*     */       
/*  91 */       ch = readChar(bin);
/*     */     }
/*     */     
/*  94 */     String token = new String(bout.toByteArray());
/*     */     
/*  96 */     return token;
/*     */   }
/*     */   
/*     */   public byte[] getContent(ByteArrayInputStream bin) {
/* 100 */     ByteArrayOutputStream bout = new ByteArrayOutputStream();
/*     */     
/* 102 */     skipWhitespace(bin);
/*     */     
/* 104 */     int ch = readChar(bin);
/*     */     
/* 106 */     while (ch != -1) {
/* 107 */       bout.write(ch);
/*     */       
/* 109 */       ch = readChar(bin);
/*     */     }
/*     */     
/* 112 */     return bout.toByteArray();
/*     */   }
/*     */   
/*     */   private void skipWhitespace(ByteArrayInputStream bin) {
/* 116 */     int ch = readChar(bin);
/*     */     
/* 118 */     while ((ch == 32) || (ch == 10) || (ch == 13)) {
/* 119 */       ch = readChar(bin);
/*     */     }
/*     */     
/* 122 */     ungetChar(ch);
/*     */   }
/*     */   
/*     */   private void init() {
/* 126 */     this.buffer = new Vector();
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\protocol\Parser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */