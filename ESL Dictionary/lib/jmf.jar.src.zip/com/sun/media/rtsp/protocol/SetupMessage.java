/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetupMessage
/*    */   extends RequestMessage
/*    */ {
/*    */   public SetupMessage(byte[] data)
/*    */   {
/* 14 */     super(data);
/*    */   }
/*    */   
/*    */   public SetupMessage(String url, int sequenceNumber, int port_lo, int port_hi) {
/* 18 */     String msg = "SETUP " + url + "RTSP/1.0" + "\r\n" + "CSeq: " + sequenceNumber + "\r\n" + "Transport: RTP/AVP;unicast;client_port=" + port_lo + "-" + port_hi;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\protocol\SetupMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */