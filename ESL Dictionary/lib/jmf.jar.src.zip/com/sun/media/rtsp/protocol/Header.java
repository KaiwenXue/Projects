/*     */ package com.sun.media.rtsp.protocol;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Header
/*     */   extends Parser
/*     */ {
/*     */   public int type;
/*     */   public Object parameter;
/*     */   public int contentLength;
/*     */   public static final int TRANSPORT = 1;
/*     */   public static final int CSEQ = 2;
/*     */   public static final int SESSION = 3;
/*     */   public static final int DURATION = 4;
/*     */   public static final int RANGE = 5;
/*     */   public static final int DATE = 6;
/*     */   public static final int SERVER = 7;
/*     */   public static final int CONTENT_TYPE = 8;
/*     */   public static final int CONTENT_BASE = 9;
/*     */   public static final int CONTENT_LENGTH = 10;
/*     */   
/*     */   public Header(String input)
/*     */   {
/*  31 */     ByteArrayInputStream bin = new ByteArrayInputStream(input.getBytes());
/*     */     
/*  33 */     String id = getToken(bin);
/*     */     String tmp;
/*  35 */     if (id.equalsIgnoreCase("CSeq:")) {
/*  36 */       this.type = 2;
/*     */       
/*  38 */       String number = getStringToken(bin).trim();
/*     */       
/*  40 */       this.parameter = new CSeqHeader(number);
/*  41 */     } else if (id.equalsIgnoreCase("Transport:")) {
/*  42 */       this.type = 1;
/*     */       
/*  44 */       String tx = getToken(bin);
/*     */       
/*  46 */       this.parameter = new TransportHeader(tx);
/*  47 */     } else if (id.equalsIgnoreCase("Session:")) {
/*  48 */       this.type = 3;
/*     */       
/*  50 */       String tx = getToken(bin);
/*     */       
/*  52 */       this.parameter = new SessionHeader(tx);
/*  53 */     } else if (id.equalsIgnoreCase("Duration:")) {
/*  54 */       this.type = 4;
/*     */       
/*  56 */       String tx = getToken(bin);
/*     */       
/*  58 */       Debug.println("Duration : " + tx);
/*     */       
/*  60 */       this.parameter = new DurationHeader(tx);
/*  61 */     } else if (id.equalsIgnoreCase("Range:")) {
/*  62 */       this.type = 5;
/*     */       
/*  64 */       String tx = getToken(bin);
/*     */       
/*  66 */       this.parameter = new RangeHeader(tx); } else { String date;
/*  67 */       if (id.equalsIgnoreCase("Date:")) {
/*  68 */         this.type = 6;
/*     */         
/*  70 */         date = getStringToken(bin);
/*     */       } else {
/*     */         String entries;
/*  73 */         if (id.equalsIgnoreCase("Allow:")) {
/*  74 */           this.type = 6;
/*     */           
/*  76 */           entries = getStringToken(bin);
/*     */         } else {
/*     */           String server;
/*  79 */           if (id.equalsIgnoreCase("Server:")) {
/*  80 */             this.type = 7;
/*     */             
/*  82 */             server = getStringToken(bin);
/*     */           } else {
/*     */             String content_type;
/*  85 */             if (id.equalsIgnoreCase("Content-Type:")) {
/*  86 */               this.type = 8;
/*     */               
/*  88 */               content_type = getStringToken(bin);
/*     */ 
/*     */             }
/*  91 */             else if (id.equalsIgnoreCase("Content-Base:")) {
/*  92 */               this.type = 9;
/*  93 */               String content_base = getStringToken(bin);
/*     */               
/*  95 */               this.parameter = new ContentBaseHeader(content_base);
/*  96 */             } else if (id.equalsIgnoreCase("Content-Length:")) {
/*  97 */               this.type = 10;
/*     */               
/*  99 */               String content_length = getStringToken(bin);
/*     */               
/*     */ 
/*     */ 
/* 103 */               this.contentLength = new Integer(content_length).intValue(); } else { String date;
/* 104 */               if (id.equalsIgnoreCase("Last-Modified:")) {
/* 105 */                 date = getStringToken(bin);
/*     */               } else {
/*     */                 String rtpInfo;
/* 108 */                 if (id.equalsIgnoreCase("RTP-Info:")) {
/* 109 */                   rtpInfo = getStringToken(bin);
/*     */ 
/*     */                 }
/* 112 */                 else if (id.length() > 0) {
/* 113 */                   Debug.println("unknown id : <" + id + ">");
/*     */                   
/* 115 */                   tmp = getStringToken(bin);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\protocol\Header.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */