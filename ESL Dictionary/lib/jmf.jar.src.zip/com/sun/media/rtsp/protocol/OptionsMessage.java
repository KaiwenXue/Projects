/*    */ package com.sun.media.rtsp.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptionsMessage
/*    */   extends RequestMessage
/*    */ {
/*    */   public OptionsMessage(byte[] data)
/*    */   {
/* 14 */     super(data);
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\protocol\OptionsMessage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */