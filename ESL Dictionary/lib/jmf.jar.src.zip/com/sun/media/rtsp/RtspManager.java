/*     */ package com.sun.media.rtsp;
/*     */ 
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.rtsp.protocol.Message;
/*     */ import java.io.PrintStream;
/*     */ import java.net.ConnectException;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RtspManager
/*     */ {
/*     */   private Vector listeners;
/*     */   private int connectionCounter;
/*     */   private Vector connections;
/*     */   private String address;
/*     */   private int port;
/*     */   
/*     */   public RtspManager()
/*     */   {
/*  24 */     this.listeners = new Vector();
/*     */     
/*  26 */     this.connections = new Vector();
/*     */     
/*  28 */     Server server = new Server(this);
/*     */     
/*  30 */     server.start();
/*     */   }
/*     */   
/*     */   public RtspManager(boolean server_socket) {
/*  34 */     this.listeners = new Vector();
/*     */     
/*  36 */     this.connections = new Vector();
/*     */     
/*  38 */     if (server_socket) {
/*  39 */       Server server = new Server(this);
/*     */       
/*  41 */       server.start();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean sendMessage(int connectionId, String message) {
/*  46 */     Log.comment("outgoing msg:");
/*  47 */     Log.comment(message);
/*     */     
/*  49 */     Connection connection = getConnection(connectionId);
/*     */     
/*     */     boolean success;
/*     */     
/*  53 */     if (connection == null) {
/*  54 */       success = false;
/*     */     } else {
/*  56 */       success = connection.sendData(message.getBytes());
/*     */     }
/*     */     
/*  59 */     return success;
/*     */   }
/*     */   
/*     */   public void dataIndication(int connectionId, Message message) {
/*  63 */     for (int i = 0; i < this.listeners.size(); i++) {
/*  64 */       RtspListener listener = (RtspListener)this.listeners.elementAt(i);
/*     */       
/*  66 */       listener.rtspMessageIndication(connectionId, message);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addListener(RtspListener listener) {
/*  71 */     this.listeners.addElement(listener);
/*     */   }
/*     */   
/*     */   public void removeListener(RtspListener listener) {
/*  75 */     this.listeners.removeElement(listener);
/*     */   }
/*     */   
/*     */   public int createConnection(String address, int port) {
/*  79 */     this.address = address;
/*  80 */     this.port = port;
/*     */     
/*  82 */     int connectionId = -1;
/*     */     try
/*     */     {
/*  85 */       Connection connection = new Connection(this, this.connectionCounter + 1, address.getBytes(), port);
/*     */       
/*     */ 
/*  88 */       this.connections.addElement(connection);
/*     */       
/*  90 */       connectionId = connection.connectionId;
/*     */       
/*  92 */       this.connectionCounter += 1;
/*     */     } catch (UnknownHostException e) {
/*  94 */       Log.error("[EXCEPTION]: Unknown host.");
/*     */       
/*  96 */       connectionId = -2;
/*     */     }
/*     */     catch (ConnectException e) {
/*  99 */       Log.error("[EXCEPTION]: Can't connect to server.");
/*     */       
/* 101 */       connectionId = -3;
/*     */     }
/*     */     
/* 104 */     return connectionId;
/*     */   }
/*     */   
/*     */   public void addConnection(Socket socket) {
/* 108 */     this.connectionCounter += 1;
/*     */     
/* 110 */     Connection connection = new Connection(this, this.connectionCounter, socket);
/*     */     
/* 112 */     this.connections.addElement(connection);
/*     */   }
/*     */   
/*     */   public void removeConnection(int connectionId) {
/* 116 */     Connection connection = getConnection(connectionId);
/*     */     
/* 118 */     this.connections.removeElement(connection);
/*     */     
/* 120 */     for (int i = 0; i < this.listeners.size(); i++) {
/* 121 */       RtspListener listener = (RtspListener)this.listeners.elementAt(i);
/*     */       
/* 123 */       listener.rtspConnectionTerminated(connectionId);
/*     */     }
/*     */   }
/*     */   
/*     */   public void closeConnection(int connectionId) {
/* 128 */     Connection connection = getConnection(connectionId);
/*     */     
/* 130 */     if (connection != null) {
/* 131 */       connection.close();
/*     */       
/* 133 */       this.connections.removeElement(connection);
/*     */     } else {
/* 135 */       System.out.println("connection not found!");
/*     */     }
/*     */   }
/*     */   
/*     */   public Connection getConnection(int connectionId) {
/* 140 */     Connection connection = null;
/*     */     
/* 142 */     for (int i = 0; i < this.connections.size(); i++) {
/* 143 */       Connection tmpConnection = (Connection)this.connections.elementAt(i);
/*     */       
/* 145 */       if (tmpConnection.connectionId == connectionId) {
/* 146 */         connection = tmpConnection;
/*     */         
/* 148 */         break;
/*     */       }
/*     */     }
/*     */     
/* 152 */     return connection;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\RtspManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */