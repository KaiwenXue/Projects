package com.sun.media.rtsp;

public abstract interface RtspAppListener
{
  public abstract void streamsReceivedEvent();
  
  public abstract void postStatusMessage(int paramInt, String paramString);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\RtspAppListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */