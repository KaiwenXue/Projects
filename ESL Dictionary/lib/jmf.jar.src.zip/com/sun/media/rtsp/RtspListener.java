package com.sun.media.rtsp;

import com.sun.media.rtsp.protocol.Message;

public abstract interface RtspListener
{
  public abstract void rtspMessageIndication(int paramInt, Message paramMessage);
  
  public abstract void rtspConnectionTerminated(int paramInt);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\RtspListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */