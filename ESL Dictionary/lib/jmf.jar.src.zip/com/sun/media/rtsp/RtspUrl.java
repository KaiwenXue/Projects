/*    */ package com.sun.media.rtsp;
/*    */ 
/*    */ import java.net.MalformedURLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RtspUrl
/*    */ {
/*    */   private String url;
/*    */   
/*    */   public RtspUrl(String url)
/*    */     throws MalformedURLException
/*    */   {
/* 15 */     this.url = url;
/*    */     
/* 17 */     if (url.length() < 7) {
/* 18 */       throw new MalformedURLException();
/*    */     }
/*    */     
/* 21 */     if (!url.startsWith("rtsp://")) {
/* 22 */       throw new MalformedURLException();
/*    */     }
/*    */   }
/*    */   
/*    */   public String getFile() {
/* 27 */     String str = this.url.substring(7);
/*    */     
/* 29 */     int start = str.indexOf('/');
/*    */     
/* 31 */     String file = "";
/*    */     
/* 33 */     if (start != -1) {
/* 34 */       file = str.substring(start + 1);
/*    */     }
/*    */     
/* 37 */     return file;
/*    */   }
/*    */   
/*    */   public String getHost() {
/* 41 */     String host = null;
/*    */     
/* 43 */     String str = this.url.substring(7);
/*    */     
/* 45 */     int end = str.indexOf(':');
/*    */     
/* 47 */     if (end == -1) {
/* 48 */       end = str.indexOf('/');
/*    */       
/* 50 */       if (end == -1) {
/* 51 */         host = str;
/*    */       } else {
/* 53 */         host = str.substring(0, end);
/*    */       }
/*    */     } else {
/* 56 */       host = str.substring(0, end);
/*    */     }
/*    */     
/* 59 */     return host;
/*    */   }
/*    */   
/*    */   public int getPort() {
/* 63 */     int port = 554;
/*    */     
/* 65 */     String str = this.url.substring(7);
/*    */     
/* 67 */     int start = str.indexOf(':');
/*    */     
/* 69 */     if (start != -1) {
/* 70 */       int end = str.indexOf('/');
/*    */       
/* 72 */       port = new Integer(str.substring(start + 1, end)).intValue();
/*    */     }
/*    */     
/* 75 */     return port;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\RtspUrl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */