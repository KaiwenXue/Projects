/*    */ package com.sun.media.rtsp;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.net.InetAddress;
/*    */ import java.net.ServerSocket;
/*    */ import java.net.Socket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Server
/*    */   extends Thread
/*    */ {
/*    */   private RtspManager rtspManager;
/*    */   private ServerSocket serverSocket;
/*    */   
/*    */   public Server(RtspManager rtspManager)
/*    */   {
/* 20 */     this.rtspManager = rtspManager;
/*    */     try
/*    */     {
/* 23 */       this.serverSocket = new ServerSocket(RtspPort.getPort());
/*    */       
/* 25 */       System.err.println("Server Socket: " + this.serverSocket.toString());
/* 26 */       this.serverSocket.getInetAddress();System.err.println("Socket is connected to: " + InetAddress.getLocalHost());
/*    */       
/* 28 */       System.err.println("Local port: " + this.serverSocket.getLocalPort());
/*    */     } catch (IOException e) {
/* 30 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */   
/*    */   public void run() {
/* 35 */     Debug.println("Server running...");
/*    */     
/* 37 */     if (this.serverSocket == null) {
/* 38 */       return;
/*    */     }
/*    */     
/*    */     for (;;)
/*    */     {
/*    */       try
/*    */       {
/* 45 */         Debug.println("accepting...");
/*    */         
/* 47 */         Socket socket = this.serverSocket.accept();
/*    */         
/* 49 */         this.rtspManager.addConnection(socket);
/*    */       } catch (IOException e) {
/* 51 */         e.printStackTrace();
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void shutdown() {
/*    */     try {
/* 58 */       Debug.println("...closing server socket");
/*    */       
/* 60 */       this.serverSocket.close();
/*    */     } catch (IOException e) {
/* 62 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtsp\Server.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */