/*     */ package com.sun.media.protocol;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.util.MediaThread;
/*     */ import com.sun.media.util.Registry;
/*     */ import com.sun.media.util.jdk12;
/*     */ import com.sun.media.util.jdk12CreateThreadRunnableAction;
/*     */ import com.sun.media.util.jdk12DeleteFileAction;
/*     */ import com.sun.media.util.jdk12MakeDirectoryAction;
/*     */ import com.sun.media.util.jdk12PriorityAction;
/*     */ import com.sun.media.util.jdk12RandomAccessFileAction;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.DownloadProgressListener;
/*     */ import javax.media.protocol.CachedStream;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.PullSourceStream;
/*     */ import javax.media.protocol.Seekable;
/*     */ 
/*     */ 
/*     */ public class CachedPullSourceStream
/*     */   implements Runnable, PullSourceStream, Seekable, CachedStream
/*     */ {
/*     */   private InputStream stream;
/*  33 */   private RandomAccessFile readRAF = null;
/*  34 */   private RandomAccessFile writeRAF = null;
/*     */   private String fileName;
/*  36 */   private int bufferSize = 2048;
/*  37 */   private byte[] buffer = new byte[this.bufferSize];
/*  38 */   private boolean eosReached = false;
/*  39 */   private boolean ioException = false;
/*     */   private long length;
/*     */   private File file;
/*     */   private String protocol;
/*  43 */   private boolean readAborted = false;
/*  44 */   private boolean paused = false;
/*  45 */   private boolean abort = false;
/*     */   private MediaThread downloadThread;
/*     */   private long contentLength;
/*  48 */   private int highMarkFactor = 10;
/*     */   
/*     */ 
/*  51 */   private boolean blockRead = true;
/*  52 */   private static int MAX_HIGH_MARK = 2000000;
/*  53 */   private static int DEFAULT_HIGH_MARK = 1000000;
/*  54 */   private static int MIN_HIGH_MARK = 8192;
/*  55 */   private int highMark = DEFAULT_HIGH_MARK;
/*  56 */   private int lowMark = 0;
/*     */   
/*     */ 
/*  59 */   private boolean enabled = true;
/*     */   
/*  61 */   private boolean jitterEnabled = true;
/*     */   
/*  63 */   private DownloadProgressListener listener = null;
/*  64 */   private int numKiloBytesUpdateIncrement = -1;
/*  65 */   private boolean closed = true;
/*     */   
/*  67 */   private static JMFSecurity jmfSecurity = null;
/*  68 */   private static boolean securityPrivelege = false;
/*  69 */   private Method[] m = new Method[1];
/*  70 */   private Class[] cl = new Class[1];
/*  71 */   private Object[][] args = new Object[1][0];
/*     */   
/*  73 */   private int maxCacheSize = Integer.MAX_VALUE;
/*     */   
/*     */   static {
/*     */     try {
/*  77 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  78 */       securityPrivelege = true;
/*     */     }
/*     */     catch (SecurityException e) {}
/*     */   }
/*     */   
/*     */   public CachedPullSourceStream(InputStream stream, String fileName, long contentLength, String protocol)
/*     */     throws IOException
/*     */   {
/*  86 */     this.stream = stream;
/*  87 */     this.contentLength = contentLength;
/*  88 */     this.fileName = fileName;
/*  89 */     this.protocol = protocol;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */     if (jmfSecurity != null) {
/*  97 */       String permission = null;
/*  98 */       int permissionid = 0;
/*     */       try {
/* 100 */         if (jmfSecurity.getName().startsWith("jmf-security"))
/*     */         {
/*     */           try
/*     */           {
/* 104 */             permission = "thread";
/* 105 */             jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/* 106 */             this.m[0].invoke(this.cl[0], this.args[0]);
/*     */             
/* 108 */             permission = "thread group";
/* 109 */             jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/* 110 */             this.m[0].invoke(this.cl[0], this.args[0]);
/*     */           }
/*     */           catch (Throwable t) {}
/*     */           
/*     */ 
/* 115 */           permission = "read file";
/* 116 */           permissionid = 2;
/* 117 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 2);
/* 118 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */           
/*     */ 
/* 121 */           permission = "write file";
/* 122 */           permissionid = 4;
/* 123 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 4);
/* 124 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */           
/* 126 */           permission = "delete file";
/* 127 */           permissionid = 8;
/* 128 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 8);
/* 129 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */         }
/* 131 */         else if (jmfSecurity.getName().startsWith("internet")) {
/* 132 */           PolicyEngine.checkPermission(PermissionID.FILEIO);
/* 133 */           PolicyEngine.assertPermission(PermissionID.FILEIO);
/*     */           try {
/* 135 */             PolicyEngine.checkPermission(PermissionID.THREAD);
/* 136 */             PolicyEngine.assertPermission(PermissionID.THREAD);
/*     */ 
/*     */           }
/*     */           catch (Throwable t) {}
/*     */         }
/*     */         
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 145 */         if (permissionid > 0)
/* 146 */           jmfSecurity.permissionFailureNotification(permissionid);
/* 147 */         securityPrivelege = false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 154 */     if (!securityPrivelege)
/*     */     {
/* 156 */       throw new IOException("No security privilege for caching");
/*     */     }
/*     */     
/* 159 */     createFilesAndThread(fileName);
/*     */     
/* 161 */     Object cdir = Registry.get("secure.maxCacheSizeMB");
/*     */     
/* 163 */     if ((cdir != null) && ((cdir instanceof Integer))) {
/* 164 */       int size = ((Integer)cdir).intValue();
/* 165 */       if (size < 1)
/* 166 */         size = 1;
/* 167 */       this.maxCacheSize = (size * 1000000);
/*     */     }
/*     */     
/* 170 */     this.highMark = getHighMark(contentLength);
/* 171 */     this.closed = false;
/*     */   }
/*     */   
/*     */   private int getHighMark(long contentLength)
/*     */   {
/* 176 */     if (contentLength <= 0L) {
/* 177 */       return DEFAULT_HIGH_MARK;
/*     */     }
/* 179 */     long tryHighMark = contentLength / this.highMarkFactor;
/*     */     
/* 181 */     if (tryHighMark < MIN_HIGH_MARK) {
/* 182 */       tryHighMark = MIN_HIGH_MARK;
/* 183 */     } else if (tryHighMark > MAX_HIGH_MARK)
/* 184 */       tryHighMark = MAX_HIGH_MARK;
/* 185 */     return (int)tryHighMark;
/*     */   }
/*     */   
/*     */   public void setEnabledBuffering(boolean b)
/*     */   {
/* 190 */     this.jitterEnabled = b;
/*     */   }
/*     */   
/*     */   public boolean getEnabledBuffering() {
/* 194 */     return this.jitterEnabled;
/*     */   }
/*     */   
/*     */   private void createFilesAndThread(String fileName) throws IOException
/*     */   {
/*     */     try {
/* 200 */       this.file = new File(fileName);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 207 */       String parent = this.file.getParent();
/* 208 */       File parentFile = null;
/* 209 */       if (parent != null) {
/* 210 */         parentFile = new File(parent);
/*     */       }
/*     */       
/*     */ 
/* 214 */       if ((securityPrivelege) && (jmfSecurity != null) && (jmfSecurity.getName().startsWith("jdk12")))
/*     */       {
/*     */ 
/* 217 */         if (parentFile != null) {
/* 218 */           cons = jdk12MakeDirectoryAction.cons;
/*     */           
/* 220 */           Boolean success = (Boolean)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { parentFile }) });
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 228 */           if ((success == null) || (!success.booleanValue())) {
/* 229 */             throw new IOException("Unable to create directory " + parentFile);
/*     */           }
/*     */         }
/*     */         
/* 233 */         Constructor cons = jdk12RandomAccessFileAction.cons;
/*     */         
/* 235 */         this.writeRAF = ((RandomAccessFile)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { this.file.getPath(), "rw" }) }));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 244 */         if (this.writeRAF == null) {
/* 245 */           throw new IOException("Cannot create cache file");
/*     */         }
/*     */         
/* 248 */         this.readRAF = ((RandomAccessFile)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { this.file.getPath(), "r" }) }));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 257 */         if (this.readRAF == null) {
/* 258 */           throw new IOException("Cannot create cache file");
/*     */         }
/*     */         
/* 261 */         cons = jdk12CreateThreadRunnableAction.cons;
/*     */         
/* 263 */         this.downloadThread = ((MediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { MediaThread.class, this }) }));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 272 */         this.downloadThread.setName("download");
/* 273 */         cons = jdk12PriorityAction.cons;
/* 274 */         jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { this.downloadThread, new Integer(MediaThread.getVideoPriority()) }) });
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 284 */         if ((parentFile != null) && 
/* 285 */           (!parentFile.exists()) && (!parentFile.mkdirs())) {
/* 286 */           throw new IOException("Unable to create directory " + parentFile);
/*     */         }
/*     */         
/* 289 */         this.writeRAF = new RandomAccessFile(this.file, "rw");
/* 290 */         this.readRAF = new RandomAccessFile(this.file, "r");
/*     */         
/* 292 */         this.downloadThread = new MediaThread(this, "download");
/* 293 */         this.downloadThread.useVideoPriority();
/*     */       }
/*     */     }
/*     */     catch (Throwable e) {
/* 297 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized void setLength(long length) {
/* 302 */     this.length = length;
/*     */   }
/*     */   
/*     */   private synchronized long getLength()
/*     */   {
/* 307 */     return this.length;
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/* 312 */     int totalBytesRead = 0;
/* 313 */     int nextUpdate = this.numKiloBytesUpdateIncrement;
/* 314 */     int debugIndex = 1;
/*     */     
/* 316 */     if (this.ioException) {
/* 317 */       return;
/*     */     }
/* 319 */     while (!this.eosReached)
/*     */     {
/* 321 */       if (this.abort)
/*     */       {
/* 323 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 342 */         if ((this.contentLength > 0L) && (!this.protocol.equals("https"))) {
/* 343 */           while (this.stream.available() == 0) {
/* 344 */             synchronized (this) {
/*     */               try {
/* 346 */                 wait(25L);
/*     */               }
/*     */               catch (InterruptedException e) {}
/*     */             }
/* 350 */             if (this.abort)
/*     */             {
/* 352 */               return;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 357 */         while (this.paused)
/*     */         {
/* 359 */           synchronized (this)
/*     */           {
/*     */             try
/*     */             {
/* 363 */               wait(1000L);
/*     */             }
/*     */             catch (InterruptedException e) {}
/* 366 */             if (this.abort)
/*     */             {
/* 368 */               return;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 373 */         int bytesRead = this.stream.read(this.buffer, 0, this.buffer.length);
/* 374 */         if (bytesRead != -1) {
/* 375 */           if (getLength() + bytesRead > this.maxCacheSize) {
/* 376 */             Log.warning("MAX CACHESIZE of " + this.maxCacheSize + " reached ");
/*     */             
/* 378 */             this.contentLength = totalBytesRead;
/* 379 */             this.eosReached = true;
/*     */           }
/* 381 */           this.writeRAF.write(this.buffer, 0, bytesRead);
/* 382 */           totalBytesRead += bytesRead;
/*     */           
/* 384 */           long length = totalBytesRead;
/* 385 */           setLength(length);
/*     */           
/* 387 */           if (length == this.contentLength) {
/* 388 */             this.eosReached = true;
/*     */           }
/*     */           
/*     */ 
/* 392 */           if ((this.listener != null) && 
/* 393 */             (totalBytesRead >= nextUpdate)) {
/* 394 */             this.listener.downloadUpdate();
/* 395 */             nextUpdate += this.numKiloBytesUpdateIncrement;
/*     */           }
/*     */           
/*     */         }
/*     */         else
/*     */         {
/* 401 */           setLength(totalBytesRead);
/* 402 */           this.contentLength = totalBytesRead;
/* 403 */           this.eosReached = true;
/*     */         }
/* 405 */         loadUpdate();
/*     */       } catch (IOException e) {
/* 407 */         Log.warning(e + " : Check if you have enough space in the cache directory");
/* 408 */         this.ioException = true;
/* 409 */         this.eosReached = true;
/* 410 */         this.blockRead = false;
/* 411 */         break;
/*     */       }
/*     */     }
/*     */     
/* 415 */     if (this.listener != null) {
/* 416 */       this.listener.downloadUpdate();
/*     */     }
/*     */     
/* 419 */     if (this.writeRAF != null) {
/*     */       try {
/* 421 */         this.writeRAF.close();
/* 422 */         this.writeRAF = null;
/*     */       }
/*     */       catch (IOException e) {}
/* 425 */       this.writeRAF = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void startDownload()
/*     */   {
/* 440 */     if ((this.enabled) && 
/* 441 */       (this.downloadThread != null)) {
/* 442 */       this.downloadThread.start();
/*     */     }
/*     */   }
/*     */   
/*     */   void pauseDownload()
/*     */   {
/* 448 */     if ((this.downloadThread != null) && (!this.downloadThread.isAlive()))
/* 449 */       return;
/* 450 */     if (this.enabled) {
/* 451 */       synchronized (this) {
/* 452 */         if (!this.paused) {
/* 453 */           this.paused = true;
/*     */           
/* 455 */           notify();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void resumeDownload()
/*     */   {
/* 463 */     if ((this.downloadThread != null) && (!this.downloadThread.isAlive()))
/* 464 */       return;
/* 465 */     if (this.enabled) {
/* 466 */       synchronized (this) {
/* 467 */         if (this.paused) {
/* 468 */           this.paused = false;
/*     */           
/* 470 */           notify();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void abortDownload()
/*     */   {
/* 479 */     this.abort = true;
/*     */   }
/*     */   
/*     */   public void abortRead()
/*     */   {
/* 484 */     synchronized (this) {
/* 485 */       this.readAborted = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private long getWriteReadPtrOffset()
/*     */   {
/* 555 */     return getLength() - tell();
/*     */   }
/*     */   
/*     */ 
/*     */   private synchronized void loadUpdate()
/*     */   {
/* 561 */     if ((this.blockRead) && (
/* 562 */       (this.eosReached) || (getWriteReadPtrOffset() >= this.highMark)))
/*     */     {
/*     */ 
/* 565 */       this.blockRead = false;
/* 566 */       synchronized (this) {
/* 567 */         notify();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized boolean drainCondition()
/*     */   {
/* 574 */     return drainCondition(tell());
/*     */   }
/*     */   
/*     */   private synchronized boolean drainCondition(long offset) {
/* 578 */     offset = getLength() - offset;
/* 579 */     if (this.eosReached) {
/* 580 */       if (this.blockRead) {
/* 581 */         this.blockRead = false;
/* 582 */         notify();
/*     */       }
/* 584 */       return false;
/*     */     }
/*     */     
/* 587 */     if (this.blockRead) {
/* 588 */       if (offset < this.highMark) {
/* 589 */         return true;
/*     */       }
/* 591 */       this.blockRead = false;
/* 592 */       notify();
/* 593 */       return false;
/*     */     }
/*     */     
/* 596 */     if (offset < this.lowMark) {
/* 597 */       this.blockRead = true;
/* 598 */       return true;
/*     */     }
/* 600 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean willReadBytesBlock(long offset, int numBytes)
/*     */   {
/* 606 */     if ((this.jitterEnabled) && (drainCondition(offset))) {
/* 607 */       return true;
/*     */     }
/* 609 */     return offset + numBytes > getLength();
/*     */   }
/*     */   
/*     */   public boolean willReadBytesBlock(int numBytes) {
/* 613 */     return willReadBytesBlock(tell(), numBytes);
/*     */   }
/*     */   
/*     */   private int waitUntilSeekWillSucceed(long where) throws IOException
/*     */   {
/* 618 */     boolean debugPrint = true;
/*     */     
/*     */ 
/* 621 */     if ((!this.jitterEnabled) || (!drainCondition(where)))
/*     */     {
/* 623 */       if (where <= getLength()) {
/* 624 */         return 0;
/*     */       }
/*     */     }
/*     */     for (;;)
/*     */     {
/* 629 */       if (this.eosReached) {
/* 630 */         if (where <= getLength()) {
/* 631 */           return 0;
/*     */         }
/*     */         
/* 634 */         return -1;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 639 */       if (this.jitterEnabled) {
/* 640 */         synchronized (this) {
/* 641 */           while (this.blockRead) {
/*     */             try {
/* 643 */               wait(100L);
/*     */             }
/*     */             catch (InterruptedException e) {}
/* 646 */             if (this.readAborted) {
/* 647 */               e = -2;return e;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 654 */       if (this.readAborted) {
/* 655 */         return -2;
/*     */       }
/*     */       
/* 658 */       if (where <= getLength()) {
/* 659 */         return 0;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 668 */         Thread.currentThread();Thread.sleep(250L);
/*     */       }
/*     */       catch (InterruptedException e) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long tell()
/*     */   {
/* 680 */     synchronized (this) {
/* 681 */       if (this.closed) {
/* 682 */         long l1 = -1L;return l1;
/*     */       }
/* 684 */       try { long l2 = this.readRAF.getFilePointer();return l2;
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 688 */         long l3 = -1L;return l3;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized long doSeek(long where)
/*     */   {
/* 698 */     if (this.closed)
/* 699 */       return -1L;
/*     */     try {
/* 701 */       this.readRAF.seek(where);
/* 702 */       return this.readRAF.getFilePointer();
/*     */     } catch (IOException e) {}
/* 704 */     return -1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized int doRead(byte[] buffer, int offset, int length)
/*     */     throws IOException
/*     */   {
/* 715 */     if (this.closed) {
/* 716 */       return -1;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 721 */       return this.readRAF.read(buffer, offset, length);
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e)
/*     */     {
/*     */ 
/* 728 */       e.printStackTrace(); }
/* 729 */     return -2;
/*     */   }
/*     */   
/*     */ 
/*     */   private synchronized void doClose()
/*     */   {
/*     */     try
/*     */     {
/* 737 */       this.closed = true;
/* 738 */       if (this.readRAF != null) {
/* 739 */         this.readRAF.close();
/*     */       }
/* 741 */       if (this.writeRAF != null) {
/* 742 */         this.writeRAF.close();
/*     */       }
/* 744 */       if (this.file == null) {
/* 745 */         return;
/*     */       }
/* 747 */       deleteFile(this.file);
/* 748 */       this.file = null;
/*     */     }
/*     */     catch (IOException e) {}
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isRandomAccess()
/*     */   {
/* 756 */     if (this.enabled)
/* 757 */       return true;
/*     */     try {
/* 759 */       Seekable s = (Seekable)this.stream;
/* 760 */       return s.isRandomAccess();
/*     */     } catch (ClassCastException e) {}
/* 762 */     return false;
/*     */   }
/*     */   
/*     */   public boolean willReadBlock()
/*     */   {
/* 767 */     return false;
/*     */   }
/*     */   
/*     */   public int read(byte[] buffer, int offset, int length)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 775 */       int result = waitUntilSeekWillSucceed(tell() + length);
/* 776 */       if (result == -1)
/* 777 */         return -1;
/* 778 */       int j; if (result != -2) {
/* 779 */         return doRead(buffer, offset, length);
/*     */       }
/*     */       
/* 782 */       return result;
/*     */     }
/*     */     finally {
/* 785 */       if (this.jitterEnabled) {
/* 786 */         drainCondition();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public ContentDescriptor getContentDescriptor() {
/* 792 */     return null;
/*     */   }
/*     */   
/*     */   public boolean endOfStream() {
/* 796 */     return false;
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 800 */     return new Object[0];
/*     */   }
/*     */   
/*     */   public Object getControl(String controlType) {
/* 804 */     return null;
/*     */   }
/*     */   
/*     */   void close()
/*     */   {
/* 809 */     if (!this.abort) {
/* 810 */       abortDownload();
/*     */     }
/*     */     
/* 813 */     if (this.downloadThread != null)
/*     */     {
/* 815 */       for (int i = 0; i < 20; i++) {
/* 816 */         if (!this.downloadThread.isAlive()) {
/*     */           break;
/*     */         }
/*     */         try
/*     */         {
/* 821 */           Thread.currentThread();Thread.sleep(100L);
/*     */         }
/*     */         catch (InterruptedException e) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 842 */     doClose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getContentLength()
/*     */   {
/* 853 */     return this.contentLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   long getContentProgress()
/*     */   {
/* 862 */     return this.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void addDownloadProgressListener(DownloadProgressListener l, int numKiloBytes)
/*     */   {
/* 869 */     this.listener = l;
/* 870 */     if (numKiloBytes <= 0)
/* 871 */       numKiloBytes = 1024;
/* 872 */     this.numKiloBytesUpdateIncrement = (numKiloBytes * 1024);
/*     */   }
/*     */   
/*     */ 
/*     */   void removeDownloadProgressListener(DownloadProgressListener l)
/*     */   {
/* 878 */     this.listener = null;
/*     */   }
/*     */   
/*     */   long getStartOffset() {
/* 882 */     return 0L;
/*     */   }
/*     */   
/*     */   long getEndOffset()
/*     */   {
/* 887 */     return this.length;
/*     */   }
/*     */   
/*     */   private boolean deleteFile(File file)
/*     */   {
/* 892 */     boolean fileDeleted = false;
/*     */     try {
/* 894 */       if (jmfSecurity != null) {
/*     */         try {
/* 896 */           if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 897 */             jmfSecurity.requestPermission(this.m, this.cl, this.args, 8);
/* 898 */             this.m[0].invoke(this.cl[0], this.args[0]);
/* 899 */           } else if (jmfSecurity.getName().startsWith("internet")) {
/* 900 */             PolicyEngine.checkPermission(PermissionID.FILEIO);
/* 901 */             PolicyEngine.assertPermission(PermissionID.FILEIO);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 908 */           securityPrivelege = false;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 913 */       if ((jmfSecurity != null) && (jmfSecurity.getName().startsWith("jdk12"))) {
/* 914 */         Constructor cons = jdk12DeleteFileAction.cons;
/*     */         
/* 916 */         Boolean success = (Boolean)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { file }) });
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 924 */         fileDeleted = success.booleanValue();
/*     */       } else {
/* 926 */         fileDeleted = file.delete();
/*     */       }
/*     */     }
/*     */     catch (Throwable e) {}
/* 930 */     return fileDeleted;
/*     */   }
/*     */   
/*     */   boolean isDownloading() {
/* 934 */     if (this.eosReached)
/* 935 */       return false;
/* 936 */     return this.length != -1L;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public long seek(long where)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: istore_3
/*     */     //   2: aload_0
/*     */     //   3: astore 4
/*     */     //   5: aload 4
/*     */     //   7: monitorenter
/*     */     //   8: aload_0
/*     */     //   9: iconst_0
/*     */     //   10: putfield 13	com/sun/media/protocol/CachedPullSourceStream:readAborted	Z
/*     */     //   13: aload 4
/*     */     //   15: monitorexit
/*     */     //   16: goto +11 -> 27
/*     */     //   19: astore 5
/*     */     //   21: aload 4
/*     */     //   23: monitorexit
/*     */     //   24: aload 5
/*     */     //   26: athrow
/*     */     //   27: aload_0
/*     */     //   28: getfield 22	com/sun/media/protocol/CachedPullSourceStream:jitterEnabled	Z
/*     */     //   31: ifeq +11 -> 42
/*     */     //   34: aload_0
/*     */     //   35: lload_1
/*     */     //   36: invokespecial 135	com/sun/media/protocol/CachedPullSourceStream:drainCondition	(J)Z
/*     */     //   39: ifne +25 -> 64
/*     */     //   42: lload_1
/*     */     //   43: aload_0
/*     */     //   44: invokespecial 121	com/sun/media/protocol/CachedPullSourceStream:getLength	()J
/*     */     //   47: lcmp
/*     */     //   48: ifgt +16 -> 64
/*     */     //   51: aload_0
/*     */     //   52: lload_1
/*     */     //   53: invokespecial 136	com/sun/media/protocol/CachedPullSourceStream:doSeek	(J)J
/*     */     //   56: lstore 5
/*     */     //   58: jsr +192 -> 250
/*     */     //   61: lload 5
/*     */     //   63: lreturn
/*     */     //   64: aload_0
/*     */     //   65: getfield 11	com/sun/media/protocol/CachedPullSourceStream:eosReached	Z
/*     */     //   68: ifeq +36 -> 104
/*     */     //   71: lload_1
/*     */     //   72: aload_0
/*     */     //   73: invokespecial 121	com/sun/media/protocol/CachedPullSourceStream:getLength	()J
/*     */     //   76: lcmp
/*     */     //   77: ifgt +16 -> 93
/*     */     //   80: aload_0
/*     */     //   81: lload_1
/*     */     //   82: invokespecial 136	com/sun/media/protocol/CachedPullSourceStream:doSeek	(J)J
/*     */     //   85: lstore 5
/*     */     //   87: jsr +163 -> 250
/*     */     //   90: lload 5
/*     */     //   92: lreturn
/*     */     //   93: ldc2_w 137
/*     */     //   96: lstore 5
/*     */     //   98: jsr +152 -> 250
/*     */     //   101: lload 5
/*     */     //   103: lreturn
/*     */     //   104: aload_0
/*     */     //   105: getfield 22	com/sun/media/protocol/CachedPullSourceStream:jitterEnabled	Z
/*     */     //   108: ifeq +71 -> 179
/*     */     //   111: aload_0
/*     */     //   112: astore 5
/*     */     //   114: aload 5
/*     */     //   116: monitorenter
/*     */     //   117: goto +41 -> 158
/*     */     //   120: aload_0
/*     */     //   121: ldc2_w 139
/*     */     //   124: invokevirtual 115	java/lang/Object:wait	(J)V
/*     */     //   127: goto +5 -> 132
/*     */     //   130: astore 6
/*     */     //   132: aload_0
/*     */     //   133: getfield 13	com/sun/media/protocol/CachedPullSourceStream:readAborted	Z
/*     */     //   136: ifeq +22 -> 158
/*     */     //   139: aload_0
/*     */     //   140: iconst_0
/*     */     //   141: putfield 13	com/sun/media/protocol/CachedPullSourceStream:readAborted	Z
/*     */     //   144: ldc2_w 141
/*     */     //   147: lstore 6
/*     */     //   149: aload 5
/*     */     //   151: monitorexit
/*     */     //   152: jsr +98 -> 250
/*     */     //   155: lload 6
/*     */     //   157: lreturn
/*     */     //   158: aload_0
/*     */     //   159: getfield 17	com/sun/media/protocol/CachedPullSourceStream:blockRead	Z
/*     */     //   162: ifne -42 -> 120
/*     */     //   165: aload 5
/*     */     //   167: monitorexit
/*     */     //   168: goto +11 -> 179
/*     */     //   171: astore 8
/*     */     //   173: aload 5
/*     */     //   175: monitorexit
/*     */     //   176: aload 8
/*     */     //   178: athrow
/*     */     //   179: aload_0
/*     */     //   180: getfield 13	com/sun/media/protocol/CachedPullSourceStream:readAborted	Z
/*     */     //   183: ifeq +19 -> 202
/*     */     //   186: aload_0
/*     */     //   187: iconst_0
/*     */     //   188: putfield 13	com/sun/media/protocol/CachedPullSourceStream:readAborted	Z
/*     */     //   191: ldc2_w 141
/*     */     //   194: lstore 5
/*     */     //   196: jsr +54 -> 250
/*     */     //   199: lload 5
/*     */     //   201: lreturn
/*     */     //   202: lload_1
/*     */     //   203: aload_0
/*     */     //   204: invokespecial 121	com/sun/media/protocol/CachedPullSourceStream:getLength	()J
/*     */     //   207: lcmp
/*     */     //   208: ifgt +16 -> 224
/*     */     //   211: aload_0
/*     */     //   212: lload_1
/*     */     //   213: invokespecial 136	com/sun/media/protocol/CachedPullSourceStream:doSeek	(J)J
/*     */     //   216: lstore 5
/*     */     //   218: jsr +32 -> 250
/*     */     //   221: lload 5
/*     */     //   223: lreturn
/*     */     //   224: invokestatic 143	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   227: pop
/*     */     //   228: ldc2_w 144
/*     */     //   231: invokestatic 146	java/lang/Thread:sleep	(J)V
/*     */     //   234: goto +5 -> 239
/*     */     //   237: astore 5
/*     */     //   239: goto -175 -> 64
/*     */     //   242: astore 9
/*     */     //   244: jsr +6 -> 250
/*     */     //   247: aload 9
/*     */     //   249: athrow
/*     */     //   250: astore 10
/*     */     //   252: aload_0
/*     */     //   253: getfield 22	com/sun/media/protocol/CachedPullSourceStream:jitterEnabled	Z
/*     */     //   256: ifeq +9 -> 265
/*     */     //   259: aload_0
/*     */     //   260: lload_1
/*     */     //   261: invokespecial 135	com/sun/media/protocol/CachedPullSourceStream:drainCondition	(J)Z
/*     */     //   264: pop
/*     */     //   265: ret 10
/*     */     // Line number table:
/*     */     //   Java source line #490	-> byte code offset #0
/*     */     //   Java source line #492	-> byte code offset #2
/*     */     //   Java source line #493	-> byte code offset #8
/*     */     //   Java source line #494	-> byte code offset #19
/*     */     //   Java source line #498	-> byte code offset #27
/*     */     //   Java source line #499	-> byte code offset #42
/*     */     //   Java source line #500	-> byte code offset #51
/*     */     //   Java source line #505	-> byte code offset #64
/*     */     //   Java source line #506	-> byte code offset #71
/*     */     //   Java source line #507	-> byte code offset #80
/*     */     //   Java source line #509	-> byte code offset #93
/*     */     //   Java source line #513	-> byte code offset #104
/*     */     //   Java source line #514	-> byte code offset #111
/*     */     //   Java source line #515	-> byte code offset #117
/*     */     //   Java source line #517	-> byte code offset #120
/*     */     //   Java source line #518	-> byte code offset #130
/*     */     //   Java source line #520	-> byte code offset #132
/*     */     //   Java source line #523	-> byte code offset #139
/*     */     //   Java source line #524	-> byte code offset #144
/*     */     //   Java source line #515	-> byte code offset #158
/*     */     //   Java source line #527	-> byte code offset #171
/*     */     //   Java source line #530	-> byte code offset #179
/*     */     //   Java source line #533	-> byte code offset #186
/*     */     //   Java source line #534	-> byte code offset #191
/*     */     //   Java source line #537	-> byte code offset #202
/*     */     //   Java source line #538	-> byte code offset #211
/*     */     //   Java source line #542	-> byte code offset #224
/*     */     //   Java source line #543	-> byte code offset #237
/*     */     //   Java source line #504	-> byte code offset #239
/*     */     //   Java source line #548	-> byte code offset #242
/*     */     //   Java source line #549	-> byte code offset #259
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	267	0	this	CachedPullSourceStream
/*     */     //   0	267	1	where	long
/*     */     //   1	2	3	debugTime	int
/*     */     //   3	19	4	localCachedPullSourceStream1	CachedPullSourceStream
/*     */     //   19	6	5	localObject1	Object
/*     */     //   56	46	5	l1	long
/*     */     //   194	28	5	l2	long
/*     */     //   237	3	5	e	InterruptedException
/*     */     //   130	26	6	e	InterruptedException
/*     */     //   171	6	8	localObject2	Object
/*     */     //   242	6	9	localObject3	Object
/*     */     //   250	1	10	localObject4	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   8	19	19	finally
/*     */     //   120	127	130	java/lang/InterruptedException
/*     */     //   117	171	171	finally
/*     */     //   224	234	237	java/lang/InterruptedException
/*     */     //   27	242	242	finally
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\protocol\CachedPullSourceStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */