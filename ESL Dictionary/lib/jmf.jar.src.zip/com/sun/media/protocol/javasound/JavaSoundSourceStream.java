/*     */ package com.sun.media.protocol.javasound;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.CircularBuffer;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.Log;
/*     */ import com.sun.media.protocol.BasicSourceStream;
/*     */ import com.sun.media.renderer.audio.device.JavaSoundOutput;
/*     */ import com.sun.media.ui.AudioFormatChooser;
/*     */ import com.sun.media.util.Arch;
/*     */ import com.sun.media.util.LoopThread;
/*     */ import com.sun.media.util.jdk12;
/*     */ import java.awt.Component;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.CaptureDeviceInfo;
/*     */ import javax.media.Control;
/*     */ import javax.media.Format;
/*     */ import javax.media.MediaLocator;
/*     */ import javax.media.Owned;
/*     */ import javax.media.control.BufferControl;
/*     */ import javax.media.control.FormatControl;
/*     */ import javax.media.protocol.BufferTransferHandler;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.DataLine;
/*     */ import javax.sound.sampled.DataLine.Info;
/*     */ import javax.sound.sampled.Line;
/*     */ import javax.sound.sampled.TargetDataLine;
/*     */ 
/*     */ public class JavaSoundSourceStream extends BasicSourceStream implements PushBufferStream
/*     */ {
/*  38 */   TargetDataLine dataLine = null;
/*     */   
/*     */ 
/*  41 */   boolean reconnect = false;
/*     */   
/*     */ 
/*     */ 
/*  45 */   boolean started = false;
/*     */   
/*     */ 
/*  48 */   CircularBuffer cb = new CircularBuffer(1);
/*  49 */   PushThread pushThread = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   static int DefRate = 44100;
/*  56 */   static int DefBits = 16;
/*  57 */   static int DefChannels = 2;
/*  58 */   static int DefSigned = 1;
/*  59 */   static int DefEndian = Arch.isBigEndian() ? 1 : 0;
/*     */   
/*     */ 
/*  62 */   static int OtherEndian = Arch.isBigEndian() ? 1 : 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */   private static JMFSecurity jmfSecurity = null;
/*  69 */   private static boolean securityPrivelege = false;
/*  70 */   private Method[] mSecurity = new Method[1];
/*  71 */   private Class[] clSecurity = new Class[1];
/*  72 */   private Object[][] argsSecurity = new Object[1][0];
/*     */   
/*     */   static
/*     */   {
/*     */     try {
/*  77 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  78 */       securityPrivelege = true;
/*     */     } catch (SecurityException e) {}
/*     */   }
/*     */   
/*  82 */   static Format[] supported = { new javax.media.format.AudioFormat("LINEAR", 44100.0D, 16, 2, DefEndian, DefSigned), new javax.media.format.AudioFormat("LINEAR", 44100.0D, 16, 1, DefEndian, DefSigned), new javax.media.format.AudioFormat("LINEAR", 22050.0D, 16, 2, DefEndian, DefSigned), new javax.media.format.AudioFormat("LINEAR", 22050.0D, 16, 1, DefEndian, DefSigned), new javax.media.format.AudioFormat("LINEAR", 11025.0D, 16, 2, DefEndian, DefSigned), new javax.media.format.AudioFormat("LINEAR", 11025.0D, 16, 1, DefEndian, DefSigned), new javax.media.format.AudioFormat("LINEAR", 8000.0D, 16, 2, DefEndian, DefSigned), new javax.media.format.AudioFormat("LINEAR", 8000.0D, 16, 1, DefEndian, DefSigned) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */   protected static CaptureDeviceInfo[] deviceList = { new CaptureDeviceInfo("JavaSound audio capture", new MediaLocator("javasound://44100"), supported) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JavaSoundSourceStream(DataSource ds)
/*     */   {
/* 152 */     super(new ContentDescriptor("raw"), -1L);
/* 153 */     this.dsource = ds;
/*     */     
/*     */ 
/* 156 */     this.bc = new BC(this);
/*     */     
/* 158 */     this.controls = new Control[2];
/* 159 */     this.controls[0] = new FC(this);
/* 160 */     this.controls[1] = this.bc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Format parseLocator(MediaLocator ml)
/*     */   {
/* 173 */     String rateStr = null;String bitsStr = null;String channelsStr = null;
/* 174 */     String endianStr = null;String signedStr = null;
/*     */     
/*     */ 
/*     */ 
/* 178 */     String remainder = ml.getRemainder();
/* 179 */     if ((remainder != null) && (remainder.length() > 0)) {
/* 180 */       while ((remainder.length() > 1) && (remainder.charAt(0) == '/')) {
/* 181 */         remainder = remainder.substring(1);
/*     */       }
/* 183 */       int off = remainder.indexOf('/');
/* 184 */       if (off == -1) {
/* 185 */         if (!remainder.equals(""))
/* 186 */           rateStr = remainder;
/*     */       } else {
/* 188 */         rateStr = remainder.substring(0, off);
/* 189 */         remainder = remainder.substring(off + 1);
/*     */         
/* 191 */         off = remainder.indexOf('/');
/* 192 */         if (off == -1) {
/* 193 */           if (!remainder.equals(""))
/* 194 */             bitsStr = remainder;
/*     */         } else {
/* 196 */           bitsStr = remainder.substring(0, off);
/* 197 */           remainder = remainder.substring(off + 1);
/*     */           
/* 199 */           off = remainder.indexOf('/');
/* 200 */           if (off == -1) {
/* 201 */             if (!remainder.equals(""))
/* 202 */               channelsStr = remainder;
/*     */           } else {
/* 204 */             channelsStr = remainder.substring(0, off);
/* 205 */             remainder = remainder.substring(off + 1);
/*     */             
/* 207 */             off = remainder.indexOf('/');
/* 208 */             if (off == -1) {
/* 209 */               if (!remainder.equals(""))
/* 210 */                 endianStr = remainder;
/*     */             } else {
/* 212 */               endianStr = remainder.substring(0, off);
/* 213 */               if (!remainder.equals("")) {
/* 214 */                 signedStr = remainder.substring(off + 1);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 222 */     int rate = DefRate;
/* 223 */     if (rateStr != null) {
/*     */       try {
/* 225 */         Integer integer = Integer.valueOf(rateStr);
/* 226 */         if (integer != null) {
/* 227 */           rate = integer.intValue();
/*     */         }
/*     */       }
/*     */       catch (Throwable t) {}
/* 231 */       if ((rate <= 0) || (rate > 96000)) {
/* 232 */         Log.warning("JavaSound capture: unsupported sample rate: " + rate);
/* 233 */         rate = DefRate;
/* 234 */         Log.warning("        defaults to: " + rate);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 239 */     int bits = DefBits;
/* 240 */     if (bitsStr != null) {
/*     */       try {
/* 242 */         Integer integer = Integer.valueOf(bitsStr);
/* 243 */         if (integer != null) {
/* 244 */           bits = integer.intValue();
/*     */         }
/*     */       }
/*     */       catch (Throwable t) {}
/* 248 */       if ((bits != 8) && (bits != 16)) {
/* 249 */         Log.warning("JavaSound capture: unsupported sample size: " + bits);
/* 250 */         bits = DefBits;
/* 251 */         Log.warning("        defaults to: " + bits);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 256 */     int channels = DefChannels;
/* 257 */     if (channelsStr != null) {
/*     */       try {
/* 259 */         Integer integer = Integer.valueOf(channelsStr);
/* 260 */         if (integer != null) {
/* 261 */           channels = integer.intValue();
/*     */         }
/*     */       }
/*     */       catch (Throwable t) {}
/* 265 */       if ((channels != 1) && (channels != 2)) {
/* 266 */         Log.warning("JavaSound capture: unsupported # of channels: " + channels);
/* 267 */         channels = DefChannels;
/* 268 */         Log.warning("        defaults to: " + channels);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 273 */     int endian = DefEndian;
/* 274 */     if (endianStr != null) {
/* 275 */       if (endianStr.equalsIgnoreCase("big")) {
/* 276 */         endian = 1;
/* 277 */       } else if (endianStr.equalsIgnoreCase("little")) {
/* 278 */         endian = 0;
/*     */       } else {
/* 280 */         Log.warning("JavaSound capture: unsupported endianess: " + endianStr);
/* 281 */         Log.warning("        defaults to: big endian");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 286 */     int signed = DefSigned;
/* 287 */     if (signedStr != null) {
/* 288 */       if (signedStr.equalsIgnoreCase("signed")) {
/* 289 */         signed = 1;
/* 290 */       } else if (signedStr.equalsIgnoreCase("unsigned")) {
/* 291 */         signed = 0;
/*     */       } else {
/* 293 */         Log.warning("JavaSound capture: unsupported signedness: " + signedStr);
/* 294 */         Log.warning("        defaults to: signed");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 299 */     javax.media.format.AudioFormat fmt = new javax.media.format.AudioFormat("LINEAR", rate, bits, channels, endian, signed);
/*     */     
/*     */ 
/*     */ 
/* 303 */     return fmt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Format setFormat(Format fmt)
/*     */   {
/* 312 */     if (this.started) {
/* 313 */       Log.warning("Cannot change audio capture format after started.");
/* 314 */       return this.format;
/*     */     }
/*     */     
/* 317 */     if (fmt == null) {
/* 318 */       return this.format;
/*     */     }
/* 320 */     Format f = null;
/* 321 */     for (int i = 0; i < supported.length; i++) {
/* 322 */       if ((fmt.matches(supported[i])) && ((f = fmt.intersects(supported[i])) != null)) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 328 */     if (f == null) {
/* 329 */       return this.format;
/*     */     }
/*     */     try {
/* 332 */       if (this.devFormat != null)
/*     */       {
/* 334 */         if ((!this.devFormat.matches(f)) && (!JavaSoundOutput.isOpen()))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 339 */           this.format = ((javax.media.format.AudioFormat)f);
/* 340 */           disconnect();
/* 341 */           connect();
/*     */         }
/*     */       } else {
/* 344 */         this.format = ((javax.media.format.AudioFormat)f);
/* 345 */         connect();
/*     */       }
/*     */     } catch (IOException e) {
/* 348 */       return null;
/*     */     }
/*     */     
/* 351 */     if (this.afc != null) {
/* 352 */       this.afc.setCurrentFormat(this.format);
/*     */     }
/* 354 */     return this.format;
/*     */   }
/*     */   
/*     */   public boolean isConnected()
/*     */   {
/* 359 */     return this.devFormat != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void connect()
/*     */     throws IOException
/*     */   {
/* 370 */     if (isConnected()) {
/* 371 */       return;
/*     */     }
/* 373 */     if (JavaSoundOutput.isOpen()) {
/* 374 */       Log.warning("JavaSound is already opened for rendering.  Will capture at the default format.");
/* 375 */       this.format = null;
/*     */     }
/*     */     
/* 378 */     openDev();
/*     */     
/* 380 */     if (this.pushThread == null)
/*     */     {
/* 382 */       if (jmfSecurity != null) {
/* 383 */         String permission = null;
/*     */         try {
/* 385 */           if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 386 */             permission = "thread";
/* 387 */             jmfSecurity.requestPermission(this.mSecurity, this.clSecurity, this.argsSecurity, 16);
/*     */             
/* 389 */             this.mSecurity[0].invoke(this.clSecurity[0], this.argsSecurity[0]);
/*     */             
/* 391 */             permission = "thread group";
/* 392 */             jmfSecurity.requestPermission(this.mSecurity, this.clSecurity, this.argsSecurity, 32);
/*     */             
/* 394 */             this.mSecurity[0].invoke(this.clSecurity[0], this.argsSecurity[0]);
/* 395 */           } else if (jmfSecurity.getName().startsWith("internet")) {
/* 396 */             PolicyEngine.checkPermission(PermissionID.THREAD);
/* 397 */             PolicyEngine.assertPermission(PermissionID.THREAD);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         catch (Throwable e)
/*     */         {
/* 404 */           securityPrivelege = false;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 411 */       if ((jmfSecurity != null) && (jmfSecurity.getName().startsWith("jdk12"))) {
/*     */         try {
/* 413 */           Constructor cons = jdk12CreateThreadAction.cons;
/*     */           
/* 415 */           this.pushThread = ((PushThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { PushThread.class }) }));
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         catch (Exception e) {}
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 426 */         this.pushThread = new PushThread();
/*     */       }
/*     */       
/* 429 */       this.pushThread.setSourceStream(this);
/*     */     }
/*     */     
/* 432 */     if (this.reconnect)
/* 433 */       Log.comment("Capture buffer size: " + this.bufSize);
/* 434 */     this.devFormat = this.format;
/* 435 */     this.reconnect = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void openDev()
/*     */     throws IOException
/*     */   {
/* 445 */     javax.sound.sampled.AudioFormat afmt = null;
/*     */     DataLine.Info info;
/* 447 */     if (this.format != null)
/*     */     {
/* 449 */       afmt = JavaSoundOutput.convertFormat(this.format);
/* 450 */       int chnls = this.format.getChannels() == -1 ? 1 : this.format.getChannels();
/*     */       
/*     */ 
/* 453 */       int size = this.format.getSampleSizeInBits() == -1 ? 16 : this.format.getSampleSizeInBits();
/*     */       
/*     */ 
/* 456 */       int frameSize = size * chnls / 8;
/*     */       
/* 458 */       if (frameSize == 0) {
/* 459 */         frameSize = 1;
/*     */       }
/* 461 */       this.bufSize = ((int)(this.format.getSampleRate() * frameSize * this.bc.getBufferLength() / 1000.0D));
/*     */       
/*     */ 
/* 464 */       info = new DataLine.Info(TargetDataLine.class, afmt, this.bufSize);
/*     */     } else {
/* 466 */       info = new DataLine.Info(TargetDataLine.class, null, -1);
/*     */     }
/*     */     
/*     */ 
/* 470 */     if (!AudioSystem.isLineSupported(info)) {
/* 471 */       Log.error("Audio not supported: " + info + "\n");
/* 472 */       throw new IOException("Cannot open audio device for input.");
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 477 */       this.dataLine = ((TargetDataLine)AudioSystem.getLine(info));
/*     */       
/* 479 */       if (this.format != null) {
/* 480 */         this.dataLine.open(afmt, this.bufSize);
/*     */       } else {
/* 482 */         this.dataLine.open();
/* 483 */         this.format = JavaSoundOutput.convertFormat(this.dataLine.getFormat());
/*     */       }
/*     */       
/* 486 */       this.bufSize = this.dataLine.getBufferSize();
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 491 */       Log.error("Cannot open audio device for input: " + e);
/* 492 */       throw new IOException(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   public void disconnect() {
/* 497 */     if (this.dataLine == null) {
/* 498 */       return;
/*     */     }
/*     */     
/*     */ 
/* 502 */     this.dataLine.stop();
/* 503 */     this.dataLine.close();
/*     */     
/* 505 */     this.dataLine = null;
/* 506 */     this.devFormat = null;
/* 507 */     if (this.pushThread != null) {
/* 508 */       this.pushThread.kill();
/* 509 */       this.pushThread = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void start()
/*     */     throws IOException
/*     */   {
/* 518 */     if (this.dataLine == null)
/* 519 */       throw new IOException("A JavaSound input channel cannot be opened.");
/* 520 */     if (this.started) {
/* 521 */       return;
/*     */     }
/*     */     
/* 524 */     if (this.afc != null)
/*     */     {
/* 526 */       if (((??? = this.afc.getFormat()) != null) && (!???.matches(this.format)) && 
/* 527 */         (setFormat(???) == null)) {}
/*     */       
/*     */ 
/*     */ 
/* 531 */       this.afc.setEnabled(false);
/*     */     }
/*     */     
/*     */ 
/* 535 */     if (this.reconnect) {
/* 536 */       disconnect();
/*     */     }
/*     */     
/* 539 */     if (!isConnected()) {
/* 540 */       connect();
/*     */     }
/*     */     
/* 543 */     synchronized (this.cb) {
/* 544 */       while (this.cb.canRead()) {
/* 545 */         this.cb.read();
/* 546 */         this.cb.readReport();
/*     */       }
/* 548 */       this.cb.notifyAll();
/*     */     }
/*     */     
/* 551 */     this.pushThread.start();
/* 552 */     this.dataLine.flush();
/* 553 */     this.dataLine.start();
/* 554 */     this.started = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */     throws IOException
/*     */   {
/* 562 */     if (!this.started) {
/* 563 */       return;
/*     */     }
/* 565 */     this.pushThread.pause();
/* 566 */     if (this.dataLine != null)
/* 567 */       this.dataLine.stop();
/* 568 */     this.started = false;
/* 569 */     if ((this.afc != null) && (!JavaSoundOutput.isOpen())) {
/* 570 */       this.afc.setEnabled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   public Format getFormat() {
/* 575 */     return this.format;
/*     */   }
/*     */   
/*     */   public Object[] getControls()
/*     */   {
/* 580 */     return this.controls;
/*     */   }
/*     */   
/*     */   public static Format[] getSupportedFormats()
/*     */   {
/* 585 */     return supported;
/*     */   }
/*     */   
/*     */   public static CaptureDeviceInfo[] listCaptureDeviceInfo()
/*     */   {
/* 590 */     return deviceList;
/*     */   }
/*     */   
/*     */   public void setTransferHandler(BufferTransferHandler th)
/*     */   {
/* 595 */     this.transferHandler = th;
/*     */   }
/*     */   
/*     */   public boolean willReadBlock()
/*     */   {
/* 600 */     return !this.started;
/*     */   }
/*     */   
/*     */ 
/*     */   public void read(Buffer in)
/*     */   {
/*     */     Buffer buffer;
/*     */     
/* 608 */     synchronized (this.cb) {
/* 609 */       while (!this.cb.canRead()) {
/*     */         try {
/* 611 */           this.cb.wait();
/*     */         } catch (Exception ???) {}
/*     */       }
/* 614 */       buffer = this.cb.read();
/*     */     }
/*     */     
/*     */ 
/* 618 */     Object data = in.getData();
/* 619 */     in.copy(buffer);
/* 620 */     buffer.setData(data);
/*     */     
/* 622 */     synchronized (this.cb) {
/* 623 */       this.cb.readReport();
/* 624 */       this.cb.notify();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   class FC
/*     */     implements FormatControl, Owned
/*     */   {
/*     */     JavaSoundSourceStream jsss;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public FC(JavaSoundSourceStream jsss)
/*     */     {
/* 642 */       this.jsss = jsss;
/*     */     }
/*     */     
/*     */     public Object getOwner() {
/* 646 */       return JavaSoundSourceStream.this.dsource;
/*     */     }
/*     */     
/*     */     public Format getFormat() {
/* 650 */       return JavaSoundSourceStream.this.format;
/*     */     }
/*     */     
/*     */     public Format setFormat(Format fmt) {
/* 654 */       return this.jsss.setFormat(fmt);
/*     */     }
/*     */     
/*     */     public Format[] getSupportedFormats() {
/* 658 */       return JavaSoundSourceStream.supported;
/*     */     }
/*     */     
/*     */     public boolean isEnabled() {
/* 662 */       return true;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {}
/*     */     
/*     */     public Component getControlComponent()
/*     */     {
/* 669 */       if (JavaSoundSourceStream.this.afc == null) {
/* 670 */         JavaSoundSourceStream.this.afc = new AudioFormatChooser(JavaSoundSourceStream.supported, JavaSoundSourceStream.this.format);
/* 671 */         JavaSoundSourceStream.this.afc.setName("JavaSound");
/* 672 */         if ((JavaSoundSourceStream.this.started) || (JavaSoundSourceStream.this.dataLine == null) || (JavaSoundOutput.isOpen()))
/* 673 */           JavaSoundSourceStream.this.afc.setEnabled(false);
/*     */       }
/* 675 */       return JavaSoundSourceStream.this.afc;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 680 */   static int DefaultMinBufferSize = 16;
/* 681 */   static int DefaultMaxBufferSize = 4000;
/* 682 */   long bufLenReq = 125L;
/*     */   DataSource dsource;
/*     */   javax.media.format.AudioFormat format;
/*     */   javax.media.format.AudioFormat devFormat;
/*     */   int bufSize;
/*     */   BufferTransferHandler transferHandler;
/*     */   AudioFormatChooser afc;
/*     */   BufferControl bc;
/*     */   
/*     */   class BC implements BufferControl, Owned {
/* 692 */     BC(JavaSoundSourceStream js) { this.jsss = js; }
/*     */     
/*     */     JavaSoundSourceStream jsss;
/*     */     public long getBufferLength() {
/* 696 */       return JavaSoundSourceStream.this.bufLenReq;
/*     */     }
/*     */     
/*     */     public long setBufferLength(long time) {
/* 700 */       if (time < JavaSoundSourceStream.DefaultMinBufferSize) {
/* 701 */         JavaSoundSourceStream.this.bufLenReq = JavaSoundSourceStream.DefaultMinBufferSize;
/* 702 */       } else if (time > JavaSoundSourceStream.DefaultMaxBufferSize) {
/* 703 */         JavaSoundSourceStream.this.bufLenReq = JavaSoundSourceStream.DefaultMaxBufferSize;
/*     */       } else
/* 705 */         JavaSoundSourceStream.this.bufLenReq = time;
/* 706 */       Log.comment("Capture buffer length set: " + JavaSoundSourceStream.this.bufLenReq);
/* 707 */       JavaSoundSourceStream.this.reconnect = true;
/* 708 */       return JavaSoundSourceStream.this.bufLenReq;
/*     */     }
/*     */     
/*     */     public long getMinimumThreshold() {
/* 712 */       return 0L;
/*     */     }
/*     */     
/*     */     public long setMinimumThreshold(long time) {
/* 716 */       return 0L;
/*     */     }
/*     */     
/*     */     public void setEnabledThreshold(boolean b) {}
/*     */     
/*     */     public boolean getEnabledThreshold()
/*     */     {
/* 723 */       return false;
/*     */     }
/*     */     
/*     */     public Component getControlComponent() {
/* 727 */       return null;
/*     */     }
/*     */     
/*     */     public Object getOwner() {
/* 731 */       return JavaSoundSourceStream.this.dsource;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\protocol\javasound\JavaSoundSourceStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */