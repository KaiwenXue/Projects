package com.sun.media.protocol;

public abstract interface RTPSource
{
  public abstract int getSSRC();
  
  public abstract String getCNAME();
  
  public abstract void prebuffer();
  
  public abstract void flush();
  
  public abstract void setBufferListener(BufferListener paramBufferListener);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\protocol\RTPSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */