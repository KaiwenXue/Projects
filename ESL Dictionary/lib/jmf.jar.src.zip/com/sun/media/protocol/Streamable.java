package com.sun.media.protocol;

public abstract interface Streamable
{
  public abstract boolean isPrefetchable();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\protocol\Streamable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */