/*    */ package com.sun.media.protocol.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.media.protocol.SourceCloneable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataSource
/*    */   extends com.sun.media.protocol.DataSource
/*    */   implements SourceCloneable
/*    */ {
/*    */   public javax.media.protocol.DataSource createClone()
/*    */   {
/* 15 */     DataSource ds = new DataSource();
/* 16 */     ds.setLocator(getLocator());
/* 17 */     if (this.connected) {
/*    */       try {
/* 19 */         ds.connect();
/*    */       } catch (IOException e) {
/* 21 */         return null;
/*    */       }
/*    */     }
/* 24 */     return ds;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\protocol\http\DataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */