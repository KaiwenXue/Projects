package com.sun.media.protocol.ftp;

public class DataSource
  extends com.sun.media.protocol.DataSource
{}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\protocol\ftp\DataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */