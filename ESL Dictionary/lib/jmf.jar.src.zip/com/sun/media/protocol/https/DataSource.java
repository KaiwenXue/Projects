/*     */ package com.sun.media.protocol.https;
/*     */ 
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.net.URLStreamHandlerFactory;
/*     */ import javax.media.protocol.SourceCloneable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataSource
/*     */   extends com.sun.media.protocol.DataSource
/*     */   implements SourceCloneable
/*     */ {
/*  21 */   private static SecurityManager securityManager = ;
/*     */   
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  27 */     boolean netscape = false;
/*  28 */     boolean ie = false;
/*  29 */     boolean msjvm = false;
/*     */     
/*  31 */     String javaVendor = System.getProperty("java.vendor", "Sun").toLowerCase();
/*     */     
/*     */ 
/*  34 */     if (javaVendor.indexOf("icrosoft") > 0) {
/*  35 */       msjvm = true;
/*     */     }
/*     */     
/*     */ 
/*  39 */     if (securityManager != null) {
/*  40 */       netscape = securityManager.toString().indexOf("netscape") != -1;
/*  41 */       ie = securityManager.toString().indexOf("com.ms.security") != -1;
/*     */     }
/*     */     
/*     */ 
/*  45 */     if ((ie) || (msjvm)) {
/*     */       try {
/*  47 */         Class clsFactory = Class.forName("com.ms.net.wininet.WininetStreamHandlerFactory");
/*     */         
/*     */ 
/*     */ 
/*  51 */         if (clsFactory != null) {
/*  52 */           URL.setURLStreamHandlerFactory((URLStreamHandlerFactory)clsFactory.newInstance());
/*     */         }
/*     */       }
/*     */       catch (Throwable t) {}
/*     */     }
/*  57 */     else if (!netscape)
/*     */     {
/*     */ 
/*  60 */       if (!JMFSecurityManager.isJDK12()) {
/*  61 */         throw new UnsatisfiedLinkError("Fatal Error: DataSource for https protocol needs JDK1.2 or higher VM");
/*     */       }
/*     */       try {
/*  64 */         Class sslproviderC = Class.forName("com.sun.net.ssl.internal.ssl.Provider");
/*     */         
/*     */ 
/*  67 */         Object provider = sslproviderC.newInstance();
/*     */         
/*  69 */         Class securityC = Class.forName("java.security.Security");
/*  70 */         Class providerC = Class.forName("java.security.Provider");
/*  71 */         Class systemC = Class.forName("java.lang.System");
/*     */         
/*  73 */         Method addProviderM = securityC.getMethod("addProvider", new Class[] { providerC });
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*  78 */         Method setPropertyM = systemC.getMethod("setProperty", new Class[] { String.class, String.class });
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */         if ((addProviderM != null) && (setPropertyM != null)) {
/*  85 */           addProviderM.invoke(securityC, new Object[] { provider });
/*  86 */           setPropertyM.invoke(systemC, new Object[] { "java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol" });
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*  93 */         throw new UnsatisfiedLinkError("Fatal Error:Java Secure Socket Extension classes are not present");
/*     */       } catch (Error e) {
/*  95 */         throw new UnsatisfiedLinkError("Fatal Error:Java Secure Socket Extension classes are not present");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public javax.media.protocol.DataSource createClone()
/*     */   {
/* 102 */     DataSource ds = new DataSource();
/* 103 */     ds.setLocator(getLocator());
/* 104 */     if (this.connected) {
/*     */       try {
/* 106 */         ds.connect();
/*     */       } catch (IOException e) {
/* 108 */         return null;
/*     */       }
/*     */     }
/* 111 */     return ds;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\protocol\https\DataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */