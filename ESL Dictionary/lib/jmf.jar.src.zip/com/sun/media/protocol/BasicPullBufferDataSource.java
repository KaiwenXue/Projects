/*    */ package com.sun.media.protocol;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import javax.media.Duration;
/*    */ import javax.media.Time;
/*    */ import javax.media.protocol.PullBufferDataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BasicPullBufferDataSource
/*    */   extends PullBufferDataSource
/*    */ {
/* 16 */   protected Object[] controls = new Object[0];
/* 17 */   protected boolean started = false;
/* 18 */   protected String contentType = "content/unknown";
/* 19 */   protected boolean connected = false;
/* 20 */   protected Time duration = Duration.DURATION_UNKNOWN;
/*    */   
/*    */   public String getContentType() {
/* 23 */     if (!this.connected) {
/* 24 */       System.err.println("Error: DataSource not connected");
/* 25 */       return null;
/*    */     }
/* 27 */     return this.contentType;
/*    */   }
/*    */   
/*    */   public void connect() throws IOException {
/* 31 */     if (this.connected)
/* 32 */       return;
/* 33 */     this.connected = true;
/*    */   }
/*    */   
/*    */   public void disconnect() {
/*    */     try {
/* 38 */       if (this.started)
/* 39 */         stop();
/*    */     } catch (IOException e) {}
/* 41 */     this.connected = false;
/*    */   }
/*    */   
/*    */   public void start() throws IOException
/*    */   {
/* 46 */     if (!this.connected)
/* 47 */       throw new Error("DataSource must be connected before it can be started");
/* 48 */     if (this.started)
/* 49 */       return;
/* 50 */     this.started = true;
/*    */   }
/*    */   
/*    */   public void stop() throws IOException {
/* 54 */     if ((!this.connected) || (!this.started))
/* 55 */       return;
/* 56 */     this.started = false;
/*    */   }
/*    */   
/*    */   public Object[] getControls() {
/* 60 */     return this.controls;
/*    */   }
/*    */   
/*    */   public Object getControl(String controlType) {
/*    */     try {
/* 65 */       Class cls = Class.forName(controlType);
/* 66 */       Object[] cs = getControls();
/* 67 */       for (int i = 0; i < cs.length; i++) {
/* 68 */         if (cls.isInstance(cs[i]))
/* 69 */           return cs[i];
/*    */       }
/* 71 */       return null;
/*    */     }
/*    */     catch (Exception e) {}
/* 74 */     return null;
/*    */   }
/*    */   
/*    */   public Time getDuration()
/*    */   {
/* 79 */     return this.duration;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\protocol\BasicPullBufferDataSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */