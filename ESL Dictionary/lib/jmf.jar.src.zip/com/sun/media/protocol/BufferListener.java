package com.sun.media.protocol;

import javax.media.protocol.DataSource;

public abstract interface BufferListener
{
  public abstract void minThresholdReached(DataSource paramDataSource);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\protocol\BufferListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */