package com.sun.media.renderer.audio.device;

import javax.media.format.AudioFormat;

public abstract interface AudioOutput
{
  public abstract boolean initialize(AudioFormat paramAudioFormat, int paramInt);
  
  public abstract void dispose();
  
  public abstract void pause();
  
  public abstract void resume();
  
  public abstract void drain();
  
  public abstract void flush();
  
  public abstract long getMediaNanoseconds();
  
  public abstract void setGain(double paramDouble);
  
  public abstract double getGain();
  
  public abstract void setMute(boolean paramBoolean);
  
  public abstract boolean getMute();
  
  public abstract float setRate(float paramFloat);
  
  public abstract float getRate();
  
  public abstract int bufferAvailable();
  
  public abstract int write(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\renderer\audio\device\AudioOutput.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */