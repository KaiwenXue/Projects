/*    */ package com.sun.media.renderer.audio.device;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12CreateThreadAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   private Class threadclass;
/* 17 */   private String name = null;
/*    */   public static Constructor cons;
/*    */   public static Constructor conswithname;
/*    */   
/*    */   static {
/*    */     try {
/* 23 */       cons = class$com$sun$media$renderer$audio$device$jdk12CreateThreadAction.getConstructor(new Class[] { Class.class });
/*    */       
/* 25 */       conswithname = class$com$sun$media$renderer$audio$device$jdk12CreateThreadAction.getConstructor(new Class[] { Class.class, String.class });
/*    */     }
/*    */     catch (Throwable e) {}
/*    */   }
/*    */   
/*    */   public jdk12CreateThreadAction(Class threadclass, String name)
/*    */   {
/*    */     try
/*    */     {
/* 34 */       this.threadclass = threadclass;
/* 35 */       this.name = name;
/*    */     }
/*    */     catch (Throwable e) {}
/*    */   }
/*    */   
/*    */   public jdk12CreateThreadAction(Class threadclass)
/*    */   {
/* 42 */     this(threadclass, null);
/*    */   }
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 47 */       Object object = this.threadclass.newInstance();
/* 48 */       if (this.name != null) {
/* 49 */         ((Thread)object).setName(this.name);
/*    */       }
/* 51 */       return object;
/*    */     }
/*    */     catch (Throwable e) {}
/* 54 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\renderer\audio\device\jdk12CreateThreadAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */