/*    */ package com.sun.media.renderer.video;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MSHeavyComponent
/*    */   extends HeavyComponent
/*    */   implements com.ms.awt.HeavyComponent
/*    */ {
/*    */   public boolean needsHeavyPeer()
/*    */   {
/* 16 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\renderer\video\MSHeavyComponent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */