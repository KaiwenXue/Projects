/*     */ package com.sun.media.renderer.video;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.image.AffineTransformOp;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.DataBufferInt;
/*     */ import java.awt.image.DirectColorModel;
/*     */ import java.awt.image.Raster;
/*     */ import java.awt.image.SinglePixelPackedSampleModel;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.util.Vector;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.format.RGBFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Java2DRenderer
/*     */   implements Blitter
/*     */ {
/*  40 */   private transient AffineTransformOp savedATO = null;
/*  41 */   private transient DirectColorModel dcm = null;
/*  42 */   private transient Image destImage = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public Java2DRenderer()
/*     */   {
/*     */     try
/*     */     {
/*  50 */       Class.forName("java.awt.Graphics2D");
/*     */     } catch (ClassNotFoundException localClassNotFoundException) {
/*  52 */       throw new RuntimeException("No Java2D");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Image process(Buffer paramBuffer, Object paramObject1, Object paramObject2, Dimension paramDimension)
/*     */   {
/*  61 */     return (Image)paramObject1;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void draw(Graphics paramGraphics, Component paramComponent, Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
/*     */   {
/*  67 */     if ((paramImage == null) || (paramInt3 < 1) || (paramInt4 < 1))
/*  68 */       return;
/*  69 */     if (this.savedATO == null) {
/*  70 */       AffineTransform localAffineTransform = new AffineTransform(paramInt3 / paramInt7, 0.0F, 
/*  71 */         0.0F, paramInt4 / paramInt8, 
/*  72 */         0.0F, 0.0F);
/*  73 */       AffineTransformOp localAffineTransformOp = new AffineTransformOp(localAffineTransform, null);
/*     */       
/*  75 */       this.savedATO = localAffineTransformOp;
/*  76 */       this.destImage = localAffineTransformOp.createCompatibleDestImage((BufferedImage)paramImage, 
/*  77 */         this.dcm);
/*     */     }
/*  79 */     this.savedATO.filter((BufferedImage)paramImage, (BufferedImage)this.destImage);
/*  80 */     if ((paramGraphics != null) && (paramImage != null) && ((paramGraphics instanceof Graphics2D))) {
/*  81 */       ((Graphics2D)paramGraphics).drawImage(this.destImage, 0, 0, paramComponent);
/*     */     }
/*     */   }
/*     */   
/*     */   public int newData(Buffer paramBuffer, Vector paramVector1, Vector paramVector2, Vector paramVector3)
/*     */   {
/*  87 */     Object localObject = paramBuffer.getData();
/*  88 */     if (!(localObject instanceof int[]))
/*  89 */       return -1;
/*  90 */     RGBFormat localRGBFormat = (RGBFormat)paramBuffer.getFormat();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */     int i = localRGBFormat.getRedMask();
/*  99 */     int j = localRGBFormat.getGreenMask();
/* 100 */     int k = localRGBFormat.getBlueMask();
/* 101 */     int[] arrayOfInt = new int[3];
/* 102 */     arrayOfInt[0] = i;
/* 103 */     arrayOfInt[1] = j;
/* 104 */     arrayOfInt[2] = k;
/*     */     
/* 106 */     DataBufferInt localDataBufferInt = new DataBufferInt((int[])localObject, 
/* 107 */       localRGBFormat.getLineStride() * 
/* 108 */       localRGBFormat.getSize().height);
/*     */     
/* 110 */     SinglePixelPackedSampleModel localSinglePixelPackedSampleModel = new SinglePixelPackedSampleModel(3, 
/* 111 */       localRGBFormat.getLineStride(), 
/* 112 */       localRGBFormat.getSize().height, 
/* 113 */       arrayOfInt);
/* 114 */     WritableRaster localWritableRaster = Raster.createWritableRaster(localSinglePixelPackedSampleModel, localDataBufferInt, new Point(0, 0));
/*     */     
/* 116 */     this.dcm = new DirectColorModel(24, i, j, k);
/* 117 */     BufferedImage localBufferedImage = new BufferedImage(this.dcm, localWritableRaster, true, null);
/*     */     
/* 119 */     paramVector3.addElement(localObject);
/* 120 */     paramVector1.addElement(localBufferedImage);
/* 121 */     paramVector2.addElement(localBufferedImage);
/* 122 */     synchronized (this) {
/* 123 */       this.savedATO = null;
/*     */     }
/* 125 */     return paramVector1.size() - 1;
/*     */   }
/*     */   
/*     */   public void resized(Component paramComponent) {
/* 129 */     this.savedATO = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\renderer\video\Java2DRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */