/*    */ package com.sun.media.sdp;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimeDescription
/*    */   extends Parser
/*    */ {
/*    */   public String timeActive;
/*    */   public Vector repeatTimes;
/*    */   
/*    */   public TimeDescription(ByteArrayInputStream bin)
/*    */   {
/* 19 */     this.timeActive = getLine(bin);
/*    */     
/*    */ 
/* 22 */     this.repeatTimes = new Vector();
/*    */     
/* 24 */     boolean found = getToken(bin, "r=", false);
/*    */     
/* 26 */     while (found) {
/* 27 */       String repeatTime = getLine(bin);
/*    */       
/* 29 */       this.repeatTimes.addElement(repeatTime);
/*    */       
/* 31 */       found = getToken(bin, "r=", false);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\sdp\TimeDescription.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */