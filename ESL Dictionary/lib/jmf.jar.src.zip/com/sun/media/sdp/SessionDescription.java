/*     */ package com.sun.media.sdp;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionDescription
/*     */   extends Parser
/*     */ {
/*     */   public Vector timeDescriptions;
/*     */   public Vector sessionAttributes;
/*     */   public boolean connectionIncluded;
/*     */   public String version;
/*     */   public String origin;
/*     */   public String sessionName;
/*     */   public String sessionInfo;
/*     */   public String uri;
/*     */   public String email;
/*     */   public String phone;
/*     */   public String connectionInfo;
/*     */   public String bandwidthInfo;
/*     */   public String timezoneAdjustment;
/*     */   public String encryptionKey;
/*     */   
/*     */   public SessionDescription(ByteArrayInputStream bin)
/*     */   {
/*  32 */     this.connectionIncluded = false;
/*     */     
/*     */ 
/*  35 */     this.version = getLine(bin);
/*     */     
/*     */ 
/*  38 */     if (getToken(bin, "o=", true)) {
/*  39 */       this.origin = getLine(bin);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  44 */     if (getToken(bin, "s=", true)) {
/*  45 */       this.sessionName = getLine(bin);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  50 */     if (getToken(bin, "i=", false)) {
/*  51 */       this.sessionInfo = getLine(bin);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  56 */     if (getToken(bin, "u=", false)) {
/*  57 */       this.uri = getLine(bin);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  62 */     if (getToken(bin, "e=", false)) {
/*  63 */       this.email = getLine(bin);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  68 */     if (getToken(bin, "e=", false)) {
/*  69 */       this.email = getLine(bin);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  74 */     if (getToken(bin, "p=", false)) {
/*  75 */       this.phone = getLine(bin);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  80 */     if (getToken(bin, "c=", false)) {
/*  81 */       this.connectionIncluded = true;
/*     */       
/*  83 */       this.connectionInfo = getLine(bin);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  89 */     if (getToken(bin, "b=", false)) {
/*  90 */       this.bandwidthInfo = getLine(bin);
/*     */       
/*  92 */       System.out.println("bandwidth info: " + this.bandwidthInfo);
/*     */     }
/*     */     
/*     */ 
/*  96 */     this.timeDescriptions = new Vector();
/*     */     
/*  98 */     boolean found = getToken(bin, "t=", true);
/*     */     
/* 100 */     while (found) {
/* 101 */       TimeDescription timeDescription = new TimeDescription(bin);
/*     */       
/* 103 */       this.timeDescriptions.addElement(timeDescription);
/*     */       
/* 105 */       found = getToken(bin, "t=", false);
/*     */     }
/*     */     
/*     */ 
/* 109 */     if (getToken(bin, "z=", false)) {
/* 110 */       this.timezoneAdjustment = getLine(bin);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 115 */     if (getToken(bin, "k=", false)) {
/* 116 */       this.encryptionKey = getLine(bin);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 121 */     this.sessionAttributes = new Vector();
/*     */     
/* 123 */     found = getToken(bin, "a=", false);
/*     */     
/* 125 */     while (found) {
/* 126 */       String sessionAttribute = getLine(bin);
/*     */       
/*     */ 
/* 129 */       int index = sessionAttribute.indexOf(':');
/*     */       
/* 131 */       if (index > 0) {
/* 132 */         String name = sessionAttribute.substring(0, index);
/* 133 */         String value = sessionAttribute.substring(index + 1);
/*     */         
/* 135 */         MediaAttribute attribute = new MediaAttribute(name, value);
/*     */         
/* 137 */         this.sessionAttributes.addElement(attribute);
/*     */       }
/*     */       
/* 140 */       found = getToken(bin, "a=", false);
/*     */     }
/*     */   }
/*     */   
/*     */   public MediaAttribute getSessionAttribute(String name) {
/* 145 */     MediaAttribute attribute = null;
/*     */     
/* 147 */     if (this.sessionAttributes != null) {
/* 148 */       for (int i = 0; i < this.sessionAttributes.size(); i++) {
/* 149 */         MediaAttribute entry = (MediaAttribute)this.sessionAttributes.elementAt(i);
/*     */         
/*     */ 
/* 152 */         if (entry.getName().equals(name)) {
/* 153 */           attribute = entry;
/* 154 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 159 */     return attribute;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\sdp\SessionDescription.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */