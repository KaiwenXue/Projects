/*     */ package com.sun.media.multiplexer;
/*     */ 
/*     */ import com.sun.media.BasicClock;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.MediaTimeBase;
/*     */ import com.sun.media.Syncable;
/*     */ import com.sun.media.controls.MonitorAdapter;
/*     */ import com.sun.media.datasink.RandomAccess;
/*     */ import java.awt.Component;
/*     */ import java.io.IOException;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Clock;
/*     */ import javax.media.ClockStoppedException;
/*     */ import javax.media.Control;
/*     */ import javax.media.Duration;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.Multiplexer;
/*     */ import javax.media.Owned;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.control.StreamWriterControl;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PushDataSource;
/*     */ import javax.media.protocol.PushSourceStream;
/*     */ import javax.media.protocol.Seekable;
/*     */ import javax.media.protocol.SourceTransferHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BasicMux
/*     */   extends BasicPlugIn
/*     */   implements Multiplexer, Clock
/*     */ {
/*     */   protected Format[] supportedInputs;
/*     */   protected ContentDescriptor[] supportedOutputs;
/*  45 */   protected int numTracks = 0;
/*     */   protected Format[] inputs;
/*     */   protected BasicMuxDataSource source;
/*     */   protected BasicMuxPushStream stream;
/*     */   protected ContentDescriptor outputCD;
/*  50 */   protected boolean flushing = false;
/*  51 */   protected Integer sourceLock = new Integer(0);
/*  52 */   protected boolean eos = false;
/*  53 */   protected boolean firstBuffer = true;
/*  54 */   protected int fileSize = 0;
/*  55 */   protected int filePointer = 0;
/*  56 */   protected long fileSizeLimit = -1L;
/*  57 */   protected boolean streamSizeLimitSupported = true;
/*  58 */   protected boolean fileSizeLimitReached = false;
/*  59 */   protected SourceTransferHandler sth = null;
/*  60 */   protected boolean isLiveData = false;
/*     */   
/*  62 */   protected StreamWriterControl swc = null;
/*  63 */   protected MonitorAdapter[] mc = null;
/*     */   
/*     */ 
/*  66 */   protected BasicMuxTimeBase timeBase = null;
/*     */   
/*     */ 
/*  69 */   Object startup = new Integer(0);
/*     */   
/*     */ 
/*     */ 
/*  73 */   boolean readyToStart = false;
/*     */   
/*     */   long[] mediaTime;
/*     */   
/*     */   boolean[] ready;
/*     */   
/*  79 */   protected BasicClock clock = null;
/*     */   
/*     */ 
/*  82 */   int master = 0;
/*     */   
/*  84 */   boolean mClosed = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BasicMux()
/*     */   {
/*  91 */     this.timeBase = new BasicMuxTimeBase();
/*  92 */     this.clock = new BasicClock();
/*     */     try {
/*  94 */       this.clock.setTimeBase(this.timeBase);
/*     */     }
/*     */     catch (Exception e) {}
/*  97 */     this.swc = new SWC(this);
/*  98 */     this.controls = new Control[] { this.swc };
/*     */   }
/*     */   
/*     */   public void open()
/*     */   {
/* 103 */     this.firstBuffer = true;
/* 104 */     this.firstBuffers = new Buffer[this.inputs.length];
/* 105 */     this.firstBuffersDone = new boolean[this.inputs.length];
/* 106 */     this.nonKeyCount = new int[this.inputs.length];
/* 107 */     this.mediaTime = new long[this.inputs.length];
/*     */     
/* 109 */     for (int i = 0; i < this.inputs.length; i++) {
/* 110 */       this.firstBuffers[i] = null;
/* 111 */       this.firstBuffersDone[i] = false;
/* 112 */       this.nonKeyCount[i] = 0;
/* 113 */       this.mediaTime[i] = 0L;
/*     */     }
/*     */     
/* 116 */     this.ready = new boolean[this.inputs.length];
/* 117 */     resetReady();
/*     */     
/* 119 */     int len = 0;
/* 120 */     this.mc = new MonitorAdapter[this.inputs.length];
/*     */     
/* 122 */     for (i = 0; i < this.inputs.length; i++) {
/* 123 */       if (((this.inputs[i] instanceof VideoFormat)) || ((this.inputs[i] instanceof AudioFormat)))
/*     */       {
/* 125 */         this.mc[i] = new MonitorAdapter(this.inputs[i], this);
/* 126 */         if (this.mc[i] != null) {
/* 127 */           len++;
/*     */         }
/*     */       }
/*     */     }
/* 131 */     int j = 0;
/* 132 */     this.controls = new Control[len + 1];
/* 133 */     for (i = 0; i < this.mc.length; i++) {
/* 134 */       if (this.mc[i] != null)
/* 135 */         this.controls[(j++)] = this.mc[i];
/*     */     }
/* 137 */     this.controls[j] = this.swc;
/*     */   }
/*     */   
/*     */   public void close() {
/* 141 */     if (this.sth != null) {
/* 142 */       writeFooter();
/* 143 */       write(null, 0, -1);
/*     */     }
/*     */     
/* 146 */     for (int i = 0; i < this.mc.length; i++) {
/* 147 */       if (this.mc[i] != null) {
/* 148 */         this.mc[i].close();
/*     */       }
/*     */     }
/* 151 */     synchronized (this.dataLock) {
/* 152 */       this.mClosed = true;
/* 153 */       this.dataLock.notifyAll();
/*     */     }
/*     */   }
/*     */   
/*     */   public void reset()
/*     */   {
/* 159 */     for (int i = 0; i < this.mediaTime.length; i++) {
/* 160 */       this.mediaTime[i] = 0L;
/* 161 */       if (this.mc[i] != null)
/* 162 */         this.mc[i].reset();
/*     */     }
/* 164 */     this.timeBase.update();
/* 165 */     resetReady();
/* 166 */     synchronized (this.sourceLock) {
/* 167 */       this.flushing = true;
/* 168 */       this.sourceLock.notifyAll();
/*     */     }
/*     */   }
/*     */   
/*     */   private void resetReady() {
/* 173 */     for (int i = 0; i < this.ready.length; i++)
/* 174 */       this.ready[i] = false;
/* 175 */     this.readyToStart = false;
/* 176 */     synchronized (this.startup) {
/* 177 */       this.startup.notifyAll();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean checkReady() {
/* 182 */     if (this.readyToStart)
/* 183 */       return true;
/* 184 */     for (int i = 0; i < this.ready.length; i++) {
/* 185 */       if (this.ready[i] == 0)
/* 186 */         return false;
/*     */     }
/* 188 */     this.readyToStart = true;
/* 189 */     return true;
/*     */   }
/*     */   
/*     */   public Format[] getSupportedInputFormats() {
/* 193 */     return this.supportedInputs;
/*     */   }
/*     */   
/*     */   public ContentDescriptor[] getSupportedOutputContentDescriptors(Format[] inputs) {
/* 197 */     return this.supportedOutputs;
/*     */   }
/*     */   
/*     */   public int setNumTracks(int numTracks) {
/* 201 */     this.numTracks = numTracks;
/*     */     
/* 203 */     if (this.inputs == null) {
/* 204 */       this.inputs = new Format[numTracks];
/*     */     } else {
/* 206 */       Format[] newInputs = new Format[numTracks];
/* 207 */       for (int i = 0; i < this.inputs.length; i++) {
/* 208 */         newInputs[i] = this.inputs[i];
/*     */       }
/* 210 */       this.inputs = newInputs;
/*     */     }
/*     */     
/* 213 */     return numTracks;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Format setInputFormat(Format format, int trackID)
/*     */   {
/* 221 */     this.inputs[trackID] = format;
/* 222 */     return format;
/*     */   }
/*     */   
/*     */   public int process(Buffer buffer, int trackID) {
/* 226 */     if (buffer.isDiscard())
/* 227 */       return 0;
/* 228 */     if ((!this.isLiveData) && ((buffer.getFlags() & 0x8000) > 0)) {
/* 229 */       this.isLiveData = true;
/*     */     }
/*     */     
/* 232 */     while ((this.source == null) || (!this.source.isConnected()) || (!this.source.isStarted())) {
/* 233 */       synchronized (this.sourceLock) {
/*     */         try {
/* 235 */           this.sourceLock.wait(500L);
/*     */         }
/*     */         catch (InterruptedException ie) {}
/* 238 */         if (this.flushing) {
/* 239 */           this.flushing = false;
/* 240 */           buffer.setLength(0);
/* 241 */           ie = 0;return ie;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 246 */     synchronized (this) {
/* 247 */       if (this.firstBuffer) {
/* 248 */         writeHeader();
/* 249 */         this.firstBuffer = false;
/*     */       }
/*     */     }
/*     */     
/* 253 */     if (this.numTracks > 1)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 258 */       if (((buffer.getFlags() & 0x1000) != 0) && 
/* 259 */         (buffer.getTimeStamp() <= 0L)) {
/* 260 */         return 0;
/*     */       }
/*     */       
/* 263 */       if ((!this.startCompensated) && 
/* 264 */         (!compensateStart(buffer, trackID)))
/*     */       {
/* 266 */         return 0;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 271 */     updateClock(buffer, trackID);
/* 272 */     if ((this.mc[trackID] != null) && (this.mc[trackID].isEnabled()))
/* 273 */       this.mc[trackID].process(buffer);
/* 274 */     int processResult = doProcess(buffer, trackID);
/* 275 */     if (this.fileSizeLimitReached)
/* 276 */       processResult |= 0x8;
/* 277 */     return processResult;
/*     */   }
/*     */   
/*     */ 
/* 281 */   boolean dataReady = false;
/* 282 */   boolean startCompensated = false;
/* 283 */   Object dataLock = new Object();
/*     */   Buffer[] firstBuffers;
/*     */   boolean[] firstBuffersDone;
/*     */   int[] nonKeyCount;
/* 287 */   long masterTime = -1L;
/*     */   
/*     */ 
/*     */ 
/* 291 */   VideoFormat jpegFmt = new VideoFormat("jpeg");
/* 292 */   VideoFormat mjpgFmt = new VideoFormat("mjpg");
/* 293 */   VideoFormat rgbFmt = new VideoFormat("rgb");
/* 294 */   VideoFormat yuvFmt = new VideoFormat("yuv");
/*     */   
/*     */   private boolean compensateStart(Buffer buffer, int trackID)
/*     */   {
/* 298 */     synchronized (this.dataLock)
/*     */     {
/*     */       label171:
/*     */       
/*     */       int i;
/*     */       
/* 304 */       if (this.dataReady) {
/* 305 */         if (this.firstBuffersDone[trackID] == 0) {
/* 306 */           if (buffer.getTimeStamp() < this.masterTime)
/*     */           {
/* 308 */             boolean bool1 = false;return bool1;
/*     */           }
/* 310 */           if ((buffer.getFormat() instanceof VideoFormat)) {
/* 311 */             Format fmt = buffer.getFormat();
/* 312 */             isKey = (this.jpegFmt.matches(fmt)) || (this.mjpgFmt.matches(fmt)) || (this.rgbFmt.matches(fmt)) || (this.yuvFmt.matches(fmt));
/*     */             
/*     */ 
/*     */ 
/* 316 */             if ((!isKey) && ((buffer.getFlags() & 0x10) == 0)) { int tmp134_133 = trackID; int[] tmp134_130 = this.nonKeyCount; int tmp136_135 = tmp134_130[tmp134_133];tmp134_130[tmp134_133] = (tmp136_135 + 1); if (tmp136_135 <= 30) {}
/*     */             }
/*     */             else {
/* 319 */               buffer.setTimeStamp(this.masterTime);
/* 320 */               this.firstBuffersDone[trackID] = true;
/*     */               break label171; }
/* 322 */             boolean bool2 = false;return bool2;
/*     */           }
/*     */           else
/*     */           {
/* 326 */             buffer.setTimeStamp(this.masterTime);
/* 327 */             this.firstBuffersDone[trackID] = true;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 332 */           for (i = 0; i < this.firstBuffersDone.length; i++)
/* 333 */             if (this.firstBuffersDone[i] == 0) {
/* 334 */               isKey = true;return isKey;
/*     */             }
/* 336 */           this.startCompensated = true;
/* 337 */           boolean isKey = true;return isKey;
/*     */         }
/*     */         
/* 340 */         i = 1;return i;
/*     */       }
/*     */       
/* 343 */       if (buffer.getTimeStamp() < 0L)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 348 */         this.startCompensated = true;
/* 349 */         this.dataReady = true;
/* 350 */         this.dataLock.notifyAll();
/* 351 */         i = 1;return i;
/*     */       }
/*     */       
/*     */ 
/* 355 */       this.firstBuffers[trackID] = buffer;
/*     */       
/*     */ 
/* 358 */       boolean done = true;
/*     */       
/* 360 */       for (int i = 0; i < this.firstBuffers.length; i++) {
/* 361 */         if (this.firstBuffers[i] == null) {
/* 362 */           done = false;
/*     */         }
/*     */       }
/* 365 */       if (!done)
/*     */       {
/*     */ 
/* 368 */         while ((!this.dataReady) && (!this.mClosed)) {
/*     */           try {
/* 370 */             this.dataLock.wait();
/*     */           }
/*     */           catch (Exception e) {}
/*     */         }
/* 374 */         if ((this.mClosed) || (this.firstBuffers[trackID] == null))
/*     */         {
/* 376 */           bool3 = false;return bool3;
/*     */         }
/* 378 */         boolean bool3 = true;return bool3;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 387 */       this.masterTime = this.firstBuffers[0].getTimeStamp();
/*     */       
/* 389 */       for (int i = 0; i < this.firstBuffers.length; i++) {
/* 390 */         if ((this.firstBuffers[i].getFormat() instanceof AudioFormat)) {
/* 391 */           this.masterTime = this.firstBuffers[i].getTimeStamp();
/* 392 */           break;
/*     */         }
/* 394 */         if (this.firstBuffers[i].getTimeStamp() < this.masterTime) {
/* 395 */           this.masterTime = this.firstBuffers[i].getTimeStamp();
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 401 */       this.startCompensated = true;
/* 402 */       for (int i = 0; i < this.firstBuffers.length; i++)
/*     */       {
/* 404 */         if (this.firstBuffers[i].getTimeStamp() >= this.masterTime) {
/* 405 */           this.firstBuffers[i].setTimeStamp(this.masterTime);
/* 406 */           this.firstBuffersDone[i] = true;
/*     */         } else {
/* 408 */           this.firstBuffers[i] = null;
/* 409 */           this.startCompensated = false;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 415 */       synchronized (this.dataLock) {
/* 416 */         this.dataReady = true;
/* 417 */         this.dataLock.notifyAll();
/*     */       }
/*     */       
/* 420 */       boolean bool4 = this.firstBuffers[trackID] != null;return bool4;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void updateClock(Buffer buffer, int trackID)
/*     */   {
/* 428 */     if ((!this.readyToStart) && (this.numTracks > 1)) {
/* 429 */       synchronized (this.startup) {
/* 430 */         this.ready[trackID] = true;
/* 431 */         if (checkReady()) {
/* 432 */           this.startup.notifyAll();
/*     */         } else {
/*     */           try
/*     */           {
/* 436 */             while (!this.readyToStart) {
/* 437 */               this.startup.wait(1000L);
/*     */             }
/*     */           }
/*     */           catch (Exception e) {}
/*     */         }
/*     */       }
/*     */     }
/* 444 */     long timestamp = buffer.getTimeStamp();
/*     */     
/* 446 */     if ((timestamp <= 0L) && ((buffer.getFormat() instanceof AudioFormat)))
/*     */     {
/*     */ 
/* 449 */       timestamp = this.mediaTime[trackID];
/* 450 */       this.mediaTime[trackID] += getDuration(buffer);
/* 451 */     } else if (timestamp <= 0L)
/*     */     {
/* 453 */       this.mediaTime[trackID] = (System.currentTimeMillis() * 1000000L - this.systemStartTime);
/*     */     }
/*     */     else {
/* 456 */       this.mediaTime[trackID] = timestamp;
/*     */     }
/* 458 */     this.timeBase.update();
/*     */   }
/*     */   
/*     */   public ContentDescriptor setContentDescriptor(ContentDescriptor outputCD) {
/* 462 */     if (BasicPlugIn.matches(outputCD, this.supportedOutputs) == null) {
/* 463 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 467 */     this.outputCD = outputCD;
/* 468 */     return outputCD;
/*     */   }
/*     */   
/*     */   public DataSource getDataOutput() {
/* 472 */     if (this.source == null) {
/* 473 */       this.source = new BasicMuxDataSource(this, this.outputCD);
/* 474 */       synchronized (this.sourceLock) {
/* 475 */         this.sourceLock.notifyAll();
/*     */       }
/*     */     }
/* 478 */     return this.source;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int doProcess(Buffer buffer, int trackID)
/*     */   {
/* 487 */     byte[] data = (byte[])buffer.getData();
/* 488 */     int dataLen = buffer.getLength();
/* 489 */     if (!buffer.isEOM())
/* 490 */       write(data, buffer.getOffset(), dataLen);
/* 491 */     return 0;
/*     */   }
/*     */   
/*     */   protected int write(byte[] data, int offset, int length) {
/* 495 */     if ((this.source == null) || (!this.source.isConnected()))
/* 496 */       return length;
/* 497 */     if (length > 0) {
/* 498 */       this.filePointer += length;
/* 499 */       if (this.filePointer > this.fileSize)
/* 500 */         this.fileSize = this.filePointer;
/* 501 */       if ((this.fileSizeLimit > 0L) && (this.fileSize >= this.fileSizeLimit))
/* 502 */         this.fileSizeLimitReached = true;
/*     */     }
/* 504 */     return this.stream.write(data, offset, length);
/*     */   }
/*     */   
/*     */   void setStream(BasicMuxPushStream ps) {
/* 508 */     this.stream = ps;
/*     */   }
/*     */   
/*     */   long getStreamSize() {
/* 512 */     return this.fileSize;
/*     */   }
/*     */   
/*     */   boolean needsSeekable()
/*     */   {
/* 517 */     return false;
/*     */   }
/*     */   
/*     */   protected int seek(int location) {
/* 521 */     if ((this.source == null) || (!this.source.isConnected()))
/* 522 */       return location;
/* 523 */     this.filePointer = this.stream.seek(location);
/* 524 */     return this.filePointer;
/*     */   }
/*     */   
/*     */   boolean isEOS() {
/* 528 */     return this.eos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void writeHeader() {}
/*     */   
/*     */ 
/*     */ 
/* 537 */   protected int maxBufSize = 32768;
/* 538 */   protected byte[] buf = new byte[this.maxBufSize];
/*     */   
/*     */   protected void writeFooter() {}
/*     */   
/*     */   protected void bufClear() {
/* 543 */     this.bufOffset = 0;
/* 544 */     this.bufLength = 0;
/*     */   }
/*     */   
/*     */   protected void bufSkip(int size) {
/* 548 */     this.bufOffset += size;
/* 549 */     this.bufLength += size;
/* 550 */     this.filePointer += size;
/*     */   }
/*     */   
/*     */   protected void bufWriteBytes(String s) {
/* 554 */     byte[] bytes = s.getBytes();
/* 555 */     bufWriteBytes(bytes);
/*     */   }
/*     */   
/*     */   protected void bufWriteBytes(byte[] bytes) {
/* 559 */     System.arraycopy(bytes, 0, this.buf, this.bufOffset, bytes.length);
/*     */     
/* 561 */     this.bufOffset += bytes.length;
/* 562 */     this.bufLength += bytes.length;
/* 563 */     this.filePointer += bytes.length;
/*     */   }
/*     */   
/*     */   protected void bufWriteInt(int value) {
/* 567 */     this.buf[(this.bufOffset + 0)] = ((byte)(value >> 24 & 0xFF));
/* 568 */     this.buf[(this.bufOffset + 1)] = ((byte)(value >> 16 & 0xFF));
/* 569 */     this.buf[(this.bufOffset + 2)] = ((byte)(value >> 8 & 0xFF));
/* 570 */     this.buf[(this.bufOffset + 3)] = ((byte)(value >> 0 & 0xFF));
/* 571 */     this.bufOffset += 4;
/* 572 */     this.bufLength += 4;
/* 573 */     this.filePointer += 4;
/*     */   }
/*     */   
/*     */   protected void bufWriteIntLittleEndian(int value) {
/* 577 */     this.buf[(this.bufOffset + 3)] = ((byte)(value >>> 24 & 0xFF));
/* 578 */     this.buf[(this.bufOffset + 2)] = ((byte)(value >>> 16 & 0xFF));
/* 579 */     this.buf[(this.bufOffset + 1)] = ((byte)(value >>> 8 & 0xFF));
/* 580 */     this.buf[(this.bufOffset + 0)] = ((byte)(value >>> 0 & 0xFF));
/* 581 */     this.bufOffset += 4;
/* 582 */     this.bufLength += 4;
/* 583 */     this.filePointer += 4;
/*     */   }
/*     */   
/*     */   protected void bufWriteShort(short value) {
/* 587 */     this.buf[(this.bufOffset + 0)] = ((byte)(value >> 8 & 0xFF));
/* 588 */     this.buf[(this.bufOffset + 1)] = ((byte)(value >> 0 & 0xFF));
/* 589 */     this.bufOffset += 2;
/* 590 */     this.bufLength += 2;
/* 591 */     this.filePointer += 2;
/*     */   }
/*     */   
/*     */   protected void bufWriteShortLittleEndian(short value) {
/* 595 */     this.buf[(this.bufOffset + 1)] = ((byte)(value >> 8 & 0xFF));
/* 596 */     this.buf[(this.bufOffset + 0)] = ((byte)(value >> 0 & 0xFF));
/* 597 */     this.bufOffset += 2;
/* 598 */     this.bufLength += 2;
/* 599 */     this.filePointer += 2;
/*     */   }
/*     */   
/*     */   protected void bufWriteByte(byte value) {
/* 603 */     this.buf[this.bufOffset] = value;
/* 604 */     this.bufOffset += 1;
/* 605 */     this.bufLength += 1;
/* 606 */     this.filePointer += 1;
/*     */   }
/*     */   
/*     */   protected void bufFlush() {
/* 610 */     this.filePointer -= this.bufLength;
/* 611 */     write(this.buf, 0, this.bufLength);
/*     */   }
/*     */   
/*     */   private long getDuration(Buffer buffer) {
/* 615 */     AudioFormat format = (AudioFormat)buffer.getFormat();
/*     */     
/*     */ 
/* 618 */     long duration = format.computeDuration(buffer.getLength());
/*     */     
/* 620 */     if (duration < 0L) {
/* 621 */       return 0L;
/*     */     }
/* 623 */     return duration;
/*     */   }
/*     */   
/*     */ 
/*     */   protected int bufOffset;
/*     */   
/*     */   protected int bufLength;
/* 630 */   Object timeSetSync = new Object();
/* 631 */   boolean started = false;
/* 632 */   long systemStartTime = System.currentTimeMillis() * 1000000L;
/*     */   
/*     */   public void setTimeBase(TimeBase master) throws IncompatibleTimeBaseException {
/* 635 */     if (master != this.timeBase)
/* 636 */       throw new IncompatibleTimeBaseException();
/*     */   }
/*     */   
/*     */   public void syncStart(Time at) {
/* 640 */     synchronized (this.timeSetSync) {
/* 641 */       if (this.started) return;
/* 642 */       this.started = true;
/* 643 */       this.clock.syncStart(at);
/* 644 */       this.timeBase.mediaStarted();
/* 645 */       this.systemStartTime = (System.currentTimeMillis() * 1000000L);
/*     */     }
/*     */   }
/*     */   
/*     */   public void stop() {
/* 650 */     synchronized (this.timeSetSync) {
/* 651 */       if (!this.started) return;
/* 652 */       this.started = false;
/* 653 */       this.clock.stop();
/* 654 */       this.timeBase.mediaStopped();
/*     */     }
/*     */   }
/*     */   
/*     */   public void setStopTime(Time stopTime) {
/* 659 */     this.clock.setStopTime(stopTime);
/*     */   }
/*     */   
/*     */   public Time getStopTime() {
/* 663 */     return this.clock.getStopTime();
/*     */   }
/*     */   
/*     */   public void setMediaTime(Time now) {
/* 667 */     synchronized (this.timeSetSync) {
/* 668 */       this.clock.setMediaTime(now);
/* 669 */       for (int i = 0; i < this.mediaTime.length; i++)
/* 670 */         this.mediaTime[i] = now.getNanoseconds();
/* 671 */       this.timeBase.update();
/*     */     }
/*     */   }
/*     */   
/*     */   public Time getMediaTime() {
/* 676 */     return this.clock.getMediaTime();
/*     */   }
/*     */   
/*     */   public long getMediaNanoseconds()
/*     */   {
/* 681 */     return this.clock.getMediaNanoseconds();
/*     */   }
/*     */   
/*     */   public Time getSyncTime() {
/* 685 */     return this.clock.getSyncTime();
/*     */   }
/*     */   
/*     */   public TimeBase getTimeBase()
/*     */   {
/* 690 */     return this.clock.getTimeBase();
/*     */   }
/*     */   
/*     */   public Time mapToTimeBase(Time t) throws ClockStoppedException {
/* 694 */     return this.clock.mapToTimeBase(t);
/*     */   }
/*     */   
/*     */   public float getRate() {
/* 698 */     return this.clock.getRate();
/*     */   }
/*     */   
/*     */   public float setRate(float factor) {
/* 702 */     if (factor == this.clock.getRate())
/* 703 */       return factor;
/* 704 */     return this.clock.setRate(1.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean requireTwoPass()
/*     */   {
/* 714 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   class SWC
/*     */     implements StreamWriterControl, Owned
/*     */   {
/*     */     private BasicMux bmx;
/*     */     
/*     */ 
/*     */     public SWC(BasicMux bmx)
/*     */     {
/* 726 */       this.bmx = bmx;
/*     */     }
/*     */     
/*     */     public boolean setStreamSizeLimit(long limit) {
/* 730 */       this.bmx.fileSizeLimit = limit;
/* 731 */       return BasicMux.this.streamSizeLimitSupported;
/*     */     }
/*     */     
/*     */     public long getStreamSize() {
/* 735 */       return this.bmx.getStreamSize();
/*     */     }
/*     */     
/*     */     public Object getOwner() {
/* 739 */       return this.bmx;
/*     */     }
/*     */     
/*     */ 
/* 743 */     public Component getControlComponent() { return null; }
/*     */   }
/*     */   
/*     */   class BasicMuxTimeBase extends MediaTimeBase {
/*     */     BasicMuxTimeBase() {}
/*     */     
/* 749 */     long ticks = 0L;
/* 750 */     boolean updated = false;
/*     */     
/*     */     public long getMediaTime() {
/* 753 */       if (!this.updated) {
/* 754 */         return this.ticks;
/*     */       }
/* 756 */       if (BasicMux.this.mediaTime.length == 1) {
/* 757 */         this.ticks = BasicMux.this.mediaTime[0];
/*     */       } else {
/* 759 */         this.ticks = BasicMux.this.mediaTime[0];
/* 760 */         for (int i = 1; i < BasicMux.this.mediaTime.length; i++) {
/* 761 */           if (BasicMux.this.mediaTime[i] < this.ticks)
/* 762 */             this.ticks = BasicMux.this.mediaTime[i];
/*     */         }
/*     */       }
/* 765 */       this.updated = false;
/* 766 */       return this.ticks;
/*     */     }
/*     */     
/*     */     public void update() {
/* 770 */       this.updated = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   class BasicMuxDataSource
/*     */     extends PushDataSource
/*     */   {
/*     */     private BasicMux mux;
/*     */     private ContentDescriptor cd;
/*     */     private BasicMux.BasicMuxPushStream[] streams;
/*     */     private BasicMux.BasicMuxPushStream stream;
/* 782 */     private boolean connected = false;
/* 783 */     private boolean started = false;
/*     */     
/*     */     public BasicMuxDataSource(BasicMux mux, ContentDescriptor cd) {
/* 786 */       this.cd = cd;
/* 787 */       this.mux = mux;
/*     */     }
/*     */     
/*     */     public PushSourceStream[] getStreams() {
/* 791 */       if (this.streams == null) {
/* 792 */         this.streams = new BasicMux.BasicMuxPushStream[1];
/* 793 */         this.stream = new BasicMux.BasicMuxPushStream(BasicMux.this, this.cd);
/* 794 */         this.streams[0] = this.stream;
/* 795 */         BasicMux.this.setStream(this.stream);
/*     */       }
/* 797 */       return this.streams;
/*     */     }
/*     */     
/*     */     public String getContentType() {
/* 801 */       return this.cd.getContentType();
/*     */     }
/*     */     
/*     */     public void connect() throws IOException {
/* 805 */       if (this.streams == null)
/* 806 */         getStreams();
/* 807 */       this.connected = true;
/* 808 */       synchronized (BasicMux.this.sourceLock) {
/* 809 */         BasicMux.this.sourceLock.notifyAll();
/*     */       }
/*     */     }
/*     */     
/*     */     boolean isConnected() {
/* 814 */       return this.connected;
/*     */     }
/*     */     
/*     */     boolean isStarted() {
/* 818 */       return this.started;
/*     */     }
/*     */     
/*     */     public void disconnect() {
/* 822 */       this.connected = false;
/*     */     }
/*     */     
/*     */     public void start() throws IOException {
/* 826 */       if ((this.streams == null) || (!this.connected))
/* 827 */         throw new IOException("Source not connected yet!");
/* 828 */       this.started = true;
/* 829 */       synchronized (BasicMux.this.sourceLock) {
/* 830 */         BasicMux.this.sourceLock.notifyAll();
/*     */       }
/*     */     }
/*     */     
/*     */     public void stop() {
/* 835 */       this.started = false;
/*     */     }
/*     */     
/*     */     public Object[] getControls() {
/* 839 */       return new Control[0];
/*     */     }
/*     */     
/*     */     public Object getControl(String s) {
/* 843 */       return null;
/*     */     }
/*     */     
/*     */     public Time getDuration() {
/* 847 */       return Duration.DURATION_UNKNOWN;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   class BasicMuxPushStream
/*     */     implements PushSourceStream
/*     */   {
/*     */     private ContentDescriptor cd;
/*     */     
/*     */     private byte[] data;
/*     */     
/*     */     private int dataLen;
/*     */     private int dataOff;
/* 861 */     private Integer writeLock = new Integer(0);
/*     */     
/*     */     public BasicMuxPushStream(ContentDescriptor cd) {
/* 864 */       this.cd = cd;
/*     */     }
/*     */     
/*     */     public ContentDescriptor getContentDescriptor() {
/* 868 */       return this.cd;
/*     */     }
/*     */     
/*     */     public long getContentLength() {
/* 872 */       return -1L;
/*     */     }
/*     */     
/*     */     public boolean endOfStream() {
/* 876 */       return BasicMux.this.isEOS();
/*     */     }
/*     */     
/*     */     synchronized int write(byte[] data, int offset, int length)
/*     */     {
/* 881 */       if (BasicMux.this.sth == null) {
/* 882 */         return 0;
/*     */       }
/* 884 */       if ((BasicMux.this.isLiveData) && ((BasicMux.this.sth instanceof Syncable))) {
/* 885 */         ((Syncable)BasicMux.this.sth).setSyncEnabled();
/*     */       }
/* 887 */       synchronized (this.writeLock) {
/* 888 */         this.data = data;
/* 889 */         this.dataOff = offset;
/* 890 */         this.dataLen = length;
/*     */         
/*     */ 
/* 893 */         BasicMux.this.sth.transferData(this);
/* 894 */         while (this.dataLen > 0) {
/* 895 */           if (this.dataLen == length) {
/*     */             try {
/* 897 */               this.writeLock.wait();
/*     */             }
/*     */             catch (InterruptedException ie) {}
/*     */           }
/* 901 */           if (BasicMux.this.sth == null) {
/*     */             break;
/*     */           }
/* 904 */           if ((this.dataLen > 0) && (this.dataLen != length)) {
/* 905 */             length = this.dataLen;
/* 906 */             BasicMux.this.sth.transferData(this);
/*     */           }
/*     */         }
/*     */       }
/* 910 */       return length;
/*     */     }
/*     */     
/*     */     synchronized int seek(int location) {
/* 914 */       if (BasicMux.this.sth != null) {
/* 915 */         ((Seekable)BasicMux.this.sth).seek(location);
/* 916 */         int seekVal = (int)((Seekable)BasicMux.this.sth).tell();
/* 917 */         return seekVal;
/*     */       }
/* 919 */       return -1;
/*     */     }
/*     */     
/*     */     public int read(byte[] buffer, int offset, int length) throws IOException {
/* 923 */       int transferred = 0;
/*     */       
/* 925 */       synchronized (this.writeLock) {
/* 926 */         if (this.dataLen == -1) {
/* 927 */           transferred = -1;
/*     */         } else {
/* 929 */           if (length >= this.dataLen) {
/* 930 */             transferred = this.dataLen;
/*     */           } else {
/* 932 */             transferred = length;
/*     */           }
/* 934 */           System.arraycopy(this.data, this.dataOff, buffer, offset, transferred);
/*     */           
/* 936 */           this.dataLen -= transferred;
/* 937 */           this.dataOff += transferred;
/*     */         }
/* 939 */         this.writeLock.notifyAll();
/* 940 */         int i = transferred;return i;
/*     */       }
/*     */     }
/*     */     
/*     */     public int getMinimumTransferSize() {
/* 945 */       return this.dataLen;
/*     */     }
/*     */     
/*     */     public void setTransferHandler(SourceTransferHandler sth) {
/* 949 */       synchronized (this.writeLock) {
/* 950 */         BasicMux.this.sth = sth;
/* 951 */         if ((sth != null) && (BasicMux.this.needsSeekable()) && (!(sth instanceof Seekable))) {
/* 952 */           throw new Error("SourceTransferHandler needs to be seekable");
/*     */         }
/* 954 */         boolean requireTwoPass = BasicMux.this.requireTwoPass();
/*     */         
/* 956 */         if ((requireTwoPass) && 
/* 957 */           (sth != null) && ((sth instanceof RandomAccess)))
/*     */         {
/* 959 */           RandomAccess st = (RandomAccess)sth;
/* 960 */           st.setEnabled(true);
/*     */         }
/*     */         
/* 963 */         this.writeLock.notifyAll();
/*     */       }
/*     */     }
/*     */     
/*     */     public Object[] getControls() {
/* 968 */       return new Control[0];
/*     */     }
/*     */     
/*     */     public Object getControl(String s) {
/* 972 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\multiplexer\BasicMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */