/*     */ package com.sun.media.multiplexer.audio;
/*     */ 
/*     */ import com.sun.media.multiplexer.BasicMux;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.FileTypeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AUMux
/*     */   extends BasicMux
/*     */ {
/*     */   private static final int HEADER_SIZE = 24;
/*     */   private static final int UNKNOWN_ENCODING = -1;
/*     */   private AudioFormat audioFormat;
/*     */   private int sampleSizeInBits;
/*     */   private int encoding;
/*     */   private double sampleRate;
/*     */   private int channels;
/*     */   private static final int AU_SUN_MAGIC = 779316836;
/*     */   private static final int AU_ULAW_8 = 1;
/*     */   private static final int AU_ALAW_8 = 27;
/*     */   private static final int AU_LINEAR_8 = 2;
/*     */   private static final int AU_LINEAR_16 = 3;
/*     */   private static final int AU_LINEAR_24 = 4;
/*     */   private static final int AU_LINEAR_32 = 5;
/*     */   private static final int AU_FLOAT = 6;
/*     */   private static final int AU_DOUBLE = 7;
/*     */   
/*     */   public AUMux()
/*     */   {
/*  46 */     this.supportedInputs = new Format[1];
/*  47 */     this.supportedInputs[0] = new AudioFormat(null);
/*  48 */     this.supportedOutputs = new ContentDescriptor[1];
/*  49 */     this.supportedOutputs[0] = new FileTypeDescriptor("audio.basic");
/*     */   }
/*     */   
/*     */   public String getName() {
/*  53 */     return "Basic Audio Multiplexer";
/*     */   }
/*     */   
/*     */   public int setNumTracks(int nTracks) {
/*  57 */     if (nTracks != 1) {
/*  58 */       return 1;
/*     */     }
/*  60 */     return super.setNumTracks(nTracks);
/*     */   }
/*     */   
/*     */   protected void writeHeader() {
/*  64 */     bufClear();
/*  65 */     bufWriteInt(779316836);
/*  66 */     bufWriteInt(24);
/*  67 */     bufWriteInt(-1);
/*  68 */     bufWriteInt(this.encoding);
/*  69 */     bufWriteInt((int)this.sampleRate);
/*  70 */     bufWriteInt(this.channels);
/*  71 */     bufFlush();
/*     */   }
/*     */   
/*     */ 
/*  75 */   Format bigEndian = new AudioFormat(null, -1.0D, -1, -1, 1, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Format setInputFormat(Format format, int trackID)
/*     */   {
/*  84 */     String reason = null;
/*     */     
/*  86 */     if (!(format instanceof AudioFormat)) {
/*  87 */       return null;
/*     */     }
/*  89 */     this.audioFormat = ((AudioFormat)format);
/*     */     
/*  91 */     String encodingString = this.audioFormat.getEncoding();
/*  92 */     this.sampleSizeInBits = this.audioFormat.getSampleSizeInBits();
/*     */     
/*     */ 
/*  95 */     if (encodingString.equalsIgnoreCase("LINEAR")) {
/*  96 */       if ((this.sampleSizeInBits > 8) && (this.audioFormat.getEndian() == 0))
/*     */       {
/*  98 */         return null;
/*     */       }
/* 100 */       if (this.audioFormat.getSigned() == 0) {
/* 101 */         return null;
/*     */       }
/* 103 */       if ((this.audioFormat.getEndian() == -1) || (this.audioFormat.getSigned() == -1))
/*     */       {
/* 105 */         this.audioFormat = ((AudioFormat)this.audioFormat.intersects(this.bigEndian));
/*     */       }
/*     */     }
/*     */     
/* 109 */     this.encoding = getEncoding(encodingString, this.sampleSizeInBits);
/* 110 */     if (this.encoding == -1) {
/* 111 */       reason = "No support for encoding " + encodingString;
/*     */     }
/*     */     
/* 114 */     this.sampleRate = this.audioFormat.getSampleRate();
/* 115 */     this.channels = this.audioFormat.getChannels();
/*     */     
/* 117 */     if (reason == null) {
/* 118 */       return this.audioFormat;
/*     */     }
/* 120 */     return null;
/*     */   }
/*     */   
/*     */   protected void writeFooter() {
/* 124 */     seek(8);
/* 125 */     bufClear();
/* 126 */     bufWriteInt(this.fileSize - 24);
/* 127 */     bufFlush();
/*     */   }
/*     */   
/*     */   private int getEncoding(String encodingString, int sampleSizeInBits)
/*     */   {
/* 132 */     if (encodingString.equalsIgnoreCase("ULAW"))
/* 133 */       return 1;
/* 134 */     if (encodingString.equalsIgnoreCase("alaw"))
/* 135 */       return 27;
/* 136 */     if (encodingString.equalsIgnoreCase("LINEAR")) {
/* 137 */       if (sampleSizeInBits == 8)
/* 138 */         return 2;
/* 139 */       if (sampleSizeInBits == 16)
/* 140 */         return 3;
/* 141 */       if (sampleSizeInBits == 24)
/* 142 */         return 4;
/* 143 */       if (sampleSizeInBits == 32) {
/* 144 */         return 5;
/*     */       }
/* 146 */       return -1; }
/* 147 */     if (encodingString.equalsIgnoreCase("float"))
/* 148 */       return 6;
/* 149 */     if (encodingString.equalsIgnoreCase("double")) {
/* 150 */       return 7;
/*     */     }
/*     */     
/* 153 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\multiplexer\audio\AUMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */