/*    */ package com.sun.media.multiplexer.audio;
/*    */ 
/*    */ import com.sun.media.multiplexer.BasicMux;
/*    */ import javax.media.Format;
/*    */ import javax.media.format.AudioFormat;
/*    */ import javax.media.protocol.ContentDescriptor;
/*    */ import javax.media.protocol.FileTypeDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GSMMux
/*    */   extends BasicMux
/*    */ {
/*    */   public GSMMux()
/*    */   {
/* 41 */     this.supportedInputs = new Format[1];
/* 42 */     this.supportedInputs[0] = new AudioFormat("gsm");
/* 43 */     this.supportedOutputs = new ContentDescriptor[1];
/* 44 */     this.supportedOutputs[0] = new FileTypeDescriptor("audio.x_gsm");
/*    */   }
/*    */   
/*    */   public String getName() {
/* 48 */     return "GSM Multiplexer";
/*    */   }
/*    */   
/*    */   public Format setInputFormat(Format input, int trackID) {
/* 52 */     if (!(input instanceof AudioFormat))
/* 53 */       return null;
/* 54 */     AudioFormat format = (AudioFormat)input;
/* 55 */     double sampleRate = format.getSampleRate();
/*    */     
/* 57 */     String reason = null;
/* 58 */     double epsilon = 0.25D;
/*    */     
/*    */ 
/* 61 */     if (!format.getEncoding().equalsIgnoreCase("gsm")) {
/* 62 */       reason = "Encoding has to be GSM";
/* 63 */     } else if (Math.abs(sampleRate - 8000.0D) > epsilon) {
/* 64 */       reason = "Sample rate should be 8000. Cannot handle sample rate " + sampleRate;
/* 65 */     } else if (format.getFrameSizeInBits() != 264) {
/* 66 */       reason = "framesize should be 33 bytes";
/* 67 */     } else if (format.getChannels() != 1) {
/* 68 */       reason = "Number of channels should be 1";
/*    */     }
/* 70 */     if (reason != null) {
/* 71 */       return null;
/*    */     }
/* 73 */     this.inputs[0] = format;
/* 74 */     return format;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\multiplexer\audio\GSMMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */