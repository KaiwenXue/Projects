/*      */ package com.sun.media.multiplexer.video;
/*      */ 
/*      */ import com.sun.media.BasicPlugIn;
/*      */ import com.sun.media.format.AviVideoFormat;
/*      */ import com.sun.media.format.WavAudioFormat;
/*      */ import com.sun.media.multiplexer.BasicMux;
/*      */ import com.sun.media.parser.BasicPullParser;
/*      */ import com.sun.media.util.ByteBuffer;
/*      */ import java.awt.Dimension;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ import javax.media.Buffer;
/*      */ import javax.media.Format;
/*      */ import javax.media.format.AudioFormat;
/*      */ import javax.media.format.RGBFormat;
/*      */ import javax.media.format.VideoFormat;
/*      */ import javax.media.format.YUVFormat;
/*      */ import javax.media.protocol.ContentDescriptor;
/*      */ import javax.media.protocol.FileTypeDescriptor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class AVIMux
/*      */   extends BasicMux
/*      */ {
/*      */   private int[] suggestedBufferSizes;
/*      */   private int[] suggestedBufferSizeOffsets;
/*      */   private int[] scaleOffsets;
/*      */   private boolean[] endOfMediaStatus;
/*   42 */   private int numberOfEoms = 0;
/*   43 */   private int width = 0;
/*   44 */   private int height = 0;
/*      */   
/*      */   private static final int MAX_FRAMES_STORED = 20000;
/*      */   
/*      */   private static final int AVIH_HEADER_LENGTH = 56;
/*      */   
/*      */   private static final int STRH_HEADER_LENGTH = 56;
/*      */   
/*      */   private static final int STRF_VIDEO_HEADER_LENGTH = 40;
/*      */   
/*      */   private static final int STRF_AUDIO_HEADER_LENGTH = 16;
/*      */   
/*      */   static final String AUDIO = "auds";
/*      */   
/*      */   static final String VIDEO = "vids";
/*      */   
/*      */   static final int AVIF_HASINDEX = 16;
/*      */   
/*      */   static final int AVIF_MUSTUSEINDEX = 32;
/*      */   
/*      */   static final int AVIF_ISINTERLEAVED = 256;
/*      */   static final int AVIF_WASCAPTUREFILE = 65536;
/*      */   static final int AVIF_COPYRIGHTED = 131072;
/*      */   static final int AVIF_KEYFRAME = 16;
/*   68 */   private int usecPerFrame = -1;
/*   69 */   private float frameRate = -1.0F;
/*      */   
/*      */   private int maxBytesPerSecond;
/*      */   private int paddingGranularity;
/*      */   private long avgFrameTime;
/*   74 */   private int flags = 16;
/*   75 */   private int totalDataLength = 0;
/*   76 */   private int totalFrames = 0;
/*   77 */   private int totalVideoFrames = 0;
/*      */   private int initialFrames;
/*   79 */   private int[] reserved = new int[4];
/*      */   
/*   81 */   private Vector chunkList = new Vector(1);
/*   82 */   private final int BUF_SIZE = 16384;
/*   83 */   private ByteBuffer bbuf = new ByteBuffer(16384);
/*   84 */   private int chunkOffset = 4;
/*   85 */   private int moviOffset = 0;
/*   86 */   private int avihOffset = 0;
/*   87 */   private int hdrlSizeOffset = 0;
/*   88 */   private int totalStrlLength = 0;
/*      */   
/*   90 */   private int blockAlign = 1;
/*      */   
/*      */ 
/*   93 */   private int samplesPerBlock = -1;
/*      */   
/*      */ 
/*   96 */   private double sampleRate = 0.0D;
/*      */   
/*      */ 
/*   99 */   private double audioDuration = 0.0D;
/*      */   
/*      */ 
/*  102 */   private int averageBytesPerSecond = -1;
/*      */   
/*      */ 
/*  105 */   private int mp3BitRate = -1;
/*      */   
/*      */ 
/*  108 */   private long cumulativeInterFrameTimeVideo = 0L;
/*  109 */   private long previousTimeStampVideo = 0L;
/*      */   
/*      */   static final String LISTRECORDCHUNK = "rec ";
/*      */   
/*      */   static final String VIDEO_MAGIC = "dc";
/*      */   static final String VIDEO_MAGIC_JPEG = "db";
/*      */   static final String VIDEO_MAGIC_IV32a = "iv";
/*      */   static final String VIDEO_MAGIC_IV32b = "32";
/*      */   static final String VIDEO_MAGIC_IV31 = "31";
/*      */   static final String VIDEO_MAGIC_CVID = "id";
/*      */   static final String AUDIO_MAGIC = "wb";
/*      */   
/*      */   public AVIMux()
/*      */   {
/*  123 */     this.supportedInputs = new Format[2];
/*  124 */     this.supportedInputs[0] = new AudioFormat(null);
/*  125 */     this.supportedInputs[1] = new VideoFormat(null);
/*      */     
/*  127 */     this.supportedOutputs = new ContentDescriptor[1];
/*  128 */     this.supportedOutputs[0] = new FileTypeDescriptor("video.x_msvideo");
/*      */     
/*  130 */     this.chunkList.addElement(this.bbuf);
/*      */   }
/*      */   
/*      */   private Format[] createRGBFormats(Dimension size) {
/*  134 */     int NS = -1;
/*  135 */     Format[] rgbFormats = { new RGBFormat(size, size.width * size.height * 2, Format.byteArray, NS, 16, 31744, 992, 31, 2, size.width * 2, 1, 1), new RGBFormat(size, size.width * size.height * 3, Format.byteArray, NS, 24, 3, 2, 1, 3, size.width * 3, 1, NS), new RGBFormat(size, size.width * size.height * 4, Format.byteArray, NS, 32, 3, 2, 1, 4, size.width * 4, 1, NS) };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  147 */     return rgbFormats;
/*      */   }
/*      */   
/*      */   private Format[] createYUVFormats(Dimension size) {
/*  151 */     int NS = -1;
/*  152 */     Format[] yuvFormats = { new YUVFormat(size, size.width * size.height * 2, Format.byteArray, NS, 32, size.width * 2, size.width * 2, 1, 0, 2), new YUVFormat(size, size.width * size.height * 2, Format.byteArray, NS, 32, size.width * 2, size.width * 2, 0, 1, 3), new YUVFormat(size, size.width * size.height * 3 / 2, Format.byteArray, NS, 2, size.width, size.width / 2, 0, size.width * size.height, size.width * size.height * 5 / 4), new YUVFormat(size, size.width * size.height * 3 / 2, Format.byteArray, NS, 2, size.width, size.width / 2, 0, size.width * size.height * 5 / 4, size.width * size.height) };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  174 */     return yuvFormats;
/*      */   }
/*      */   
/*      */   public String getName() {
/*  178 */     return "AVI Multiplexer";
/*      */   }
/*      */   
/*      */ 
/*  182 */   Format littleEndian = new AudioFormat(null, -1.0D, -1, -1, 0, -1);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  190 */   Format signed = new AudioFormat(null, -1.0D, -1, -1, 0, 1);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  197 */   Format unsigned = new AudioFormat(null, -1.0D, -1, -1, 0, 0);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Format setInputFormat(Format input, int trackID)
/*      */   {
/*  206 */     String reason = null;
/*      */     
/*  208 */     if ((input instanceof AudioFormat)) {
/*  209 */       AudioFormat af = (AudioFormat)input;
/*  210 */       WavAudioFormat wavAudioFormat = null;
/*      */       
/*  212 */       if ((input instanceof WavAudioFormat)) {
/*  213 */         wavAudioFormat = (WavAudioFormat)input;
/*      */       }
/*      */       
/*  216 */       String encoding = af.getEncoding();
/*  217 */       if (encoding == null) {
/*  218 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  229 */       if (encoding.equalsIgnoreCase("LINEAR")) {
/*  230 */         if (af.getSampleSizeInBits() > 8) {
/*  231 */           if (af.getEndian() == 1) {
/*  232 */             return null;
/*      */           }
/*  234 */           if (af.getSigned() == 0) {
/*  235 */             return null;
/*      */           }
/*      */           
/*  238 */           if ((af.getEndian() == -1) || (af.getSigned() == -1))
/*      */           {
/*  240 */             input = (AudioFormat)af.intersects(this.signed);
/*      */           }
/*      */         } else {
/*  243 */           if (af.getSigned() == 1) {
/*  244 */             return null;
/*      */           }
/*      */           
/*  247 */           if ((af.getEndian() == -1) || (af.getSigned() == -1))
/*      */           {
/*  249 */             input = (AudioFormat)af.intersects(this.unsigned);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  254 */       Integer formatTag = (Integer)WavAudioFormat.reverseFormatMapper.get(encoding.toLowerCase());
/*      */       
/*  256 */       if ((formatTag == null) || (af.getEncoding().equalsIgnoreCase("truespeech")) || (af.getEncoding().toLowerCase().startsWith("voxware")))
/*      */       {
/*      */ 
/*      */ 
/*  260 */         reason = "Cannot handle format";
/*  261 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  266 */       short wFormatTag = formatTag.shortValue();
/*  267 */       switch (wFormatTag) {
/*      */       case 2: 
/*      */       case 17: 
/*      */       case 49: 
/*  271 */         if (wavAudioFormat == null) {
/*  272 */           reason = "A WavAudioFormat is required  to provide encoding specific information for this encoding " + wFormatTag;
/*      */           
/*      */ 
/*  275 */           return null;
/*      */         }
/*      */         break; }
/*  278 */     } else if ((input instanceof VideoFormat)) {
/*  279 */       VideoFormat vf = (VideoFormat)input;
/*      */       
/*  281 */       String encoding = vf.getEncoding();
/*  282 */       Dimension size = vf.getSize();
/*  283 */       if (size == null)
/*  284 */         size = new Dimension(320, 240);
/*  285 */       if (encoding == null) {
/*  286 */         return null;
/*      */       }
/*  288 */       if (encoding.equalsIgnoreCase("rgb")) {
/*  289 */         if (BasicPlugIn.matches(vf, createRGBFormats(size)) == null)
/*  290 */           return null;
/*  291 */       } else if (encoding.equalsIgnoreCase("yuv")) {
/*  292 */         if (BasicPlugIn.matches(vf, createYUVFormats(size)) == null)
/*  293 */           return null;
/*  294 */       } else { if (encoding.equalsIgnoreCase("jpeg"))
/*  295 */           return null;
/*  296 */         if (encoding.length() > 4)
/*  297 */           return null;
/*      */       }
/*  299 */       this.frameRate = vf.getFrameRate();
/*  300 */       if (this.frameRate > 0.0F)
/*  301 */         this.usecPerFrame = ((int)(1.0F / this.frameRate * 1000000.0F));
/*  302 */       this.avgFrameTime = (this.usecPerFrame * 1000);
/*      */     } else {
/*  304 */       reason = "Can only support Audio and Video formats";
/*      */     }
/*      */     
/*  307 */     if (reason != null) {
/*  308 */       return null;
/*      */     }
/*  310 */     this.inputs[trackID] = input;
/*      */     
/*  312 */     return input;
/*      */   }
/*      */   
/*      */ 
/*      */   public int setNumTracks(int nTracks)
/*      */   {
/*  318 */     if (nTracks > 2) {
/*  319 */       return 2;
/*      */     }
/*  321 */     this.suggestedBufferSizeOffsets = new int[nTracks];
/*  322 */     this.suggestedBufferSizes = new int[nTracks];
/*  323 */     this.endOfMediaStatus = new boolean[nTracks];
/*  324 */     for (int i = 0; i < nTracks; i++) {
/*  325 */       this.suggestedBufferSizes[i] = -1;
/*  326 */       this.suggestedBufferSizeOffsets[i] = -1;
/*      */     }
/*      */     
/*  329 */     return super.setNumTracks(nTracks);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public synchronized int doProcess(Buffer buffer, int trackID)
/*      */   {
/*  336 */     if (buffer.isEOM()) {
/*  337 */       this.numberOfEoms += 1;
/*  338 */       if (this.numberOfEoms >= this.numTracks) {
/*  339 */         return super.doProcess(buffer, trackID);
/*      */       }
/*  341 */       return 0;
/*      */     }
/*      */     
/*      */ 
/*  345 */     if (buffer.getData() == null) {
/*  346 */       return 0;
/*      */     }
/*  348 */     boolean isVideoFormat = buffer.getFormat() instanceof VideoFormat;
/*      */     
/*  350 */     if (isVideoFormat) {
/*  351 */       long timeStamp = buffer.getTimeStamp();
/*  352 */       if (timeStamp - this.previousTimeStampVideo > this.avgFrameTime * 1.9D)
/*      */       {
/*  354 */         int blankFrames = (int)((timeStamp - this.previousTimeStampVideo) / this.avgFrameTime);
/*      */         
/*  356 */         for (int i = 0; i < blankFrames; i++) {
/*  357 */           Buffer blankBuffer = new Buffer();
/*  358 */           blankBuffer.setTimeStamp(this.previousTimeStampVideo + i * this.avgFrameTime);
/*      */           
/*  360 */           blankBuffer.setFormat(buffer.getFormat());
/*  361 */           blankBuffer.setDuration(this.avgFrameTime);
/*  362 */           blankBuffer.setSequenceNumber(buffer.getSequenceNumber());
/*  363 */           blankBuffer.setFlags(buffer.getFlags() & 0xFFFFFFEF);
/*      */           
/*  365 */           int result = writeFrame(blankBuffer, trackID);
/*  366 */           if (result != 0) {
/*  367 */             return result;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  374 */     return writeFrame(buffer, trackID);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int writeFrame(Buffer buffer, int trackID)
/*      */   {
/*  383 */     boolean isVideoFormat = buffer.getFormat() instanceof VideoFormat;
/*      */     
/*  385 */     int length = buffer.getLength();
/*  386 */     int pad; if ((length & 0x1) > 0) {
/*  387 */       pad = 1;
/*      */     } else {
/*  389 */       pad = 0;
/*      */     }
/*  391 */     String aviEncodingMagic = getAviEncodingMagic(trackID, isVideoFormat);
/*  392 */     bufClear();
/*  393 */     bufWriteBytes(aviEncodingMagic);
/*  394 */     bufWriteIntLittleEndian(length + pad);
/*  395 */     bufFlush();
/*      */     
/*  397 */     if (length > 0)
/*  398 */       write((byte[])buffer.getData(), buffer.getOffset(), length);
/*  399 */     if (pad > 0) {
/*  400 */       bufClear();
/*  401 */       bufWriteByte((byte)0);
/*  402 */       bufFlush();
/*      */     }
/*      */     
/*  405 */     this.totalDataLength += length + pad;
/*      */     
/*  407 */     if (length > this.suggestedBufferSizes[trackID]) {
/*  408 */       this.suggestedBufferSizes[trackID] = length;
/*      */     }
/*  410 */     if (this.bbuf.length == 16384) {
/*  411 */       this.bbuf = new ByteBuffer(16384);
/*  412 */       this.chunkList.addElement(this.bbuf);
/*      */     }
/*      */     
/*  415 */     this.bbuf.writeBytes(aviEncodingMagic);
/*  416 */     int flag = (buffer.getFlags() & 0x10) != 0 ? 16 : 0;
/*      */     
/*      */ 
/*  419 */     this.bbuf.writeIntLittleEndian(flag);
/*  420 */     this.bbuf.writeIntLittleEndian(this.chunkOffset);
/*  421 */     this.bbuf.writeIntLittleEndian(length);
/*  422 */     this.chunkOffset += length + pad + 8;
/*  423 */     if (isVideoFormat) {
/*  424 */       long timeStamp = buffer.getTimeStamp();
/*      */       
/*  426 */       if (this.totalVideoFrames > 0) {
/*  427 */         this.cumulativeInterFrameTimeVideo += timeStamp - this.previousTimeStampVideo;
/*      */       }
/*  429 */       this.previousTimeStampVideo = timeStamp;
/*  430 */       this.totalVideoFrames += 1;
/*      */     }
/*  432 */     else if (this.samplesPerBlock != -1) {
/*  433 */       int numBlocks = length / this.blockAlign;
/*  434 */       int numSamples = numBlocks * this.samplesPerBlock;
/*  435 */       this.audioDuration += numSamples / this.sampleRate;
/*      */     }
/*  437 */     else if (this.averageBytesPerSecond > 0) {
/*  438 */       this.audioDuration += length / this.averageBytesPerSecond;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  444 */     this.totalFrames += 1;
/*  445 */     return 0;
/*      */   }
/*      */   
/*      */   protected void writeHeader()
/*      */   {
/*  450 */     for (int i = 0; i < this.inputs.length; i++)
/*      */     {
/*      */ 
/*  453 */       if ((this.inputs[i] instanceof AudioFormat)) {
/*  454 */         AudioFormat af = (AudioFormat)this.inputs[i];
/*  455 */         WavAudioFormat wavAudioFormat = null;
/*      */         
/*  457 */         this.sampleRate = af.getSampleRate();
/*  458 */         if (af.getEncoding().equalsIgnoreCase("LINEAR")) {
/*  459 */           this.samplesPerBlock = 1;
/*      */         }
/*      */         
/*  462 */         if ((this.inputs[i] instanceof WavAudioFormat)) {
/*  463 */           wavAudioFormat = (WavAudioFormat)this.inputs[i];
/*      */           
/*  465 */           byte[] codecSpecificHeader = wavAudioFormat.getCodecSpecificHeader();
/*  466 */           if ((!af.getEncoding().equalsIgnoreCase("mpeglayer3")) && (codecSpecificHeader != null) && (codecSpecificHeader.length >= 2))
/*      */           {
/*      */             try
/*      */             {
/*  470 */               this.samplesPerBlock = BasicPullParser.parseShortFromArray(codecSpecificHeader, false);
/*      */ 
/*      */             }
/*      */             catch (IOException e)
/*      */             {
/*  475 */               System.err.println("Unable to parse codecSpecificHeader");
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  484 */     bufClear();
/*  485 */     bufWriteBytes("RIFF");
/*  486 */     bufSkip(4);
/*  487 */     bufWriteBytes("AVI ");
/*  488 */     bufWriteBytes("LIST");
/*  489 */     this.hdrlSizeOffset = this.filePointer;
/*  490 */     bufSkip(4);
/*  491 */     bufWriteBytes("hdrl");
/*  492 */     bufWriteBytes("avih");
/*  493 */     bufWriteIntLittleEndian(56);
/*  494 */     this.avihOffset = this.filePointer;
/*  495 */     bufSkip(56);
/*      */     
/*  497 */     this.scaleOffsets = new int[this.numTracks];
/*  498 */     for (int i = 0; i < this.numTracks; i++) {
/*  499 */       Format format = this.inputs[i];
/*  500 */       boolean isVideo = format instanceof VideoFormat;
/*  501 */       bufWriteBytes("LIST");
/*      */       
/*  503 */       byte[] codecSpecificHeader = null;
/*  504 */       int extraByteLength = 0;
/*      */       
/*  506 */       AviVideoFormat aviVideoFormat = null;
/*  507 */       WavAudioFormat wavAudioFormat = null;
/*  508 */       int planes = 1;
/*  509 */       int depth = 24;
/*  510 */       String yuvEncoding = null;
/*      */       
/*  512 */       String encoding = format.getEncoding();
/*  513 */       int wFormatTag = -1;
/*      */       
/*  515 */       if (isVideo) {
/*  516 */         int bytesInBitmap = 40;
/*  517 */         RGBFormat rgbFormat = null;
/*      */         
/*  519 */         if ((format instanceof RGBFormat)) {
/*  520 */           rgbFormat = (RGBFormat)format;
/*  521 */         } else if ((format instanceof YUVFormat)) {
/*  522 */           YUVFormat yuv = (YUVFormat)format;
/*  523 */           if ((yuv.getYuvType() == 32) && (yuv.getStrideY() == yuv.getSize().width * 2) && (yuv.getOffsetY() == 0) && (yuv.getOffsetU() == 1) && (yuv.getOffsetV() == 3))
/*      */           {
/*      */ 
/*      */ 
/*  527 */             yuvEncoding = "YUY2";
/*  528 */           } else if ((yuv.getYuvType() == 32) && (yuv.getStrideY() == yuv.getSize().width * 2) && (yuv.getOffsetY() == 1) && (yuv.getOffsetU() == 0) && (yuv.getOffsetV() == 2))
/*      */           {
/*      */ 
/*      */ 
/*  532 */             yuvEncoding = "UYVY";
/*  533 */           } else if ((yuv.getYuvType() == 32) && (yuv.getStrideY() == yuv.getSize().width * 2) && (yuv.getOffsetY() == 0) && (yuv.getOffsetU() == 3) && (yuv.getOffsetV() == 1))
/*      */           {
/*      */ 
/*      */ 
/*  537 */             yuvEncoding = "YVYU";
/*  538 */           } else if ((yuv.getYuvType() == 2) && 
/*  539 */             (yuv.getStrideY() == yuv.getSize().width) && (yuv.getStrideUV() == yuv.getSize().width / 2))
/*      */           {
/*  541 */             if (yuv.getOffsetU() < yuv.getOffsetV()) {
/*  542 */               yuvEncoding = "I420";
/*      */             } else {
/*  544 */               yuvEncoding = "YV12";
/*      */             }
/*      */           }
/*      */         }
/*  548 */         if ((format instanceof AviVideoFormat)) {
/*  549 */           aviVideoFormat = (AviVideoFormat)format;
/*      */         }
/*  551 */         if (aviVideoFormat != null) {
/*  552 */           planes = aviVideoFormat.getPlanes();
/*  553 */           depth = aviVideoFormat.getBitsPerPixel();
/*  554 */           codecSpecificHeader = aviVideoFormat.getCodecSpecificHeader();
/*  555 */         } else if (rgbFormat != null) {
/*  556 */           depth = rgbFormat.getBitsPerPixel();
/*      */         }
/*      */       } else {
/*  559 */         if ((format instanceof WavAudioFormat)) {
/*  560 */           wavAudioFormat = (WavAudioFormat)format;
/*  561 */           codecSpecificHeader = wavAudioFormat.getCodecSpecificHeader();
/*      */         }
/*  563 */         if (codecSpecificHeader == null) {
/*  564 */           Integer formatTag = (Integer)WavAudioFormat.reverseFormatMapper.get(encoding.toLowerCase());
/*      */           
/*      */ 
/*  567 */           if (formatTag != null) {
/*  568 */             wFormatTag = formatTag.shortValue();
/*  569 */             if (wFormatTag == 85) {
/*  570 */               extraByteLength = 12;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  576 */       if ((extraByteLength <= 0) && (codecSpecificHeader != null)) {
/*  577 */         extraByteLength = codecSpecificHeader.length;
/*      */       }
/*      */       
/*      */ 
/*  581 */       int strlLength = 0;
/*  582 */       if (isVideo) {
/*  583 */         strlLength = 116 + extraByteLength;
/*      */         
/*  585 */         bufWriteIntLittleEndian(strlLength);
/*      */       } else {
/*  587 */         if (extraByteLength > 0) {
/*  588 */           strlLength = 92 + extraByteLength + 2;
/*      */         }
/*      */         else {
/*  591 */           strlLength = 92;
/*      */         }
/*      */         
/*  594 */         bufWriteIntLittleEndian(strlLength);
/*      */       }
/*  596 */       this.totalStrlLength += strlLength;
/*  597 */       bufWriteBytes("strl");
/*  598 */       bufWriteBytes("strh");
/*  599 */       bufWriteIntLittleEndian(56);
/*      */       
/*      */ 
/*      */ 
/*  603 */       if (isVideo) {
/*  604 */         bufWriteBytes("vids");
/*      */         
/*      */ 
/*  607 */         if (encoding.startsWith("rgb")) {
/*  608 */           encoding = "DIB ";
/*  609 */         } else if (yuvEncoding != null) {
/*  610 */           encoding = yuvEncoding;
/*      */         }
/*  612 */         bufWriteBytes(encoding);
/*      */       }
/*      */       else {
/*  615 */         bufWriteBytes("auds");
/*  616 */         bufWriteIntLittleEndian(0);
/*      */       }
/*  618 */       bufWriteIntLittleEndian(0);
/*  619 */       bufWriteIntLittleEndian(0);
/*  620 */       bufWriteIntLittleEndian(0);
/*  621 */       this.scaleOffsets[i] = this.filePointer;
/*      */       
/*  623 */       bufWriteIntLittleEndian(1);
/*  624 */       bufWriteIntLittleEndian(15);
/*  625 */       bufWriteIntLittleEndian(0);
/*  626 */       bufWriteIntLittleEndian(0);
/*  627 */       this.suggestedBufferSizeOffsets[i] = this.filePointer;
/*  628 */       bufWriteIntLittleEndian(0);
/*  629 */       bufWriteIntLittleEndian(10000);
/*  630 */       bufWriteIntLittleEndian(0);
/*  631 */       bufWriteIntLittleEndian(0);
/*  632 */       bufWriteIntLittleEndian(0);
/*      */       
/*      */ 
/*      */ 
/*  636 */       bufWriteBytes("strf");
/*  637 */       if (isVideo)
/*      */       {
/*  639 */         bufWriteIntLittleEndian(40 + extraByteLength);
/*      */         
/*  641 */         bufWriteIntLittleEndian(40 + extraByteLength);
/*  642 */         this.width = ((VideoFormat)format).getSize().width;
/*  643 */         this.height = ((VideoFormat)format).getSize().height;
/*  644 */         bufWriteIntLittleEndian(this.width);
/*  645 */         bufWriteIntLittleEndian(this.height);
/*  646 */         bufWriteShortLittleEndian((short)planes);
/*  647 */         bufWriteShortLittleEndian((short)depth);
/*      */         
/*  649 */         if (encoding.startsWith("DIB")) {
/*  650 */           bufWriteIntLittleEndian(0);
/*      */         } else {
/*  652 */           bufWriteBytes(encoding);
/*      */         }
/*  654 */         int biSizeImage = 0;
/*  655 */         int biXPelsPerMeter = 0;
/*  656 */         int biYPelsPerMeter = 0;
/*  657 */         int biClrUsed = 0;
/*  658 */         int biClrImportant = 0;
/*      */         
/*  660 */         if (aviVideoFormat != null) {
/*  661 */           if (aviVideoFormat.getImageSize() != -1)
/*  662 */             biSizeImage = aviVideoFormat.getImageSize();
/*  663 */           if (aviVideoFormat.getXPelsPerMeter() != -1)
/*  664 */             biXPelsPerMeter = aviVideoFormat.getXPelsPerMeter();
/*  665 */           if (aviVideoFormat.getYPelsPerMeter() != -1)
/*  666 */             biYPelsPerMeter = aviVideoFormat.getYPelsPerMeter();
/*  667 */           if (aviVideoFormat.getClrUsed() != -1)
/*  668 */             biClrUsed = aviVideoFormat.getClrUsed();
/*  669 */           if (aviVideoFormat.getClrImportant() != -1) {
/*  670 */             biClrImportant = aviVideoFormat.getClrImportant();
/*      */           }
/*      */         }
/*  673 */         bufWriteIntLittleEndian(biSizeImage);
/*  674 */         bufWriteIntLittleEndian(biXPelsPerMeter);
/*  675 */         bufWriteIntLittleEndian(biYPelsPerMeter);
/*  676 */         bufWriteIntLittleEndian(biClrUsed);
/*  677 */         bufWriteIntLittleEndian(biClrImportant);
/*      */       }
/*      */       else
/*      */       {
/*  681 */         AudioFormat audioFormat = (AudioFormat)format;
/*  682 */         if (extraByteLength > 0) {
/*  683 */           bufWriteIntLittleEndian(16 + extraByteLength + 2);
/*      */         }
/*      */         else {
/*  686 */           bufWriteIntLittleEndian(16);
/*      */         }
/*      */         
/*      */ 
/*  690 */         if (encoding.equals("unknown")) {
/*  691 */           encoding = "LINEAR";
/*      */         }
/*      */         
/*      */ 
/*  695 */         Integer formatTag = (Integer)WavAudioFormat.reverseFormatMapper.get(encoding.toLowerCase());
/*      */         
/*  697 */         if (formatTag != null)
/*      */         {
/*      */ 
/*  700 */           bufWriteShortLittleEndian(formatTag.shortValue());
/*  701 */           short numChannels = (short)audioFormat.getChannels();
/*      */           
/*  703 */           bufWriteShortLittleEndian(numChannels);
/*  704 */           bufWriteIntLittleEndian((int)audioFormat.getSampleRate());
/*  705 */           short sampleSizeInBits = (short)audioFormat.getSampleSizeInBits();
/*      */           
/*  707 */           if (wavAudioFormat != null) {
/*  708 */             this.averageBytesPerSecond = wavAudioFormat.getAverageBytesPerSecond();
/*      */             
/*  710 */             if (formatTag.shortValue() == 85) {
/*  711 */               this.mp3BitRate = (this.averageBytesPerSecond * 8);
/*      */             }
/*  713 */           } else if (formatTag.shortValue() == 85)
/*      */           {
/*  715 */             int frameRate = (int)audioFormat.getFrameRate();
/*      */             
/*  717 */             if (frameRate != -1) {
/*  718 */               this.averageBytesPerSecond = frameRate;
/*  719 */               this.mp3BitRate = (this.averageBytesPerSecond * 8);
/*      */             } else {
/*  721 */               this.averageBytesPerSecond = ((int)audioFormat.getSampleRate() * numChannels * (sampleSizeInBits / 8));
/*      */             }
/*      */             
/*      */           }
/*      */           else
/*      */           {
/*  727 */             this.averageBytesPerSecond = ((int)audioFormat.getSampleRate() * numChannels * (sampleSizeInBits / 8));
/*      */           }
/*      */           
/*      */ 
/*  731 */           bufWriteIntLittleEndian(this.averageBytesPerSecond);
/*  732 */           this.blockAlign = (audioFormat.getFrameSizeInBits() / 8);
/*  733 */           if (this.blockAlign < 1) {
/*  734 */             this.blockAlign = (sampleSizeInBits * numChannels / 8);
/*      */           }
/*  736 */           if (this.blockAlign == 0) {
/*  737 */             this.blockAlign = 1;
/*      */           }
/*  739 */           if (this.mp3BitRate > 0)
/*      */           {
/*  741 */             this.blockAlign = 1;
/*      */           }
/*  743 */           bufWriteShortLittleEndian((short)this.blockAlign);
/*  744 */           bufWriteShortLittleEndian(sampleSizeInBits);
/*      */         }
/*      */       }
/*  747 */       if (extraByteLength > 0) {
/*  748 */         if (!isVideo) {
/*  749 */           if (codecSpecificHeader != null) {
/*  750 */             bufWriteShortLittleEndian((short)codecSpecificHeader.length);
/*  751 */             bufWriteBytes(codecSpecificHeader);
/*      */           } else {
/*  753 */             Integer formatTag = (Integer)WavAudioFormat.reverseFormatMapper.get(encoding.toLowerCase());
/*      */             
/*      */ 
/*  756 */             if (formatTag != null) {
/*  757 */               wFormatTag = formatTag.shortValue();
/*  758 */               if (wFormatTag == 85) {
/*  759 */                 AudioFormat af = (AudioFormat)this.inputs[i];
/*  760 */                 int frameRate = (int)af.getFrameRate();
/*      */                 
/*      */                 int blockSize;
/*  763 */                 if (frameRate > 0) {
/*  764 */                   float temp = 72.0F * frameRate * 8.0F / 8000.0F;
/*  765 */                   temp = (float)(temp * (8000.0D / af.getSampleRate()));
/*  766 */                   blockSize = (int)temp;
/*      */                 } else {
/*  768 */                   blockSize = 417;
/*      */                 }
/*      */                 
/*      */ 
/*  772 */                 bufWriteShortLittleEndian((short)12);
/*  773 */                 bufWriteShortLittleEndian((short)1);
/*  774 */                 bufWriteIntLittleEndian(2);
/*  775 */                 bufWriteShortLittleEndian((short)blockSize);
/*  776 */                 bufWriteShortLittleEndian((short)1);
/*  777 */                 bufWriteShortLittleEndian((short)1393);
/*      */               }
/*      */             }
/*      */           }
/*      */         } else {
/*  782 */           bufWriteBytes(codecSpecificHeader);
/*      */         }
/*      */       }
/*      */     }
/*  786 */     bufWriteBytes("LIST");
/*  787 */     this.moviOffset = this.filePointer;
/*  788 */     bufSkip(4);
/*  789 */     bufWriteBytes("movi");
/*  790 */     bufFlush();
/*      */     
/*      */ 
/*      */ 
/*  794 */     seek(this.hdrlSizeOffset);
/*  795 */     int hdrlSize = this.totalStrlLength + 56 + 4 * (3 + 2 * this.numTracks);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  801 */     bufClear();
/*  802 */     bufWriteIntLittleEndian(hdrlSize);
/*      */     
/*  804 */     bufFlush();
/*  805 */     seek(this.moviOffset + 8);
/*      */   }
/*      */   
/*      */   protected void writeFooter() {
/*  809 */     writeIDX1Chunk();
/*  810 */     writeAVIH();
/*  811 */     seek(this.moviOffset);
/*      */     
/*      */ 
/*      */ 
/*  815 */     bufClear();
/*  816 */     bufWriteIntLittleEndian(4 + this.totalDataLength + this.totalFrames * 8);
/*  817 */     bufFlush();
/*      */     
/*  819 */     for (int i = 0; i < this.numTracks; i++) {
/*  820 */       int offset = this.suggestedBufferSizeOffsets[i];
/*  821 */       if (offset > 0) {
/*  822 */         seek(offset);
/*  823 */         bufClear();
/*  824 */         bufWriteIntLittleEndian(this.suggestedBufferSizes[i]);
/*  825 */         bufFlush();
/*      */       }
/*  827 */       seek(this.scaleOffsets[i]);
/*  828 */       if ((this.inputs[i] instanceof VideoFormat)) {
/*  829 */         int rateVal = 10000;
/*  830 */         bufClear();
/*  831 */         bufWriteIntLittleEndian(this.usecPerFrame / 100);
/*  832 */         bufWriteIntLittleEndian(rateVal);
/*      */         
/*  834 */         bufWriteIntLittleEndian(0);
/*  835 */         bufWriteIntLittleEndian(this.totalVideoFrames);
/*      */         
/*  837 */         bufFlush();
/*      */       }
/*      */       else
/*      */       {
/*  841 */         AudioFormat audioFormat = (AudioFormat)this.inputs[i];
/*      */         
/*      */ 
/*  844 */         if (this.mp3BitRate > 0) {
/*  845 */           bufClear();
/*  846 */           bufWriteIntLittleEndian(8);
/*  847 */           bufFlush();
/*      */           
/*  849 */           bufClear();
/*  850 */           bufWriteIntLittleEndian(this.mp3BitRate);
/*  851 */           bufFlush();
/*      */           
/*  853 */           this.blockAlign = 1;
/*      */         } else {
/*  855 */           bufClear();
/*  856 */           bufWriteIntLittleEndian(this.blockAlign);
/*  857 */           bufFlush();
/*      */           
/*  859 */           int factor = 1;
/*  860 */           if (this.samplesPerBlock > 0)
/*  861 */             factor = this.samplesPerBlock;
/*  862 */           int rate = (int)(audioFormat.getSampleRate() / factor * this.blockAlign);
/*      */           
/*  864 */           bufClear();
/*  865 */           bufWriteIntLittleEndian(rate);
/*  866 */           bufFlush();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  871 */         seek(this.filePointer + 16);
/*  872 */         bufClear();
/*  873 */         bufWriteIntLittleEndian(this.blockAlign);
/*  874 */         bufFlush();
/*      */       }
/*      */     }
/*      */     
/*  878 */     seek(4);
/*  879 */     bufClear();
/*  880 */     bufWriteIntLittleEndian(this.fileSize - 8);
/*  881 */     bufFlush();
/*      */   }
/*      */   
/*      */   private void writeIDX1Chunk()
/*      */   {
/*  886 */     bufClear();
/*  887 */     bufWriteBytes("idx1");
/*  888 */     bufWriteIntLittleEndian(this.totalFrames * 16);
/*  889 */     bufFlush();
/*      */     
/*  891 */     for (int i = 0; i < this.chunkList.size(); i++)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  898 */       ByteBuffer bbuf = (ByteBuffer)this.chunkList.elementAt(i);
/*  899 */       write(bbuf.buffer, 0, bbuf.length);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void writeAVIH()
/*      */   {
/*  907 */     int audioFrames = 0;
/*  908 */     if (this.totalVideoFrames <= 0)
/*      */     {
/*  910 */       this.usecPerFrame = 1000;
/*  911 */       audioFrames = (int)(this.audioDuration * 1000000.0D / this.usecPerFrame);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  917 */       int computedUsecPerFrame = (int)(this.cumulativeInterFrameTimeVideo / (1000.0D * (this.totalVideoFrames - 1)));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  922 */       this.usecPerFrame = computedUsecPerFrame;
/*      */     }
/*  924 */     seek(this.avihOffset);
/*  925 */     bufClear();
/*  926 */     bufWriteIntLittleEndian(this.usecPerFrame);
/*  927 */     bufWriteIntLittleEndian(this.maxBytesPerSecond);
/*  928 */     bufWriteIntLittleEndian(this.paddingGranularity);
/*  929 */     bufWriteIntLittleEndian(this.flags);
/*      */     
/*      */ 
/*  932 */     if (this.totalVideoFrames > 0) {
/*  933 */       bufWriteIntLittleEndian(this.totalVideoFrames);
/*      */     } else {
/*  935 */       bufWriteIntLittleEndian(audioFrames);
/*      */     }
/*  937 */     bufWriteIntLittleEndian(this.initialFrames);
/*  938 */     bufWriteIntLittleEndian(this.numTracks);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  946 */     bufWriteIntLittleEndian(0);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  956 */     bufWriteIntLittleEndian(this.width);
/*  957 */     bufWriteIntLittleEndian(this.height);
/*  958 */     bufWriteIntLittleEndian(0);
/*  959 */     bufWriteIntLittleEndian(0);
/*  960 */     bufWriteIntLittleEndian(0);
/*  961 */     bufWriteIntLittleEndian(0);
/*  962 */     bufFlush();
/*      */   }
/*      */   
/*      */ 
/*      */   private String getAviEncodingMagic(int streamNumber, boolean isVideoFormat)
/*      */   {
/*  968 */     String encoding = this.inputs[streamNumber].getEncoding().toLowerCase();
/*      */     
/*      */     String magic;
/*  971 */     if (isVideoFormat)
/*      */     {
/*  973 */       if (encoding.equalsIgnoreCase("cvid")) {
/*  974 */         magic = "id";
/*  975 */       } else if (encoding.startsWith("iv32")) {
/*  976 */         magic = "32";
/*  977 */       } else if (encoding.startsWith("iv31")) {
/*  978 */         magic = "31";
/*  979 */       } else if (encoding.startsWith("iv")) {
/*  980 */         magic = "iv";
/*      */       } else
/*  982 */         magic = "dc";
/*      */     } else {
/*  984 */       magic = "wb";
/*      */     }
/*  986 */     String streamPrefix = null;
/*      */     
/*      */ 
/*  989 */     if (streamNumber == 0) {
/*  990 */       streamPrefix = "00";
/*  991 */     } else if (streamNumber == 1) {
/*  992 */       streamPrefix = "01";
/*  993 */     } else if (streamNumber == 2) {
/*  994 */       streamPrefix = "02";
/*  995 */     } else if (streamNumber == 3) {
/*  996 */       streamPrefix = "03";
/*  997 */     } else if (streamNumber == 4) {
/*  998 */       streamPrefix = "04";
/*      */     }
/*      */     
/* 1001 */     return streamPrefix + magic;
/*      */   }
/*      */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\multiplexer\video\AVIMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */