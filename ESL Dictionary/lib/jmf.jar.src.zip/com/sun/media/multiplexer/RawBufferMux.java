/*     */ package com.sun.media.multiplexer;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.BasicClock;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.CircularBuffer;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.MediaTimeBase;
/*     */ import com.sun.media.controls.MonitorAdapter;
/*     */ import com.sun.media.protocol.BasicPushBufferDataSource;
/*     */ import com.sun.media.util.MediaThread;
/*     */ import com.sun.media.util.jdk12;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Clock;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleTimeBaseException;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.Time;
/*     */ import javax.media.TimeBase;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.protocol.BufferTransferHandler;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.PushBufferStream;
/*     */ 
/*     */ public class RawBufferMux extends BasicPlugIn implements javax.media.Multiplexer, Clock
/*     */ {
/*  34 */   protected ContentDescriptor[] supported = null;
/*     */   
/*     */ 
/*  37 */   protected ContentDescriptor contentDesc = null;
/*     */   
/*     */ 
/*  40 */   protected RawBufferDataSource source = null;
/*     */   
/*     */ 
/*  43 */   protected RawBufferSourceStream[] streams = null;
/*     */   
/*     */ 
/*     */ 
/*  47 */   protected BasicClock clock = null;
/*     */   
/*     */ 
/*  50 */   protected RawMuxTimeBase timeBase = null;
/*     */   protected long[] mediaTime;
/*  52 */   protected int masterTrackID = -1;
/*     */   
/*  54 */   boolean sourceDisconnected = false;
/*  55 */   boolean allowDrop = false;
/*     */   
/*  57 */   boolean hasRead = false;
/*     */   
/*  59 */   private static JMFSecurity jmfSecurity = null;
/*  60 */   private static boolean securityPrivelege = false;
/*  61 */   private Method[] m = new Method[1];
/*  62 */   private Class[] cl = new Class[1];
/*  63 */   private Object[][] args = new Object[1][0];
/*  64 */   protected int numTracks = 0;
/*     */   
/*     */   protected Format[] trackFormats;
/*     */   
/*  68 */   protected MonitorAdapter[] mc = null;
/*     */   
/*     */ 
/*  71 */   static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
/*     */   
/*     */   static {
/*     */     try {
/*  75 */       jmfSecurity = com.sun.media.JMFSecurityManager.getJMFSecurity();
/*  76 */       securityPrivelege = true;
/*     */     }
/*     */     catch (SecurityException e) {}
/*     */   }
/*     */   
/*     */   public RawBufferMux() {
/*  82 */     this.supported = new ContentDescriptor[1];
/*  83 */     this.supported[0] = new ContentDescriptor("raw");
/*  84 */     this.timeBase = new RawMuxTimeBase();
/*  85 */     this.clock = new BasicClock();
/*     */     try {
/*  87 */       this.clock.setTimeBase(this.timeBase);
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 101 */     return "Raw Buffer Multiplexer";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open()
/*     */     throws ResourceUnavailableException
/*     */   {
/* 115 */     initializeTracks(this.trackFormats);
/*     */     
/* 117 */     if ((this.source == null) || (this.source.getStreams() == null))
/* 118 */       throw new ResourceUnavailableException("DataSource and SourceStreams were not created succesfully.");
/*     */     try {
/* 120 */       this.source.connect();
/*     */     } catch (IOException e) {
/* 122 */       throw new ResourceUnavailableException(e.getMessage());
/*     */     }
/*     */     
/* 125 */     int len = 0;
/*     */     
/*     */ 
/* 128 */     this.mediaTime = new long[this.trackFormats.length];
/* 129 */     this.mc = new MonitorAdapter[this.trackFormats.length];
/*     */     
/* 131 */     for (int i = 0; i < this.trackFormats.length; i++) {
/* 132 */       this.mediaTime[i] = 0L;
/* 133 */       if (((this.trackFormats[i] instanceof VideoFormat)) || ((this.trackFormats[i] instanceof AudioFormat)))
/*     */       {
/* 135 */         this.mc[i] = new MonitorAdapter(this.trackFormats[i], this);
/* 136 */         if (this.mc[i] != null) {
/* 137 */           len++;
/*     */         }
/*     */       }
/*     */     }
/* 141 */     int j = 0;
/* 142 */     this.controls = new javax.media.Control[len];
/* 143 */     for (i = 0; i < this.mc.length; i++) {
/* 144 */       if (this.mc[i] != null) {
/* 145 */         this.controls[(j++)] = this.mc[i];
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 157 */     if (this.source != null) {
/*     */       try {
/* 159 */         this.source.stop();
/* 160 */         this.source.disconnect();
/*     */       }
/*     */       catch (IOException e) {}
/* 163 */       this.source = null;
/*     */     }
/*     */     
/* 166 */     for (int i = 0; i < this.mc.length; i++) {
/* 167 */       if (this.mc[i] != null) {
/* 168 */         this.mc[i].close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 177 */     for (int i = 0; i < this.streams.length; i++) {
/* 178 */       this.streams[i].reset();
/* 179 */       if (this.mc[i] != null) {
/* 180 */         this.mc[i].reset();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentDescriptor[] getSupportedOutputContentDescriptors(Format[] fmt)
/*     */   {
/* 201 */     return this.supported;
/*     */   }
/*     */   
/*     */   public Format[] getSupportedInputFormats() {
/* 205 */     return new Format[] { new AudioFormat(null), new VideoFormat(null) };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataSource getDataOutput()
/*     */   {
/* 219 */     return this.source;
/*     */   }
/*     */   
/*     */   public int setNumTracks(int nTracks) {
/* 223 */     this.numTracks = nTracks;
/* 224 */     this.trackFormats = new Format[nTracks];
/* 225 */     for (int i = 0; i < nTracks; i++)
/* 226 */       this.trackFormats[i] = null;
/* 227 */     return nTracks;
/*     */   }
/*     */   
/*     */   public Format setInputFormat(Format input, int trackID) {
/* 231 */     if (trackID < this.numTracks)
/* 232 */       this.trackFormats[trackID] = input;
/* 233 */     for (int i = 0; i < this.numTracks; i++) {
/* 234 */       if (this.trackFormats[i] == null) {
/* 235 */         return input;
/*     */       }
/*     */     }
/* 238 */     return input;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean initializeTracks(Format[] trackFormats)
/*     */   {
/* 254 */     if (this.source.getStreams() != null)
/* 255 */       throw new Error("initializeTracks has been called previously. ");
/* 256 */     this.source.initialize(trackFormats);
/* 257 */     this.streams = ((RawBufferSourceStream[])this.source.getStreams());
/*     */     
/* 259 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int process(Buffer buffer, int trackID)
/*     */   {
/* 280 */     if ((buffer.getFlags() & 0x1000) != 0) {
/* 281 */       buffer.setFlags(buffer.getFlags() & 0xEFFF | 0x100);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 286 */     if ((this.mc[trackID] != null) && (this.mc[trackID].isEnabled())) {
/* 287 */       this.mc[trackID].process(buffer);
/*     */     }
/* 289 */     if ((this.streams == null) || (buffer == null) || (trackID >= this.streams.length))
/*     */     {
/* 291 */       return 1;
/*     */     }
/*     */     
/* 294 */     updateTime(buffer, trackID);
/*     */     
/* 296 */     return this.streams[trackID].process(buffer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void updateTime(Buffer buf, int trackID)
/*     */   {
/* 304 */     if ((buf.getFormat() instanceof AudioFormat))
/*     */     {
/* 306 */       if (mpegAudio.matches(buf.getFormat())) {
/* 307 */         if (buf.getTimeStamp() < 0L) {
/* 308 */           if (this.systemStartTime >= 0L) {
/* 309 */             this.mediaTime[trackID] = ((this.mediaStartTime + System.currentTimeMillis() - this.systemStartTime) * 1000000L);
/*     */           }
/*     */         }
/*     */         else {
/* 313 */           this.mediaTime[trackID] = buf.getTimeStamp();
/*     */         }
/*     */       }
/*     */       else {
/* 317 */         long t = ((AudioFormat)buf.getFormat()).computeDuration(buf.getLength());
/* 318 */         if (t >= 0L) {
/* 319 */           this.mediaTime[trackID] += t;
/*     */         } else {
/* 321 */           this.mediaTime[trackID] = buf.getTimeStamp();
/*     */         }
/*     */       }
/* 324 */     } else if (buf.getTimeStamp() < 0L)
/*     */     {
/* 326 */       if (this.systemStartTime >= 0L) {
/* 327 */         this.mediaTime[trackID] = ((this.mediaStartTime + System.currentTimeMillis() - this.systemStartTime) * 1000000L);
/*     */       }
/*     */     }
/*     */     else {
/* 331 */       this.mediaTime[trackID] = buf.getTimeStamp();
/*     */     }
/* 333 */     this.timeBase.update();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ContentDescriptor setContentDescriptor(ContentDescriptor outputContentDescriptor)
/*     */   {
/* 352 */     if (BasicPlugIn.matches(outputContentDescriptor, this.supported) == null) {
/* 353 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 357 */     this.contentDesc = outputContentDescriptor;
/* 358 */     this.source = new RawBufferDataSource();
/*     */     
/* 360 */     return this.contentDesc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 368 */   Object timeSetSync = new Object();
/* 369 */   boolean started = false;
/*     */   
/*     */ 
/* 372 */   long systemStartTime = -1L;
/* 373 */   long mediaStartTime = -1L;
/*     */   
/*     */   public void setTimeBase(TimeBase master) throws IncompatibleTimeBaseException {
/* 376 */     if (master != this.timeBase) {
/* 377 */       throw new IncompatibleTimeBaseException();
/*     */     }
/*     */   }
/*     */   
/*     */   public void syncStart(Time at) {
/* 382 */     synchronized (this.timeSetSync) {
/* 383 */       if (this.started) return;
/* 384 */       this.started = true;
/* 385 */       this.clock.syncStart(at);
/* 386 */       this.timeBase.mediaStarted();
/* 387 */       this.systemStartTime = System.currentTimeMillis();
/* 388 */       this.mediaStartTime = (getMediaNanoseconds() / 1000000L);
/*     */     }
/*     */   }
/*     */   
/*     */   public void stop() {
/* 393 */     synchronized (this.timeSetSync) {
/* 394 */       if (!this.started) return;
/* 395 */       this.started = false;
/* 396 */       this.clock.stop();
/* 397 */       this.timeBase.mediaStopped();
/*     */     }
/*     */   }
/*     */   
/*     */   public void setStopTime(Time stopTime) {
/* 402 */     this.clock.setStopTime(stopTime);
/*     */   }
/*     */   
/*     */   public Time getStopTime() {
/* 406 */     return this.clock.getStopTime();
/*     */   }
/*     */   
/*     */   public void setMediaTime(Time now) {
/* 410 */     synchronized (this.timeSetSync) {
/* 411 */       this.clock.setMediaTime(now);
/* 412 */       for (int i = 0; i < this.mediaTime.length; i++)
/* 413 */         this.mediaTime[i] = now.getNanoseconds();
/* 414 */       this.timeBase.update();
/* 415 */       this.systemStartTime = System.currentTimeMillis();
/* 416 */       this.mediaStartTime = (now.getNanoseconds() / 1000000L);
/*     */     }
/*     */   }
/*     */   
/*     */   public Time getMediaTime() {
/* 421 */     return this.clock.getMediaTime();
/*     */   }
/*     */   
/*     */   public long getMediaNanoseconds()
/*     */   {
/* 426 */     return this.clock.getMediaNanoseconds();
/*     */   }
/*     */   
/*     */   public Time getSyncTime() {
/* 430 */     return this.clock.getSyncTime();
/*     */   }
/*     */   
/*     */   public TimeBase getTimeBase()
/*     */   {
/* 435 */     return this.clock.getTimeBase();
/*     */   }
/*     */   
/*     */   public Time mapToTimeBase(Time t) throws javax.media.ClockStoppedException {
/* 439 */     return this.clock.mapToTimeBase(t);
/*     */   }
/*     */   
/*     */   public float getRate() {
/* 443 */     return this.clock.getRate();
/*     */   }
/*     */   
/*     */   public float setRate(float factor) {
/* 447 */     if (factor == this.clock.getRate())
/* 448 */       return factor;
/* 449 */     return this.clock.setRate(1.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   class RawMuxTimeBase
/*     */     extends MediaTimeBase
/*     */   {
/* 460 */     long ticks = 0L;
/* 461 */     boolean updated = false;
/*     */     
/*     */     RawMuxTimeBase() {}
/*     */     
/* 465 */     public long getMediaTime() { if (RawBufferMux.this.masterTrackID >= 0) {
/* 466 */         return RawBufferMux.this.mediaTime[RawBufferMux.this.masterTrackID];
/*     */       }
/*     */       
/* 469 */       if (!this.updated) {
/* 470 */         return this.ticks;
/*     */       }
/* 472 */       if (RawBufferMux.this.mediaTime.length == 1) {
/* 473 */         this.ticks = RawBufferMux.this.mediaTime[0];
/*     */       } else {
/* 475 */         this.ticks = RawBufferMux.this.mediaTime[0];
/* 476 */         for (int i = 1; i < RawBufferMux.this.mediaTime.length; i++) {
/* 477 */           if (RawBufferMux.this.mediaTime[i] < this.ticks) {
/* 478 */             this.ticks = RawBufferMux.this.mediaTime[i];
/*     */           }
/*     */         }
/*     */       }
/* 482 */       this.updated = false;
/*     */       
/* 484 */       return this.ticks;
/*     */     }
/*     */     
/*     */     public void update() {
/* 488 */       this.updated = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   class RawBufferDataSource
/*     */     extends BasicPushBufferDataSource
/*     */   {
/*     */     public RawBufferDataSource()
/*     */     {
/* 503 */       if (RawBufferMux.this.contentDesc == null)
/* 504 */         return;
/* 505 */       this.contentType = RawBufferMux.this.contentDesc.getContentType();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public PushBufferStream[] getStreams()
/*     */     {
/* 518 */       return (PushBufferStream[])RawBufferMux.this.streams;
/*     */     }
/*     */     
/*     */     public void start() throws IOException {
/* 522 */       super.start();
/*     */       
/* 524 */       for (int i = 0; i < RawBufferMux.this.streams.length; i++)
/* 525 */         RawBufferMux.this.streams[i].start();
/*     */     }
/*     */     
/*     */     public void stop() throws IOException {
/* 529 */       super.stop();
/*     */       
/* 531 */       for (int i = 0; i < RawBufferMux.this.streams.length; i++)
/* 532 */         RawBufferMux.this.streams[i].stop();
/*     */     }
/*     */     
/*     */     public void connect() throws IOException {
/* 536 */       super.connect();
/* 537 */       RawBufferMux.this.sourceDisconnected = false;
/*     */     }
/*     */     
/*     */     public void disconnect() {
/* 541 */       super.disconnect();
/* 542 */       RawBufferMux.this.sourceDisconnected = true;
/*     */       
/* 544 */       for (int i = 0; i < RawBufferMux.this.streams.length; i++) {
/* 545 */         RawBufferMux.this.streams[i].stop();
/* 546 */         RawBufferMux.this.streams[i].close();
/*     */       }
/*     */     }
/*     */     
/*     */     private void initialize(Format[] trackFormats) {
/* 551 */       RawBufferMux.this.streams = new RawBufferMux.RawBufferSourceStream[trackFormats.length];
/* 552 */       for (int i = 0; i < trackFormats.length; i++) {
/* 553 */         RawBufferMux.this.streams[i] = new RawBufferMux.RawBufferSourceStream(RawBufferMux.this, trackFormats[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   class RawBufferSourceStream
/*     */     extends com.sun.media.protocol.BasicSourceStream
/*     */     implements PushBufferStream, Runnable
/*     */   {
/* 569 */     Format format = null;
/*     */     CircularBuffer bufferQ;
/* 571 */     boolean started = false;
/* 572 */     Object startReq = new Integer(0);
/* 573 */     BufferTransferHandler handler = null;
/* 574 */     Thread streamThread = null;
/* 575 */     boolean closed = false;
/* 576 */     boolean draining = false;
/* 577 */     Object drainSync = new Object();
/*     */     
/*     */     public RawBufferSourceStream(Format fmt)
/*     */     {
/* 581 */       this.contentDescriptor = RawBufferMux.this.contentDesc;
/* 582 */       this.format = fmt;
/* 583 */       this.bufferQ = new CircularBuffer(5);
/*     */       
/* 585 */       if (RawBufferMux.jmfSecurity != null) {
/* 586 */         String permission = null;
/*     */         try {
/* 588 */           if (RawBufferMux.jmfSecurity.getName().startsWith("jmf-security")) {
/* 589 */             permission = "thread";
/* 590 */             RawBufferMux.jmfSecurity.requestPermission(RawBufferMux.this.m, RawBufferMux.this.cl, RawBufferMux.this.args, 16);
/* 591 */             RawBufferMux.this.m[0].invoke(RawBufferMux.this.cl[0], RawBufferMux.this.args[0]);
/*     */             
/* 593 */             permission = "thread group";
/* 594 */             RawBufferMux.jmfSecurity.requestPermission(RawBufferMux.this.m, RawBufferMux.this.cl, RawBufferMux.this.args, 32);
/* 595 */             RawBufferMux.this.m[0].invoke(RawBufferMux.this.cl[0], RawBufferMux.this.args[0]);
/* 596 */           } else if (RawBufferMux.jmfSecurity.getName().startsWith("internet")) {
/* 597 */             PolicyEngine.checkPermission(PermissionID.THREAD);
/* 598 */             PolicyEngine.assertPermission(PermissionID.THREAD);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         catch (Throwable e)
/*     */         {
/* 605 */           RawBufferMux.access$502(false);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 610 */       if ((RawBufferMux.jmfSecurity != null) && (RawBufferMux.jmfSecurity.getName().startsWith("jdk12")))
/*     */       {
/* 612 */         RawBufferSourceStream rbss = this;
/*     */         try
/*     */         {
/* 615 */           Constructor cons = com.sun.media.util.jdk12CreateThreadRunnableAction.cons;
/*     */           
/* 617 */           this.streamThread = ((MediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { MediaThread.class, this }) }));
/*     */ 
/*     */ 
/*     */         }
/*     */         catch (Exception e) {}
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 628 */         this.streamThread = new MediaThread(this, "RawBufferStream Thread");
/*     */       }
/* 630 */       if (this.streamThread != null) {
/* 631 */         this.streamThread.start();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Format getFormat()
/*     */     {
/* 641 */       return this.format;
/*     */     }
/*     */     
/*     */     public void setTransferHandler(BufferTransferHandler handler) {
/* 645 */       this.handler = handler;
/*     */     }
/*     */     
/*     */     public void read(Buffer buffer) throws IOException
/*     */     {
/* 650 */       if (this.closed) {
/* 651 */         throw new IOException("The source stream is closed");
/*     */       }
/*     */       
/* 654 */       Buffer current = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 659 */       synchronized (this.bufferQ) {
/* 660 */         while (!this.bufferQ.canRead()) {
/*     */           try {
/* 662 */             this.bufferQ.wait();
/*     */           } catch (Exception ???) {}
/*     */         }
/* 665 */         current = this.bufferQ.read();
/*     */       }
/*     */       
/* 668 */       if (current.isEOM()) {
/* 669 */         synchronized (this.drainSync) {
/* 670 */           if (this.draining) {
/* 671 */             this.draining = false;
/* 672 */             this.drainSync.notifyAll();
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 678 */       Object data = buffer.getData();
/* 679 */       Object hdr = buffer.getHeader();
/* 680 */       buffer.copy(current);
/* 681 */       current.setData(data);
/* 682 */       current.setHeader(hdr);
/*     */       
/*     */ 
/* 685 */       synchronized (this.bufferQ) {
/* 686 */         RawBufferMux.this.hasRead = true;
/* 687 */         this.bufferQ.readReport();
/* 688 */         this.bufferQ.notifyAll();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void start()
/*     */     {
/* 698 */       synchronized (this.startReq) {
/* 699 */         if (this.started)
/* 700 */           return;
/* 701 */         this.started = true;
/* 702 */         this.startReq.notifyAll();
/*     */       }
/* 704 */       synchronized (this.bufferQ) {
/* 705 */         RawBufferMux.this.hasRead = true;
/* 706 */         this.bufferQ.notifyAll();
/*     */       }
/*     */     }
/*     */     
/*     */     protected void stop() {
/* 711 */       synchronized (this.startReq) {
/* 712 */         this.started = false;
/*     */       }
/* 714 */       synchronized (this.bufferQ) {
/* 715 */         this.bufferQ.notifyAll();
/*     */       }
/*     */     }
/*     */     
/*     */     protected void close()
/*     */     {
/* 721 */       this.closed = true;
/* 722 */       if (this.streamThread != null) {
/*     */         try
/*     */         {
/* 725 */           reset();
/* 726 */           synchronized (this.startReq) {
/* 727 */             this.startReq.notifyAll();
/*     */           }
/*     */         }
/*     */         catch (Exception e) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected void reset()
/*     */     {
/* 738 */       synchronized (this.bufferQ) {
/* 739 */         while (this.bufferQ.canRead()) {
/* 740 */           ??? = this.bufferQ.read();
/* 741 */           this.bufferQ.readReport();
/*     */         }
/* 743 */         this.bufferQ.notifyAll();
/*     */       }
/*     */       
/* 746 */       synchronized (this.drainSync) {
/* 747 */         if (this.draining) {
/* 748 */           this.draining = false;
/* 749 */           this.drainSync.notifyAll();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     protected int process(Buffer filled)
/*     */     {
/*     */       Buffer buffer;
/* 757 */       synchronized (this.bufferQ) {
/* 758 */         if (RawBufferMux.this.allowDrop)
/*     */         {
/*     */ 
/*     */ 
/* 762 */           if ((!this.bufferQ.canWrite()) && (this.bufferQ.canRead()))
/*     */           {
/*     */ 
/*     */ 
/* 766 */             Buffer tmp = this.bufferQ.peek();
/* 767 */             if ((tmp.getFlags() & 0x20) == 0)
/*     */             {
/* 769 */               this.bufferQ.read();
/* 770 */               this.bufferQ.readReport();
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 777 */         while ((!this.bufferQ.canWrite()) && (!this.closed)) {
/*     */           try {
/* 779 */             this.bufferQ.wait();
/*     */           } catch (Exception e) {}
/*     */         }
/* 782 */         if (this.closed) {
/* 783 */           e = 0;return e; }
/* 784 */         buffer = this.bufferQ.getEmptyBuffer();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 791 */       Object bdata = buffer.getData();
/* 792 */       Object bheader = buffer.getHeader();
/* 793 */       buffer.setData(filled.getData());
/* 794 */       buffer.setHeader(filled.getHeader());
/* 795 */       filled.setData(bdata);
/* 796 */       filled.setHeader(bheader);
/*     */       
/*     */ 
/* 799 */       buffer.setLength(filled.getLength());
/* 800 */       buffer.setEOM(filled.isEOM());
/* 801 */       buffer.setFlags(filled.getFlags());
/* 802 */       buffer.setTimeStamp(filled.getTimeStamp());
/* 803 */       buffer.setFormat(filled.getFormat());
/* 804 */       buffer.setOffset(filled.getOffset());
/* 805 */       buffer.setSequenceNumber(filled.getSequenceNumber());
/*     */       
/*     */ 
/* 808 */       if (filled.isEOM()) {
/* 809 */         this.draining = true;
/*     */       }
/* 811 */       synchronized (this.bufferQ) {
/* 812 */         this.bufferQ.writeReport();
/* 813 */         this.bufferQ.notifyAll();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 818 */       if (filled.isEOM()) {
/* 819 */         synchronized (this.drainSync) {
/*     */           try {
/* 821 */             if (this.draining)
/*     */             {
/* 823 */               this.drainSync.wait(3000L);
/*     */             }
/*     */           }
/*     */           catch (Exception e) {}
/*     */         }
/*     */       }
/* 829 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void run()
/*     */     {
/*     */       for (;;)
/*     */       {
/*     */         try
/*     */         {
/* 842 */           synchronized (this.startReq)
/*     */           {
/* 844 */             continue;this.startReq.wait();
/* 843 */             if (!this.started) { if (!this.closed) {
/*     */                 continue;
/*     */               }
/*     */             }
/*     */           }
/* 848 */           synchronized (this.bufferQ)
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 864 */             if (!RawBufferMux.this.hasRead)
/* 865 */               this.bufferQ.wait(250L);
/* 866 */             RawBufferMux.this.hasRead = false;
/* 867 */             if ((!this.bufferQ.canRead()) && (!this.closed)) if (this.started) {
/*     */                 continue;
/*     */               }
/*     */           }
/* 871 */           if (this.closed) {
/* 872 */             return;
/*     */           }
/*     */           
/* 875 */           if (this.started)
/*     */           {
/*     */ 
/*     */ 
/* 879 */             if (this.handler != null)
/* 880 */               this.handler.transferData(this);
/*     */           }
/*     */         } catch (InterruptedException e) {
/* 883 */           System.err.println("Thread " + e.getMessage());
/* 884 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\multiplexer\RawBufferMux.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */