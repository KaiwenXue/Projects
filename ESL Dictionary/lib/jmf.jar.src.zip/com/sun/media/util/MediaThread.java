/*     */ package com.sun.media.util;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JDK12Security;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaThread
/*     */   extends Thread
/*     */ {
/*     */   private static ThreadGroup threadGroup;
/*  35 */   static boolean securityPrivilege = true;
/*     */   
/*     */   private static final boolean debug = false;
/*  38 */   private static int controlPriority = 9;
/*  39 */   private static int audioPriority = 5;
/*     */   
/*  41 */   private static int videoPriority = 3;
/*  42 */   private static int networkPriority = audioPriority + 1;
/*  43 */   private static int videoNetworkPriority = networkPriority - 1;
/*     */   
/*     */ 
/*  46 */   private static int defaultMaxPriority = 4;
/*     */   
/*     */   static {
/*  49 */     JMFSecurity jmfSecurity = null;
/*  50 */     Method[] m = new Method[1];
/*  51 */     Class[] cl = new Class[1];
/*  52 */     Object[][] args = new Object[1][0];
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/*  58 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  59 */       if (jmfSecurity != null) {
/*  60 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  61 */           boolean haveBoth = true;
/*     */           
/*  63 */           defaultMaxPriority = Thread.currentThread().getPriority();
/*     */           try {
/*  65 */             jmfSecurity.requestPermission(m, cl, args, 16);
/*  66 */             m[0].invoke(cl[0], args[0]);
/*     */           } catch (Throwable t) {
/*  68 */             jmfSecurity.permissionFailureNotification(16);
/*  69 */             haveBoth = false;
/*     */           }
/*  71 */           if (haveBoth) {
/*  72 */             defaultMaxPriority = Thread.currentThread().getThreadGroup().getMaxPriority();
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */           try
/*     */           {
/*  79 */             jmfSecurity.requestPermission(m, cl, args, 32);
/*  80 */             m[0].invoke(cl[0], args[0]);
/*     */           } catch (Throwable t) {
/*  82 */             jmfSecurity.permissionFailureNotification(32);
/*  83 */             haveBoth = false;
/*     */           }
/*  85 */           if (!haveBoth) {
/*  86 */             throw new Exception("No thread and or threadgroup permission");
/*     */           }
/*  88 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/*  89 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*  90 */         } else if (jmfSecurity.getName().startsWith("jdk12")) {
/*  91 */           Constructor cons = jdk12Action.getCheckPermissionAction();
/*     */           
/*  93 */           defaultMaxPriority = Thread.currentThread().getPriority();
/*  94 */           jdk12.doPrivContextM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { JDK12Security.getThreadPermission() }), jdk12.getContextM.invoke(null, null) });
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 104 */           defaultMaxPriority = Thread.currentThread().getThreadGroup().getMaxPriority();
/*     */           
/*     */ 
/*     */ 
/* 108 */           jdk12.doPrivContextM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { JDK12Security.getThreadGroupPermission() }), jdk12.getContextM.invoke(null, null) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 118 */         else if (jmfSecurity.getName().startsWith("default"))
/*     */         {
/*     */ 
/* 121 */           if (MediaThread.class.getClassLoader() != null)
/*     */           {
/* 123 */             throw new SecurityException();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 130 */       securityPrivilege = false;
/*     */       
/*     */ 
/*     */ 
/* 134 */       controlPriority = defaultMaxPriority;
/* 135 */       audioPriority = defaultMaxPriority;
/* 136 */       videoPriority = defaultMaxPriority - 1;
/* 137 */       networkPriority = defaultMaxPriority;
/* 138 */       videoNetworkPriority = defaultMaxPriority;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 144 */     if (securityPrivilege) {
/* 145 */       threadGroup = getRootThreadGroup();
/*     */     }
/*     */     else
/*     */     {
/* 149 */       threadGroup = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static ThreadGroup getRootThreadGroup()
/*     */   {
/* 157 */     ThreadGroup current = null;
/*     */     try {
/* 159 */       current = Thread.currentThread().getThreadGroup();
/* 160 */       ThreadGroup g = current;
/* 161 */       while (g.getParent() != null) { g = g.getParent();
/*     */       }
/* 163 */       return g;
/*     */     } catch (Exception e) {
/* 165 */       return null;
/*     */     } catch (Error e) {}
/* 167 */     return null;
/*     */   }
/*     */   
/*     */   public MediaThread()
/*     */   {
/* 172 */     this("JMF thread");
/*     */   }
/*     */   
/*     */   public MediaThread(String name) {
/* 176 */     super(threadGroup, name);
/*     */   }
/*     */   
/*     */   public MediaThread(Runnable r)
/*     */   {
/* 181 */     this(r, "JMF thread");
/*     */   }
/*     */   
/*     */   public MediaThread(Runnable r, String name) {
/* 185 */     super(threadGroup, r, name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void useControlPriority()
/*     */   {
/* 194 */     usePriority(controlPriority);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void useAudioPriority()
/*     */   {
/* 201 */     usePriority(audioPriority);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void useVideoPriority()
/*     */   {
/* 208 */     usePriority(videoPriority);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void useNetworkPriority()
/*     */   {
/* 215 */     usePriority(networkPriority);
/*     */   }
/*     */   
/*     */   public void useVideoNetworkPriority() {
/* 219 */     usePriority(videoNetworkPriority);
/*     */   }
/*     */   
/*     */   public static int getControlPriority()
/*     */   {
/* 224 */     return controlPriority;
/*     */   }
/*     */   
/*     */   public static int getAudioPriority() {
/* 228 */     return audioPriority;
/*     */   }
/*     */   
/*     */   public static int getVideoPriority() {
/* 232 */     return videoPriority;
/*     */   }
/*     */   
/*     */   public static int getNetworkPriority() {
/* 236 */     return networkPriority;
/*     */   }
/*     */   
/*     */   public static int getVideoNetworkPriority() {
/* 240 */     return videoNetworkPriority;
/*     */   }
/*     */   
/*     */   private void usePriority(int priority)
/*     */   {
/*     */     try {
/* 246 */       setPriority(priority);
/*     */     }
/*     */     catch (Throwable t) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkPriority(String name, int ask, boolean priv, int got)
/*     */   {
/* 257 */     if (ask != got) {
/* 258 */       System.out.println("MediaThread: " + name + " privilege? " + priv + "  ask pri: " + ask + " got pri:  " + got);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\MediaThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */