/*    */ package com.sun.media.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMFPropertiesGen
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 19 */     String[] nativeList = RegistryGen.nativePlugins;
/* 20 */     String[] defaultList = RegistryGen.defaultPlugins;
/*    */     
/* 22 */     boolean allJava = false;
/*    */     
/* 24 */     if ((args.length > 0) && (args[0].equalsIgnoreCase("java"))) {
/* 25 */       allJava = true;
/*    */     }
/*    */     
/* 28 */     String[] mergedList = RegistryGen.findAllPlugInList(allJava, defaultList, nativeList);
/* 29 */     RegistryGen.registerPlugIns(mergedList);
/*    */     
/*    */ 
/* 32 */     if (!allJava) {
/* 33 */       String fileSeparator = System.getProperty("file.separator");
/* 34 */       if (fileSeparator.equals("/")) {
/* 35 */         Registry.set("secure.cacheDir", "/tmp");
/*    */       } else {
/* 37 */         Registry.set("secure.cacheDir", "C:" + fileSeparator + "temp");
/*    */       }
/*    */       try {
/* 40 */         Registry.commit();
/*    */       }
/*    */       catch (Exception e) {}
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 47 */     System.exit(0);
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\JMFPropertiesGen.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */