/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12
/*    */ {
/*    */   public static Class ac;
/*    */   public static Class accontextC;
/*    */   public static Class permissionC;
/*    */   public static Class privActionC;
/*    */   public static Method checkPermissionM;
/*    */   public static Method doPrivM;
/*    */   public static Method doPrivContextM;
/*    */   public static Method getContextM;
/*    */   
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 33 */       ac = Class.forName("java.security.AccessController");
/* 34 */       accontextC = Class.forName("java.security.AccessControlContext");
/* 35 */       permissionC = Class.forName("java.security.Permission");
/* 36 */       privActionC = Class.forName("java.security.PrivilegedAction");
/*    */       
/* 38 */       checkPermissionM = ac.getMethod("checkPermission", new Class[] { permissionC });
/*    */       
/*    */ 
/*    */ 
/*    */ 
/* 43 */       doPrivM = ac.getMethod("doPrivileged", new Class[] { privActionC });
/*    */       
/*    */ 
/*    */ 
/*    */ 
/* 48 */       getContextM = ac.getMethod("getContext", null);
/*    */       
/*    */ 
/*    */ 
/* 52 */       doPrivContextM = ac.getMethod("doPrivileged", new Class[] { privActionC, accontextC });
/*    */     }
/*    */     catch (Throwable t) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\jdk12.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */