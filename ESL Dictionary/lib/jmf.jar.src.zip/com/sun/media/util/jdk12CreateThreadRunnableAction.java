/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12CreateThreadRunnableAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   private Class threadclass;
/*    */   private Runnable runnable;
/* 19 */   private String name = null;
/*    */   public static Constructor cons;
/*    */   public static Constructor conswithname;
/*    */   
/*    */   static
/*    */   {
/*    */     try {
/* 26 */       cons = class$com$sun$media$util$jdk12CreateThreadRunnableAction.getConstructor(new Class[] { Class.class, Runnable.class });
/*    */       
/* 28 */       conswithname = class$com$sun$media$util$jdk12CreateThreadRunnableAction.getConstructor(new Class[] { Class.class, Runnable.class, String.class });
/*    */     }
/*    */     catch (Throwable e) {}
/*    */   }
/*    */   
/*    */ 
/*    */   public jdk12CreateThreadRunnableAction(Class threadclass, Runnable run, String name)
/*    */   {
/*    */     try
/*    */     {
/* 38 */       this.threadclass = threadclass;
/* 39 */       this.runnable = run;
/* 40 */       this.name = name;
/*    */     }
/*    */     catch (Throwable e) {}
/*    */   }
/*    */   
/*    */   public jdk12CreateThreadRunnableAction(Class threadclass, Runnable run)
/*    */   {
/* 47 */     this(threadclass, run, null);
/*    */   }
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 52 */       Constructor cons = this.threadclass.getConstructor(new Class[] { Runnable.class });
/*    */       
/* 54 */       Object object = cons.newInstance(new Object[] { this.runnable });
/* 55 */       if (this.name != null) {
/* 56 */         ((Thread)object).setName(this.name);
/*    */       }
/* 58 */       return object;
/*    */     } catch (Throwable e) {}
/* 60 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\jdk12CreateThreadRunnableAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */