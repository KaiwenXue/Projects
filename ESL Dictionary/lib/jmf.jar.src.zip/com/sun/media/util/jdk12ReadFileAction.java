/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12ReadFileAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   public static Constructor cons;
/*    */   private String name;
/*    */   
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 21 */       cons = class$com$sun$media$util$jdk12ReadFileAction.getConstructor(new Class[] { String.class });
/*    */     }
/*    */     catch (Throwable e) {}
/*    */   }
/*    */   
/*    */ 
/*    */   public jdk12ReadFileAction(String name)
/*    */   {
/*    */     try
/*    */     {
/* 31 */       this.name = name;
/*    */     }
/*    */     catch (Throwable e) {}
/*    */   }
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 38 */       return new FileInputStream(this.name);
/*    */     } catch (Throwable t) {}
/* 40 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\jdk12ReadFileAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */