/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12PropertyAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   public static Constructor cons;
/*    */   private String name;
/*    */   
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 20 */       cons = class$com$sun$media$util$jdk12PropertyAction.getConstructor(new Class[] { String.class });
/*    */     }
/*    */     catch (Throwable e) {}
/*    */   }
/*    */   
/*    */ 
/*    */   public jdk12PropertyAction(String name)
/*    */   {
/*    */     try
/*    */     {
/* 30 */       this.name = name;
/*    */     }
/*    */     catch (Throwable e) {}
/*    */   }
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 37 */       return System.getProperty(this.name);
/*    */     } catch (Throwable t) {}
/* 39 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\jdk12PropertyAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */