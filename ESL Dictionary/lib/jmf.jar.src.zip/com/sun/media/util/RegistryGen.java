/*     */ package com.sun.media.util;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import javax.media.CaptureDeviceInfo;
/*     */ import javax.media.CaptureDeviceManager;
/*     */ import javax.media.Codec;
/*     */ import javax.media.Demultiplexer;
/*     */ import javax.media.Effect;
/*     */ import javax.media.Format;
/*     */ import javax.media.Multiplexer;
/*     */ import javax.media.PlugInManager;
/*     */ import javax.media.Renderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegistryGen
/*     */ {
/*     */   static String arname;
/*     */   static String pkgname;
/*     */   static String destdir;
/*     */   static String[] names;
/*     */   static DataOutputStream ds;
/*  33 */   static byte[] properties = null;
/*  34 */   private static String filename = null;
/*  35 */   private static Format[] emptyFormat = new Format[0];
/*     */   
/*     */   static
/*     */   {
/*  39 */     String fileSeparator = System.getProperty("file.separator");
/*  40 */     Registry.set("secure.allowCaching", new Boolean(true));
/*  41 */     Registry.set("secure.maxCacheSizeMB", new Integer(250));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  47 */     Registry.set("secure.allowSaveFileFromApplets", new Boolean(false));
/*  48 */     Registry.set("secure.allowCaptureFromApplets", new Boolean(false));
/*     */     
/*  50 */     Registry.set("allowLogging", new Boolean(false));
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  55 */       Registry.commit();
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */   static String[] nativePlugins = { "com.ibm.media.codec.video.mpeg.MpegVideo", "com.sun.media.codec.video.cinepak.NativeDecoder", "com.sun.media.codec.video.cinepakpro.NativeEncoder", "com.sun.media.codec.video.h261.NativeDecoder", "com.sun.media.codec.video.vh263.NativeDecoder", "com.sun.media.codec.video.jpeg.NativeDecoder", "com.sun.media.codec.video.vcm.NativeDecoder", "com.sun.media.codec.video.vcm.NativeEncoder", "com.ibm.media.codec.audio.g723.NativeDecoder", "com.ibm.media.codec.audio.gsm.NativeDecoder", "com.ibm.media.codec.audio.gsm.NativeDecoder_ms", "com.ibm.media.codec.audio.ACMCodec", "com.sun.media.codec.video.jpeg.NativeEncoder", "com.ibm.media.codec.video.h263.NativeEncoder", "com.ibm.media.codec.audio.g723.NativeEncoder", "com.ibm.media.codec.audio.gsm.NativeEncoder", "com.sun.media.codec.audio.mpa.NativeDecoder", "com.sun.media.codec.audio.mpa.NativeEncoder", "com.sun.media.codec.video.colorspace.YUVToRGB", "com.sun.media.renderer.video.DDRenderer", "com.sun.media.renderer.video.GDIRenderer", "com.sun.media.renderer.video.SunRayRenderer", "com.sun.media.renderer.video.XILRenderer", "com.sun.media.renderer.video.XLibRenderer" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */   static String[] defaultPlugins = { "com.ibm.media.parser.video.MpegParser", "com.sun.media.parser.audio.WavParser", "com.sun.media.parser.audio.AuParser", "com.sun.media.parser.audio.AiffParser", "com.sun.media.parser.audio.GsmParser", "com.sun.media.parser.RawStreamParser", "com.sun.media.parser.RawBufferParser", "com.sun.media.parser.RawPullStreamParser", "com.sun.media.parser.RawPullBufferParser", "com.sun.media.parser.video.QuicktimeParser", "com.sun.media.parser.video.AviParser", "com.sun.media.codec.audio.mpa.JavaDecoder", "com.sun.media.codec.video.cinepak.JavaDecoder", "com.ibm.media.codec.video.h263.JavaDecoder", "com.sun.media.codec.video.colorspace.JavaRGBConverter", "com.sun.media.codec.video.colorspace.JavaRGBToYUV", "com.ibm.media.codec.audio.PCMToPCM", "com.ibm.media.codec.audio.rc.RCModule", "com.sun.media.codec.audio.rc.RateCvrt", "com.sun.media.codec.audio.msadpcm.JavaDecoder", "com.ibm.media.codec.audio.ulaw.JavaDecoder", "com.ibm.media.codec.audio.alaw.JavaDecoder", "com.ibm.media.codec.audio.dvi.JavaDecoder", "com.ibm.media.codec.audio.g723.JavaDecoder", "com.ibm.media.codec.audio.gsm.JavaDecoder", "com.ibm.media.codec.audio.gsm.JavaDecoder_ms", "com.ibm.media.codec.audio.ima4.JavaDecoder", "com.ibm.media.codec.audio.ima4.JavaDecoder_ms", "com.ibm.media.codec.audio.ulaw.JavaEncoder", "com.ibm.media.codec.audio.dvi.JavaEncoder", "com.ibm.media.codec.audio.gsm.JavaEncoder", "com.ibm.media.codec.audio.gsm.JavaEncoder_ms", "com.ibm.media.codec.audio.ima4.JavaEncoder", "com.ibm.media.codec.audio.ima4.JavaEncoder_ms", "com.sun.media.codec.audio.ulaw.Packetizer", "com.sun.media.codec.audio.ulaw.DePacketizer", "com.sun.media.codec.audio.mpa.Packetizer", "com.sun.media.codec.audio.mpa.DePacketizer", "com.ibm.media.codec.audio.gsm.Packetizer", "com.ibm.media.codec.audio.g723.Packetizer", "com.sun.media.codec.video.jpeg.Packetizer", "com.sun.media.codec.video.jpeg.DePacketizer", "com.sun.media.codec.video.mpeg.Packetizer", "com.sun.media.codec.video.mpeg.DePacketizer", "com.sun.media.renderer.audio.JavaSoundRenderer", "com.sun.media.renderer.audio.SunAudioRenderer", "com.sun.media.renderer.video.AWTRenderer", "com.sun.media.renderer.video.LightWeightRenderer", "com.sun.media.renderer.video.JPEGRenderer", "com.sun.media.multiplexer.RawBufferMux", "com.sun.media.multiplexer.RawSyncBufferMux", "com.sun.media.multiplexer.RTPSyncBufferMux", "com.sun.media.multiplexer.audio.GSMMux", "com.sun.media.multiplexer.audio.MPEGMux", "com.sun.media.multiplexer.audio.WAVMux", "com.sun.media.multiplexer.audio.AIFFMux", "com.sun.media.multiplexer.audio.AUMux", "com.sun.media.multiplexer.video.AVIMux", "com.sun.media.multiplexer.video.QuicktimeMux" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void printUsage()
/*     */   {
/* 234 */     System.err.println("java RegistryGen [-d <destdir>] [-j java] <registrylib> ");
/* 235 */     System.err.println("-j java: all-java");
/*     */   }
/*     */   
/*     */   static void writeClass()
/*     */   {
/* 240 */     int accBytes = 0;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 245 */       ds.writeBytes("/* Generated by RegistryGen.\n   DO NOT EDIT.*/\n\n");
/* 246 */       if (pkgname != null) {
/* 247 */         ds.writeBytes("package ");
/* 248 */         ds.writeBytes(pkgname);
/* 249 */         ds.writeBytes(";\n\n");
/*     */       }
/*     */       
/*     */ 
/* 253 */       ds.writeBytes("public abstract class ");
/* 254 */       ds.writeBytes(arname);
/* 255 */       ds.writeBytes(" {\n\n");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 270 */       if (properties.length > 0) {
/* 271 */         ds.writeBytes("   public static byte[] getData(){\n");
/* 272 */         ds.writeBytes("       int i;\n");
/* 273 */         ds.writeBytes("       byte[] b= new byte[" + properties.length + "];\n");
/* 274 */         ds.writeBytes("       for (i=0;i<b.length;i++)\n");
/*     */         
/* 276 */         ds.writeBytes("          b[i] = (byte)(s.charAt(i)-1);\n");
/*     */         
/* 278 */         ds.writeBytes("       return b;\n");
/* 279 */         ds.writeBytes("    }\n");
/*     */       } else {
/* 281 */         ds.writeBytes("   public static byte[] getData(){\n");
/* 282 */         ds.writeBytes("       return null;\n");
/* 283 */         ds.writeBytes("    }\n");
/*     */       }
/*     */       
/*     */ 
/* 287 */       ds.writeBytes("    private static String s = \n        ");
/* 288 */       ds.writeBytes("\"");
/* 289 */       int len = properties.length;
/* 290 */       for (int j = 0; j < len; j++)
/*     */       {
/* 292 */         ds.writeBytes("\\" + byte2oct((byte)(1 + properties[j])));
/* 293 */         if (j % 16 == 15) {
/* 294 */           ds.writeBytes("\"+\n        \"");
/*     */         }
/*     */       }
/* 297 */       ds.writeBytes("\";\n\n");
/*     */       
/*     */ 
/* 300 */       ds.writeBytes("}\n");
/*     */     }
/*     */     catch (IOException e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String byte2oct(byte b)
/*     */   {
/* 309 */     int i = b & 0xFF;
/* 310 */     int dig3 = i % 8;
/* 311 */     int dig2 = i / 8 % 8;
/* 312 */     int dig1 = i / 64;
/* 313 */     return "" + dig1 + "" + dig2 + "" + dig3;
/*     */   }
/*     */   
/*     */   private static void registerPlugIn(String className)
/*     */   {
/*     */     boolean result;
/*     */     try {
/* 320 */       Class pic = Class.forName(className);
/* 321 */       Object instance = pic.newInstance();
/* 322 */       Format[] inputs = null;
/* 323 */       Format[] outputs = null;
/*     */       
/*     */       int type;
/* 326 */       if ((instance instanceof Demultiplexer)) {
/* 327 */         type = 1;
/* 328 */         inputs = ((Demultiplexer)instance).getSupportedInputContentDescriptors();
/* 329 */         outputs = emptyFormat;
/* 330 */       } else if ((instance instanceof Codec)) {
/* 331 */         type = 2;
/* 332 */         inputs = ((Codec)instance).getSupportedInputFormats();
/* 333 */         outputs = ((Codec)instance).getSupportedOutputFormats(null);
/* 334 */       } else if ((instance instanceof Renderer)) {
/* 335 */         type = 4;
/* 336 */         inputs = ((Renderer)instance).getSupportedInputFormats();
/* 337 */         outputs = emptyFormat;
/* 338 */       } else if ((instance instanceof Multiplexer)) {
/* 339 */         type = 5;
/* 340 */         inputs = emptyFormat;
/* 341 */         outputs = ((Multiplexer)instance).getSupportedOutputContentDescriptors(null);
/* 342 */       } else if ((instance instanceof Effect)) {
/* 343 */         type = 3;
/* 344 */         inputs = ((Effect)instance).getSupportedInputFormats();
/* 345 */         outputs = ((Effect)instance).getSupportedOutputFormats(null);
/*     */       } else {
/* 347 */         type = 0;
/*     */       }
/* 349 */       if ((instance instanceof DynamicPlugIn)) {
/* 350 */         inputs = ((DynamicPlugIn)instance).getBaseInputFormats();
/* 351 */         outputs = ((DynamicPlugIn)instance).getBaseOutputFormats();
/*     */       }
/*     */       
/* 354 */       if (type != 0) {
/* 355 */         result = PlugInManager.addPlugIn(className, inputs, outputs, type);
/*     */       }
/*     */     }
/*     */     catch (ClassNotFoundException cnfe) {}catch (Exception e) {}catch (UnsatisfiedLinkError erro) {}
/*     */   }
/*     */   
/*     */ 
/*     */   private static void deletePlugins(int type)
/*     */   {
/* 364 */     Vector v = PlugInManager.getPlugInList(null, null, type);
/* 365 */     Enumeration eClassNames = v.elements();
/* 366 */     while (eClassNames.hasMoreElements()) {
/* 367 */       String className = (String)eClassNames.nextElement();
/* 368 */       PlugInManager.removePlugIn(className, type);
/*     */     }
/*     */   }
/*     */   
/*     */   static void registerPlugIns(String[] plugins)
/*     */   {
/* 374 */     if (plugins == null) {
/* 375 */       return;
/*     */     }
/*     */     
/* 378 */     deletePlugins(1);
/* 379 */     deletePlugins(2);
/* 380 */     deletePlugins(4);
/* 381 */     deletePlugins(5);
/* 382 */     deletePlugins(3);
/*     */     
/* 384 */     for (int i = 0; i < plugins.length; i++)
/* 385 */       registerPlugIn(plugins[i]);
/*     */     try {
/* 387 */       PlugInManager.commit();
/*     */     } catch (Exception e) {
/* 389 */       System.err.println("can't commit PlugInManager");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static void registerCaptureDevices(CaptureDeviceInfo[] cdis)
/*     */   {
/* 397 */     for (int i = 0; i < cdis.length; i++)
/*     */     {
/* 399 */       CaptureDeviceManager.addDevice(cdis[i]);
/*     */     }
/*     */     try
/*     */     {
/* 403 */       CaptureDeviceManager.commit();
/*     */     } catch (IOException ioe) {
/* 405 */       System.err.println("can't commit CaptureDeviceManager");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean readProperties()
/*     */   {
/* 412 */     String classpath = null;
/*     */     try {
/* 414 */       classpath = System.getProperty("java.class.path");
/*     */     } catch (Exception e) {
/* 416 */       filename = null;
/*     */       
/* 418 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 423 */     StringTokenizer tokens = new StringTokenizer(classpath, File.pathSeparator);
/*     */     
/* 425 */     String strJMF = "jmf.properties";
/* 426 */     File file = null;
/*     */     
/* 428 */     while (tokens.hasMoreTokens()) {
/* 429 */       String dir = tokens.nextToken();
/* 430 */       String caps = dir.toUpperCase();
/*     */       
/*     */       try
/*     */       {
/* 434 */         if ((caps.indexOf(".ZIP") > 0) || (caps.indexOf(".JAR") > 0)) {
/* 435 */           int sep = dir.lastIndexOf(File.separator);
/* 436 */           if ((sep == -1) && (!File.separator.equals("/")))
/*     */           {
/* 438 */             sep = dir.lastIndexOf("/");
/*     */           }
/* 440 */           if (sep == -1) {
/* 441 */             sep = dir.lastIndexOf(":");
/* 442 */             if (sep == -1) {
/* 443 */               dir = strJMF;
/*     */             } else {
/* 445 */               dir = dir.substring(0, sep) + ":" + strJMF;
/*     */             }
/*     */           } else {
/* 448 */             dir = dir.substring(0, sep) + File.separator + strJMF;
/*     */           }
/*     */         } else {
/* 451 */           dir = dir + File.separator + strJMF;
/*     */         }
/* 453 */       } catch (Exception e) { dir = dir + File.separator + strJMF;
/*     */       }
/*     */       try {
/* 456 */         file = new File(dir);
/* 457 */         if (file.exists()) {
/* 458 */           filename = dir;
/* 459 */           break;
/*     */         }
/*     */       } catch (Throwable t) {
/* 462 */         filename = null;
/* 463 */         return false;
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 468 */       if ((filename == null) || (file == null))
/* 469 */         return false;
/* 470 */       if (file.length() == 0L)
/* 471 */         return false;
/*     */     } catch (Throwable t) {
/* 473 */       return false;
/*     */     }
/*     */     try
/*     */     {
/* 477 */       FileInputStream fis = new FileInputStream(filename);
/* 478 */       DataInputStream dis = new DataInputStream(fis);
/* 479 */       int len = dis.available();
/* 480 */       properties = new byte[len];
/* 481 */       dis.read(properties, 0, len);
/* 482 */       dis.close();
/* 483 */       fis.close();
/*     */     }
/*     */     catch (IOException ioe) {
/* 486 */       System.err.println("IOException in readProperties: " + ioe);
/* 487 */       return false;
/*     */     }
/*     */     
/* 490 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String[] findAllPlugInList(boolean allJava, String[] defaultList, String[] nativeList)
/*     */   {
/*     */     String[] mergedList;
/*     */     
/* 499 */     if (allJava)
/*     */     {
/* 501 */       mergedList = defaultList;
/*     */     } else {
/* 503 */       int addDirectAudio = 0;
/*     */       
/*     */ 
/* 506 */       if ((System.getProperty("os.name").startsWith("Solaris")) || (System.getProperty("os.name").startsWith("SunOS")))
/*     */       {
/* 508 */         addDirectAudio = 1;
/*     */       }
/*     */       
/*     */ 
/* 512 */       mergedList = new String[nativeList.length + addDirectAudio + defaultList.length];
/*     */       
/*     */ 
/* 515 */       for (int i = 0; i < nativeList.length; i++) {
/* 516 */         mergedList[i] = nativeList[i];
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 523 */       if (addDirectAudio == 0) {
/* 524 */         for (i = 0; i < defaultList.length; i++) {
/* 525 */           mergedList[(i + nativeList.length)] = defaultList[i];
/*     */         }
/*     */       }
/*     */       else {
/* 529 */         int idxJS = -1;
/* 530 */         for (int j = 0; j < defaultList.length; j++) {
/* 531 */           if (defaultList[j].indexOf("JavaSoundRenderer") >= 0) {
/* 532 */             idxJS = j;
/* 533 */             break;
/*     */           }
/*     */         }
/*     */         
/* 537 */         if (idxJS >= 0) {
/* 538 */           for (int j = 0; j <= idxJS; j++) {
/* 539 */             mergedList[(nativeList.length + j)] = defaultList[j];
/*     */           }
/* 541 */           mergedList[(nativeList.length + idxJS + 1)] = "com.sun.media.renderer.audio.DirectAudioRenderer";
/*     */           
/* 543 */           for (int j = idxJS + 1; j < defaultList.length; j++) {
/* 544 */             mergedList[(nativeList.length + 1 + j)] = defaultList[j];
/*     */           }
/*     */         } else {
/* 547 */           for (int j = 0; j < defaultList.length; j++)
/* 548 */             mergedList[(nativeList.length + j)] = defaultList[j];
/* 549 */           mergedList[(nativeList.length + defaultList.length)] = "com.sun.media.renderer.audio.DirectAudioRenderer";
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 554 */     return mergedList;
/*     */   }
/*     */   
/*     */   public static void main(String[] args)
/*     */   {
/* 559 */     boolean allJava = false;
/*     */     
/*     */ 
/* 562 */     names = new String[args.length + 1];
/* 563 */     int i = 0; for (int j = 0; i < args.length; i++) {
/* 564 */       if (args[i].equals("-d")) {
/* 565 */         if (i++ >= args.length) {
/* 566 */           printUsage();
/* 567 */           return;
/*     */         }
/* 569 */         destdir = args[i];
/* 570 */       } else if (args[i].equals("-j")) {
/* 571 */         int k = i + 1;
/* 572 */         if ((k < args.length) && (args[k].equalsIgnoreCase("java"))) {
/* 573 */           allJava = true;
/* 574 */           i++;
/*     */         } else {
/* 576 */           allJava = false;
/*     */         }
/*     */       } else {
/* 579 */         names[(j++)] = args[i];
/*     */       }
/*     */     }
/* 582 */     names[j] = null;
/*     */     
/* 584 */     if (j == 0) {
/* 585 */       printUsage();
/* 586 */       return;
/*     */     }
/*     */     
/*     */ 
/* 590 */     i = names[0].lastIndexOf(".");
/* 591 */     if (i == -1) {
/* 592 */       pkgname = null;
/* 593 */       arname = names[0];
/*     */     } else {
/* 595 */       pkgname = names[0].substring(0, i);
/* 596 */       arname = names[0].substring(i + 1);
/*     */     }
/*     */     
/*     */ 
/* 600 */     String filename = null;
/*     */     try {
/* 602 */       if (destdir == null) {
/* 603 */         filename = arname + ".java";
/*     */       } else
/* 605 */         filename = destdir + File.separator + arname + ".java";
/* 606 */       ds = new DataOutputStream(new FileOutputStream(filename));
/*     */     } catch (IOException e) {
/* 608 */       System.err.println("Cannot open file: " + filename + e);
/*     */     }
/*     */     
/* 611 */     String[] mergedList = null;
/* 612 */     mergedList = findAllPlugInList(allJava, defaultPlugins, nativePlugins);
/*     */     
/* 614 */     registerPlugIns(mergedList);
/* 615 */     if (!readProperties()) {
/* 616 */       System.err.println("Cannot read jmf.properties");
/* 617 */       System.exit(0);
/*     */     }
/* 619 */     writeClass();
/* 620 */     System.exit(0);
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\RegistryGen.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */