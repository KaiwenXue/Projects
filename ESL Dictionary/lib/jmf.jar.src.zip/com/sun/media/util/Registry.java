/*     */ package com.sun.media.util;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OptionalDataException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import javax.media.Format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Registry
/*     */ {
/*  38 */   private static Hashtable hash = null;
/*     */   
/*  40 */   private static String filename = null;
/*     */   
/*     */ 
/*     */   private static final int versionNumber = 200;
/*     */   
/*  45 */   private static boolean securityPrivelege = false;
/*  46 */   private static JMFSecurity jmfSecurity = null;
/*  47 */   private static Method[] m = new Method[1];
/*  48 */   private static Class[] cl = new Class[1];
/*  49 */   private static Object[][] args = new Object[1][0];
/*     */   private static final String CLASSPATH = "java.class.path";
/*  51 */   private static String userhome = null;
/*  52 */   private static String classpath = null;
/*     */   
/*  54 */   private static boolean jdkInit = false;
/*     */   
/*     */   private static Method forName3ArgsM;
/*     */   
/*     */   private static Method getSystemClassLoaderM;
/*     */   
/*     */   private static ClassLoader systemClassLoader;
/*     */   private static Method getContextClassLoaderM;
/*     */   
/*     */   static
/*     */   {
/*  65 */     hash = new Hashtable();
/*     */     try
/*     */     {
/*  68 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  69 */       securityPrivelege = true;
/*     */     }
/*     */     catch (SecurityException e) {}
/*     */     
/*  73 */     if (jmfSecurity != null) {
/*  74 */       String permission = null;
/*     */       try {
/*  76 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  77 */           permission = "read property";
/*  78 */           jmfSecurity.requestPermission(m, cl, args, 1);
/*  79 */           m[0].invoke(cl[0], args[0]);
/*     */           
/*     */ 
/*  82 */           permission = "read file";
/*  83 */           jmfSecurity.requestPermission(m, cl, args, 2);
/*  84 */           m[0].invoke(cl[0], args[0]);
/*  85 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/*  86 */           PolicyEngine.checkPermission(PermissionID.PROPERTY);
/*  87 */           PolicyEngine.checkPermission(PermissionID.FILEIO);
/*  88 */           PolicyEngine.assertPermission(PermissionID.PROPERTY);
/*  89 */           PolicyEngine.assertPermission(PermissionID.FILEIO);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/*  96 */         securityPrivelege = false;
/*     */       }
/*     */     }
/*     */     
/* 100 */     if ((jmfSecurity != null) && (jmfSecurity.getName().startsWith("jdk12"))) {
/*     */       try {
/* 102 */         Constructor cons = jdk12PropertyAction.cons;
/* 103 */         classpath = (String)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { "java.class.path" }) });
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */         userhome = (String)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { "user.home" }) });
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/*     */ 
/*     */ 
/* 120 */         securityPrivelege = false;
/*     */       }
/*     */     } else {
/*     */       try {
/* 124 */         if (securityPrivelege) {
/* 125 */           classpath = System.getProperty("java.class.path");
/* 126 */           userhome = System.getProperty("user.home");
/*     */         }
/*     */       } catch (Exception e) {
/* 129 */         filename = null;
/* 130 */         securityPrivelege = false;
/*     */       }
/*     */     }
/*     */     
/* 134 */     if (classpath == null) {
/* 135 */       securityPrivelege = false;
/*     */     }
/* 137 */     InputStream registryInputStream = null;
/*     */     
/* 139 */     String jmfDir = getJMFDir();
/* 140 */     if (jmfDir != null) {
/* 141 */       classpath = classpath + File.pathSeparator + jmfDir;
/*     */     }
/*     */     
/* 144 */     if (securityPrivelege) {
/* 145 */       registryInputStream = findJMFPropertiesFile();
/* 146 */       if (registryInputStream == null) {
/* 147 */         securityPrivelege = false;
/*     */       }
/*     */     }
/*     */     
/* 151 */     if (!readRegistry(registryInputStream)) {
/* 152 */       hash = new Hashtable();
/*     */     }
/*     */   }
/*     */   
/*     */   private static String getJMFDir()
/*     */   {
/*     */     try
/*     */     {
/* 160 */       if (File.separator.equals("/")) {
/* 161 */         if (userhome == null)
/* 162 */           return null;
/* 163 */         pointerFile = userhome;
/*     */       } else {
/* 165 */         JMFSecurityManager.loadLibrary("jmutil");
/* 166 */         pointerFile = nGetUserHome() + File.separator + "java";
/*     */       }
/* 168 */       String pointerFile = pointerFile + File.separator + ".jmfdir";
/* 169 */       File f = new File(pointerFile);
/* 170 */       FileInputStream fis = getRegistryStream(f);
/* 171 */       BufferedReader br = new BufferedReader(new InputStreamReader(fis));
/* 172 */       String dir = br.readLine();
/* 173 */       br.close();
/* 174 */       return dir;
/*     */     }
/*     */     catch (Throwable t) {}
/* 177 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final synchronized boolean set(String key, Object value)
/*     */   {
/* 187 */     if ((key != null) && (value != null)) {
/* 188 */       if ((jmfSecurity != null) && (key.indexOf("secure.") == 0))
/* 189 */         return false;
/* 190 */       hash.put(key, value);
/* 191 */       return true;
/*     */     }
/* 193 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final synchronized Object get(String key)
/*     */   {
/* 201 */     if (key != null) {
/* 202 */       return hash.get(key);
/*     */     }
/* 204 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final synchronized boolean remove(String key)
/*     */   {
/* 212 */     if ((key != null) && 
/* 213 */       (hash.containsKey(key))) {
/* 214 */       hash.remove(key);
/* 215 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 219 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final synchronized void removeGroup(String keyStart)
/*     */   {
/* 227 */     Vector keys = new Vector();
/* 228 */     if (keyStart != null) {
/* 229 */       Enumeration e = hash.keys();
/* 230 */       while (e.hasMoreElements()) {
/* 231 */         String key = (String)e.nextElement();
/* 232 */         if (key.startsWith(keyStart)) {
/* 233 */           keys.addElement(key);
/*     */         }
/*     */       }
/*     */     }
/* 237 */     for (int i = 0; i < keys.size(); i++) {
/* 238 */       hash.remove(keys.elementAt(i));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final synchronized boolean commit()
/*     */     throws IOException
/*     */   {
/* 250 */     if (jmfSecurity != null) {
/* 251 */       throw new SecurityException("commit: Permission denied");
/*     */     }
/*     */     
/* 254 */     if (filename == null) {
/* 255 */       throw new IOException("Can't find registry file");
/*     */     }
/* 257 */     FileOutputStream fos = new FileOutputStream(filename);
/* 258 */     ObjectOutputStream oos = new ObjectOutputStream(fos);
/*     */     
/* 260 */     int tableSize = hash.size();
/* 261 */     oos.writeInt(tableSize);
/* 262 */     oos.writeInt(200);
/* 263 */     for (Enumeration e = hash.keys(); e.hasMoreElements();) {
/* 264 */       String key = (String)e.nextElement();
/* 265 */       Object value = hash.get(key);
/*     */       
/* 267 */       oos.writeUTF(key);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 279 */       oos.writeObject(value);
/* 280 */       oos.flush();
/*     */     }
/* 282 */     oos.close();
/* 283 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final synchronized InputStream findJMFPropertiesFile()
/*     */   {
/* 290 */     StringTokenizer tokens = new StringTokenizer(classpath, File.pathSeparator);
/*     */     
/* 292 */     String strJMF = "jmf.properties";
/* 293 */     File file = null;
/* 294 */     InputStream ris = null;
/*     */     
/* 296 */     while (tokens.hasMoreTokens()) {
/* 297 */       String dir = tokens.nextToken();
/* 298 */       String caps = dir.toUpperCase();
/*     */       
/*     */       try
/*     */       {
/* 302 */         if ((caps.indexOf(".ZIP") > 0) || (caps.indexOf(".JAR") > 0)) {
/* 303 */           int sep = dir.lastIndexOf(File.separator);
/* 304 */           if ((sep == -1) && (!File.separator.equals("/")))
/*     */           {
/* 306 */             sep = dir.lastIndexOf("/");
/*     */           }
/* 308 */           if (sep == -1) {
/* 309 */             sep = dir.lastIndexOf(":");
/* 310 */             if (sep == -1) {
/* 311 */               dir = strJMF;
/*     */             } else {
/* 313 */               dir = dir.substring(0, sep) + ":" + strJMF;
/*     */             }
/*     */           } else {
/* 316 */             dir = dir.substring(0, sep) + File.separator + strJMF;
/*     */           }
/*     */         } else {
/* 319 */           dir = dir + File.separator + strJMF;
/*     */         }
/* 321 */       } catch (Exception e) { dir = dir + File.separator + strJMF;
/*     */       }
/*     */       try
/*     */       {
/* 325 */         file = new File(dir);
/*     */         
/* 327 */         ris = getRegistryStream(file);
/* 328 */         if (ris != null) {
/* 329 */           filename = dir;
/* 330 */           break;
/*     */         }
/*     */       } catch (Throwable t) {
/* 333 */         filename = null;
/* 334 */         return null;
/*     */       }
/*     */     }
/*     */     try {
/* 338 */       if ((filename == null) || (file == null)) {
/* 339 */         return null;
/*     */       }
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 344 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 348 */     return ris;
/*     */   }
/*     */   
/*     */   private static FileInputStream getRegistryStream(File file) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 355 */       if ((jmfSecurity != null) && (jmfSecurity.getName().startsWith("jdk12"))) {
/* 356 */         Constructor cons = jdk12ReadFileAction.cons;
/* 357 */         return (FileInputStream)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { file.getPath() }) });
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 366 */       if (!file.exists())
/*     */       {
/* 368 */         return null;
/*     */       }
/* 370 */       return new FileInputStream(file.getPath());
/*     */     }
/*     */     catch (Throwable t) {}
/*     */     
/* 374 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final synchronized boolean readRegistry(InputStream ris)
/*     */   {
/* 382 */     if (realReadRegistry(ris)) {
/* 383 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */     byte[] data;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 392 */       Class c = Class.forName("com.sun.media.util.RegistryLib");
/* 393 */       data = (byte[])c.getMethod("getData", null).invoke(c, null);
/*     */     }
/*     */     catch (Exception e) {
/* 396 */       return false;
/*     */     }
/* 398 */     if (data == null)
/*     */     {
/* 400 */       return false;
/*     */     }
/*     */     
/* 403 */     InputStream def_ris = new ByteArrayInputStream(data);
/*     */     
/* 405 */     return realReadRegistry(def_ris);
/*     */   }
/*     */   
/*     */   private static final boolean realReadRegistry(InputStream ris) {
/* 409 */     if (ris == null) {
/* 410 */       return false;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 415 */       ObjectInputStream ois = new ObjectInputStream(ris);
/*     */       
/* 417 */       int tableSize = ois.readInt();
/* 418 */       int version = ois.readInt();
/* 419 */       if (version > 200) {
/* 420 */         System.err.println("Version number mismatch.\nThere could be errors in reading the registry");
/*     */       }
/*     */       
/* 423 */       hash = new Hashtable();
/* 424 */       for (int i = 0; i < tableSize; i++) {
/* 425 */         String key = ois.readUTF();
/* 426 */         boolean failed = false;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 438 */           Object value = ois.readObject();
/* 439 */           hash.put(key, value);
/*     */         } catch (ClassNotFoundException cnfe) {
/* 441 */           failed = true;
/*     */         } catch (OptionalDataException ode) {
/* 443 */           failed = true;
/*     */         }
/*     */       }
/* 446 */       ois.close();
/* 447 */       ris.close();
/*     */     } catch (IOException ioe) {
/* 449 */       System.err.println("IOException in readRegistry: " + ioe);
/* 450 */       return false;
/*     */     } catch (Throwable t) {
/* 452 */       return false;
/*     */     }
/*     */     
/* 455 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean checkIfJDK12()
/*     */   {
/* 460 */     if (jdkInit)
/* 461 */       return forName3ArgsM != null;
/* 462 */     jdkInit = true;
/*     */     try {
/* 464 */       forName3ArgsM = class$java$lang$Class.getMethod("forName", new Class[] { String.class, Boolean.TYPE, ClassLoader.class });
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 469 */       getSystemClassLoaderM = ClassLoader.class.getMethod("getSystemClassLoader", null);
/*     */       
/*     */ 
/* 472 */       systemClassLoader = (ClassLoader)getSystemClassLoaderM.invoke(ClassLoader.class, null);
/*     */       
/* 474 */       getContextClassLoaderM = Thread.class.getMethod("getContextClassLoader", null);
/*     */       
/* 476 */       return true;
/*     */     } catch (Throwable t) {
/* 478 */       forName3ArgsM = null; }
/* 479 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Class getClassForName(String className)
/*     */     throws ClassNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 494 */       return Class.forName(className);
/*     */     } catch (Exception e) {
/* 496 */       if (!checkIfJDK12()) {
/* 497 */         throw new ClassNotFoundException(e.getMessage());
/*     */       }
/*     */     } catch (Error e) {
/* 500 */       if (!checkIfJDK12()) {
/* 501 */         throw e;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 511 */         return (Class)forName3ArgsM.invoke(class$java$lang$Class, new Object[] { className, new Boolean(true), systemClassLoader });
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/*     */ 
/*     */ 
/* 523 */           ClassLoader contextClassLoader = (ClassLoader)getContextClassLoaderM.invoke(Thread.currentThread(), null);
/*     */           
/* 525 */           return (Class)forName3ArgsM.invoke(class$java$lang$Class, new Object[] { className, new Boolean(true), contextClassLoader });
/*     */         }
/*     */         catch (Exception e) {
/* 528 */           throw new ClassNotFoundException(e.getMessage());
/*     */         } catch (Error e) {
/* 530 */           throw e;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 540 */     Format f1 = new Format("crap", Integer.class);
/*     */     
/* 542 */     Object bad = new Integer(5);
/*     */     try {
/* 544 */       Class vfclass = Class.forName("javax.media.format.H261Format");
/* 545 */       bad = vfclass.newInstance();
/*     */     } catch (ClassNotFoundException cnfe) {
/* 547 */       System.err.println("H261Format not found in main()");
/*     */     }
/*     */     catch (InstantiationException ie) {}catch (IllegalAccessException iae) {}
/*     */     
/* 551 */     Format f2 = new Format("crap2", Boolean.class);
/*     */     
/* 553 */     set("obj1", f1);
/* 554 */     set("obj2", bad);
/* 555 */     set("obj3", f2);
/*     */     try {
/* 557 */       commit();
/*     */     } catch (IOException ioe) {
/* 559 */       System.err.println("main: IO error in commit " + ioe);
/*     */     }
/*     */   }
/*     */   
/*     */   private static native String nGetUserHome();
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\Registry.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */