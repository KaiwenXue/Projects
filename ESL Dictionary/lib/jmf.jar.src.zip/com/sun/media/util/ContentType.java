/*    */ package com.sun.media.util;
/*    */ 
/*    */ import com.sun.media.Log;
/*    */ import com.sun.media.MimeManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentType
/*    */ {
/*    */   public static String getCorrectedContentType(String contentType, String fileName)
/*    */   {
/* 13 */     if (contentType != null) {
/* 14 */       if (contentType.startsWith("text"))
/*    */       {
/*    */ 
/*    */ 
/*    */ 
/* 19 */         int i = fileName.lastIndexOf(".");
/* 20 */         if (i != -1) {
/* 21 */           String ext = fileName.substring(i + 1).toLowerCase();
/* 22 */           String type = MimeManager.getMimeType(ext);
/* 23 */           if (type != null) {
/* 24 */             return type;
/*    */           }
/*    */         }
/*    */         
/* 28 */         Log.error("Warning: The URL may not exist. Please check URL");
/* 29 */         return contentType;
/*    */       }
/* 31 */       if (contentType.equals("audio/wav"))
/* 32 */         return "audio/x-wav";
/* 33 */       if (contentType.equals("audio/aiff"))
/* 34 */         return "audio/x-aiff";
/* 35 */       if (contentType.equals("application/x-troff-msvideo"))
/*    */       {
/*    */ 
/*    */ 
/* 39 */         return "video/x-msvideo"; }
/* 40 */       if (contentType.equals("video/msvideo"))
/* 41 */         return "video/x-msvideo";
/* 42 */       if (contentType.equals("video/avi"))
/* 43 */         return "video/x-msvideo";
/* 44 */       if (contentType.equals("audio/x-mpegaudio")) {
/* 45 */         return "audio/mpeg";
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 50 */     String type = null;
/* 51 */     int i = fileName.lastIndexOf(".");
/* 52 */     if (i != -1) {
/* 53 */       String ext = fileName.substring(i + 1).toLowerCase();
/* 54 */       type = MimeManager.getMimeType(ext);
/*    */     }
/*    */     
/* 57 */     if (type != null) {
/* 58 */       return type;
/*    */     }
/* 60 */     if (contentType != null) {
/* 61 */       return contentType;
/*    */     }
/* 63 */     return "content/unknown";
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\ContentType.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */