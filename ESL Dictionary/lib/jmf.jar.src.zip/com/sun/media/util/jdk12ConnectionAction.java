/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.net.URLConnection;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12ConnectionAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   public static Constructor cons;
/*    */   private URLConnection urlC;
/*    */   
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 21 */       cons = class$com$sun$media$util$jdk12ConnectionAction.getConstructor(new Class[] { URLConnection.class });
/*    */     }
/*    */     catch (Throwable e) {}
/*    */   }
/*    */   
/*    */ 
/*    */   public jdk12ConnectionAction(URLConnection urlC)
/*    */   {
/*    */     try
/*    */     {
/* 31 */       this.urlC = urlC;
/*    */     }
/*    */     catch (Throwable e) {}
/*    */   }
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 38 */       return this.urlC.getInputStream();
/*    */     } catch (Throwable t) {}
/* 40 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\jdk12ConnectionAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */