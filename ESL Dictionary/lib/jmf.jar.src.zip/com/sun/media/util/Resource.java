/*     */ package com.sun.media.util;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OptionalDataException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Resource
/*     */ {
/*  40 */   private static Hashtable hash = null;
/*     */   
/*     */ 
/*  43 */   private static String filename = null;
/*     */   
/*     */ 
/*     */   private static final int versionNumber = 200;
/*     */   
/*     */ 
/*  49 */   private static boolean securityPrivelege = false;
/*  50 */   private static JMFSecurity jmfSecurity = null;
/*  51 */   private static Method[] m = new Method[1];
/*  52 */   private static Class[] cl = new Class[1];
/*  53 */   private static Object[][] args = new Object[1][0];
/*     */   private static final String USERHOME = "user.home";
/*  55 */   private static String userhome = null;
/*     */   static FormatTable audioFmtTbl;
/*     */   static FormatTable videoFmtTbl;
/*     */   static FormatTable miscFmtTbl;
/*     */   
/*     */   static
/*     */   {
/*  62 */     hash = new Hashtable();
/*     */     try
/*     */     {
/*  65 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  66 */       securityPrivelege = true;
/*     */     }
/*     */     catch (SecurityException e) {}
/*     */     
/*  70 */     if (jmfSecurity != null) {
/*  71 */       String permission = null;
/*     */       try {
/*  73 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  74 */           permission = "read property";
/*  75 */           jmfSecurity.requestPermission(m, cl, args, 1);
/*  76 */           m[0].invoke(cl[0], args[0]);
/*     */           
/*     */ 
/*  79 */           permission = "read file";
/*  80 */           jmfSecurity.requestPermission(m, cl, args, 2);
/*  81 */           m[0].invoke(cl[0], args[0]);
/*  82 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/*  83 */           PolicyEngine.checkPermission(PermissionID.PROPERTY);
/*  84 */           PolicyEngine.checkPermission(PermissionID.FILEIO);
/*  85 */           PolicyEngine.assertPermission(PermissionID.PROPERTY);
/*  86 */           PolicyEngine.assertPermission(PermissionID.FILEIO);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/*  93 */         securityPrivelege = false;
/*     */       }
/*     */     }
/*     */     
/*  97 */     if ((jmfSecurity != null) && (jmfSecurity.getName().startsWith("jdk12"))) {
/*     */       try {
/*  99 */         Constructor cons = jdk12PropertyAction.cons;
/* 100 */         userhome = (String)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { "user.home" }) });
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 110 */         securityPrivelege = false;
/*     */       }
/*     */     } else {
/*     */       try {
/* 114 */         if (securityPrivelege)
/* 115 */           userhome = System.getProperty("user.home");
/*     */       } catch (Exception e) {
/* 117 */         userhome = null;
/* 118 */         securityPrivelege = false;
/*     */       }
/*     */     }
/*     */     
/* 122 */     if (userhome == null) {
/* 123 */       securityPrivelege = false;
/*     */     }
/* 125 */     InputStream is = null;
/*     */     
/* 127 */     if (securityPrivelege) {
/* 128 */       is = findResourceFile();
/* 129 */       if (is == null) {
/* 130 */         securityPrivelege = false;
/*     */       }
/*     */     }
/*     */     
/* 134 */     if (!readResource(is)) {
/* 135 */       hash = new Hashtable();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final synchronized void reset()
/*     */   {
/* 141 */     hash = new Hashtable();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final synchronized boolean set(String key, Object value)
/*     */   {
/* 150 */     if ((key != null) && (value != null)) {
/* 151 */       if ((jmfSecurity != null) && (key.indexOf("secure.") == 0))
/* 152 */         return false;
/* 153 */       hash.put(key, value);
/* 154 */       return true;
/*     */     }
/* 156 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final synchronized Object get(String key)
/*     */   {
/* 164 */     if (key != null) {
/* 165 */       return hash.get(key);
/*     */     }
/* 167 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final synchronized boolean remove(String key)
/*     */   {
/* 175 */     if ((key != null) && 
/* 176 */       (hash.containsKey(key))) {
/* 177 */       hash.remove(key);
/* 178 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 182 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final synchronized void removeGroup(String keyStart)
/*     */   {
/* 190 */     Vector keys = new Vector();
/* 191 */     if (keyStart != null) {
/* 192 */       Enumeration e = hash.keys();
/* 193 */       while (e.hasMoreElements()) {
/* 194 */         String key = (String)e.nextElement();
/* 195 */         if (key.startsWith(keyStart)) {
/* 196 */           keys.addElement(key);
/*     */         }
/*     */       }
/*     */     }
/* 200 */     for (int i = 0; i < keys.size(); i++) {
/* 201 */       hash.remove(keys.elementAt(i));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final synchronized boolean commit()
/*     */     throws IOException
/*     */   {
/* 212 */     if (filename == null) {
/* 213 */       throw new IOException("Can't find resource file");
/*     */     }
/* 215 */     FileOutputStream fos = new FileOutputStream(filename);
/* 216 */     ObjectOutputStream oos = new ObjectOutputStream(fos);
/*     */     
/* 218 */     int tableSize = hash.size();
/* 219 */     oos.writeInt(tableSize);
/* 220 */     oos.writeInt(200);
/* 221 */     for (Enumeration e = hash.keys(); e.hasMoreElements();) {
/* 222 */       String key = (String)e.nextElement();
/* 223 */       Object value = hash.get(key);
/*     */       
/* 225 */       oos.writeUTF(key);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 237 */       oos.writeObject(value);
/* 238 */       oos.flush();
/*     */     }
/* 240 */     oos.close();
/* 241 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static final synchronized void destroy()
/*     */   {
/* 248 */     if (filename == null)
/* 249 */       return;
/*     */     try {
/* 251 */       File file = new File(filename);
/* 252 */       file.delete();
/*     */     } catch (Throwable t) {
/* 254 */       filename = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static final synchronized InputStream findResourceFile()
/*     */   {
/* 261 */     String strJMF = ".jmf-resource";
/* 262 */     File file = null;
/* 263 */     InputStream ris = null;
/*     */     
/* 265 */     if (userhome == null) {
/* 266 */       return null;
/*     */     }
/*     */     try {
/* 269 */       filename = userhome + File.separator + strJMF;
/*     */       
/* 271 */       file = new File(filename);
/* 272 */       ris = getResourceStream(file);
/*     */     } catch (Throwable t) {
/* 274 */       filename = null;
/* 275 */       return null;
/*     */     }
/*     */     
/* 278 */     return ris;
/*     */   }
/*     */   
/*     */   private static final FileInputStream getResourceStream(File file) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 285 */       if ((jmfSecurity != null) && (jmfSecurity.getName().startsWith("jdk12"))) {
/* 286 */         Constructor cons = jdk12ReadFileAction.cons;
/* 287 */         return (FileInputStream)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { file.getPath() }) });
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 296 */       if (!file.exists())
/*     */       {
/* 298 */         return null;
/*     */       }
/* 300 */       return new FileInputStream(file.getPath());
/*     */     }
/*     */     catch (Throwable t) {}
/*     */     
/* 304 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final synchronized boolean readResource(InputStream ris)
/*     */   {
/* 311 */     if (ris == null) {
/* 312 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 318 */       ObjectInputStream ois = new ObjectInputStream(ris);
/*     */       
/* 320 */       int tableSize = ois.readInt();
/* 321 */       int version = ois.readInt();
/* 322 */       if (version > 200) {
/* 323 */         System.err.println("Version number mismatch.\nThere could be errors in reading the resource");
/*     */       }
/*     */       
/* 326 */       hash = new Hashtable();
/* 327 */       for (int i = 0; i < tableSize; i++) {
/* 328 */         String key = ois.readUTF();
/* 329 */         boolean failed = false;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 341 */           Object value = ois.readObject();
/* 342 */           hash.put(key, value);
/*     */         } catch (ClassNotFoundException cnfe) {
/* 344 */           failed = true;
/*     */         } catch (OptionalDataException ode) {
/* 346 */           failed = true;
/*     */         }
/*     */       }
/* 349 */       ois.close();
/* 350 */       ris.close();
/*     */     } catch (IOException ioe) {
/* 352 */       System.err.println("IOException in readResource: " + ioe);
/* 353 */       return false;
/*     */     } catch (Throwable t) {
/* 355 */       return false;
/*     */     }
/*     */     
/* 358 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 376 */   static Object fmtTblSync = new Object();
/*     */   
/* 378 */   static int AUDIO_TBL_SIZE = 40;
/* 379 */   static int VIDEO_TBL_SIZE = 20;
/* 380 */   static int MISC_TBL_SIZE = 10;
/*     */   
/* 382 */   static String AUDIO_SIZE_KEY = "ATS";
/* 383 */   static String AUDIO_INPUT_KEY = "AI.";
/* 384 */   static String AUDIO_FORMAT_KEY = "AF.";
/* 385 */   static String AUDIO_HIT_KEY = "AH.";
/* 386 */   static String VIDEO_SIZE_KEY = "VTS";
/* 387 */   static String VIDEO_INPUT_KEY = "VI.";
/* 388 */   static String VIDEO_FORMAT_KEY = "VF.";
/* 389 */   static String VIDEO_HIT_KEY = "VH.";
/* 390 */   static String MISC_SIZE_KEY = "MTS";
/* 391 */   static String MISC_INPUT_KEY = "MI.";
/* 392 */   static String MISC_FORMAT_KEY = "MF.";
/* 393 */   static String MISC_HIT_KEY = "MH.";
/*     */   
/* 395 */   static boolean needSaving = false;
/*     */   
/*     */ 
/*     */ 
/*     */   static final void initDB()
/*     */   {
/* 401 */     synchronized (fmtTblSync) {
/* 402 */       audioFmtTbl = new FormatTable(AUDIO_TBL_SIZE);
/* 403 */       videoFmtTbl = new FormatTable(VIDEO_TBL_SIZE);
/* 404 */       miscFmtTbl = new FormatTable(MISC_TBL_SIZE);
/* 405 */       loadDB();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void purgeDB()
/*     */   {
/* 414 */     synchronized (fmtTblSync) {
/* 415 */       if (audioFmtTbl == null)
/* 416 */         return;
/* 417 */       audioFmtTbl = new FormatTable(AUDIO_TBL_SIZE);
/* 418 */       videoFmtTbl = new FormatTable(VIDEO_TBL_SIZE);
/* 419 */       miscFmtTbl = new FormatTable(MISC_TBL_SIZE);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Format[] getDB(Format input)
/*     */   {
/* 430 */     synchronized (fmtTblSync)
/*     */     {
/* 432 */       if (audioFmtTbl == null) {
/* 433 */         initDB();
/*     */       }
/* 435 */       if ((input instanceof AudioFormat)) {
/* 436 */         Format[] arrayOfFormat1 = audioFmtTbl.get(input);return arrayOfFormat1; }
/* 437 */       if ((input instanceof VideoFormat)) {
/* 438 */         Format[] arrayOfFormat2 = videoFmtTbl.get(input);return arrayOfFormat2;
/*     */       }
/* 440 */       Format[] arrayOfFormat3 = miscFmtTbl.get(input);return arrayOfFormat3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final Format[] putDB(Format input, Format[] supported)
/*     */   {
/* 450 */     synchronized (fmtTblSync)
/*     */     {
/* 452 */       Format in = input.relax();
/* 453 */       Format[] list = new Format[supported.length];
/* 454 */       for (int i = 0; i < supported.length; i++) {
/* 455 */         list[i] = supported[i].relax();
/*     */       }
/* 457 */       if ((in instanceof AudioFormat)) {
/* 458 */         audioFmtTbl.save(in, list);
/* 459 */       } else if ((in instanceof VideoFormat)) {
/* 460 */         videoFmtTbl.save(in, list);
/*     */       } else {
/* 462 */         miscFmtTbl.save(in, list);
/*     */       }
/* 464 */       needSaving = true;
/*     */       
/* 466 */       Format[] arrayOfFormat1 = list;return arrayOfFormat1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final void loadDB()
/*     */   {
/* 476 */     synchronized (fmtTblSync)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 481 */       Object key = get(AUDIO_SIZE_KEY);
/* 482 */       int size; if ((key instanceof Integer)) {
/* 483 */         size = ((Integer)key).intValue();
/*     */       } else
/* 485 */         size = 0;
/* 486 */       if (size > AUDIO_TBL_SIZE)
/*     */       {
/* 488 */         System.err.println("Resource file is corrupted");
/* 489 */         size = AUDIO_TBL_SIZE;
/*     */       }
/*     */       
/* 492 */       audioFmtTbl.last = size;
/* 493 */       Object value; Object hit; for (int i = 0; i < size; i++) {
/* 494 */         key = get(AUDIO_INPUT_KEY + i);
/* 495 */         value = get(AUDIO_FORMAT_KEY + i);
/* 496 */         hit = get(AUDIO_HIT_KEY + i);
/* 497 */         if (((key instanceof Format)) && ((value instanceof Format[])) && ((hit instanceof Integer)))
/*     */         {
/* 499 */           audioFmtTbl.keys[i] = ((Format)key);
/* 500 */           audioFmtTbl.table[i] = ((Format[])value);
/* 501 */           audioFmtTbl.hits[i] = ((Integer)hit).intValue();
/*     */         } else {
/* 503 */           System.err.println("Resource file is corrupted");
/* 504 */           audioFmtTbl.last = 0;
/* 505 */           break;
/*     */         }
/*     */       }
/*     */       
/* 509 */       key = get(VIDEO_SIZE_KEY);
/* 510 */       if ((key instanceof Integer)) {
/* 511 */         size = ((Integer)key).intValue();
/*     */       } else
/* 513 */         size = 0;
/* 514 */       if (size > VIDEO_TBL_SIZE)
/*     */       {
/* 516 */         System.err.println("Resource file is corrupted");
/* 517 */         size = VIDEO_TBL_SIZE;
/*     */       }
/*     */       
/* 520 */       videoFmtTbl.last = size;
/* 521 */       for (i = 0; i < size; i++) {
/* 522 */         key = get(VIDEO_INPUT_KEY + i);
/* 523 */         value = get(VIDEO_FORMAT_KEY + i);
/* 524 */         hit = get(VIDEO_HIT_KEY + i);
/* 525 */         if (((key instanceof Format)) && ((value instanceof Format[])) && ((hit instanceof Integer)))
/*     */         {
/* 527 */           videoFmtTbl.keys[i] = ((Format)key);
/* 528 */           videoFmtTbl.table[i] = ((Format[])value);
/* 529 */           videoFmtTbl.hits[i] = ((Integer)hit).intValue();
/*     */         } else {
/* 531 */           System.err.println("Resource file is corrupted");
/* 532 */           videoFmtTbl.last = 0;
/* 533 */           break;
/*     */         }
/*     */       }
/*     */       
/* 537 */       key = get(MISC_SIZE_KEY);
/* 538 */       if ((key instanceof Integer)) {
/* 539 */         size = ((Integer)key).intValue();
/*     */       } else
/* 541 */         size = 0;
/* 542 */       if (size > MISC_TBL_SIZE)
/*     */       {
/* 544 */         System.err.println("Resource file is corrupted");
/* 545 */         size = MISC_TBL_SIZE;
/*     */       }
/*     */       
/* 548 */       miscFmtTbl.last = size;
/* 549 */       for (i = 0; i < size; i++) {
/* 550 */         key = get(MISC_INPUT_KEY + i);
/* 551 */         value = get(MISC_FORMAT_KEY + i);
/* 552 */         hit = get(MISC_HIT_KEY + i);
/* 553 */         if (((key instanceof Format)) && ((value instanceof Format[])) && ((hit instanceof Integer)))
/*     */         {
/* 555 */           miscFmtTbl.keys[i] = ((Format)key);
/* 556 */           miscFmtTbl.table[i] = ((Format[])value);
/* 557 */           miscFmtTbl.hits[i] = ((Integer)hit).intValue();
/*     */         } else {
/* 559 */           System.err.println("Resource file is corrupted");
/* 560 */           miscFmtTbl.last = 0;
/* 561 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void saveDB()
/*     */   {
/* 574 */     synchronized (fmtTblSync)
/*     */     {
/* 576 */       if (!needSaving) {
/* 577 */         return;
/*     */       }
/* 579 */       reset();
/*     */       
/*     */ 
/* 582 */       set(AUDIO_SIZE_KEY, new Integer(audioFmtTbl.last));
/* 583 */       for (int i = 0; i < audioFmtTbl.last; i++) {
/* 584 */         set(AUDIO_INPUT_KEY + i, audioFmtTbl.keys[i]);
/* 585 */         set(AUDIO_FORMAT_KEY + i, audioFmtTbl.table[i]);
/* 586 */         set(AUDIO_HIT_KEY + i, new Integer(audioFmtTbl.hits[i]));
/*     */       }
/* 588 */       set(VIDEO_SIZE_KEY, new Integer(videoFmtTbl.last));
/* 589 */       for (i = 0; i < videoFmtTbl.last; i++) {
/* 590 */         set(VIDEO_INPUT_KEY + i, videoFmtTbl.keys[i]);
/* 591 */         set(VIDEO_FORMAT_KEY + i, videoFmtTbl.table[i]);
/* 592 */         set(VIDEO_HIT_KEY + i, new Integer(videoFmtTbl.hits[i]));
/*     */       }
/* 594 */       set(MISC_SIZE_KEY, new Integer(miscFmtTbl.last));
/* 595 */       for (i = 0; i < miscFmtTbl.last; i++) {
/* 596 */         set(MISC_INPUT_KEY + i, miscFmtTbl.keys[i]);
/* 597 */         set(MISC_FORMAT_KEY + i, miscFmtTbl.table[i]);
/* 598 */         set(MISC_HIT_KEY + i, new Integer(miscFmtTbl.hits[i]));
/*     */       }
/*     */       try
/*     */       {
/* 602 */         commit();
/*     */       }
/*     */       catch (Throwable e) {}
/*     */       
/*     */ 
/* 607 */       needSaving = false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\Resource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */