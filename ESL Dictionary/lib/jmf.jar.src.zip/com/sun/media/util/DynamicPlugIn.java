package com.sun.media.util;

import javax.media.Format;

public abstract interface DynamicPlugIn
{
  public abstract Format[] getBaseInputFormats();
  
  public abstract Format[] getBaseOutputFormats();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\DynamicPlugIn.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */