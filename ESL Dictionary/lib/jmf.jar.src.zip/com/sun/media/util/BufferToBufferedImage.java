/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Image;
/*    */ import java.awt.Point;
/*    */ import java.awt.geom.AffineTransform;
/*    */ import java.awt.image.AffineTransformOp;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.DataBufferInt;
/*    */ import java.awt.image.DirectColorModel;
/*    */ import java.awt.image.Raster;
/*    */ import java.awt.image.SinglePixelPackedSampleModel;
/*    */ import java.awt.image.WritableRaster;
/*    */ import javax.media.Buffer;
/*    */ import javax.media.format.RGBFormat;
/*    */ import javax.media.format.VideoFormat;
/*    */ import javax.media.util.BufferToImage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BufferToBufferedImage
/*    */   extends BufferToImage
/*    */ {
/*    */   public BufferToBufferedImage()
/*    */     throws ClassNotFoundException
/*    */   {
/* 28 */     super(null);
/* 29 */     Class.forName("java.awt.Graphics2D");
/*    */   }
/*    */   
/*    */   public BufferToBufferedImage(VideoFormat paramVideoFormat) throws ClassNotFoundException {
/* 33 */     super(paramVideoFormat);
/* 34 */     Class.forName("java.awt.Graphics2D");
/*    */   }
/*    */   
/*    */   public Image createImage(Buffer paramBuffer) {
/* 38 */     RGBFormat localRGBFormat = (RGBFormat)paramBuffer.getFormat();
/*    */     
/* 40 */     Object localObject = paramBuffer.getData();
/*    */     
/*    */ 
/* 43 */     int i = localRGBFormat.getRedMask();
/* 44 */     int j = localRGBFormat.getGreenMask();
/* 45 */     int k = localRGBFormat.getBlueMask();
/* 46 */     int[] arrayOfInt = new int[3];
/* 47 */     arrayOfInt[0] = i;
/* 48 */     arrayOfInt[1] = j;
/* 49 */     arrayOfInt[2] = k;
/*    */     
/* 51 */     DataBufferInt localDataBufferInt = new DataBufferInt((int[])localObject, 
/* 52 */       localRGBFormat.getLineStride() * 
/* 53 */       localRGBFormat.getSize().height);
/*    */     
/* 55 */     SinglePixelPackedSampleModel localSinglePixelPackedSampleModel = new SinglePixelPackedSampleModel(3, 
/* 56 */       localRGBFormat.getLineStride(), 
/* 57 */       localRGBFormat.getSize().height, 
/* 58 */       arrayOfInt);
/* 59 */     WritableRaster localWritableRaster = Raster.createWritableRaster(localSinglePixelPackedSampleModel, localDataBufferInt, new Point(0, 0));
/*    */     
/* 61 */     DirectColorModel localDirectColorModel = new DirectColorModel(24, i, j, k);
/* 62 */     BufferedImage localBufferedImage1 = new BufferedImage(localDirectColorModel, localWritableRaster, true, null);
/*    */     
/* 64 */     AffineTransform localAffineTransform = new AffineTransform(1.0F, 0.0F, 
/* 65 */       0.0F, 1.0F, 
/* 66 */       0.0F, 0.0F);
/* 67 */     AffineTransformOp localAffineTransformOp = new AffineTransformOp(localAffineTransform, null);
/*    */     
/* 69 */     BufferedImage localBufferedImage2 = localAffineTransformOp.createCompatibleDestImage(localBufferedImage1, 
/* 70 */       localDirectColorModel);
/*    */     
/*    */ 
/* 73 */     localAffineTransformOp.filter(localBufferedImage1, localBufferedImage2);
/*    */     
/* 75 */     return localBufferedImage2;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\BufferToBufferedImage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */