package com.sun.media.util;

public abstract interface RTPInfo
{
  public abstract String getCNAME();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\RTPInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */