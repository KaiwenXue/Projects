/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12PriorityAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   private Thread t;
/*    */   private int priority;
/*    */   public static Constructor cons;
/*    */   
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 20 */       cons = class$com$sun$media$util$jdk12PriorityAction.getConstructor(new Class[] { Thread.class, Integer.TYPE });
/*    */     }
/*    */     catch (Throwable e) {}
/*    */   }
/*    */   
/*    */   public jdk12PriorityAction(Thread t, int priority)
/*    */   {
/* 27 */     this.t = t;
/* 28 */     this.priority = priority;
/*    */   }
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 33 */       this.t.setPriority(this.priority);
/* 34 */       return null;
/*    */     }
/*    */     catch (Throwable t) {}
/*    */     
/* 38 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\jdk12PriorityAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */