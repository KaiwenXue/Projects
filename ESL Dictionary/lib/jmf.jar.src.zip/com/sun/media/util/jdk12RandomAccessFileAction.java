/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.io.RandomAccessFile;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12RandomAccessFileAction
/*    */   implements PrivilegedAction
/*    */ {
/*    */   public static Constructor cons;
/*    */   private String name;
/*    */   private String mode;
/*    */   
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 23 */       cons = class$com$sun$media$util$jdk12RandomAccessFileAction.getConstructor(new Class[] { String.class, String.class });
/*    */     }
/*    */     catch (Throwable e) {}
/*    */   }
/*    */   
/*    */   public jdk12RandomAccessFileAction(String name, String mode)
/*    */   {
/* 30 */     boolean rw = mode.equals("rw");
/* 31 */     if (!rw)
/* 32 */       mode = "r";
/* 33 */     this.mode = mode;
/* 34 */     this.name = name;
/*    */   }
/*    */   
/*    */   public Object run() {
/*    */     try {
/* 39 */       return new RandomAccessFile(this.name, this.mode);
/*    */     } catch (Throwable e) {}
/* 41 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\jdk12RandomAccessFileAction.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */