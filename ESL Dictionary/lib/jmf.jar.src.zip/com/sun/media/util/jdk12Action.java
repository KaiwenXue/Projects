/*    */ package com.sun.media.util;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.security.Permission;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class jdk12Action
/*    */ {
/*    */   public static Constructor getCheckPermissionAction()
/*    */     throws NoSuchMethodException
/*    */   {
/* 15 */     return class$com$sun$media$util$CheckPermissionAction.getConstructor(new Class[] { Permission.class });
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\util\jdk12Action.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */