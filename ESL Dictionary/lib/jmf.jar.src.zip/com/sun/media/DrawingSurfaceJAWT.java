/*    */ package com.sun.media;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Toolkit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DrawingSurfaceJAWT
/*    */ {
/*    */   public static final int valid = 0;
/*    */   public static final int pawt = 1;
/*    */   public static final int pds = 2;
/*    */   public static final int pwinid = 3;
/*    */   public static final int pdisp = 4;
/* 19 */   private static boolean avail = true;
/*    */   
/*    */   static {
/* 22 */     try { Toolkit.getDefaultToolkit();
/* 23 */       JMFSecurityManager.loadLibrary("jmfjawt");
/*    */       
/* 25 */       avail = true;
/*    */     } catch (Throwable t) {
/* 27 */       t.printStackTrace();
/* 28 */       avail = false;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 42 */   int[] winfo = null;
/*    */   
/*    */   public DrawingSurfaceJAWT() {
/* 45 */     if (!avail) {
/* 46 */       throw new RuntimeException("can't load jmfjawt native module");
/*    */     }
/*    */     
/*    */ 
/* 50 */     this.winfo = new int[5];
/* 51 */     for (int i = 0; i < 5; i++) {
/* 52 */       this.winfo[i] = 0;
/*    */     }
/*    */   }
/*    */   
/*    */   public int[] getWindowInfo(Component cc) {
/* 57 */     int value = 0;
/* 58 */     value = getAWT();
/* 59 */     if (value == 0) {
/* 60 */       this.winfo[0] = 0;
/* 61 */       return this.winfo;
/*    */     }
/* 63 */     this.winfo[1] = value;
/*    */     
/* 65 */     value = getDrawingSurface(cc, this.winfo[1]);
/* 66 */     if (value == 0) {
/* 67 */       this.winfo[0] = 0;
/* 68 */       return this.winfo;
/*    */     }
/*    */     
/* 71 */     this.winfo[2] = value;
/*    */     
/* 73 */     value = getDrawingSurfaceWinID(this.winfo[2]);
/* 74 */     if (value == 0) {
/* 75 */       this.winfo[0] = 0;
/* 76 */       return this.winfo;
/*    */     }
/*    */     
/* 79 */     this.winfo[3] = value;
/*    */     
/* 81 */     value = getDrawingSurfaceDisplay(this.winfo[2]);
/* 82 */     if (value == 0) {
/* 83 */       this.winfo[0] = 0;
/* 84 */       return this.winfo;
/*    */     }
/*    */     
/* 87 */     this.winfo[4] = value;
/* 88 */     this.winfo[0] = 1;
/*    */     
/* 90 */     return this.winfo;
/*    */   }
/*    */   
/*    */   public static native int getWindowHandle(Component paramComponent);
/*    */   
/*    */   public static native boolean lockAWT(int paramInt);
/*    */   
/*    */   public static native void unlockAWT(int paramInt);
/*    */   
/*    */   public static native void freeResource(int paramInt1, int paramInt2);
/*    */   
/*    */   public native int getAWT();
/*    */   
/*    */   public native int getDrawingSurface(Component paramComponent, int paramInt);
/*    */   
/*    */   public native int getDrawingSurfaceWinID(int paramInt);
/*    */   
/*    */   public native int getDrawingSurfaceDisplay(int paramInt);
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\DrawingSurfaceJAWT.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */