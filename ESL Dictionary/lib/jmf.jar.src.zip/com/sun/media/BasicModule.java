/*     */ package com.sun.media;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.Time;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BasicModule
/*     */   implements Module, StateTransistor
/*     */ {
/*  22 */   protected Registry inputConnectors = new Registry();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  27 */   protected Registry outputConnectors = new Registry();
/*     */   
/*     */   protected InputConnector[] inputConnectorsArray;
/*     */   
/*     */   protected OutputConnector[] outputConnectorsArray;
/*  32 */   protected int protocol = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  37 */   protected String name = null;
/*     */   
/*     */   protected ModuleListener moduleListener;
/*     */   
/*     */   protected BasicController controller;
/*  42 */   protected boolean resetted = false;
/*  43 */   protected boolean prefetchFailed = false;
/*     */   
/*  45 */   protected JMD jmd = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean doRealize()
/*     */   {
/*  52 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doFailedRealize() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void abortRealize() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void connectorPushed(InputConnector inputConnector)
/*     */   {
/*  69 */     process();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean doPrefetch()
/*     */   {
/*  78 */     this.resetted = false;
/*  79 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doFailedPrefetch() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void abortPrefetch() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doStart()
/*     */   {
/*  98 */     this.resetted = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doStop() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doDealloc() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doClose() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doSetMediaTime(Time t) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public float doSetRate(float r)
/*     */   {
/* 127 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object[] getControls()
/*     */   {
/* 134 */     return null;
/*     */   }
/*     */   
/*     */   public Object getControl(String s) {
/* 138 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setModuleListener(ModuleListener listener)
/*     */   {
/* 149 */     this.moduleListener = listener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFormat(Connector connector, Format format) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getInputConnectorNames()
/*     */   {
/* 165 */     return this.inputConnectors.getNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getOutputConnectorNames()
/*     */   {
/* 173 */     return this.outputConnectors.getNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputConnector getInputConnector(String connectorName)
/*     */   {
/* 181 */     return (InputConnector)this.inputConnectors.get(connectorName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public OutputConnector getOutputConnector(String connectorName)
/*     */   {
/* 188 */     return (OutputConnector)this.outputConnectors.get(connectorName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerInputConnector(String name, InputConnector inputConnector)
/*     */   {
/* 197 */     this.inputConnectors.put(name, inputConnector);
/* 198 */     inputConnector.setModule(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerOutputConnector(String name, OutputConnector outputConnector)
/*     */   {
/* 206 */     this.outputConnectors.put(name, outputConnector);
/* 207 */     outputConnector.setModule(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 222 */     this.resetted = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean verifyBuffer(Buffer buffer)
/*     */   {
/* 229 */     if (buffer.isDiscard())
/* 230 */       return true;
/* 231 */     Object data = buffer.getData();
/* 232 */     if (buffer.getLength() < 0) {
/* 233 */       System.err.println("warning: data length shouldn't be negative: " + buffer.getLength());
/*     */     }
/* 235 */     if (data == null) {
/* 236 */       System.err.println("warning: data buffer is null");
/* 237 */       if (buffer.getLength() != 0) {
/* 238 */         System.err.println("buffer advertized length = " + buffer.getLength() + " but data buffer is null!");
/* 239 */         return false;
/*     */       }
/* 241 */     } else if ((data instanceof byte[])) {
/* 242 */       if (buffer.getLength() > ((byte[])data).length) {
/* 243 */         System.err.println("buffer advertized length = " + buffer.getLength() + " but actual length = " + ((byte[])data).length);
/* 244 */         return false;
/*     */       }
/* 246 */     } else if (((data instanceof int[])) && 
/* 247 */       (buffer.getLength() > ((int[])data).length)) {
/* 248 */       System.err.println("buffer advertized length = " + buffer.getLength() + " but actual length = " + ((int[])data).length);
/* 249 */       return false;
/*     */     }
/*     */     
/* 252 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean isInterrupted()
/*     */   {
/* 259 */     return this.controller == null ? false : this.controller.isInterrupted();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isThreaded()
/*     */   {
/* 267 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean canRun()
/*     */   {
/* 275 */     for (int i = 0; i < this.inputConnectorsArray.length; i++)
/* 276 */       if (!this.inputConnectorsArray[i].isValidBufferAvailable())
/* 277 */         return false;
/* 278 */     for (int i = 0; i < this.outputConnectorsArray.length; i++) {
/* 279 */       if (!this.outputConnectorsArray[i].isEmptyBufferAvailable())
/* 280 */         return false;
/*     */     }
/* 282 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void process();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void error()
/*     */   {
/* 305 */     throw new RuntimeException(getClass().getName() + " error");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final BasicController getController()
/*     */   {
/* 312 */     return this.controller;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setController(BasicController c)
/*     */   {
/* 319 */     this.controller = c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final int getState()
/*     */   {
/* 326 */     return this.controller.getState();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final String getName()
/*     */   {
/* 333 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 341 */     this.name = name;
/*     */   }
/*     */   
/*     */   public void setJMD(JMD jmd) {
/* 345 */     this.jmd = jmd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Time getMediaTime()
/*     */   {
/* 352 */     return this.controller.getMediaTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long getMediaNanoseconds()
/*     */   {
/* 359 */     return this.controller.getMediaNanoseconds();
/*     */   }
/*     */   
/*     */   public long getLatency() {
/* 363 */     return ((PlaybackEngine)this.controller).getLatency();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setProtocol(int protocol)
/*     */   {
/* 370 */     this.protocol = protocol;
/* 371 */     Connector[] connectors = this.inputConnectors.getConnectors();
/* 372 */     for (int i = 0; i < connectors.length; i++)
/* 373 */       connectors[i].setProtocol(protocol);
/* 374 */     connectors = this.outputConnectors.getConnectors();
/* 375 */     for (int i = 0; i < connectors.length; i++) {
/* 376 */       connectors[i].setProtocol(protocol);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getProtocol()
/*     */   {
/* 384 */     return this.protocol;
/*     */   }
/*     */   
/*     */   public boolean prefetchFailed() {
/* 388 */     return this.prefetchFailed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   class Registry
/*     */     extends Hashtable
/*     */   {
/* 401 */     Connector def = null;
/*     */     
/*     */     Registry() {}
/*     */     
/* 405 */     String[] getNames() { Enumeration namesEnum = keys();
/* 406 */       String[] namesArray = new String[size()];
/* 407 */       for (int i = 0; i < size(); i++)
/* 408 */         namesArray[i] = ((String)namesEnum.nextElement());
/* 409 */       return namesArray;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     void put(String name, Connector connector)
/*     */     {
/* 416 */       if (containsKey(name))
/* 417 */         throw new RuntimeException("Connector '" + name + "' already exists in Module '" + BasicModule.this.getClass().getName() + "::" + name + "'");
/* 418 */       if (this.def == null)
/* 419 */         this.def = connector;
/* 420 */       super.put(name, connector);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     Object get(String name)
/*     */     {
/* 427 */       if (name == null)
/* 428 */         return this.def;
/* 429 */       return super.get(name);
/*     */     }
/*     */     
/*     */     Connector[] getConnectors()
/*     */     {
/* 434 */       Enumeration connectorsEnum = elements();
/* 435 */       Connector[] connectorsArray = new Connector[size()];
/* 436 */       for (int i = 0; i < size(); i++)
/* 437 */         connectorsArray[i] = ((Connector)connectorsEnum.nextElement());
/* 438 */       return connectorsArray;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\BasicModule.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */