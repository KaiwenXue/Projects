/*      */ package com.sun.media.rtp;
/*      */ 
/*      */ import com.ms.security.PermissionID;
/*      */ import com.ms.security.PolicyEngine;
/*      */ import com.sun.media.JMFSecurity;
/*      */ import com.sun.media.JMFSecurityManager;
/*      */ import com.sun.media.Log;
/*      */ import com.sun.media.protocol.BasicSourceStream;
/*      */ import com.sun.media.protocol.BufferListener;
/*      */ import com.sun.media.protocol.rtp.DataSource;
/*      */ import com.sun.media.rtp.util.RTPMediaThread;
/*      */ import com.sun.media.util.MediaThread;
/*      */ import com.sun.media.util.jdk12;
/*      */ import com.sun.media.util.jdk12CreateThreadRunnableAction;
/*      */ import com.sun.media.util.jdk12PriorityAction;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Method;
/*      */ import javax.media.Buffer;
/*      */ import javax.media.Format;
/*      */ import javax.media.control.BufferControl;
/*      */ import javax.media.format.AudioFormat;
/*      */ import javax.media.format.VideoFormat;
/*      */ import javax.media.protocol.BufferTransferHandler;
/*      */ import javax.media.protocol.ContentDescriptor;
/*      */ import javax.media.protocol.PushBufferStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RTPSourceStream
/*      */   extends BasicSourceStream
/*      */   implements PushBufferStream, Runnable
/*      */ {
/*      */   private DataSource dsource;
/*   44 */   private Format format = null;
/*   45 */   BufferTransferHandler handler = null;
/*   46 */   boolean started = false;
/*   47 */   boolean killed = false;
/*   48 */   boolean replenish = true;
/*      */   PktQue pktQ;
/*   50 */   Object startReq = new Object();
/*   51 */   private RTPMediaThread thread = null;
/*      */   
/*   53 */   private boolean hasRead = false;
/*      */   
/*   55 */   private int DEFAULT_AUDIO_RATE = 8000;
/*   56 */   private int DEFAULT_VIDEO_RATE = 15;
/*      */   
/*      */ 
/*   59 */   private BufferControlImpl bc = null;
/*   60 */   private long lastSeqRecv = -1L;
/*   61 */   private long lastSeqSent = -1L;
/*      */   
/*   63 */   private static JMFSecurity jmfSecurity = null;
/*   64 */   private static boolean securityPrivelege = false;
/*   65 */   private Method[] m = new Method[1];
/*   66 */   private Class[] cl = new Class[1];
/*   67 */   private Object[][] args = new Object[1][0];
/*      */   
/*      */   private static final int NOT_SPECIFIED = -1;
/*   70 */   private BufferListener listener = null;
/*   71 */   private int threshold = 0;
/*   72 */   private boolean prebuffering = false;
/*   73 */   private boolean prebufferNotice = false;
/*   74 */   private boolean bufferWhenStopped = true;
/*      */   
/*   76 */   static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
/*   77 */   static VideoFormat mpegVideo = new VideoFormat("mpeg/rtp");
/*      */   
/*      */   static
/*      */   {
/*      */     try {
/*   82 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*   83 */       securityPrivelege = true;
/*      */     }
/*      */     catch (SecurityException e) {}
/*      */   }
/*      */   
/*      */   public RTPSourceStream(DataSource dsource)
/*      */   {
/*   90 */     this.dsource = dsource;
/*   91 */     dsource.setSourceStream(this);
/*   92 */     this.pktQ = new PktQue(4);
/*   93 */     createThread();
/*      */   }
/*      */   
/*      */   public void setBufferControl(BufferControl b)
/*      */   {
/*   98 */     this.bc = ((BufferControlImpl)b);
/*   99 */     updateBuffer(this.bc.getBufferLength());
/*  100 */     updateThreshold(this.bc.getMinimumThreshold());
/*      */   }
/*      */   
/*      */   public long updateBuffer(long len)
/*      */   {
/*  105 */     return len;
/*      */   }
/*      */   
/*      */   public long updateThreshold(long threshold)
/*      */   {
/*  110 */     return threshold;
/*      */   }
/*      */   
/*      */   public void setBufferListener(BufferListener listener)
/*      */   {
/*  115 */     this.listener = listener;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(Buffer filled, boolean wrapped, RTPRawReceiver rtpr)
/*      */   {
/*  124 */     if ((!this.started) && (!this.bufferWhenStopped)) {
/*  125 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  131 */     if (this.lastSeqRecv - filled.getSequenceNumber() > 256L) {
/*  132 */       this.pktQ.reset();
/*      */     }
/*  134 */     this.lastSeqRecv = filled.getSequenceNumber();
/*      */     
/*  136 */     boolean overflown = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  147 */     synchronized (this.pktQ)
/*      */     {
/*      */ 
/*  150 */       this.pktQ.monitorQueueSize(filled, rtpr);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  156 */       if (this.pktQ.noMoreFree()) {
/*  157 */         long head = this.pktQ.getFirstSeq();
/*  158 */         if ((head != -1L) && (filled.getSequenceNumber() < head))
/*      */         {
/*  160 */           return;
/*      */         }
/*      */         
/*      */ 
/*  164 */         this.pktQ.dropPkt();
/*      */       }
/*      */     }
/*      */     
/*  168 */     if (this.pktQ.totalFree() <= 1) {
/*  169 */       overflown = true;
/*      */     }
/*  171 */     Buffer buf = this.pktQ.getFree();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  176 */     byte[] inData = (byte[])filled.getData();
/*  177 */     byte[] outData = (byte[])buf.getData();
/*  178 */     if ((outData == null) || (outData.length < inData.length)) {
/*  179 */       outData = new byte[inData.length];
/*      */     }
/*      */     
/*  182 */     System.arraycopy(inData, filled.getOffset(), outData, filled.getOffset(), filled.getLength());
/*      */     
/*      */ 
/*  185 */     buf.copy(filled);
/*  186 */     buf.setData(outData);
/*      */     
/*  188 */     if (overflown) {
/*  189 */       buf.setFlags(buf.getFlags() | 0x2000 | 0x20);
/*      */     }
/*      */     else
/*      */     {
/*  193 */       buf.setFlags(buf.getFlags() | 0x20);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  199 */     this.pktQ.addPkt(buf);
/*      */     
/*  201 */     synchronized (this.pktQ)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  206 */       if ((this.started) && (this.prebufferNotice) && (this.listener != null) && (this.pktQ.totalPkts() >= this.threshold))
/*      */       {
/*  208 */         this.listener.minThresholdReached(this.dsource);
/*  209 */         this.prebufferNotice = false;
/*  210 */         this.prebuffering = false;
/*      */         
/*      */ 
/*  213 */         synchronized (this.startReq) {
/*  214 */           this.startReq.notifyAll();
/*      */         }
/*      */       }
/*      */       
/*  218 */       if ((this.replenish) && ((this.format instanceof AudioFormat)))
/*      */       {
/*  220 */         if (this.pktQ.totalPkts() >= this.pktQ.size / 2) {
/*  221 */           this.replenish = false;
/*  222 */           this.pktQ.notifyAll();
/*      */         }
/*      */       }
/*      */       else {
/*  226 */         this.pktQ.notifyAll();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void read(Buffer buf)
/*      */   {
/*  239 */     if (this.pktQ.totalPkts() == 0) {
/*  240 */       buf.setDiscard(true);
/*  241 */       return;
/*      */     }
/*      */     
/*  244 */     Buffer pkt = this.pktQ.getPkt();
/*      */     
/*  246 */     this.lastSeqSent = pkt.getSequenceNumber();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  254 */     Object data = buf.getData();
/*  255 */     Object hdr = buf.getHeader();
/*  256 */     buf.copy(pkt);
/*  257 */     pkt.setData(data);
/*  258 */     pkt.setHeader(hdr);
/*  259 */     this.pktQ.returnFree(pkt);
/*      */     
/*  261 */     synchronized (this.pktQ)
/*      */     {
/*      */ 
/*  264 */       this.hasRead = true;
/*  265 */       if ((this.format instanceof AudioFormat)) {
/*  266 */         if (this.pktQ.totalPkts() > 0) {
/*  267 */           this.pktQ.notifyAll();
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  272 */           this.replenish = true;
/*      */         }
/*      */       } else {
/*  275 */         this.pktQ.notifyAll();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reset()
/*      */   {
/*  286 */     this.pktQ.reset();
/*  287 */     this.lastSeqSent = -1L;
/*      */   }
/*      */   
/*      */ 
/*      */   public Format getFormat()
/*      */   {
/*  293 */     return this.format;
/*      */   }
/*      */   
/*      */   protected void setFormat(Format format)
/*      */   {
/*  298 */     this.format = format;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setTransferHandler(BufferTransferHandler transferHandler)
/*      */   {
/*  304 */     this.handler = transferHandler;
/*      */   }
/*      */   
/*      */   void setContentDescriptor(String contentType)
/*      */   {
/*  309 */     this.contentDescriptor = new ContentDescriptor(contentType);
/*      */   }
/*      */   
/*      */   public void setBufferWhenStopped(boolean flag)
/*      */   {
/*  314 */     this.bufferWhenStopped = flag;
/*      */   }
/*      */   
/*      */   public void prebuffer()
/*      */   {
/*  319 */     synchronized (this.pktQ)
/*      */     {
/*  321 */       this.prebuffering = true;
/*  322 */       this.prebufferNotice = true;
/*      */     }
/*      */   }
/*      */   
/*      */   public void start()
/*      */   {
/*  328 */     synchronized (this.startReq) {
/*  329 */       this.started = true;
/*  330 */       this.startReq.notifyAll();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void stop()
/*      */   {
/*  338 */     synchronized (this.startReq) {
/*  339 */       this.started = false;
/*  340 */       this.prebuffering = false;
/*      */       
/*  342 */       if (!this.bufferWhenStopped) {
/*  343 */         reset();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void connect()
/*      */   {
/*  350 */     this.killed = false;
/*  351 */     createThread();
/*      */   }
/*      */   
/*      */ 
/*      */   public void close()
/*      */   {
/*  357 */     if (this.killed) {
/*  358 */       return;
/*      */     }
/*  360 */     stop();
/*  361 */     this.killed = true;
/*      */     
/*  363 */     synchronized (this.startReq) {
/*  364 */       this.startReq.notifyAll();
/*      */     }
/*      */     
/*  367 */     synchronized (this.pktQ) {
/*  368 */       this.pktQ.notifyAll();
/*      */     }
/*  370 */     this.thread = null;
/*      */     
/*      */ 
/*  373 */     if (this.bc != null) {
/*  374 */       this.bc.removeSourceStream(this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void run()
/*      */   {
/*      */     for (;;)
/*      */     {
/*      */       try
/*      */       {
/*  385 */         synchronized (this.startReq)
/*      */         {
/*  387 */           continue;this.startReq.wait();
/*  386 */           if ((!this.started) || (this.prebuffering)) if (!this.killed) {
/*      */               continue;
/*      */             }
/*      */         }
/*  390 */         synchronized (this.pktQ)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  399 */           if ((!this.hasRead) && (!this.killed))
/*  400 */             this.pktQ.wait();
/*  401 */           this.hasRead = false;
/*  402 */           if (this.pktQ.totalPkts() <= 0) if (!this.killed)
/*      */               continue;
/*      */         }
/*  405 */         if (this.killed) {
/*      */           break;
/*      */         }
/*  408 */         if (this.handler != null) {
/*  409 */           this.handler.transferData(this);
/*      */         }
/*      */       }
/*      */       catch (InterruptedException e) {
/*  413 */         Log.error("Thread " + e.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void createThread()
/*      */   {
/*  420 */     if (this.thread != null)
/*  421 */       return;
/*  422 */     if (jmfSecurity != null) {
/*  423 */       String permission = null;
/*      */       try {
/*  425 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  426 */           permission = "thread";
/*  427 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*  428 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*      */           
/*  430 */           permission = "thread group";
/*  431 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/*  432 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*      */         }
/*  434 */         else if (jmfSecurity.getName().startsWith("internet")) {
/*  435 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/*  436 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       catch (Throwable e)
/*      */       {
/*  443 */         if (permission.endsWith("group")) {
/*  444 */           jmfSecurity.permissionFailureNotification(32);
/*      */         } else {
/*  446 */           jmfSecurity.permissionFailureNotification(16);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  451 */     if ((jmfSecurity != null) && (jmfSecurity.getName().startsWith("jdk12"))) {
/*      */       try {
/*  453 */         Constructor cons = jdk12CreateThreadRunnableAction.cons;
/*      */         
/*  455 */         this.thread = ((RTPMediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { RTPMediaThread.class, this }) }));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  464 */         this.thread.setName("RTPStream");
/*      */         
/*  466 */         cons = jdk12PriorityAction.cons;
/*  467 */         jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { this.thread, new Integer(MediaThread.getControlPriority()) }) });
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (Exception e) {}
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*  478 */       this.thread = new RTPMediaThread(this, "RTPStream");
/*  479 */       this.thread.useControlPriority();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  484 */     this.thread.start();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   class PktQue
/*      */   {
/*  501 */     int FUDGE = 5;
/*  502 */     int DEFAULT_AUD_PKT_SIZE = 256;
/*  503 */     int DEFAULT_MILLISECS_PER_PKT = 30;
/*  504 */     int DEFAULT_PKTS_TO_BUFFER = 30;
/*  505 */     int MIN_BUF_CHECK = 10;
/*  506 */     int BUF_CHECK_INTERVAL = 7;
/*      */     
/*      */     int pktsEst;
/*  509 */     int framesEst = 0;
/*  510 */     int fps = 15;
/*  511 */     int pktsPerFrame = RTPSourceStream.this.DEFAULT_VIDEO_RATE;
/*  512 */     int sizePerPkt = this.DEFAULT_AUD_PKT_SIZE;
/*  513 */     int maxPktsToBuffer = 0;
/*  514 */     int sockBufSize = 0;
/*  515 */     int tooMuchBufferingCount = 0;
/*  516 */     long lastPktSeq = 0L;
/*  517 */     long lastCheckTime = 0L;
/*      */     Buffer[] fill;
/*      */     Buffer[] free;
/*      */     int headFill;
/*      */     int tailFill;
/*      */     int headFree;
/*      */     int tailFree;
/*      */     protected int size;
/*      */     
/*      */     public PktQue(int n)
/*      */     {
/*  528 */       allocBuffers(n);
/*      */     }
/*      */     
/*      */     public synchronized void reset()
/*      */     {
/*  533 */       while (moreFilled())
/*  534 */         returnFree(get());
/*  535 */       this.tooMuchBufferingCount = 0;
/*  536 */       notifyAll();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public int totalPkts()
/*      */     {
/*  544 */       return this.tailFill >= this.headFill ? this.tailFill - this.headFill : this.size - (this.headFill - this.tailFill);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int totalFree()
/*      */     {
/*  554 */       return this.tailFree >= this.headFree ? this.tailFree - this.headFree : this.size - (this.headFree - this.tailFree);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized void addPkt(Buffer buf)
/*      */     {
/*  571 */       long head = -1L;long tail = -1L;
/*  572 */       long seq = buf.getSequenceNumber();
/*      */       
/*  574 */       if (moreFilled()) {
/*  575 */         head = this.fill[this.headFill].getSequenceNumber();
/*  576 */         int i = this.tailFill - 1;
/*  577 */         if (i < 0)
/*  578 */           i = this.size - 1;
/*  579 */         tail = this.fill[i].getSequenceNumber();
/*      */       }
/*      */       
/*  582 */       if ((head == -1L) && (tail == -1L))
/*      */       {
/*      */ 
/*  585 */         append(buf);
/*      */       }
/*  587 */       else if (seq < head)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  592 */         prepend(buf);
/*      */       }
/*  594 */       else if ((head < seq) && (seq < tail))
/*      */       {
/*      */ 
/*      */ 
/*  598 */         insert(buf);
/*      */       }
/*  600 */       else if (seq > tail)
/*      */       {
/*      */ 
/*      */ 
/*  604 */         append(buf);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*  610 */         returnFree(buf);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void monitorQueueSize(Buffer buf, RTPRawReceiver rtpr)
/*      */     {
/*  628 */       this.sizePerPkt = ((this.sizePerPkt + buf.getLength()) / 2);
/*      */       
/*      */ 
/*      */ 
/*  632 */       if ((RTPSourceStream.this.format instanceof VideoFormat))
/*      */       {
/*      */ 
/*  635 */         if (this.lastPktSeq + 1L == buf.getSequenceNumber()) {
/*  636 */           this.pktsEst += 1;
/*      */         } else
/*  638 */           this.pktsEst = 1;
/*  639 */         this.lastPktSeq = buf.getSequenceNumber();
/*      */         
/*      */ 
/*  642 */         if (RTPSourceStream.mpegVideo.matches(RTPSourceStream.this.format)) {
/*  643 */           byte[] payload = (byte[])buf.getData();
/*  644 */           int offset = buf.getOffset();
/*  645 */           int ptype = payload[(offset + 2)] & 0x7;
/*  646 */           if (ptype < 3)
/*      */           {
/*  648 */             if ((buf.getFlags() & 0x800) != 0) {
/*  649 */               this.pktsPerFrame = ((this.pktsPerFrame + this.pktsEst) / 2);
/*  650 */               this.pktsEst = 0;
/*      */             }
/*      */           }
/*  653 */           this.fps = 30;
/*      */         }
/*  655 */         else if ((buf.getFlags() & 0x800) != 0) {
/*  656 */           this.pktsPerFrame = ((this.pktsPerFrame + this.pktsEst) / 2);
/*  657 */           this.pktsEst = 0;
/*  658 */           this.framesEst += 1;
/*  659 */           long now = System.currentTimeMillis();
/*  660 */           if (now - this.lastCheckTime >= 1000L)
/*      */           {
/*  662 */             this.lastCheckTime = now;
/*  663 */             this.fps = ((this.fps + this.framesEst) / 2);
/*  664 */             this.framesEst = 0;
/*  665 */             if (this.fps > 30) {
/*  666 */               this.fps = 30;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */         int pktsToBuffer;
/*      */         
/*      */ 
/*  675 */         if (RTPSourceStream.this.bc != null)
/*      */         {
/*  677 */           pktsToBuffer = (int)(RTPSourceStream.this.bc.getBufferLength() * this.fps / 1000L);
/*  678 */           if (pktsToBuffer <= 0) {
/*  679 */             pktsToBuffer = 1;
/*      */           }
/*  681 */           pktsToBuffer = this.pktsPerFrame * pktsToBuffer;
/*  682 */           RTPSourceStream.this.threshold = ((int)(RTPSourceStream.this.bc.getMinimumThreshold() * this.fps / 1000L * this.pktsPerFrame));
/*      */           
/*      */ 
/*      */ 
/*  686 */           if (RTPSourceStream.this.threshold > pktsToBuffer / 2) {}
/*  687 */           RTPSourceStream.this.threshold = (pktsToBuffer / 2);
/*      */         } else {
/*  689 */           pktsToBuffer = this.DEFAULT_PKTS_TO_BUFFER;
/*      */         }
/*      */         
/*  692 */         if (this.maxPktsToBuffer > 0) {
/*  693 */           this.maxPktsToBuffer = ((this.maxPktsToBuffer + pktsToBuffer) / 2);
/*      */         } else {
/*  695 */           this.maxPktsToBuffer = pktsToBuffer;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  713 */         int tot = totalPkts();
/*      */         
/*  715 */         if ((this.size > this.MIN_BUF_CHECK) && (tot < this.size / 4)) {
/*  716 */           if ((!RTPSourceStream.this.prebuffering) && (this.tooMuchBufferingCount++ > this.pktsPerFrame * this.fps * this.BUF_CHECK_INTERVAL))
/*      */           {
/*  718 */             cutByHalf();
/*  719 */             this.tooMuchBufferingCount = 0;
/*      */           }
/*  721 */         } else if ((tot >= this.size / 2) && (this.size < this.maxPktsToBuffer))
/*      */         {
/*  723 */           pktsToBuffer = this.size + this.size / 2;
/*  724 */           if (pktsToBuffer > this.maxPktsToBuffer)
/*  725 */             pktsToBuffer = this.maxPktsToBuffer;
/*  726 */           grow(pktsToBuffer + this.FUDGE);
/*  727 */           Log.comment("RTP video buffer size: " + this.size + " pkts, " + pktsToBuffer * this.sizePerPkt + " bytes.\n");
/*      */           
/*  729 */           this.tooMuchBufferingCount = 0;
/*      */         } else {
/*  731 */           this.tooMuchBufferingCount = 0;
/*      */         }
/*  733 */         int sizeToBuffer = pktsToBuffer * this.sizePerPkt / 2;
/*      */         
/*  735 */         if ((rtpr != null) && (sizeToBuffer > this.sockBufSize)) {
/*  736 */           rtpr.setRecvBufSize(sizeToBuffer);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  741 */           if (rtpr.getRecvBufSize() < sizeToBuffer) {
/*  742 */             this.sockBufSize = Integer.MAX_VALUE;
/*      */           } else {
/*  744 */             this.sockBufSize = sizeToBuffer;
/*      */           }
/*      */           
/*      */ 
/*  748 */           Log.comment("RTP video socket buffer size: " + rtpr.getRecvBufSize() + " bytes.\n");
/*      */         }
/*      */         
/*      */       }
/*  752 */       else if ((RTPSourceStream.this.format instanceof AudioFormat))
/*      */       {
/*  754 */         if (this.sizePerPkt <= 0) {
/*  755 */           this.sizePerPkt = this.DEFAULT_AUD_PKT_SIZE;
/*      */         }
/*      */         
/*      */ 
/*  759 */         if (RTPSourceStream.this.bc != null) {
/*      */           int lenPerPkt;
/*  761 */           if (RTPSourceStream.mpegAudio.matches(RTPSourceStream.this.format)) {
/*  762 */             lenPerPkt = this.sizePerPkt / 4;
/*      */           } else {
/*  764 */             lenPerPkt = this.DEFAULT_MILLISECS_PER_PKT;
/*      */           }
/*      */           
/*  767 */           int pktsToBuffer = (int)(RTPSourceStream.this.bc.getBufferLength() / lenPerPkt);
/*  768 */           RTPSourceStream.this.threshold = ((int)(RTPSourceStream.this.bc.getMinimumThreshold() / lenPerPkt));
/*      */           
/*      */ 
/*      */ 
/*  772 */           if (RTPSourceStream.this.threshold > pktsToBuffer / 2) {}
/*  773 */           RTPSourceStream.this.threshold = (pktsToBuffer / 2);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  782 */           if (pktsToBuffer > this.size) {
/*  783 */             grow(pktsToBuffer);
/*  784 */             Log.comment("RTP audio buffer size: " + this.size + " pkts, " + pktsToBuffer * this.sizePerPkt + " bytes.\n");
/*      */           }
/*      */           
/*      */ 
/*  788 */           int sizeToBuffer = pktsToBuffer * this.sizePerPkt / 2;
/*      */           
/*  790 */           if ((rtpr != null) && (sizeToBuffer > this.sockBufSize)) {
/*  791 */             rtpr.setRecvBufSize(sizeToBuffer);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  796 */             if (rtpr.getRecvBufSize() < sizeToBuffer) {
/*  797 */               this.sockBufSize = Integer.MAX_VALUE;
/*      */             } else {
/*  799 */               this.sockBufSize = sizeToBuffer;
/*      */             }
/*      */             
/*      */ 
/*  803 */             Log.comment("RTP audio socket buffer size: " + rtpr.getRecvBufSize() + " bytes.\n");
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized Buffer getPkt()
/*      */     {
/*  816 */       while (!moreFilled()) {
/*      */         try {
/*  818 */           wait();
/*      */         } catch (Exception e) {}
/*      */       }
/*  821 */       Buffer b = get();
/*      */       
/*  823 */       return b;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void dropPkt()
/*      */     {
/*  835 */       while (!moreFilled()) {
/*      */         try {
/*  837 */           wait();
/*      */         }
/*      */         catch (Exception e) {}
/*      */       }
/*  841 */       if ((RTPSourceStream.this.format instanceof AudioFormat))
/*      */       {
/*  843 */         dropFirstPkt();
/*      */ 
/*      */       }
/*  846 */       else if (RTPSourceStream.mpegVideo.matches(RTPSourceStream.this.format)) {
/*  847 */         dropMpegPkt();
/*      */       } else {
/*  849 */         dropFirstPkt();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized void dropFirstPkt()
/*      */     {
/*  859 */       Buffer buf = get();
/*  860 */       RTPSourceStream.this.lastSeqSent = buf.getSequenceNumber();
/*  861 */       returnFree(buf);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized void dropMpegPkt()
/*      */     {
/*  877 */       int i = this.headFill;
/*  878 */       int firstP = -1;int firstB = -1;
/*      */       
/*      */ 
/*  881 */       while (i != this.tailFill)
/*      */       {
/*  883 */         buf = this.fill[i];
/*  884 */         byte[] payload = (byte[])buf.getData();
/*  885 */         int offset = buf.getOffset();
/*  886 */         int ptype = payload[(offset + 2)] & 0x7;
/*  887 */         if (ptype > 2)
/*      */         {
/*      */ 
/*      */ 
/*  891 */           firstB = i;
/*  892 */           break; }
/*  893 */         if ((ptype == 2) && (firstP == -1))
/*      */         {
/*  895 */           firstP = i;
/*      */         }
/*      */         
/*  898 */         i++;
/*  899 */         if (i >= this.size) {
/*  900 */           i = 0;
/*      */         }
/*      */       }
/*  903 */       if (firstB == -1)
/*      */       {
/*      */ 
/*  906 */         i = firstP == -1 ? this.headFill : firstP;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  913 */       Buffer buf = this.fill[i];
/*      */       
/*  915 */       if (i == 0) {
/*  916 */         RTPSourceStream.this.lastSeqSent = buf.getSequenceNumber();
/*      */       }
/*  918 */       removeAt(i);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public synchronized long getFirstSeq()
/*      */     {
/*  926 */       if (!moreFilled())
/*  927 */         return -1L;
/*  928 */       return this.fill[this.headFill].getSequenceNumber();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private void allocBuffers(int n)
/*      */     {
/*  937 */       this.fill = new Buffer[n];
/*  938 */       this.free = new Buffer[n];
/*  939 */       for (int i = 0; i < n - 1; i++)
/*  940 */         this.free[i] = new Buffer();
/*  941 */       this.size = n;
/*  942 */       this.headFill = (this.tailFill = 0);
/*  943 */       this.headFree = 0;
/*  944 */       this.tailFree = (this.size - 1);
/*      */     }
/*      */     
/*      */     private synchronized void grow(int newSize)
/*      */     {
/*  949 */       Buffer[] newFill = new Buffer[newSize];
/*  950 */       Buffer[] newFree = new Buffer[newSize];
/*      */       
/*  952 */       int totPkts = totalPkts();
/*  953 */       int totFree = totalFree();
/*      */       
/*      */ 
/*  956 */       int i = this.headFill;
/*  957 */       int j = 0;
/*  958 */       while (i != this.tailFill) {
/*  959 */         newFill[j] = this.fill[i];
/*  960 */         i++;
/*  961 */         if (i >= this.size)
/*  962 */           i = 0;
/*  963 */         j++;
/*      */       }
/*  965 */       this.headFill = 0;
/*  966 */       this.tailFill = totPkts;
/*  967 */       this.fill = newFill;
/*      */       
/*      */ 
/*  970 */       i = this.headFree;
/*  971 */       j = 0;
/*  972 */       while (i != this.tailFree) {
/*  973 */         newFree[j] = this.free[i];
/*  974 */         i++;
/*  975 */         if (i >= this.size)
/*  976 */           i = 0;
/*  977 */         j++;
/*      */       }
/*  979 */       this.headFree = 0;
/*  980 */       this.tailFree = totFree;
/*      */       
/*      */ 
/*  983 */       i = newSize - this.size;
/*  984 */       while (i > 0) {
/*  985 */         newFree[this.tailFree] = new Buffer();
/*  986 */         this.tailFree += 1;
/*  987 */         i--;
/*      */       }
/*      */       
/*  990 */       this.free = newFree;
/*  991 */       this.size = newSize;
/*      */     }
/*      */     
/*      */     private synchronized void cutByHalf()
/*      */     {
/*  996 */       int newSize = this.size / 2;
/*  997 */       if (newSize <= 0) {
/*  998 */         return;
/*      */       }
/* 1000 */       Buffer[] newFill = new Buffer[this.size / 2];
/* 1001 */       Buffer[] newFree = new Buffer[this.size / 2];
/*      */       
/* 1003 */       int tot = totalPkts();
/*      */       
/*      */ 
/*      */ 
/* 1007 */       for (int i = 0; (i < newSize) && (i < tot); i++) {
/* 1008 */         newFill[i] = get();
/*      */       }
/*      */       
/* 1011 */       tot = newSize - i - (this.size - tot - totalFree());
/*      */       
/* 1013 */       this.headFill = 0;
/* 1014 */       this.tailFill = i;
/*      */       
/* 1016 */       for (i = 0; i <= tot; i++) {
/* 1017 */         newFree[i] = new Buffer();
/*      */       }
/*      */       
/* 1020 */       this.headFree = 0;
/* 1021 */       this.tailFree = tot;
/*      */       
/* 1023 */       this.fill = newFill;
/* 1024 */       this.free = newFree;
/* 1025 */       this.size = newSize;
/*      */     }
/*      */     
/*      */     private synchronized Buffer get() {
/* 1029 */       Buffer b = this.fill[this.headFill];
/* 1030 */       this.fill[this.headFill] = null;
/* 1031 */       this.headFill += 1;
/* 1032 */       if (this.headFill >= this.size)
/* 1033 */         this.headFill = 0;
/* 1034 */       return b;
/*      */     }
/*      */     
/*      */     private synchronized void append(Buffer b) {
/* 1038 */       this.fill[this.tailFill] = b;
/* 1039 */       this.tailFill += 1;
/* 1040 */       if (this.tailFill >= this.size)
/* 1041 */         this.tailFill = 0;
/*      */     }
/*      */     
/*      */     private synchronized void prepend(Buffer b) {
/* 1045 */       this.headFill -= 1;
/* 1046 */       if (this.headFill < 0)
/* 1047 */         this.headFill = 0;
/* 1048 */       this.fill[this.headFill] = b;
/*      */     }
/*      */     
/*      */     private synchronized void insert(Buffer b) {
/* 1052 */       int i = this.headFill;
/* 1053 */       while (i != this.tailFill) {
/* 1054 */         if (this.fill[i].getSequenceNumber() > b.getSequenceNumber())
/*      */           break;
/* 1056 */         i++;
/* 1057 */         if (i >= this.size) {
/* 1058 */           i = 0;
/*      */         }
/*      */       }
/* 1061 */       if (i != this.tailFill)
/*      */       {
/* 1063 */         this.tailFill += 1;
/* 1064 */         if (this.tailFill >= this.size)
/* 1065 */           this.tailFill = 0;
/*      */         int prev;
/* 1067 */         int j = prev = this.tailFill;
/*      */         do {
/* 1069 */           prev--;
/* 1070 */           if (prev < 0)
/* 1071 */             prev = this.size - 1;
/* 1072 */           this.fill[j] = this.fill[prev];
/* 1073 */           j = prev;
/* 1074 */         } while (j != i);
/* 1075 */         this.fill[i] = b;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private void removeAt(int n)
/*      */     {
/* 1084 */       Buffer buf = this.fill[n];
/* 1085 */       if (n == this.headFill) {
/* 1086 */         this.headFill += 1;
/* 1087 */         if (this.headFill >= this.size)
/* 1088 */           this.headFill = 0;
/* 1089 */       } else if (n == this.tailFill) {
/* 1090 */         this.tailFill -= 1;
/* 1091 */         if (this.tailFill < 0) {
/* 1092 */           this.tailFill = (this.size - 1);
/*      */         }
/*      */       } else {
/* 1095 */         int prev = n;
/*      */         do {
/* 1097 */           prev--;
/* 1098 */           if (prev < 0)
/* 1099 */             prev = this.size - 1;
/* 1100 */           this.fill[n] = this.fill[prev];
/* 1101 */           n = prev;
/* 1102 */         } while (n != this.headFill);
/* 1103 */         this.headFill += 1;
/* 1104 */         if (this.headFill >= this.size)
/* 1105 */           this.headFill = 0;
/*      */       }
/* 1107 */       returnFree(buf);
/*      */     }
/*      */     
/*      */     private boolean moreFilled() {
/* 1111 */       return this.headFill != this.tailFill;
/*      */     }
/*      */     
/*      */     public synchronized Buffer getFree() {
/* 1115 */       Buffer b = this.free[this.headFree];
/* 1116 */       this.free[this.headFree] = null;
/* 1117 */       this.headFree += 1;
/* 1118 */       if (this.headFree >= this.size)
/* 1119 */         this.headFree = 0;
/* 1120 */       return b;
/*      */     }
/*      */     
/*      */     private synchronized void returnFree(Buffer b) {
/* 1124 */       this.free[this.tailFree] = b;
/* 1125 */       this.tailFree += 1;
/* 1126 */       if (this.tailFree >= this.size)
/* 1127 */         this.tailFree = 0;
/*      */     }
/*      */     
/*      */     private boolean noMoreFree() {
/* 1131 */       return this.headFree == this.tailFree;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\RTPSourceStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */