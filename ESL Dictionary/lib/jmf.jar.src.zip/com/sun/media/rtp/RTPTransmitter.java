/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import com.sun.media.rtp.util.Packet;
/*     */ import com.sun.media.rtp.util.PacketFilter;
/*     */ import com.sun.media.rtp.util.RTPPacket;
/*     */ import com.sun.media.rtp.util.UDPPacketSender;
/*     */ import java.io.IOException;
/*     */ import java.net.UnknownHostException;
/*     */ import javax.media.Buffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTPTransmitter
/*     */ {
/*     */   RTPRawSender sender;
/*     */   SSRCCache cache;
/*     */   
/*     */   public RTPTransmitter(SSRCCache cache)
/*     */   {
/*  23 */     this.cache = cache;
/*     */   }
/*     */   
/*     */   public RTPTransmitter(SSRCCache cache, RTPRawSender sender) {
/*  27 */     this(cache);
/*  28 */     setSender(sender);
/*     */   }
/*     */   
/*     */   public RTPTransmitter(SSRCCache cache, int port, String address) throws UnknownHostException, IOException
/*     */   {
/*  33 */     this(cache, new RTPRawSender(port, address));
/*     */   }
/*     */   
/*     */   public RTPTransmitter(SSRCCache cache, int port, String address, UDPPacketSender sender)
/*     */     throws UnknownHostException, IOException
/*     */   {
/*  39 */     this(cache, new RTPRawSender(port, address, sender));
/*     */   }
/*     */   
/*     */   public void setSender(RTPRawSender s) {
/*  43 */     this.sender = s;
/*     */   }
/*     */   
/*     */   public RTPRawSender getSender() {
/*  47 */     return this.sender;
/*     */   }
/*     */   
/*     */   public void close() {
/*  51 */     if (this.sender != null)
/*  52 */       this.sender.closeConsumer();
/*     */   }
/*     */   
/*     */   protected void transmit(RTPPacket p) {
/*     */     try {
/*  57 */       this.sender.sendTo(p);
/*     */ 
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  62 */       this.cache.sm.transstats.transmit_failed += 1;
/*     */     }
/*     */   }
/*     */   
/*     */   public void TransmitPacket(Buffer b, SendSSRCInfo info)
/*     */   {
/*  68 */     info.rtptime = info.getTimeStamp(b);
/*     */     
/*  70 */     if ((b.getHeader() instanceof Long)) {
/*  71 */       info.systime = ((Long)b.getHeader()).longValue();
/*     */     } else {
/*  73 */       info.systime = System.currentTimeMillis();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */     RTPPacket p = MakeRTPPacket(b, info);
/*  84 */     if (p == null)
/*  85 */       return;
/*  86 */     transmit(p);
/*     */     
/*  88 */     info.stats.total_pdu += 1;
/*  89 */     info.stats.total_bytes += b.getLength();
/*  90 */     this.cache.sm.transstats.rtp_sent += 1;
/*  91 */     this.cache.sm.transstats.bytes_sent += b.getLength();
/*     */   }
/*     */   
/*     */   protected RTPPacket MakeRTPPacket(Buffer b, SendSSRCInfo info) {
/*  95 */     byte[] data = (byte[])b.getData();
/*  96 */     if (data == null) {
/*  97 */       return null;
/*     */     }
/*  99 */     Packet p = new Packet();
/* 100 */     p.data = data;
/* 101 */     p.offset = 0;
/* 102 */     p.length = b.getLength();
/* 103 */     p.received = false;
/*     */     
/*     */ 
/*     */ 
/* 107 */     RTPPacket rtp = new RTPPacket(p);
/* 108 */     if ((b.getFlags() & 0x800) != 0) {
/* 109 */       rtp.marker = 1;
/*     */     } else
/* 111 */       rtp.marker = 0;
/* 112 */     info.packetsize += b.getLength();
/* 113 */     rtp.payloadType = info.payloadType;
/* 114 */     rtp.seqnum = ((int)info.getSequenceNumber(b));
/*     */     
/* 116 */     rtp.timestamp = info.rtptime;
/* 117 */     rtp.ssrc = info.ssrc;
/* 118 */     rtp.payloadoffset = b.getOffset();
/* 119 */     rtp.payloadlength = b.getLength();
/*     */     
/* 121 */     info.bytesreceived += b.getLength();
/* 122 */     info.maxseq += 1;
/* 123 */     info.lasttimestamp = rtp.timestamp;
/*     */     
/* 125 */     return rtp;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\RTPTransmitter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */