package com.sun.media.rtp;

import javax.media.Buffer;
import javax.media.Format;
import javax.media.PlugIn;

public abstract interface Depacketizer
  extends PlugIn
{
  public static final int DEPACKETIZER = 6;
  
  public abstract Format[] getSupportedInputFormats();
  
  public abstract Format setInputFormat(Format paramFormat);
  
  public abstract Format parse(Buffer paramBuffer);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\Depacketizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */