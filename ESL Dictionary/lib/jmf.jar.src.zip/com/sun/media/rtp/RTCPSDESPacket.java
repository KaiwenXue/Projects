/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.FilterOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTCPSDESPacket
/*    */   extends RTCPPacket
/*    */ {
/*    */   public RTCPSDES[] sdes;
/*    */   
/*    */   public RTCPSDESPacket(RTCPPacket parent)
/*    */   {
/* 20 */     super(parent);
/* 21 */     this.type = 202;
/*    */   }
/*    */   
/*    */   public RTCPSDESPacket(RTCPSDES[] sdes)
/*    */   {
/* 26 */     this.sdes = sdes;
/* 27 */     if (sdes.length > 31)
/* 28 */       throw new IllegalArgumentException("Too many SDESs");
/*    */   }
/*    */   
/* 31 */   public String toString() { return "\tRTCP SDES Packet:\n" + RTCPSDES.toString(this.sdes); }
/*    */   
/*    */   public int calcLength()
/*    */   {
/* 35 */     int len = 4;
/* 36 */     for (int i = 0; i < this.sdes.length; i++) {
/* 37 */       int sublen = 5;
/* 38 */       for (int j = 0; j < this.sdes[i].items.length; j++)
/* 39 */         sublen += 2 + this.sdes[i].items[j].data.length;
/* 40 */       sublen = sublen + 3 & 0xFFFFFFFC;
/* 41 */       len += sublen;
/*    */     }
/* 43 */     return len;
/*    */   }
/*    */   
/*    */   void assemble(DataOutputStream out) throws IOException {
/* 47 */     out.writeByte(128 + this.sdes.length);
/* 48 */     out.writeByte(202);
/* 49 */     out.writeShort(calcLength() - 4 >> 2);
/* 50 */     for (int i = 0; i < this.sdes.length; i++) {
/* 51 */       out.writeInt(this.sdes[i].ssrc);
/* 52 */       int sublen = 0;
/* 53 */       for (int j = 0; j < this.sdes[i].items.length; j++) {
/* 54 */         out.writeByte(this.sdes[i].items[j].type);
/* 55 */         out.writeByte(this.sdes[i].items[j].data.length);
/* 56 */         out.write(this.sdes[i].items[j].data);
/* 57 */         sublen += 2 + this.sdes[i].items[j].data.length;
/*    */       }
/* 59 */       for (int j = (sublen + 4 & 0xFFFFFFFC) - sublen; j > 0; j--) {
/* 60 */         out.writeByte(0);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\RTCPSDESPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */