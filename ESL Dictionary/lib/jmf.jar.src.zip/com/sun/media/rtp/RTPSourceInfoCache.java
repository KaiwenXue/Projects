/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTPSourceInfoCache
/*    */ {
/*    */   public SSRCCache ssrccache;
/* 18 */   Hashtable cache = new Hashtable(20);
/*    */   
/*    */ 
/*    */   RTPSourceInfoCache main;
/*    */   
/*    */ 
/* 24 */   public void setMainCache(RTPSourceInfoCache main) { this.main = main; }
/*    */   
/*    */   public RTPSourceInfoCache getMainCache() {
/* 27 */     if (this.main == null) {
/* 28 */       this.main = new RTPSourceInfoCache();
/*    */     }
/* 30 */     return this.main;
/*    */   }
/*    */   
/* 33 */   public void setSSRCCache(SSRCCache ssrccache) { this.main.ssrccache = ssrccache; }
/*    */   
/*    */   public RTPSourceInfo get(String cname, boolean local)
/*    */   {
/* 37 */     RTPSourceInfo info = null;
/*    */     
/* 39 */     synchronized (this) {
/* 40 */       info = (RTPSourceInfo)this.cache.get(cname);
/* 41 */       if ((info == null) && (!local)) {
/* 42 */         info = new RTPRemoteSourceInfo(cname, this.main);
/* 43 */         this.cache.put(cname, info);
/*    */       }
/* 45 */       if ((info == null) && (local))
/*    */       {
/* 47 */         info = new RTPLocalSourceInfo(cname, this.main);
/* 48 */         this.cache.put(cname, info);
/*    */       }
/*    */     }
/*    */     
/* 52 */     return info;
/*    */   }
/*    */   
/* 55 */   public void remove(String cname) { this.cache.remove(cname); }
/*    */   
/*    */   public Hashtable getCacheTable() {
/* 58 */     return this.cache;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\RTPSourceInfoCache.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */