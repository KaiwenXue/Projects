package com.sun.media.rtp.util;

import java.io.IOException;

public abstract interface PacketSource
{
  public abstract Packet receiveFrom()
    throws IOException;
  
  public abstract void closeSource();
  
  public abstract String sourceString();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\util\PacketSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */