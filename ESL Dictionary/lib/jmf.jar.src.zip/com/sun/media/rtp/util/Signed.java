/*    */ package com.sun.media.rtp.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Signed
/*    */ {
/*    */   public static long UnsignedInt(int signed)
/*    */   {
/* 15 */     return 4294967296L + signed;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\util\Signed.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */