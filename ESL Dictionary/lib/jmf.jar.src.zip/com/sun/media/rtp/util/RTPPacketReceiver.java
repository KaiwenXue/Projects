/*     */ package com.sun.media.rtp.util;
/*     */ 
/*     */ import com.sun.media.CircularBuffer;
/*     */ import java.io.IOException;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.protocol.PushSourceStream;
/*     */ import javax.media.protocol.SourceTransferHandler;
/*     */ import javax.media.rtp.RTPPushDataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTPPacketReceiver
/*     */   implements PacketSource, SourceTransferHandler
/*     */ {
/*  20 */   RTPPushDataSource rtpsource = null;
/*  21 */   CircularBuffer bufQue = new CircularBuffer(2);
/*  22 */   boolean closed = false;
/*     */   
/*     */   public RTPPacketReceiver(RTPPushDataSource rtpsource) {
/*  25 */     this.rtpsource = rtpsource;
/*  26 */     PushSourceStream output = rtpsource.getOutputStream();
/*  27 */     output.setTransferHandler(this);
/*     */   }
/*     */   
/*     */   public RTPPacketReceiver(PushSourceStream pss) {
/*  31 */     pss.setTransferHandler(this);
/*     */   }
/*     */   
/*     */ 
/*     */   public void transferData(PushSourceStream sourcestream)
/*     */   {
/*     */     Buffer buf;
/*  38 */     synchronized (this.bufQue) {
/*  39 */       while ((!this.bufQue.canWrite()) && (!this.closed)) {
/*     */         try {
/*  41 */           this.bufQue.wait(1000L);
/*     */         }
/*     */         catch (InterruptedException e) {}
/*     */       }
/*  45 */       if (this.closed) {
/*  46 */         return;
/*     */       }
/*  48 */       buf = this.bufQue.getEmptyBuffer();
/*     */     }
/*     */     
/*  51 */     int size = sourcestream.getMinimumTransferSize();
/*     */     
/*  53 */     byte[] data = (byte[])buf.getData();
/*  54 */     int len = 0;
/*     */     
/*  56 */     if ((data == null) || (data.length < size)) {
/*  57 */       data = new byte[size];
/*  58 */       buf.setData(data);
/*     */     }
/*     */     try
/*     */     {
/*  62 */       len = sourcestream.read(data, 0, size);
/*     */     }
/*     */     catch (IOException ???) {}
/*     */     
/*  66 */     buf.setLength(len);
/*  67 */     buf.setOffset(0);
/*     */     
/*  69 */     synchronized (this.bufQue) {
/*  70 */       this.bufQue.writeReport();
/*  71 */       this.bufQue.notify();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*  76 */   boolean dataRead = false;
/*     */   
/*     */   public Packet receiveFrom()
/*     */     throws IOException
/*     */   {
/*     */     Buffer buf;
/*  82 */     synchronized (this.bufQue)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */       if (this.dataRead) {
/*  91 */         this.bufQue.readReport();
/*  92 */         this.bufQue.notify();
/*     */       }
/*     */       
/*  95 */       while ((!this.bufQue.canRead()) && (!this.closed)) {
/*     */         try {
/*  97 */           this.bufQue.wait(1000L);
/*     */         }
/*     */         catch (InterruptedException e) {}
/*     */       }
/* 101 */       if (this.closed) {
/* 102 */         buf = null;
/* 103 */         this.dataRead = false;
/*     */       } else {
/* 105 */         buf = this.bufQue.read();
/* 106 */         this.dataRead = true;
/*     */       }
/*     */     }
/*     */     
/*     */     byte[] data;
/*     */     
/* 112 */     if (buf != null) {
/* 113 */       data = (byte[])buf.getData();
/*     */     } else {
/* 115 */       data = new byte[1];
/*     */     }
/* 117 */     UDPPacket p = new UDPPacket();
/* 118 */     p.receiptTime = System.currentTimeMillis();
/* 119 */     p.data = data;
/* 120 */     p.offset = 0;
/* 121 */     p.length = (buf == null ? 0 : buf.getLength());
/*     */     
/* 123 */     return p;
/*     */   }
/*     */   
/*     */   public void closeSource() {
/* 127 */     synchronized (this.bufQue) {
/* 128 */       this.closed = true;
/* 129 */       this.bufQue.notifyAll();
/*     */     }
/*     */   }
/*     */   
/*     */   public String sourceString() {
/* 134 */     String s = "RTPPacketReceiver for " + this.rtpsource;
/* 135 */     return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\util\RTPPacketReceiver.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */