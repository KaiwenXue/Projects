/*    */ package com.sun.media.rtp.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.media.rtp.OutputDataStream;
/*    */ import javax.media.rtp.RTPConnector;
/*    */ import javax.media.rtp.RTPPushDataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTPPacketSender
/*    */   implements PacketConsumer
/*    */ {
/* 14 */   RTPPushDataSource dest = null;
/* 15 */   RTPConnector connector = null;
/* 16 */   OutputDataStream outstream = null;
/*    */   
/*    */   public RTPPacketSender(RTPPushDataSource dest) {
/* 19 */     this.dest = dest;
/* 20 */     this.outstream = dest.getInputStream();
/*    */   }
/*    */   
/*    */   public RTPPacketSender(RTPConnector connector) throws IOException {
/* 24 */     this.connector = connector;
/* 25 */     this.outstream = connector.getDataOutputStream();
/*    */   }
/*    */   
/*    */   public RTPPacketSender(OutputDataStream os) {
/* 29 */     this.outstream = os;
/*    */   }
/*    */   
/*    */   public void sendTo(Packet p) throws IOException {
/* 33 */     if (this.outstream == null) {
/* 34 */       throw new IOException();
/*    */     }
/* 36 */     this.outstream.write(p.data, 0, p.length);
/*    */   }
/*    */   
/*    */ 
/*    */   public void closeConsumer() {}
/*    */   
/*    */ 
/*    */   public RTPConnector getConnector()
/*    */   {
/* 45 */     return this.connector;
/*    */   }
/*    */   
/*    */   public String consumerString() {
/* 49 */     String s = "RTPPacketSender for " + this.dest;
/* 50 */     return s;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\util\RTPPacketSender.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */