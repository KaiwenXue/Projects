/*     */ package com.sun.media.rtp.util;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.InetAddress;
/*     */ import java.net.MulticastSocket;
/*     */ import java.net.SocketException;
/*     */ import java.net.UnknownHostException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UDPPacketReceiver
/*     */   implements PacketSource
/*     */ {
/*     */   private DatagramSocket sock;
/*     */   private int maxsize;
/*  26 */   private static JMFSecurity jmfSecurity = null;
/*  27 */   private static boolean securityPrivelege = false;
/*  28 */   private Method[] m = new Method[1];
/*  29 */   private Class[] cl = new Class[1];
/*  30 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   static {
/*     */     try {
/*  34 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  35 */       securityPrivelege = true;
/*     */     }
/*     */     catch (SecurityException e) {}
/*     */   }
/*     */   
/*     */   public DatagramSocket getSocket() {
/*  41 */     return this.sock;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UDPPacketReceiver(DatagramSocket sock, int maxsize)
/*     */   {
/*  54 */     this.sock = sock;
/*     */     
/*  56 */     this.maxsize = maxsize;
/*     */     try
/*     */     {
/*  59 */       sock.setSoTimeout(5000);
/*     */     } catch (SocketException e) {
/*  61 */       System.out.println("could not set timeout on socket");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UDPPacketReceiver(int localPort, String localAddress, int remotePort, String remoteAddress, int maxsize, DatagramSocket localSocket)
/*     */     throws SocketException, UnknownHostException, IOException
/*     */   {
/*  88 */     InetAddress localInetAddr = InetAddress.getByName(localAddress);
/*  89 */     InetAddress remoteInetAddr = InetAddress.getByName(remoteAddress);
/*     */     
/*     */ 
/*  92 */     if (remoteInetAddr.isMulticastAddress()) {
/*  93 */       MulticastSocket sock = new MulticastSocket(remotePort);
/*     */       
/*  95 */       if (jmfSecurity != null) {
/*     */         try {
/*  97 */           if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  98 */             jmfSecurity.requestPermission(this.m, this.cl, this.args, 512);
/*  99 */             this.m[0].invoke(this.cl[0], this.args[0]);
/* 100 */           } else if (jmfSecurity.getName().startsWith("internet")) {
/* 101 */             PolicyEngine.checkPermission(PermissionID.NETIO);
/* 102 */             PolicyEngine.assertPermission(PermissionID.NETIO);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         catch (Throwable e)
/*     */         {
/* 109 */           jmfSecurity.permissionFailureNotification(512);
/*     */         }
/*     */       }
/*     */       
/* 113 */       sock.joinGroup(remoteInetAddr);
/*     */       
/* 115 */       this.sock = sock;
/* 116 */       this.maxsize = maxsize;
/*     */     } else {
/* 118 */       if (localSocket != null) {
/* 119 */         this.sock = localSocket;
/*     */       } else {
/* 121 */         this.sock = new DatagramSocket(localPort, localInetAddr);
/*     */       }
/*     */       
/*     */ 
/* 125 */       if (remoteAddress != null) {}
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 140 */       this.maxsize = maxsize;
/*     */     }
/* 142 */     try { this.sock.setSoTimeout(5000);
/*     */     } catch (SocketException e) {
/* 144 */       System.out.println("could not set timeout on socket");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 149 */   byte[] dataBuf = new byte[1];
/*     */   
/*     */ 
/*     */ 
/*     */   public Packet receiveFrom()
/*     */     throws IOException
/*     */   {
/*     */     DatagramPacket dp;
/*     */     
/*     */ 
/*     */     int len;
/*     */     
/*     */     do
/*     */     {
/* 163 */       if (this.dataBuf.length < this.maxsize) {
/* 164 */         this.dataBuf = new byte[this.maxsize];
/*     */       }
/* 166 */       dp = new DatagramPacket(this.dataBuf, this.maxsize);
/*     */       
/* 168 */       this.sock.receive(dp);
/* 169 */       len = dp.getLength();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 174 */       if (len > this.maxsize >> 1) {
/* 175 */         this.maxsize = (len << 1);
/*     */       }
/* 177 */     } while (len >= dp.getData().length);
/*     */     
/* 179 */     UDPPacket p = new UDPPacket();
/* 180 */     p.receiptTime = System.currentTimeMillis();
/* 181 */     p.data = dp.getData();
/* 182 */     p.offset = 0;
/* 183 */     p.length = len;
/* 184 */     p.datagrampacket = dp;
/* 185 */     p.localPort = this.sock.getLocalPort();
/* 186 */     p.remotePort = dp.getPort();
/* 187 */     p.remoteAddress = dp.getAddress();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 192 */     return p;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void closeSource()
/*     */   {
/* 201 */     if (this.sock != null) {
/* 202 */       this.sock.close();
/* 203 */       this.sock = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String sourceString()
/*     */   {
/* 212 */     String s = "UDP Datagram Packet Receiver on port " + this.sock.getLocalPort() + "on local address " + this.sock.getLocalAddress();
/*     */     
/* 214 */     return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\util\UDPPacketReceiver.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */