/*    */ package com.sun.media.rtp.util;
/*    */ 
/*    */ import java.net.DatagramPacket;
/*    */ import java.net.InetAddress;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ public class UDPPacket
/*    */   extends Packet
/*    */ {
/*    */   public DatagramPacket datagrampacket;
/*    */   public int localPort;
/*    */   public int remotePort;
/*    */   public InetAddress remoteAddress;
/*    */   
/*    */   public String toString()
/*    */   {
/* 18 */     String s = "UDP Packet of size " + this.length;
/* 19 */     if (this.received) {
/* 20 */       s = s + " received at " + new Date(this.receiptTime) + " on port " + this.localPort + " from " + this.remoteAddress + " port " + this.remotePort;
/*    */     }
/*    */     
/* 23 */     return s;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\util\UDPPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */