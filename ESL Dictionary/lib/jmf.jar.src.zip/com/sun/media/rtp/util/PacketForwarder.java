/*     */ package com.sun.media.rtp.util;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import com.sun.media.util.MediaThread;
/*     */ import com.sun.media.util.jdk12;
/*     */ import com.sun.media.util.jdk12CreateThreadRunnableAction;
/*     */ import com.sun.media.util.jdk12PriorityAction;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PacketForwarder
/*     */   implements Runnable
/*     */ {
/*  37 */   PacketSource source = null;
/*  38 */   PacketConsumer consumer = null;
/*     */   RTPMediaThread thread;
/*  40 */   boolean closed = false;
/*     */   
/*     */ 
/*     */   private boolean paused;
/*     */   
/*     */ 
/*  46 */   public IOException exception = null;
/*     */   
/*     */ 
/*  49 */   private static JMFSecurity jmfSecurity = null;
/*  50 */   private static boolean securityPrivelege = false;
/*  51 */   private Method[] m = new Method[1];
/*  52 */   private Class[] cl = new Class[1];
/*  53 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   static {
/*     */     try {
/*  57 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  58 */       securityPrivelege = true;
/*     */     }
/*     */     catch (SecurityException e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PacketForwarder(PacketSource s, PacketConsumer c)
/*     */   {
/*  77 */     this.source = s;
/*  78 */     this.consumer = c;
/*  79 */     this.closed = false;
/*  80 */     this.exception = null;
/*     */   }
/*     */   
/*     */ 
/*  84 */   public void startPF() { startPF(null); }
/*     */   
/*     */   public void startPF(String threadname) {
/*  87 */     if (this.thread != null) {
/*  88 */       throw new IllegalArgumentException("Called start more than once");
/*     */     }
/*  90 */     if (jmfSecurity != null) {
/*  91 */       String permission = null;
/*     */       try {
/*  93 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  94 */           permission = "thread";
/*  95 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*  96 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */           
/*  98 */           permission = "thread group";
/*  99 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/* 100 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */         }
/* 102 */         else if (jmfSecurity.getName().startsWith("internet")) {
/* 103 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/* 104 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/* 111 */         if (permission.endsWith("group")) {
/* 112 */           jmfSecurity.permissionFailureNotification(32);
/*     */         } else {
/* 114 */           jmfSecurity.permissionFailureNotification(16);
/*     */         }
/*     */       }
/*     */     }
/* 118 */     if (threadname == null) {
/* 119 */       threadname = "RTPMediaThread";
/*     */     }
/* 121 */     if ((jmfSecurity != null) && (jmfSecurity.getName().startsWith("jdk12"))) {
/*     */       try {
/* 123 */         Constructor cons = jdk12CreateThreadRunnableAction.cons;
/*     */         
/* 125 */         this.thread = ((RTPMediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { RTPMediaThread.class, this }) }));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */         this.thread.setName(threadname);
/*     */         
/* 136 */         cons = jdk12PriorityAction.cons;
/* 137 */         jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { this.thread, new Integer(MediaThread.getNetworkPriority()) }) });
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (Exception e) {}
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 148 */       this.thread = new RTPMediaThread(this, threadname);
/* 149 */       this.thread.useNetworkPriority();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 154 */     this.thread.setDaemon(true);
/* 155 */     this.thread.start();
/*     */   }
/*     */   
/* 158 */   public void setVideoPriority() { this.thread.useVideoNetworkPriority(); }
/*     */   
/*     */ 
/*     */ 
/*     */   public PacketSource getSource()
/*     */   {
/* 164 */     return this.source;
/*     */   }
/*     */   
/* 167 */   public PacketConsumer getConsumer() { return this.consumer; }
/*     */   
/*     */   public String getId()
/*     */   {
/* 171 */     if (this.thread == null) {
/* 172 */       System.err.println("the packetforwarders thread is null");
/* 173 */       return null;
/*     */     }
/* 175 */     return this.thread.getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean checkForClose()
/*     */   {
/* 245 */     if ((this.closed) && (this.thread != null)) {
/* 246 */       if (this.source != null)
/* 247 */         this.source.closeSource();
/* 248 */       return true;
/*     */     }
/* 250 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 260 */     this.closed = true;
/* 261 */     if (this.consumer != null) {
/* 262 */       this.consumer.closeConsumer();
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void run()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 9	com/sun/media/rtp/util/PacketForwarder:closed	Z
/*     */     //   4: ifne +10 -> 14
/*     */     //   7: aload_0
/*     */     //   8: getfield 10	com/sun/media/rtp/util/PacketForwarder:exception	Ljava/io/IOException;
/*     */     //   11: ifnull +20 -> 31
/*     */     //   14: aload_0
/*     */     //   15: getfield 7	com/sun/media/rtp/util/PacketForwarder:source	Lcom/sun/media/rtp/util/PacketSource;
/*     */     //   18: ifnull +12 -> 30
/*     */     //   21: aload_0
/*     */     //   22: getfield 7	com/sun/media/rtp/util/PacketForwarder:source	Lcom/sun/media/rtp/util/PacketSource;
/*     */     //   25: invokeinterface 64 1 0
/*     */     //   30: return
/*     */     //   31: getstatic 22	com/sun/media/rtp/util/PacketForwarder:jmfSecurity	Lcom/sun/media/JMFSecurity;
/*     */     //   34: ifnull +110 -> 144
/*     */     //   37: getstatic 22	com/sun/media/rtp/util/PacketForwarder:jmfSecurity	Lcom/sun/media/JMFSecurity;
/*     */     //   40: invokeinterface 23 1 0
/*     */     //   45: ldc 24
/*     */     //   47: invokevirtual 25	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*     */     //   50: ifeq +51 -> 101
/*     */     //   53: getstatic 22	com/sun/media/rtp/util/PacketForwarder:jmfSecurity	Lcom/sun/media/JMFSecurity;
/*     */     //   56: aload_0
/*     */     //   57: getfield 12	com/sun/media/rtp/util/PacketForwarder:m	[Ljava/lang/reflect/Method;
/*     */     //   60: aload_0
/*     */     //   61: getfield 14	com/sun/media/rtp/util/PacketForwarder:cl	[Ljava/lang/Class;
/*     */     //   64: aload_0
/*     */     //   65: getfield 16	com/sun/media/rtp/util/PacketForwarder:args	[[Ljava/lang/Object;
/*     */     //   68: sipush 128
/*     */     //   71: invokeinterface 27 5 0
/*     */     //   76: aload_0
/*     */     //   77: getfield 12	com/sun/media/rtp/util/PacketForwarder:m	[Ljava/lang/reflect/Method;
/*     */     //   80: iconst_0
/*     */     //   81: aaload
/*     */     //   82: aload_0
/*     */     //   83: getfield 14	com/sun/media/rtp/util/PacketForwarder:cl	[Ljava/lang/Class;
/*     */     //   86: iconst_0
/*     */     //   87: aaload
/*     */     //   88: aload_0
/*     */     //   89: getfield 16	com/sun/media/rtp/util/PacketForwarder:args	[[Ljava/lang/Object;
/*     */     //   92: iconst_0
/*     */     //   93: aaload
/*     */     //   94: invokevirtual 28	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   97: pop
/*     */     //   98: goto +31 -> 129
/*     */     //   101: getstatic 22	com/sun/media/rtp/util/PacketForwarder:jmfSecurity	Lcom/sun/media/JMFSecurity;
/*     */     //   104: invokeinterface 23 1 0
/*     */     //   109: ldc 30
/*     */     //   111: invokevirtual 25	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*     */     //   114: ifeq +15 -> 129
/*     */     //   117: getstatic 65	com/ms/security/PermissionID:NETIO	Lcom/ms/security/PermissionID;
/*     */     //   120: invokestatic 32	com/ms/security/PolicyEngine:checkPermission	(Lcom/ms/security/PermissionID;)V
/*     */     //   123: getstatic 65	com/ms/security/PermissionID:NETIO	Lcom/ms/security/PermissionID;
/*     */     //   126: invokestatic 33	com/ms/security/PolicyEngine:assertPermission	(Lcom/ms/security/PermissionID;)V
/*     */     //   129: goto +15 -> 144
/*     */     //   132: astore_1
/*     */     //   133: getstatic 22	com/sun/media/rtp/util/PacketForwarder:jmfSecurity	Lcom/sun/media/JMFSecurity;
/*     */     //   136: sipush 128
/*     */     //   139: invokeinterface 37 2 0
/*     */     //   144: goto +6 -> 150
/*     */     //   147: goto +3 -> 150
/*     */     //   150: aload_0
/*     */     //   151: getfield 7	com/sun/media/rtp/util/PacketForwarder:source	Lcom/sun/media/rtp/util/PacketSource;
/*     */     //   154: invokeinterface 66 1 0
/*     */     //   159: astore_1
/*     */     //   160: aload_0
/*     */     //   161: invokespecial 67	com/sun/media/rtp/util/PacketForwarder:checkForClose	()Z
/*     */     //   164: ifeq +7 -> 171
/*     */     //   167: jsr +76 -> 243
/*     */     //   170: return
/*     */     //   171: aload_1
/*     */     //   172: ifnull +13 -> 185
/*     */     //   175: aload_0
/*     */     //   176: getfield 8	com/sun/media/rtp/util/PacketForwarder:consumer	Lcom/sun/media/rtp/util/PacketConsumer;
/*     */     //   179: aload_1
/*     */     //   180: invokeinterface 68 2 0
/*     */     //   185: aload_0
/*     */     //   186: invokespecial 67	com/sun/media/rtp/util/PacketForwarder:checkForClose	()Z
/*     */     //   189: ifeq +7 -> 196
/*     */     //   192: jsr +51 -> 243
/*     */     //   195: return
/*     */     //   196: goto +15 -> 211
/*     */     //   199: astore_1
/*     */     //   200: aload_0
/*     */     //   201: invokespecial 67	com/sun/media/rtp/util/PacketForwarder:checkForClose	()Z
/*     */     //   204: ifeq +7 -> 211
/*     */     //   207: jsr +36 -> 243
/*     */     //   210: return
/*     */     //   211: goto -61 -> 150
/*     */     //   214: astore_1
/*     */     //   215: aload_0
/*     */     //   216: invokespecial 67	com/sun/media/rtp/util/PacketForwarder:checkForClose	()Z
/*     */     //   219: ifeq +7 -> 226
/*     */     //   222: jsr +21 -> 243
/*     */     //   225: return
/*     */     //   226: aload_0
/*     */     //   227: aload_1
/*     */     //   228: putfield 10	com/sun/media/rtp/util/PacketForwarder:exception	Ljava/io/IOException;
/*     */     //   231: jsr +12 -> 243
/*     */     //   234: goto +21 -> 255
/*     */     //   237: astore_2
/*     */     //   238: jsr +5 -> 243
/*     */     //   241: aload_2
/*     */     //   242: athrow
/*     */     //   243: astore_3
/*     */     //   244: aload_0
/*     */     //   245: getfield 8	com/sun/media/rtp/util/PacketForwarder:consumer	Lcom/sun/media/rtp/util/PacketConsumer;
/*     */     //   248: invokeinterface 71 1 0
/*     */     //   253: ret 3
/*     */     //   255: return
/*     */     // Line number table:
/*     */     //   Java source line #184	-> byte code offset #0
/*     */     //   Java source line #185	-> byte code offset #14
/*     */     //   Java source line #186	-> byte code offset #21
/*     */     //   Java source line #187	-> byte code offset #30
/*     */     //   Java source line #190	-> byte code offset #31
/*     */     //   Java source line #192	-> byte code offset #37
/*     */     //   Java source line #193	-> byte code offset #53
/*     */     //   Java source line #194	-> byte code offset #76
/*     */     //   Java source line #195	-> byte code offset #101
/*     */     //   Java source line #196	-> byte code offset #117
/*     */     //   Java source line #197	-> byte code offset #123
/*     */     //   Java source line #200	-> byte code offset #132
/*     */     //   Java source line #204	-> byte code offset #133
/*     */     //   Java source line #215	-> byte code offset #144
/*     */     //   Java source line #216	-> byte code offset #147
/*     */     //   Java source line #218	-> byte code offset #150
/*     */     //   Java source line #219	-> byte code offset #160
/*     */     //   Java source line #220	-> byte code offset #167
/*     */     //   Java source line #221	-> byte code offset #171
/*     */     //   Java source line #222	-> byte code offset #175
/*     */     //   Java source line #223	-> byte code offset #185
/*     */     //   Java source line #224	-> byte code offset #192
/*     */     //   Java source line #227	-> byte code offset #199
/*     */     //   Java source line #228	-> byte code offset #207
/*     */     //   Java source line #216	-> byte code offset #211
/*     */     //   Java source line #234	-> byte code offset #214
/*     */     //   Java source line #235	-> byte code offset #222
/*     */     //   Java source line #236	-> byte code offset #226
/*     */     //   Java source line #240	-> byte code offset #237
/*     */     //   Java source line #242	-> byte code offset #255
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	256	0	this	PacketForwarder
/*     */     //   132	2	1	e	Throwable
/*     */     //   159	21	1	p	Packet
/*     */     //   199	2	1	e	java.io.InterruptedIOException
/*     */     //   214	14	1	e	IOException
/*     */     //   237	5	2	localObject1	Object
/*     */     //   243	1	3	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   37	129	132	java/lang/Throwable
/*     */     //   150	196	199	java/io/InterruptedIOException
/*     */     //   144	214	214	java/io/IOException
/*     */     //   144	237	237	finally
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\util\PacketForwarder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */