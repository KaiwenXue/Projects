/*     */ package com.sun.media.rtp.util;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSRCTable
/*     */ {
/*     */   static final int INCR = 16;
/*  21 */   int[] ssrcList = new int[16];
/*  22 */   Object[] objList = new Object[16];
/*  23 */   int total = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void put(int ssrc, Object obj)
/*     */   {
/*  29 */     if (this.total == 0)
/*     */     {
/*  31 */       this.ssrcList[0] = ssrc;
/*  32 */       this.objList[0] = obj;
/*  33 */       this.total = 1;
/*  34 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  40 */     for (int i = 0; i < this.total; i++) {
/*  41 */       if (this.ssrcList[i] >= ssrc)
/*     */       {
/*  43 */         if (this.ssrcList[i] != ssrc)
/*     */           break;
/*  45 */         this.objList[i] = obj;
/*  46 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  53 */     if (this.total == this.ssrcList.length)
/*     */     {
/*  55 */       int[] sl = new int[this.ssrcList.length + 16];
/*  56 */       Object[] ol = new Object[this.objList.length + 16];
/*     */       
/*  58 */       if (i > 0) {
/*  59 */         System.arraycopy(this.ssrcList, 0, sl, 0, this.total);
/*  60 */         System.arraycopy(this.objList, 0, ol, 0, this.total);
/*     */       }
/*     */       
/*  63 */       this.ssrcList = sl;
/*  64 */       this.objList = ol;
/*     */     }
/*     */     
/*     */ 
/*  68 */     for (int x = this.total - 1; x >= i; x--) {
/*  69 */       this.ssrcList[(x + 1)] = this.ssrcList[x];
/*  70 */       this.objList[(x + 1)] = this.objList[x];
/*     */     }
/*     */     
/*  73 */     this.ssrcList[i] = ssrc;
/*  74 */     this.objList[i] = obj;
/*  75 */     this.total += 1;
/*     */   }
/*     */   
/*     */   private int indexOf(int ssrc)
/*     */   {
/*  80 */     if (this.total <= 3)
/*     */     {
/*  82 */       if ((this.total > 0) && (this.ssrcList[0] == ssrc))
/*  83 */         return 0;
/*  84 */       if ((this.total > 1) && (this.ssrcList[1] == ssrc))
/*  85 */         return 1;
/*  86 */       if ((this.total > 2) && (this.ssrcList[2] == ssrc))
/*  87 */         return 2;
/*  88 */       return -1;
/*     */     }
/*     */     
/*     */ 
/*  92 */     if (this.ssrcList[0] == ssrc) {
/*  93 */       return 0;
/*     */     }
/*     */     
/*  96 */     if (this.ssrcList[(this.total - 1)] == ssrc) {
/*  97 */       return this.total - 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 102 */     int i = 0;
/* 103 */     int j = this.total - 1;
/*     */     
/*     */ 
/*     */     do
/*     */     {
/* 108 */       int x = (j - i) / 2 + i;
/*     */       
/* 110 */       if (this.ssrcList[x] == ssrc)
/* 111 */         return x;
/* 112 */       if (ssrc > this.ssrcList[x]) {
/* 113 */         i = x + 1;
/* 114 */       } else if (ssrc < this.ssrcList[x]) {
/* 115 */         j = x;
/*     */       }
/* 117 */     } while (i < j);
/*     */     
/* 119 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized Object remove(int ssrc)
/*     */   {
/*     */     int i;
/* 126 */     if ((i = indexOf(ssrc)) < 0) {
/* 127 */       return null;
/*     */     }
/* 129 */     Object res = this.objList[i];
/* 133 */     for (; 
/*     */         
/*     */ 
/* 133 */         i < this.total - 1; i++) {
/* 134 */       this.ssrcList[i] = this.ssrcList[(i + 1)];
/* 135 */       this.objList[i] = this.objList[(i + 1)];
/*     */     }
/*     */     
/* 138 */     this.ssrcList[(this.total - 1)] = 0;
/* 139 */     this.objList[(this.total - 1)] = null;
/* 140 */     this.total -= 1;
/*     */     
/* 142 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void removeObj(Object obj)
/*     */   {
/* 148 */     if (obj == null) {
/* 149 */       return;
/*     */     }
/*     */     
/*     */ 
/* 153 */     for (int i = 0; i < this.total; i++) {
/* 154 */       if (this.objList[i] == obj) {
/*     */         break;
/*     */       }
/*     */     }
/* 158 */     if (i >= this.total) {
/* 159 */       return;
/*     */     }
/* 163 */     for (; 
/*     */         
/* 163 */         i < this.total - 1; i++) {
/* 164 */       this.ssrcList[i] = this.ssrcList[(i + 1)];
/* 165 */       this.objList[i] = this.objList[(i + 1)];
/*     */     }
/*     */     
/* 168 */     this.ssrcList[(this.total - 1)] = 0;
/* 169 */     this.objList[(this.total - 1)] = null;
/* 170 */     this.total -= 1;
/*     */   }
/*     */   
/*     */   public synchronized void removeAll()
/*     */   {
/* 175 */     for (int i = 0; i < this.total; i++) {
/* 176 */       this.ssrcList[i] = 0;
/* 177 */       this.objList[i] = null;
/*     */     }
/* 179 */     this.total = 0;
/*     */   }
/*     */   
/*     */   public int size()
/*     */   {
/* 184 */     return this.total;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized Object get(int ssrc)
/*     */   {
/*     */     int i;
/* 191 */     if ((i = indexOf(ssrc)) < 0) {
/* 192 */       return null;
/*     */     }
/* 194 */     return this.objList[i];
/*     */   }
/*     */   
/*     */   public synchronized int getSSRC(Object obj)
/*     */   {
/* 199 */     for (int i = 0; i < this.total; i++) {
/* 200 */       if (this.objList[i] == obj) {
/* 201 */         return this.ssrcList[i];
/*     */       }
/*     */     }
/* 204 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean isEmpty()
/*     */   {
/* 209 */     return this.total == 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Enumeration elements()
/*     */   {
/* 217 */     new Enumeration() {
/* 218 */       int next = 0;
/*     */       
/*     */       public boolean hasMoreElements() {
/* 221 */         return this.next < SSRCTable.this.total;
/*     */       }
/*     */       
/*     */       public Object nextElement() {
/* 225 */         synchronized (SSRCTable.this) {
/* 226 */           if (this.next < SSRCTable.this.total) {
/* 227 */             Object localObject1 = SSRCTable.this.objList[(this.next++)];return localObject1;
/*     */           } }
/* 229 */         throw new NoSuchElementException("SSRCTable Enumeration");
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\util\SSRCTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */