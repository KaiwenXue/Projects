package com.sun.media.rtp.util;

public abstract interface RTPTimeReporter
{
  public abstract long getRTPTime();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\util\RTPTimeReporter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */