/*    */ package com.sun.media.rtp.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BadFormatException
/*    */   extends Exception
/*    */ {
/*    */   public BadFormatException() {}
/*    */   
/*    */ 
/*    */   public BadFormatException(String m)
/*    */   {
/* 13 */     super(m);
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\util\BadFormatException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */