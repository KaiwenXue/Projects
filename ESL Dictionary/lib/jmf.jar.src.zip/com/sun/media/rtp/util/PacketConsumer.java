package com.sun.media.rtp.util;

import java.io.IOException;

public abstract interface PacketConsumer
{
  public abstract void sendTo(Packet paramPacket)
    throws IOException;
  
  public abstract void closeConsumer();
  
  public abstract String consumerString();
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\util\PacketConsumer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */