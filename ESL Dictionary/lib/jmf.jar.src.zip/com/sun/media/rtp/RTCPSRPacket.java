/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTCPSRPacket
/*    */   extends RTCPPacket
/*    */ {
/*    */   int ssrc;
/*    */   long ntptimestampmsw;
/*    */   long ntptimestamplsw;
/*    */   long rtptimestamp;
/*    */   long packetcount;
/*    */   long octetcount;
/*    */   RTCPReportBlock[] reports;
/*    */   
/*    */   RTCPSRPacket(RTCPPacket parent)
/*    */   {
/* 35 */     super(parent);
/* 36 */     this.type = 200;
/*    */   }
/*    */   
/*    */   RTCPSRPacket(int ssrc, RTCPReportBlock[] reports) {
/* 40 */     this.ssrc = ssrc;
/* 41 */     this.reports = reports;
/* 42 */     if (reports.length > 31)
/* 43 */       throw new IllegalArgumentException("Too many reports");
/*    */   }
/*    */   
/* 46 */   public String toString() { return "\tRTCP SR (sender report) packet for sync source " + this.ssrc + "\n\t\tNTP timestampMSW: " + this.ntptimestampmsw + "\n\t\tNTP timestampLSW: " + this.ntptimestamplsw + "\n\t\tRTP timestamp: " + this.rtptimestamp + "\n\t\tnumber of packets sent: " + this.packetcount + "\n\t\tnumber of octets (bytes) sent: " + this.octetcount + "\n" + RTCPReportBlock.toString(this.reports); }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int calcLength()
/*    */   {
/* 56 */     return 28 + this.reports.length * 24;
/*    */   }
/*    */   
/*    */   void assemble(DataOutputStream out) throws IOException {
/* 60 */     out.writeByte(128 + this.reports.length);
/* 61 */     out.writeByte(200);
/* 62 */     out.writeShort(6 + this.reports.length * 6);
/* 63 */     out.writeInt(this.ssrc);
/* 64 */     out.writeInt((int)this.ntptimestampmsw);
/* 65 */     out.writeInt((int)this.ntptimestamplsw);
/*    */     
/* 67 */     out.writeInt((int)this.rtptimestamp);
/* 68 */     out.writeInt((int)this.packetcount);
/* 69 */     out.writeInt((int)this.octetcount);
/* 70 */     for (int i = 0; i < this.reports.length; i++) {
/* 71 */       out.writeInt(this.reports[i].ssrc);
/* 72 */       out.writeInt((this.reports[i].packetslost & 0xFFFFFF) + (this.reports[i].fractionlost << 24));
/*    */       
/* 74 */       out.writeInt((int)this.reports[i].lastseq);
/* 75 */       out.writeInt(this.reports[i].jitter);
/* 76 */       out.writeInt((int)this.reports[i].lsr);
/* 77 */       out.writeInt((int)this.reports[i].dlsr);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\RTCPSRPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */