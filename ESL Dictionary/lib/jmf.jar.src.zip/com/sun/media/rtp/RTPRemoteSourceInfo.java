/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import javax.media.rtp.RemoteParticipant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTPRemoteSourceInfo
/*    */   extends RTPSourceInfo
/*    */   implements RemoteParticipant
/*    */ {
/*    */   public RTPRemoteSourceInfo(String cname, RTPSourceInfoCache sic)
/*    */   {
/* 15 */     super(cname, sic);
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\RTPRemoteSourceInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */