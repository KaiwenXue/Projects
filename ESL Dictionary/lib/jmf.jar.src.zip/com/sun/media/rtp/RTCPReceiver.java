/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import com.sun.media.rtp.util.Packet;
/*     */ import com.sun.media.rtp.util.PacketConsumer;
/*     */ import com.sun.media.rtp.util.PacketForwarder;
/*     */ import com.sun.media.rtp.util.PacketSource;
/*     */ import com.sun.media.rtp.util.SSRCTable;
/*     */ import com.sun.media.rtp.util.UDPPacket;
/*     */ import java.io.IOException;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import javax.media.rtp.ReceiveStream;
/*     */ import javax.media.rtp.event.ActiveReceiveStreamEvent;
/*     */ import javax.media.rtp.event.ApplicationEvent;
/*     */ import javax.media.rtp.event.ByeEvent;
/*     */ import javax.media.rtp.event.NewParticipantEvent;
/*     */ import javax.media.rtp.event.ReceiverReportEvent;
/*     */ import javax.media.rtp.event.SenderReportEvent;
/*     */ import javax.media.rtp.event.StreamMappedEvent;
/*     */ import javax.media.rtp.rtcp.ReceiverReport;
/*     */ import javax.media.rtp.rtcp.SenderReport;
/*     */ 
/*     */ public class RTCPReceiver implements PacketConsumer
/*     */ {
/*     */   private static final int SR = 1;
/*     */   private static final int RR = 2;
/*  28 */   private boolean rtcpstarted = false;
/*  29 */   private boolean sentrecvstrmap = false;
/*     */   
/*     */ 
/*     */   SSRCCache cache;
/*     */   
/*  34 */   private int type = 0;
/*     */   
/*     */   public RTCPReceiver(SSRCCache cache) {
/*  37 */     this.cache = cache;
/*  38 */     SSRCInfo info = cache.lookup(cache.ourssrc.ssrc);
/*     */   }
/*     */   
/*     */   public RTCPReceiver(SSRCCache cache, PacketSource source) {
/*  42 */     this(cache);
/*     */     
/*  44 */     PacketForwarder f = new PacketForwarder(source, this);
/*  45 */     f.startPF();
/*     */   }
/*     */   
/*     */   public RTCPReceiver(SSRCCache cache, DatagramSocket sock, StreamSynch streamSynch) {
/*  49 */     this(cache, new RTCPRawReceiver(sock, cache.sm.defaultstats, streamSynch));
/*     */   }
/*     */   
/*     */   public RTCPReceiver(SSRCCache cache, int port, String address, StreamSynch streamSynch) throws UnknownHostException, IOException
/*     */   {
/*  54 */     this(cache, new RTCPRawReceiver(port | 0x1, address, cache.sm.defaultstats, streamSynch));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String consumerString()
/*     */   {
/*  61 */     return "RTCP Packet Receiver/Collector";
/*     */   }
/*     */   
/*     */   public void closeConsumer() {}
/*     */   
/*     */   public void sendTo(Packet p)
/*     */   {
/*  68 */     sendTo((RTCPPacket)p);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void sendTo(RTCPPacket p)
/*     */   {
/*  75 */     SSRCInfo info = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */     boolean unicast = this.cache.sm.isUnicast();
/*  82 */     if (unicast)
/*     */     {
/*     */ 
/*  85 */       if (!this.rtcpstarted)
/*     */       {
/*  87 */         this.cache.sm.startRTCPReports(((UDPPacket)p.base).remoteAddress);
/*  88 */         this.rtcpstarted = true;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */         byte[] lsb = this.cache.sm.controladdress.getAddress();
/*  97 */         int address = lsb[3] & 0xFF;
/*  98 */         if ((address & 0xFF) == 255) {
/*  99 */           this.cache.sm.addUnicastAddr(this.cache.sm.controladdress);
/*     */         }
/*     */         else {
/* 102 */           InetAddress localaddr = null;
/* 103 */           boolean localfound = true;
/*     */           try {
/* 105 */             localaddr = InetAddress.getLocalHost();
/*     */           } catch (UnknownHostException e) {
/* 107 */             localfound = false;
/*     */           }
/* 109 */           if (localfound) {
/* 110 */             this.cache.sm.addUnicastAddr(localaddr);
/*     */           }
/*     */         }
/*     */       }
/* 114 */       else if (!this.cache.sm.isSenderDefaultAddr(((UDPPacket)p.base).remoteAddress)) {
/* 115 */         this.cache.sm.addUnicastAddr(((UDPPacket)p.base).remoteAddress);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 120 */     switch (p.type)
/*     */     {
/*     */ 
/*     */     case -1: 
/* 124 */       RTCPCompoundPacket cp = (RTCPCompoundPacket)p;
/*     */       
/* 126 */       this.cache.updateavgrtcpsize(cp.length);
/*     */       
/*     */ 
/*     */ 
/* 130 */       for (int i = 0; i < cp.packets.length; i++) {
/* 131 */         sendTo(cp.packets[i]);
/*     */       }
/*     */       
/* 134 */       if (this.cache.sm.cleaner != null) {
/* 135 */         this.cache.sm.cleaner.setClean();
/*     */       }
/*     */       
/*     */       break;
/*     */     case 200: 
/* 140 */       RTCPSRPacket srp = (RTCPSRPacket)p;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */       this.type = 1;
/*     */       
/*     */ 
/*     */ 
/* 150 */       if ((p.base instanceof UDPPacket)) {
/* 151 */         info = this.cache.get(srp.ssrc, ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort, 1);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 156 */         info = this.cache.get(srp.ssrc, null, 0, 1);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 165 */       if (info != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 170 */         info.setAlive(true);
/* 171 */         info.lastSRntptimestamp = ((srp.ntptimestampmsw << 32) + srp.ntptimestamplsw);
/*     */         
/* 173 */         info.lastSRrtptimestamp = srp.rtptimestamp;
/* 174 */         info.lastSRreceiptTime = srp.receiptTime;
/* 175 */         info.lastRTCPreceiptTime = srp.receiptTime;
/* 176 */         info.lastHeardFrom = srp.receiptTime;
/* 177 */         if (info.quiet) {
/* 178 */           info.quiet = false;
/* 179 */           ActiveReceiveStreamEvent event = null;
/* 180 */           if ((info instanceof ReceiveStream)) {
/* 181 */             event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info);
/*     */           }
/*     */           else
/*     */           {
/* 185 */             event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, null);
/*     */           }
/*     */           
/* 188 */           this.cache.eventhandler.postEvent(event);
/*     */         }
/* 190 */         info.lastSRpacketcount = srp.packetcount;
/* 191 */         info.lastSRoctetcount = srp.octetcount;
/*     */         
/* 193 */         for (int i = 0; i < srp.reports.length; i++) {
/* 194 */           srp.reports[i].receiptTime = srp.receiptTime;
/*     */           
/* 196 */           int rbssrc = srp.reports[i].ssrc;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 208 */           RTCPReportBlock[] reporta = (RTCPReportBlock[])info.reports.get(rbssrc);
/*     */           
/* 210 */           if (reporta == null) {
/* 211 */             reporta = new RTCPReportBlock[2];
/* 212 */             reporta[0] = srp.reports[i];
/* 213 */             info.reports.put(rbssrc, reporta);
/*     */           }
/*     */           else {
/* 216 */             reporta[1] = reporta[0];
/* 217 */             reporta[0] = srp.reports[i];
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 222 */         if (info.probation <= 0) {
/* 223 */           if ((!info.newpartsent) && (info.sourceInfo != null)) {
/* 224 */             NewParticipantEvent evtsdes = new NewParticipantEvent(this.cache.sm, info.sourceInfo);
/*     */             
/*     */ 
/* 227 */             this.cache.eventhandler.postEvent(evtsdes);
/* 228 */             info.newpartsent = true;
/*     */           }
/*     */           
/* 231 */           if ((!info.recvstrmap) && (info.sourceInfo != null)) {
/* 232 */             info.recvstrmap = true;
/* 233 */             StreamMappedEvent evt = new StreamMappedEvent(this.cache.sm, (ReceiveStream)info, info.sourceInfo);
/*     */             
/*     */ 
/*     */ 
/* 237 */             this.cache.eventhandler.postEvent(evt);
/*     */           }
/*     */           
/* 240 */           SenderReportEvent evtsr = new SenderReportEvent(this.cache.sm, (SenderReport)info);
/*     */           
/* 242 */           this.cache.eventhandler.postEvent(evtsr);
/*     */         }
/*     */       }
/*     */       break;
/* 246 */     case 201:  RTCPRRPacket rrp = (RTCPRRPacket)p;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 252 */       this.type = 2;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 257 */       if ((p.base instanceof UDPPacket)) {
/* 258 */         info = this.cache.get(rrp.ssrc, ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort, 2);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 263 */         info = this.cache.get(rrp.ssrc, null, 0, 2);
/*     */       }
/*     */       
/*     */ 
/* 267 */       if (info != null)
/*     */       {
/*     */ 
/*     */ 
/* 271 */         info.setAlive(true);
/* 272 */         info.lastRTCPreceiptTime = rrp.receiptTime;
/* 273 */         info.lastHeardFrom = rrp.receiptTime;
/* 274 */         if (info.quiet) {
/* 275 */           info.quiet = false;
/* 276 */           ActiveReceiveStreamEvent event = null;
/* 277 */           if ((info instanceof ReceiveStream)) {
/* 278 */             event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 283 */             event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, null);
/*     */           }
/*     */           
/*     */ 
/* 287 */           this.cache.eventhandler.postEvent(event);
/*     */         }
/*     */         
/*     */ 
/* 291 */         for (int i = 0; i < rrp.reports.length; i++) {
/* 292 */           rrp.reports[i].receiptTime = rrp.receiptTime;
/* 293 */           int rbssrc = rrp.reports[i].ssrc;
/* 294 */           RTCPReportBlock[] reporta = (RTCPReportBlock[])info.reports.get(rbssrc);
/*     */           
/* 296 */           if (reporta == null) {
/* 297 */             reporta = new RTCPReportBlock[2];
/* 298 */             reporta[0] = rrp.reports[i];
/* 299 */             info.reports.put(rbssrc, reporta);
/*     */           }
/*     */           else {
/* 302 */             reporta[1] = reporta[0];
/* 303 */             reporta[0] = rrp.reports[i];
/*     */           }
/*     */         }
/*     */         
/* 307 */         if ((!info.newpartsent) && (info.sourceInfo != null)) {
/* 308 */           NewParticipantEvent evtsdes = new NewParticipantEvent(this.cache.sm, info.sourceInfo);
/*     */           
/*     */ 
/* 311 */           this.cache.eventhandler.postEvent(evtsdes);
/* 312 */           info.newpartsent = true;
/*     */         }
/* 314 */         ReceiverReportEvent evt = new ReceiverReportEvent(this.cache.sm, (ReceiverReport)info);
/*     */         
/*     */ 
/* 317 */         this.cache.eventhandler.postEvent(evt); }
/* 318 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 202: 
/* 326 */       RTCPSDESPacket sdesp = (RTCPSDESPacket)p;
/*     */       
/*     */ 
/* 329 */       for (int i = 0; i < sdesp.sdes.length; i++) {
/* 330 */         RTCPSDES chunk = sdesp.sdes[i];
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 337 */         if (this.type == 1) {
/* 338 */           if ((p.base instanceof UDPPacket)) {
/* 339 */             info = this.cache.get(chunk.ssrc, ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort, 1);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 344 */             info = this.cache.get(chunk.ssrc, null, 0, 1);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 349 */         if (this.type == 2) {
/* 350 */           if ((p.base instanceof UDPPacket)) {
/* 351 */             info = this.cache.get(chunk.ssrc, ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort, 2);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 356 */             info = this.cache.get(chunk.ssrc, null, 0, 2);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 361 */         if (info == null) {
/*     */           break;
/*     */         }
/* 364 */         info.setAlive(true);
/* 365 */         info.lastHeardFrom = sdesp.receiptTime;
/*     */         
/*     */ 
/* 368 */         info.addSDESInfo(chunk);
/*     */       }
/*     */       
/* 371 */       if ((info != null) && (!info.newpartsent) && (info.sourceInfo != null))
/*     */       {
/*     */ 
/* 374 */         NewParticipantEvent evtsdes = new NewParticipantEvent(this.cache.sm, info.sourceInfo);
/*     */         
/*     */ 
/* 377 */         this.cache.eventhandler.postEvent(evtsdes);
/* 378 */         info.newpartsent = true;
/*     */       }
/*     */       
/* 381 */       if ((info != null) && (!info.recvstrmap) && (info.sourceInfo != null) && ((info instanceof RecvSSRCInfo)))
/*     */       {
/*     */ 
/* 384 */         info.recvstrmap = true;
/* 385 */         StreamMappedEvent evtr = new StreamMappedEvent(this.cache.sm, (ReceiveStream)info, info.sourceInfo);
/*     */         
/*     */ 
/*     */ 
/* 389 */         this.cache.eventhandler.postEvent(evtr);
/*     */       }
/* 391 */       this.type = 0;
/* 392 */       break;
/*     */     
/*     */     case 203: 
/* 395 */       RTCPBYEPacket byep = (RTCPBYEPacket)p;
/*     */       
/* 397 */       if ((p.base instanceof UDPPacket)) {
/* 398 */         info = this.cache.get(byep.ssrc[0], ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort);
/*     */       }
/*     */       else
/*     */       {
/* 402 */         info = this.cache.get(byep.ssrc[0], null, 0);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 407 */       for (int i = 0; i < byep.ssrc.length; i++) {
/* 408 */         if ((p.base instanceof UDPPacket)) {
/* 409 */           info = this.cache.get(byep.ssrc[i], ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort);
/*     */         }
/*     */         else
/*     */         {
/* 413 */           info = this.cache.get(byep.ssrc[i], null, 0);
/*     */         }
/*     */         
/* 416 */         if (info == null) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/* 421 */         if (!this.cache.byestate) {
/* 422 */           info.setAlive(false);
/* 423 */           info.byeReceived = true;
/* 424 */           info.byeTime = p.receiptTime;
/*     */           
/* 426 */           info.lastHeardFrom = byep.receiptTime;
/*     */         }
/*     */       }
/* 429 */       if (info != null)
/*     */       {
/* 431 */         if (info.quiet) {
/* 432 */           info.quiet = false;
/*     */           
/* 434 */           ActiveReceiveStreamEvent event = null;
/* 435 */           if ((info instanceof ReceiveStream)) {
/* 436 */             event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info);
/*     */           }
/*     */           else
/*     */           {
/* 440 */             event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, null);
/*     */           }
/*     */           
/* 443 */           this.cache.eventhandler.postEvent(event);
/*     */         }
/*     */         
/*     */ 
/* 447 */         info.byereason = new String(byep.reason);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 457 */         if (!info.byeReceived) {
/* 458 */           boolean byepart = false;
/* 459 */           RTPSourceInfo sourceInfo = info.sourceInfo;
/* 460 */           if ((sourceInfo != null) && (sourceInfo.getStreamCount() == 0))
/*     */           {
/* 462 */             byepart = true;
/*     */           }
/* 464 */           ByeEvent evtbye = null;
/* 465 */           if ((info instanceof RecvSSRCInfo)) {
/* 466 */             evtbye = new ByeEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info, new String(byep.reason), byepart);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 473 */           if ((info instanceof PassiveSSRCInfo)) {
/* 474 */             evtbye = new ByeEvent(this.cache.sm, info.sourceInfo, null, new String(byep.reason), byepart);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 482 */           this.cache.eventhandler.postEvent(evtbye);
/*     */         }
/*     */       }
/*     */       break;
/*     */     case 204: 
/* 487 */       RTCPAPPPacket appp = (RTCPAPPPacket)p;
/* 488 */       if ((p.base instanceof UDPPacket)) {
/* 489 */         info = this.cache.get(appp.ssrc, ((UDPPacket)p.base).remoteAddress, ((UDPPacket)p.base).remotePort);
/*     */       }
/*     */       else
/*     */       {
/* 493 */         info = this.cache.get(appp.ssrc, null, 0);
/*     */       }
/*     */       
/* 496 */       if (info != null)
/*     */       {
/* 498 */         info.lastHeardFrom = appp.receiptTime;
/* 499 */         if (info.quiet) {
/* 500 */           info.quiet = false;
/*     */           
/* 502 */           ActiveReceiveStreamEvent event = null;
/* 503 */           if ((info instanceof ReceiveStream)) {
/* 504 */             event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info);
/*     */           }
/*     */           else
/*     */           {
/* 508 */             event = new ActiveReceiveStreamEvent(this.cache.sm, info.sourceInfo, null);
/*     */           }
/*     */           
/*     */ 
/* 512 */           this.cache.eventhandler.postEvent(event);
/*     */         }
/*     */         
/*     */ 
/* 516 */         ApplicationEvent evnt = null;
/*     */         
/* 518 */         if ((info instanceof RecvSSRCInfo))
/*     */         {
/* 520 */           evnt = new ApplicationEvent(this.cache.sm, info.sourceInfo, (ReceiveStream)info, appp.subtype, null, appp.data);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 528 */         if ((info instanceof PassiveSSRCInfo))
/*     */         {
/* 530 */           evnt = new ApplicationEvent(this.cache.sm, info.sourceInfo, null, appp.subtype, null, appp.data);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 538 */         this.cache.eventhandler.postEvent(evnt);
/*     */       }
/*     */       break;
/*     */     }
/*     */     
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\RTCPReceiver.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */