/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Button;
/*     */ import java.awt.Choice;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Label;
/*     */ import java.awt.Panel;
/*     */ import java.awt.TextComponent;
/*     */ import java.awt.TextField;
/*     */ import java.util.Vector;
/*     */ import javax.media.Format;
/*     */ import javax.media.control.BufferControl;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferControlImpl
/*     */   implements BufferControl
/*     */ {
/*  26 */   private long currBuffer = 2147483647L;
/*  27 */   private long currThreshold = 2147483647L;
/*     */   
/*     */ 
/*  30 */   private long defBuffer = 2147483647L;
/*  31 */   private long defThreshold = 2147483647L;
/*     */   
/*     */ 
/*  34 */   private long maxBuffer = 2147483647L;
/*  35 */   private long maxThreshold = 2147483647L;
/*     */   
/*     */ 
/*  38 */   BufferControlPanel controlComp = null;
/*     */   
/*     */ 
/*  41 */   boolean threshold_enabled = true;
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int AUDIO_DEFAULT_BUFFER = 250;
/*     */   
/*     */ 
/*     */   private static final int AUDIO_DEFAULT_THRESHOLD = 125;
/*     */   
/*     */ 
/*     */   private static final int AUDIO_MAX_BUFFER = 4000;
/*     */   
/*     */ 
/*     */   private static final int AUDIO_MAX_THRESHOLD = 2000;
/*     */   
/*     */ 
/*     */   private static final int VIDEO_DEFAULT_BUFFER = 135;
/*     */   
/*     */ 
/*     */   private static final int VIDEO_DEFAULT_THRESHOLD = 0;
/*     */   
/*     */ 
/*     */   private static final int VIDEO_MAX_BUFFER = 4000;
/*     */   
/*     */ 
/*     */   private static final int VIDEO_MAX_THRESHOLD = 0;
/*     */   
/*     */ 
/*     */   private static final int NOT_SPECIFIED = Integer.MAX_VALUE;
/*     */   
/*     */ 
/*  72 */   private int bufValue = Integer.MAX_VALUE;
/*  73 */   private int threshValue = Integer.MAX_VALUE;
/*  74 */   private boolean inited = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */   private Vector sourcestreamlist = new Vector(1);
/*     */   
/*     */   protected void addSourceStream(RTPSourceStream s)
/*     */   {
/*  85 */     this.sourcestreamlist.addElement(s);
/*     */     
/*  87 */     s.setBufferControl(this);
/*     */   }
/*     */   
/*     */   protected void removeSourceStream(RTPSourceStream s)
/*     */   {
/*  92 */     this.sourcestreamlist.removeElement(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void initBufferControl(Format f)
/*     */   {
/*  99 */     if ((f instanceof AudioFormat)) {
/* 100 */       this.defBuffer = (this.defBuffer == 2147483647L ? 250L : this.currBuffer);
/*     */       
/* 102 */       this.defThreshold = (this.defThreshold == 2147483647L ? 125L : this.currThreshold);
/*     */       
/* 104 */       this.maxBuffer = (this.maxBuffer == 2147483647L ? 4000L : this.maxBuffer);
/*     */       
/* 106 */       this.maxThreshold = (this.maxThreshold == 2147483647L ? 2000L : this.maxThreshold);
/*     */       
/* 108 */       this.currBuffer = (this.currBuffer == 2147483647L ? this.defBuffer : this.currBuffer);
/*     */       
/* 110 */       this.currThreshold = (this.currThreshold == 2147483647L ? this.defThreshold : this.currThreshold);
/*     */     }
/*     */     
/*     */ 
/* 114 */     if ((f instanceof VideoFormat)) {
/* 115 */       this.defBuffer = (this.defBuffer == 2147483647L ? 135L : this.currBuffer);
/*     */       
/* 117 */       this.defThreshold = (this.defThreshold == 2147483647L ? 0L : this.currThreshold);
/*     */       
/* 119 */       this.maxBuffer = (this.maxBuffer == 2147483647L ? 4000L : this.maxBuffer);
/*     */       
/* 121 */       this.maxThreshold = (this.maxThreshold == 2147483647L ? 0L : this.maxThreshold);
/*     */       
/* 123 */       this.currBuffer = (this.currBuffer == 2147483647L ? this.defBuffer : this.currBuffer);
/*     */       
/* 125 */       this.currThreshold = (this.currThreshold == 2147483647L ? this.defThreshold : this.currThreshold);
/*     */     }
/*     */     
/* 128 */     if (this.currBuffer == -2L)
/* 129 */       this.currBuffer = this.maxBuffer;
/* 130 */     if (this.currBuffer == -1L)
/* 131 */       this.currBuffer = this.defBuffer;
/* 132 */     if (this.currThreshold == -2L)
/* 133 */       this.currThreshold = this.maxThreshold;
/* 134 */     if (this.currThreshold == -1L) {
/* 135 */       this.currThreshold = this.defThreshold;
/*     */     }
/* 137 */     if (this.controlComp != null) {
/* 138 */       this.controlComp.updateBuffer(this.currBuffer);
/* 139 */       this.controlComp.updateThreshold(this.currThreshold);
/*     */     }
/* 141 */     this.inited = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getBufferLength()
/*     */   {
/* 152 */     return this.currBuffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long setBufferLength(long time)
/*     */   {
/* 176 */     if (!this.inited) {
/* 177 */       this.currBuffer = time;
/* 178 */       return time;
/*     */     }
/* 180 */     if (time == -1L)
/* 181 */       time = this.defBuffer;
/* 182 */     if (time == -2L) {
/* 183 */       time = this.maxBuffer;
/*     */     }
/*     */     
/* 186 */     if (time < this.currThreshold)
/* 187 */       return this.currBuffer;
/* 188 */     if (time >= this.maxBuffer) {
/* 189 */       this.currBuffer = this.maxBuffer;
/* 190 */     } else if ((time <= 0L) || (time == this.defBuffer)) {
/* 191 */       this.currBuffer = this.defBuffer;
/*     */     } else {
/* 193 */       this.currBuffer = time;
/*     */     }
/*     */     
/* 196 */     for (int i = 0; i < this.sourcestreamlist.size(); i++) {
/* 197 */       ((RTPSourceStream)this.sourcestreamlist.elementAt(i)).updateBuffer(this.currBuffer);
/*     */     }
/*     */     
/* 200 */     if (this.controlComp != null)
/* 201 */       this.controlComp.updateBuffer(this.currBuffer);
/* 202 */     return this.currBuffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getMinimumThreshold()
/*     */   {
/* 219 */     return this.currThreshold;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long setMinimumThreshold(long t)
/*     */   {
/* 239 */     if (!this.inited) {
/* 240 */       this.currThreshold = t;
/* 241 */       return t;
/*     */     }
/* 243 */     if (t == -1L)
/* 244 */       t = this.defThreshold;
/* 245 */     if (t == -2L) {
/* 246 */       t = this.maxThreshold;
/*     */     }
/* 248 */     if (t > this.currBuffer)
/* 249 */       return this.currThreshold;
/* 250 */     if (t >= this.maxThreshold) {
/* 251 */       this.currThreshold = this.maxThreshold;
/* 252 */     } else if (t == this.defThreshold) {
/* 253 */       this.currThreshold = this.defThreshold;
/*     */     } else
/* 255 */       this.currThreshold = t;
/* 256 */     if (t < 0L)
/* 257 */       this.currThreshold = 0L;
/* 258 */     for (int i = 0; i < this.sourcestreamlist.size(); i++)
/* 259 */       ((RTPSourceStream)this.sourcestreamlist.elementAt(i)).updateThreshold(this.currThreshold);
/* 260 */     if (this.controlComp != null)
/* 261 */       this.controlComp.updateThreshold(this.currThreshold);
/* 262 */     return this.currThreshold;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnabledThreshold(boolean b)
/*     */   {
/* 273 */     this.threshold_enabled = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getEnabledThreshold()
/*     */   {
/* 281 */     return this.threshold_enabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Component getControlComponent()
/*     */   {
/* 289 */     if (this.controlComp == null)
/* 290 */       this.controlComp = new BufferControlPanel();
/* 291 */     return this.controlComp;
/*     */   }
/*     */   
/*     */   class BufferControlPanel extends Panel
/*     */   {
/* 296 */     Panel buffersize = null;
/* 297 */     Panel threshold = null;
/* 298 */     TextField bsize; TextField btext = null;
/* 299 */     Choice bchoice = null;
/* 300 */     Choice tchoice = null;
/* 301 */     TextField tsize; TextField ttext = null;
/* 302 */     Button bb; Button tb = null;
/*     */     
/*     */     public BufferControlPanel() {
/* 305 */       super();
/* 306 */       this.buffersize = new Panel(new FlowLayout());
/* 307 */       this.buffersize.add(new Label("BufferSize"));
/* 308 */       this.bsize = new TextField(15);
/* 309 */       updateBuffer(BufferControlImpl.this.getBufferLength());
/* 310 */       this.bsize.setEnabled(false);
/* 311 */       this.buffersize.add(this.bsize);
/* 312 */       this.buffersize.add(new Label("Update"));
/* 313 */       this.buffersize.add(this.bchoice = new Choice());
/* 314 */       this.bchoice.add("DEFAULT");
/* 315 */       this.bchoice.add("MAX");
/* 316 */       this.bchoice.add("User Defined");
/* 317 */       this.bchoice.addItemListener(new BufferControlImpl.1(this));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 325 */       this.buffersize.add(new Label("If User Defined, Enter here:"));
/* 326 */       this.buffersize.add(this.btext = new TextField(10));
/* 327 */       this.btext.setEnabled(false);
/* 328 */       this.buffersize.add(this.bb = new Button("Commit"));
/* 329 */       this.bb.addActionListener(new BufferControlImpl.2(this));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 334 */       this.threshold = new Panel(new FlowLayout());
/* 335 */       this.threshold.add(new Label("Threshold"));
/* 336 */       this.tsize = new TextField(15);
/* 337 */       updateThreshold(BufferControlImpl.this.getMinimumThreshold());
/* 338 */       this.tsize.setEnabled(false);
/* 339 */       this.threshold.add(this.tsize);
/* 340 */       this.threshold.add(new Label("Update"));
/* 341 */       this.threshold.add(this.tchoice = new Choice());
/* 342 */       this.tchoice.add("DEFAULT");
/* 343 */       this.tchoice.add("MAX");
/* 344 */       this.tchoice.add("User Defined");
/* 345 */       this.tchoice.addItemListener(new BufferControlImpl.3(this));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 353 */       this.threshold.add(new Label("If User Defined, Enter here:"));
/* 354 */       this.threshold.add(this.ttext = new TextField(10));
/* 355 */       this.ttext.setEnabled(false);
/* 356 */       this.threshold.add(this.tb = new Button("Commit"));
/* 357 */       this.tb.addActionListener(new BufferControlImpl.4(this));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 362 */       add(this.buffersize, "North");
/* 363 */       add(new Label("Actual buffer & threshold sizes (in millisec) not displayed until media type is determined"), "Center");
/* 364 */       add(this.threshold, "South");
/* 365 */       setVisible(true);
/*     */     }
/*     */     
/* 368 */     private void buffersizeUpdate() { String s = this.bchoice.getSelectedItem();
/* 369 */       long b = -1L;
/* 370 */       if (s.equals("MAX")) {
/* 371 */         b = -2L;
/*     */       }
/* 373 */       else if (s.equals("DEFAULT")) {
/* 374 */         b = -1L;
/*     */       } else {
/* 376 */         s = this.btext.getText();
/* 377 */         b = new Long(s).longValue();
/*     */       }
/* 379 */       b = BufferControlImpl.this.setBufferLength(b);
/* 380 */       updateBuffer(b);
/*     */     }
/*     */     
/* 383 */     private void thresholdUpdate() { String s = this.tchoice.getSelectedItem();
/* 384 */       long t = -1L;
/* 385 */       if (s.equals("DEFAULT")) {
/* 386 */         t = -1L;
/*     */       }
/* 388 */       else if (s.equals("MAX")) {
/* 389 */         t = -2L;
/*     */       } else {
/* 391 */         s = this.ttext.getText();
/* 392 */         t = new Long(s).longValue();
/*     */       }
/* 394 */       t = BufferControlImpl.this.setMinimumThreshold(t);
/* 395 */       updateThreshold(t);
/*     */     }
/*     */     
/* 398 */     public void updateBuffer(long b) { if ((b != 2147483647L) && (b != -2L) && (b != -1L))
/*     */       {
/*     */ 
/* 401 */         this.bsize.setText(new Long(b).toString()); }
/*     */     }
/*     */     
/* 404 */     public void updateThreshold(long d) { if ((d != 2147483647L) && (d != -2L) && (d != -1L))
/*     */       {
/*     */ 
/* 407 */         this.tsize.setText(new Long(d).toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\BufferControlImpl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */