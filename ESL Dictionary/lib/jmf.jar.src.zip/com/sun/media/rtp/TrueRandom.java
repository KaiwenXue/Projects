/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TrueRandom
/*    */ {
/*    */   public void TrueRandom() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static long rand()
/*    */   {
/* 29 */     return System.currentTimeMillis();
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\TrueRandom.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */