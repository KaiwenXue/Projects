/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTCPSDES
/*    */ {
/*    */   public int ssrc;
/*    */   
/*    */ 
/*    */ 
/*    */   public RTCPSDESItem[] items;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 19 */     return "\t\tSource Description for sync source " + this.ssrc + ":\n" + RTCPSDESItem.toString(this.items);
/*    */   }
/*    */   
/*    */   public static String toString(RTCPSDES[] chunks)
/*    */   {
/* 24 */     String s = "";
/* 25 */     for (int i = 0; i < chunks.length; i++)
/* 26 */       s = s + chunks[i];
/* 27 */     return s;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\RTCPSDES.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */