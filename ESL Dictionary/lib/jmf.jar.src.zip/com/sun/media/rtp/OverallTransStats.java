/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import javax.media.rtp.GlobalTransmissionStats;
/*    */ 
/*    */ public class OverallTransStats implements GlobalTransmissionStats
/*    */ {
/*  7 */   protected int rtp_sent = 0;
/*  8 */   protected int bytes_sent = 0;
/*  9 */   protected int rtcp_sent = 0;
/* 10 */   protected int local_coll = 0;
/* 11 */   protected int remote_coll = 0;
/* 12 */   protected int transmit_failed = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getRTPSent()
/*    */   {
/* 21 */     return this.rtp_sent;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getBytesSent()
/*    */   {
/* 28 */     return this.bytes_sent;
/*    */   }
/*    */   
/*    */ 
/*    */   public int getRTCPSent()
/*    */   {
/* 34 */     return this.rtcp_sent;
/*    */   }
/*    */   
/*    */ 
/*    */   public int getLocalColls()
/*    */   {
/* 40 */     return this.local_coll;
/*    */   }
/*    */   
/*    */ 
/*    */   public int getRemoteColls()
/*    */   {
/* 46 */     return this.remote_coll;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getTransmitFailed()
/*    */   {
/* 54 */     return this.transmit_failed;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\OverallTransStats.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */