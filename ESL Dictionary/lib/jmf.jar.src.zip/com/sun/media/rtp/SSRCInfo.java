/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import com.sun.media.rtp.util.SSRCTable;
/*     */ import java.io.PrintStream;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Enumeration;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Vector;
/*     */ import javax.media.Format;
/*     */ import javax.media.rtp.LocalParticipant;
/*     */ import javax.media.rtp.Participant;
/*     */ import javax.media.rtp.rtcp.Report;
/*     */ import javax.media.rtp.rtcp.SourceDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SSRCInfo
/*     */   implements Report
/*     */ {
/*     */   private SSRCCache cache;
/*  33 */   boolean alive = false;
/*  34 */   boolean payloadchange = false;
/*  35 */   boolean byeReceived = false;
/*  36 */   long byeTime = 0L;
/*  37 */   String byereason = null;
/*     */   
/*     */ 
/*     */ 
/*  41 */   RTPSourceInfo sourceInfo = null;
/*     */   
/*     */ 
/*     */ 
/*  45 */   SourceDescription name = null;
/*  46 */   SourceDescription email = null;
/*  47 */   SourceDescription phone = null;
/*  48 */   SourceDescription loc = null;
/*  49 */   SourceDescription tool = null;
/*  50 */   SourceDescription note = null;
/*  51 */   SourceDescription priv = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  56 */   long lastSRntptimestamp = 0L;
/*  57 */   long lastSRrtptimestamp = 0L;
/*  58 */   long lastSRoctetcount = 0L;
/*  59 */   long lastSRpacketcount = 0L;
/*     */   
/*     */ 
/*  62 */   long lastRTCPreceiptTime = 0L;
/*  63 */   long lastSRreceiptTime = 0L;
/*  64 */   long lastHeardFrom = 0L;
/*  65 */   boolean quiet = false;
/*  66 */   boolean inactivesent = false;
/*     */   boolean aging;
/*  68 */   boolean sender = false;
/*  69 */   boolean ours = false;
/*     */   
/*     */   int ssrc;
/*  72 */   boolean streamconnect = false;
/*     */   
/*     */ 
/*  75 */   SSRCTable reports = new SSRCTable();
/*     */   
/*     */ 
/*  78 */   boolean active = false;
/*  79 */   boolean newrecvstream = false;
/*  80 */   boolean recvstrmap = false;
/*  81 */   boolean newpartsent = false;
/*  82 */   boolean lastsr = false;
/*  83 */   boolean wrapped = false;
/*     */   
/*     */   static final int INITIALPROBATION = 2;
/*     */   
/*  87 */   int probation = 2;
/*     */   
/*     */   static final int PAYLOAD_UNASSIGNED = -1;
/*  90 */   boolean wassender = false;
/*     */   
/*     */   int prevmaxseq;
/*     */   
/*     */   int prevlost;
/*     */   
/*     */   long starttime;
/*     */   
/*     */   long rtptime;
/*     */   
/*     */   long systime;
/*     */   
/*     */   InetAddress address;
/*     */   
/*     */   int port;
/*     */   
/*     */   RTCPReporter reporter;
/*     */   
/* 108 */   Format currentformat = null;
/* 109 */   int payloadType = -1;
/*     */   
/* 111 */   com.sun.media.protocol.rtp.DataSource dsource = null;
/*     */   
/* 113 */   javax.media.protocol.DataSource pds = null;
/* 114 */   RTPSourceStream dstream = null;
/* 115 */   RTPSinkStream sinkstream = null;
/*     */   
/*     */ 
/*     */   long lastRTPReceiptTime;
/*     */   
/*     */ 
/* 121 */   int maxseq = 0;
/* 122 */   int cycles = 0;
/*     */   
/*     */   int baseseq;
/*     */   
/*     */   int lastbadseq;
/*     */   
/*     */   int received;
/* 129 */   long lasttimestamp = 0L;
/* 130 */   int lastPayloadType = -1;
/* 131 */   double jitter = 0.0D;
/*     */   
/*     */   int bytesreceived;
/*     */   
/* 135 */   RTPStats stats = null;
/* 136 */   int clockrate = 0;
/*     */   
/* 138 */   SSRCInfo(SSRCCache cache, int ssrc) { this.cache = cache;
/* 139 */     this.ssrc = ssrc;
/* 140 */     this.stats = new RTPStats();
/*     */   }
/*     */   
/*     */   SSRCInfo(SSRCInfo info) {
/* 144 */     this.cache = info.cache;
/* 145 */     this.alive = info.alive;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 152 */     this.sourceInfo = info.sourceInfo;
/* 153 */     if (this.sourceInfo != null)
/* 154 */       this.sourceInfo.addSSRC(this);
/* 155 */     this.cache.remove(info.ssrc);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 160 */     this.name = info.name;
/* 161 */     this.email = info.email;
/* 162 */     this.phone = info.phone;
/* 163 */     this.loc = info.loc;
/* 164 */     this.tool = info.tool;
/* 165 */     this.note = info.note;
/* 166 */     this.priv = info.priv;
/* 167 */     this.lastSRntptimestamp = info.lastSRntptimestamp;
/* 168 */     this.lastSRrtptimestamp = info.lastSRrtptimestamp;
/* 169 */     this.lastSRoctetcount = info.lastSRoctetcount;
/* 170 */     this.lastSRpacketcount = info.lastSRpacketcount;
/* 171 */     this.lastRTCPreceiptTime = info.lastRTCPreceiptTime;
/* 172 */     this.lastSRreceiptTime = info.lastSRreceiptTime;
/* 173 */     this.lastHeardFrom = info.lastHeardFrom;
/* 174 */     this.quiet = info.quiet;
/* 175 */     this.inactivesent = info.inactivesent;
/* 176 */     this.aging = info.aging;
/* 177 */     this.reports = info.reports;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 182 */     this.ours = info.ours;
/* 183 */     this.ssrc = info.ssrc;
/* 184 */     this.streamconnect = info.streamconnect;
/*     */     
/* 186 */     this.newrecvstream = info.newrecvstream;
/* 187 */     this.recvstrmap = info.recvstrmap;
/* 188 */     this.newpartsent = info.newpartsent;
/* 189 */     this.lastsr = info.lastsr;
/* 190 */     this.probation = info.probation;
/* 191 */     this.wassender = info.wassender;
/* 192 */     this.prevmaxseq = info.prevmaxseq;
/* 193 */     this.prevlost = info.prevlost;
/* 194 */     this.starttime = info.starttime;
/* 195 */     this.reporter = info.reporter;
/* 196 */     if (info.reporter != null) {
/* 197 */       this.reporter.transmit.setSSRCInfo(this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 202 */     this.payloadType = info.payloadType;
/* 203 */     this.dsource = info.dsource;
/* 204 */     this.pds = info.pds;
/* 205 */     this.dstream = info.dstream;
/* 206 */     this.lastRTPReceiptTime = info.lastRTPReceiptTime;
/* 207 */     this.maxseq = info.maxseq;
/* 208 */     this.cycles = info.cycles;
/* 209 */     this.baseseq = info.baseseq;
/* 210 */     this.lastbadseq = info.lastbadseq;
/* 211 */     this.received = info.received;
/* 212 */     this.lasttimestamp = info.lasttimestamp;
/* 213 */     this.lastPayloadType = info.lastPayloadType;
/* 214 */     this.jitter = info.jitter;
/* 215 */     this.bytesreceived = info.bytesreceived;
/* 216 */     this.address = info.address;
/* 217 */     this.port = info.port;
/* 218 */     this.stats = info.stats;
/* 219 */     this.clockrate = info.clockrate;
/* 220 */     this.byeTime = info.byeTime;
/* 221 */     this.byeReceived = info.byeReceived;
/*     */   }
/*     */   
/*     */   private void InitSDES() {
/* 225 */     this.name = new SourceDescription(2, null, 0, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 230 */     this.email = new SourceDescription(3, null, 0, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 235 */     this.phone = new SourceDescription(4, null, 0, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 240 */     this.loc = new SourceDescription(5, null, 0, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 245 */     this.tool = new SourceDescription(6, null, 0, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 250 */     this.note = new SourceDescription(7, null, 0, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 255 */     this.priv = new SourceDescription(8, null, 0, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   RTPSourceInfo getRTPSourceInfo()
/*     */   {
/* 263 */     return this.sourceInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isActive()
/*     */   {
/* 277 */     return this.active;
/*     */   }
/*     */   
/*     */   int getPayloadType() {
/* 281 */     return this.payloadType;
/*     */   }
/*     */   
/*     */ 
/*     */   void setSourceDescription(SourceDescription[] userdesclist)
/*     */   {
/* 287 */     if (userdesclist == null)
/*     */     {
/* 289 */       return;
/*     */     }
/* 291 */     String cname = null;
/*     */     
/* 293 */     for (int i = 0; i < userdesclist.length; i++) {
/* 294 */       SourceDescription currdesc = userdesclist[i];
/* 295 */       if ((currdesc != null) && (currdesc.getType() == 1))
/*     */       {
/* 297 */         cname = userdesclist[i].getDescription();
/* 298 */         break;
/*     */       }
/*     */     }
/* 301 */     String sourceinfocname = null;
/* 302 */     if (this.sourceInfo != null)
/* 303 */       sourceinfocname = this.sourceInfo.getCNAME();
/* 304 */     if ((this.sourceInfo != null) && (cname != null) && (!cname.equals(sourceinfocname)))
/*     */     {
/*     */ 
/*     */ 
/* 308 */       this.sourceInfo.removeSSRC(this);
/*     */       
/* 310 */       this.sourceInfo = null;
/*     */     }
/* 312 */     if (this.sourceInfo == null) {
/* 313 */       this.sourceInfo = this.cache.sourceInfoCache.get(cname, true);
/* 314 */       this.sourceInfo.addSSRC(this);
/*     */     }
/*     */     
/* 317 */     for (int j = 0; j < userdesclist.length; j++) {
/* 318 */       SourceDescription currdesc = userdesclist[j];
/* 319 */       if (currdesc != null) {
/* 320 */         switch (currdesc.getType())
/*     */         {
/*     */         case 2: 
/* 323 */           if (this.name == null) {
/* 324 */             this.name = new SourceDescription(2, currdesc.getDescription(), 0, false);
/*     */ 
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/*     */ 
/* 332 */             this.name.setDescription(currdesc.getDescription()); }
/* 333 */           break;
/*     */         case 3: 
/* 335 */           if (this.email == null) {
/* 336 */             this.email = new SourceDescription(3, currdesc.getDescription(), 0, false);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 342 */             this.email.setDescription(currdesc.getDescription()); }
/* 343 */           break;
/*     */         case 4: 
/* 345 */           if (this.phone == null) {
/* 346 */             this.phone = new SourceDescription(4, currdesc.getDescription(), 0, false);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 352 */             this.phone.setDescription(currdesc.getDescription()); }
/* 353 */           break;
/*     */         case 5: 
/* 355 */           if (this.loc == null) {
/* 356 */             this.loc = new SourceDescription(5, currdesc.getDescription(), 0, false);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 362 */             this.loc.setDescription(currdesc.getDescription()); }
/* 363 */           break;
/*     */         case 6: 
/* 365 */           if (this.tool == null) {
/* 366 */             this.tool = new SourceDescription(6, currdesc.getDescription(), 0, false);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 372 */             this.tool.setDescription(currdesc.getDescription()); }
/* 373 */           break;
/*     */         case 7: 
/* 375 */           if (this.note == null) {
/* 376 */             this.note = new SourceDescription(7, currdesc.getDescription(), 0, false);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 382 */             this.note.setDescription(currdesc.getDescription()); }
/* 383 */           break;
/*     */         case 8: 
/* 385 */           if (this.priv == null) {
/* 386 */             this.priv = new SourceDescription(8, currdesc.getDescription(), 0, false);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 392 */             this.priv.setDescription(currdesc.getDescription());
/*     */           }
/*     */           break;
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void delete()
/*     */   {
/* 403 */     if (this.sourceInfo != null)
/*     */     {
/* 405 */       this.sourceInfo.removeSSRC(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void addSDESInfo(RTCPSDES chunk)
/*     */   {
/* 417 */     for (int ci = 0; ci < chunk.items.length; ci++)
/* 418 */       if (chunk.items[ci].type == 1)
/*     */         break;
/* 420 */     String s = new String(chunk.items[ci].data);
/* 421 */     String sourceinfocname = null;
/* 422 */     if (this.sourceInfo != null)
/* 423 */       sourceinfocname = this.sourceInfo.getCNAME();
/* 424 */     if ((this.sourceInfo != null) && (!s.equals(sourceinfocname)))
/*     */     {
/* 426 */       this.sourceInfo.removeSSRC(this);
/* 427 */       this.sourceInfo = null;
/*     */     }
/* 429 */     if (this.sourceInfo == null) {
/* 430 */       this.sourceInfo = this.cache.sourceInfoCache.get(s, this.ours);
/* 431 */       this.sourceInfo.addSSRC(this);
/*     */     }
/* 433 */     if (chunk.items.length > 1) {
/* 434 */       for (int i = 0; i < chunk.items.length; i++)
/*     */       {
/* 436 */         s = new String(chunk.items[i].data);
/* 437 */         switch (chunk.items[i].type)
/*     */         {
/*     */         case 2: 
/* 440 */           if (this.name == null) {
/* 441 */             this.name = new SourceDescription(2, s, 0, false);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 447 */             this.name.setDescription(s); }
/* 448 */           break;
/*     */         case 3: 
/* 450 */           if (this.email == null) {
/* 451 */             this.email = new SourceDescription(3, s, 0, false);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 457 */             this.email.setDescription(s); }
/* 458 */           break;
/*     */         case 4: 
/* 460 */           if (this.phone == null) {
/* 461 */             this.phone = new SourceDescription(4, s, 0, false);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 467 */             this.phone.setDescription(s); }
/* 468 */           break;
/*     */         case 5: 
/* 470 */           if (this.loc == null) {
/* 471 */             this.loc = new SourceDescription(5, s, 0, false);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 477 */             this.loc.setDescription(s); }
/* 478 */           break;
/*     */         case 6: 
/* 480 */           if (this.tool == null) {
/* 481 */             this.tool = new SourceDescription(6, s, 0, false);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 487 */             this.tool.setDescription(s); }
/* 488 */           break;
/*     */         case 7: 
/* 490 */           if (this.note == null) {
/* 491 */             this.note = new SourceDescription(7, s, 0, false);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 497 */             this.note.setDescription(s); }
/* 498 */           break;
/*     */         case 8: 
/* 500 */           if (this.priv == null) {
/* 501 */             this.priv = new SourceDescription(8, s, 0, false);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/* 507 */             this.priv.setDescription(s);
/*     */           }
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void initsource(int seqnum)
/*     */   {
/* 517 */     if (this.probation <= 0) {
/* 518 */       this.active = true;
/* 519 */       setSender(true);
/*     */     }
/* 521 */     this.baseseq = seqnum;
/* 522 */     this.maxseq = (seqnum - 1);
/* 523 */     this.lastbadseq = -2;
/* 524 */     this.cycles = 0;
/* 525 */     this.received = 0;
/* 526 */     this.bytesreceived = 0;
/* 527 */     this.lastRTPReceiptTime = 0L;
/* 528 */     this.lasttimestamp = 0L;
/* 529 */     this.jitter = 0.0D;
/* 530 */     this.prevmaxseq = this.maxseq;
/* 531 */     this.prevlost = 0;
/*     */   }
/*     */   
/*     */   void setAlive(boolean bealive) {
/* 535 */     setAging(false);
/* 536 */     if (this.alive == bealive) {
/* 537 */       return;
/*     */     }
/* 539 */     if (bealive)
/*     */     {
/*     */ 
/* 542 */       this.reports.removeAll();
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 547 */       setSender(false);
/*     */     }
/* 549 */     this.alive = bealive;
/*     */   }
/*     */   
/*     */   void setSender(boolean besender) {
/* 553 */     if (this.sender == besender) {
/* 554 */       return;
/*     */     }
/* 556 */     if (besender)
/*     */     {
/* 558 */       this.cache.sendercount += 1;
/* 559 */       setAlive(true);
/*     */     }
/*     */     else
/*     */     {
/* 563 */       this.cache.sendercount -= 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 575 */     this.sender = besender;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void setOurs(boolean beours)
/*     */   {
/* 582 */     if (this.ours == beours) {
/* 583 */       return;
/*     */     }
/* 585 */     if (beours) {
/* 586 */       setAlive(true);
/*     */     } else
/* 588 */       setAlive(false);
/* 589 */     this.ours = beours;
/*     */   }
/*     */   
/*     */   void setAging(boolean beaging) {
/* 593 */     if (this.aging == beaging) {
/* 594 */       return;
/*     */     }
/* 596 */     this.aging = beaging;
/*     */   }
/*     */   
/*     */   public String getCNAME() {
/* 600 */     return this.sourceInfo == null ? null : this.sourceInfo.getCNAME();
/*     */   }
/*     */   
/*     */   public long getSSRC()
/*     */   {
/* 605 */     return this.ssrc;
/*     */   }
/*     */   
/*     */   public Vector getFeedbackReports()
/*     */   {
/* 610 */     RTCPReportBlock[] reportblklist = null;
/*     */     
/* 612 */     if (this.reports.size() == 0) {
/* 613 */       reportlist = new Vector(0);
/* 614 */       return reportlist;
/*     */     }
/* 616 */     Vector reportlist = new Vector(this.reports.size());
/*     */     
/* 618 */     Enumeration reportblks = this.reports.elements();
/*     */     try
/*     */     {
/* 621 */       while (reportblks.hasMoreElements()) {
/* 622 */         reportblklist = (RTCPReportBlock[])reportblks.nextElement();
/*     */         
/*     */ 
/* 625 */         RTCPReportBlock report = new RTCPReportBlock();
/* 626 */         report = reportblklist[0];
/* 627 */         reportlist.addElement(report);
/*     */       }
/*     */     }
/*     */     catch (NoSuchElementException e) {
/* 631 */       System.err.println("No more elements");
/*     */     }
/* 633 */     reportlist.trimToSize();
/* 634 */     return reportlist;
/*     */   }
/*     */   
/*     */   public Participant getParticipant() {
/* 638 */     if (((this.sourceInfo instanceof LocalParticipant)) && (this.cache.sm.IsNonParticipating()))
/*     */     {
/* 640 */       return null; }
/* 641 */     return this.sourceInfo;
/*     */   }
/*     */   
/*     */ 
/* 645 */   public SSRCCache getSSRCCache() { return this.cache; }
/*     */   
/*     */   public Vector getSourceDescription() {
/* 648 */     Vector sdeslist = new Vector();
/* 649 */     sdeslist.addElement(this.sourceInfo.getCNAMESDES());
/* 650 */     if (this.name != null)
/* 651 */       sdeslist.addElement(this.name);
/* 652 */     if (this.email != null)
/* 653 */       sdeslist.addElement(this.email);
/* 654 */     if (this.phone != null)
/* 655 */       sdeslist.addElement(this.phone);
/* 656 */     if (this.loc != null)
/* 657 */       sdeslist.addElement(this.loc);
/* 658 */     if (this.tool != null)
/* 659 */       sdeslist.addElement(this.tool);
/* 660 */     if (this.note != null)
/* 661 */       sdeslist.addElement(this.note);
/* 662 */     if (this.priv != null)
/* 663 */       sdeslist.addElement(this.priv);
/* 664 */     sdeslist.trimToSize();
/* 665 */     return sdeslist;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\SSRCInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */