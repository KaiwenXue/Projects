/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import com.sun.media.rtp.util.Signed;
/*    */ import javax.media.rtp.rtcp.Feedback;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RTCPReportBlock
/*    */   implements Feedback
/*    */ {
/*    */   int ssrc;
/*    */   int fractionlost;
/*    */   int packetslost;
/*    */   long lastseq;
/*    */   int jitter;
/*    */   long lsr;
/*    */   long dlsr;
/*    */   long receiptTime;
/*    */   
/*    */   public long getSSRC()
/*    */   {
/* 35 */     return this.ssrc;
/*    */   }
/*    */   
/* 38 */   public int getFractionLost() { return this.fractionlost; }
/*    */   
/*    */   public long getNumLost() {
/* 41 */     return this.packetslost;
/*    */   }
/*    */   
/* 44 */   public long getXtndSeqNum() { return this.lastseq; }
/*    */   
/*    */   public long getJitter() {
/* 47 */     return this.jitter;
/*    */   }
/*    */   
/* 50 */   public long getLSR() { return this.lsr; }
/*    */   
/*    */   public long getDLSR() {
/* 53 */     return this.dlsr;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 57 */     long printssrc = this.ssrc;
/* 58 */     if (this.ssrc < 0)
/* 59 */       printssrc = Signed.UnsignedInt(this.ssrc);
/* 60 */     return "\t\tFor source " + printssrc + "\n\t\t\tFraction of packets lost: " + this.fractionlost + " (" + this.fractionlost / 256.0D + ")" + "\n\t\t\tPackets lost: " + this.packetslost + "\n\t\t\tLast sequence number: " + this.lastseq + "\n\t\t\tJitter: " + this.jitter + "\n\t\t\tLast SR packet received at time " + this.lsr + "\n\t\t\tDelay since last SR packet received: " + this.dlsr + " (" + this.dlsr / 65536.0D + " seconds)\n";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String toString(RTCPReportBlock[] reports)
/*    */   {
/* 72 */     String s = "";
/* 73 */     for (int i = 0; i < reports.length; i++)
/* 74 */       s = s + reports[i];
/* 75 */     return s;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\RTCPReportBlock.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */