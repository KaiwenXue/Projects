/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import com.sun.media.rtp.util.RTPPacket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SourceRTPPacket
/*    */ {
/*    */   RTPPacket p;
/*    */   SSRCInfo ssrcinfo;
/*    */   
/*    */   public SourceRTPPacket(RTPPacket p, SSRCInfo ssrcinfo)
/*    */   {
/* 16 */     this.p = p;
/* 17 */     this.ssrcinfo = ssrcinfo;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\SourceRTPPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */