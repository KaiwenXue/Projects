/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import com.sun.media.rtp.util.Packet;
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RTCPPacket
/*    */   extends Packet
/*    */ {
/*    */   public Packet base;
/*    */   public int type;
/*    */   public static final int SR = 200;
/*    */   public static final int RR = 201;
/*    */   public static final int SDES = 202;
/*    */   public static final int BYE = 203;
/*    */   public static final int APP = 204;
/*    */   public static final int COMPOUND = -1;
/*    */   
/*    */   public RTCPPacket() {}
/*    */   
/*    */   public RTCPPacket(Packet p)
/*    */   {
/* 26 */     super(p);
/* 27 */     this.base = p;
/*    */   }
/*    */   
/* 30 */   public RTCPPacket(RTCPPacket parent) { super(parent);
/* 31 */     this.base = parent.base;
/*    */   }
/*    */   
/*    */   public abstract int calcLength();
/*    */   
/*    */   abstract void assemble(DataOutputStream paramDataOutputStream)
/*    */     throws IOException;
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\RTCPPacket.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */