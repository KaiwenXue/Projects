/*    */ package com.sun.media.rtp;
/*    */ 
/*    */ import javax.media.rtp.rtcp.ReceiverReport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PassiveSSRCInfo
/*    */   extends SSRCInfo
/*    */   implements ReceiverReport
/*    */ {
/*    */   PassiveSSRCInfo(SSRCCache cache, int ssrc)
/*    */   {
/* 16 */     super(cache, ssrc);
/*    */   }
/*    */   
/*    */   PassiveSSRCInfo(SSRCInfo info) {
/* 20 */     super(info);
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\PassiveSSRCInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */