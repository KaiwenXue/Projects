/*     */ package com.sun.media.rtp;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Vector;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.rtp.Participant;
/*     */ import javax.media.rtp.RTPStream;
/*     */ import javax.media.rtp.SendStream;
/*     */ import javax.media.rtp.TransmissionStats;
/*     */ import javax.media.rtp.rtcp.Feedback;
/*     */ import javax.media.rtp.rtcp.Report;
/*     */ import javax.media.rtp.rtcp.SenderReport;
/*     */ import javax.media.rtp.rtcp.SourceDescription;
/*     */ 
/*     */ public class SendSSRCInfo extends SSRCInfo implements SenderReport, SendStream
/*     */ {
/*  22 */   boolean inited = false;
/*     */   
/*     */ 
/*     */   private static final int PACKET_SIZE = 4000;
/*     */   
/*  27 */   protected int packetsize = 0;
/*  28 */   protected Format myformat = null;
/*  29 */   protected long totalSamples = 0L;
/*  30 */   protected long lastSeq = -1L;
/*  31 */   protected long lastBufSeq = -1L;
/*     */   
/*  33 */   protected RTPTransStats stats = null;
/*  34 */   protected RTCPReporter rtcprep = null;
/*     */   
/*     */ 
/*  37 */   static AudioFormat dviAudio = new AudioFormat("dvi/rtp");
/*  38 */   static AudioFormat gsmAudio = new AudioFormat("gsm/rtp");
/*  39 */   static AudioFormat g723Audio = new AudioFormat("g723/rtp");
/*  40 */   static AudioFormat ulawAudio = new AudioFormat("ULAW/rtp");
/*  41 */   static AudioFormat mpegAudio = new AudioFormat("mpegaudio/rtp");
/*  42 */   static VideoFormat mpegVideo = new VideoFormat("mpeg/rtp");
/*     */   
/*     */   public SendSSRCInfo(SSRCCache cache, int ssrc) {
/*  45 */     super(cache, ssrc);
/*     */     
/*     */ 
/*  48 */     this.baseseq = ((int)TrueRandom.rand());
/*  49 */     this.maxseq = this.baseseq;
/*  50 */     this.lasttimestamp = ((int)TrueRandom.rand());
/*  51 */     this.sender = true;
/*  52 */     this.wassender = true;
/*  53 */     this.sinkstream = new RTPSinkStream();
/*  54 */     this.stats = new RTPTransStats();
/*     */   }
/*     */   
/*     */   public SendSSRCInfo(SSRCInfo info) {
/*  58 */     super(info);
/*  59 */     this.baseseq = ((int)TrueRandom.rand());
/*  60 */     this.maxseq = this.baseseq;
/*  61 */     this.lasttimestamp = ((int)TrueRandom.rand());
/*  62 */     this.sender = true;
/*  63 */     this.wassender = true;
/*  64 */     this.sinkstream = new RTPSinkStream();
/*  65 */     this.stats = new RTPTransStats();
/*     */   }
/*     */   
/*     */ 
/*     */   public long getTimeStamp(Buffer b)
/*     */   {
/*  71 */     if ((b.getFormat() instanceof AudioFormat))
/*     */     {
/*  73 */       if (mpegAudio.matches(b.getFormat()))
/*     */       {
/*     */ 
/*  76 */         if (b.getTimeStamp() >= 0L)
/*     */         {
/*  78 */           return b.getTimeStamp() * 90L / 1000000L;
/*     */         }
/*  80 */         return System.currentTimeMillis() * 90L;
/*     */       }
/*     */       
/*  83 */       this.totalSamples += calculateSampleCount(b);
/*  84 */       return this.totalSamples;
/*     */     }
/*     */     
/*  87 */     if ((b.getFormat() instanceof VideoFormat))
/*     */     {
/*  89 */       if (b.getTimeStamp() >= 0L)
/*     */       {
/*  91 */         return b.getTimeStamp() * 90L / 1000000L;
/*     */       }
/*  93 */       return System.currentTimeMillis() * 90L;
/*     */     }
/*     */     
/*     */ 
/*  97 */     return b.getTimeStamp();
/*     */   }
/*     */   
/*     */ 
/*     */   private int calculateSampleCount(Buffer b)
/*     */   {
/* 103 */     AudioFormat f = (AudioFormat)b.getFormat();
/*     */     
/* 105 */     if (f == null) {
/* 106 */       return -1;
/*     */     }
/* 108 */     long t = f.computeDuration(b.getLength());
/*     */     
/* 110 */     if (t == -1L) {
/* 111 */       return -1;
/*     */     }
/* 113 */     if (f.getSampleRate() != -1.0D)
/* 114 */       return (int)(t * f.getSampleRate() / 1.0E9D);
/* 115 */     if (f.getFrameRate() != -1.0D) {
/* 116 */       return (int)(t * f.getFrameRate() / 1.0E9D);
/*     */     }
/* 118 */     return -1;
/*     */   }
/*     */   
/*     */   public long getSequenceNumber(Buffer b)
/*     */   {
/* 123 */     long seq = b.getSequenceNumber();
/*     */     
/* 125 */     if (this.lastSeq == -1L) {
/* 126 */       this.lastSeq = ((System.currentTimeMillis() * Math.random()));
/* 127 */       this.lastBufSeq = seq;
/* 128 */       return this.lastSeq;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 134 */     if (seq - this.lastBufSeq > 1L) {
/* 135 */       this.lastSeq += seq - this.lastBufSeq;
/*     */     } else {
/* 137 */       this.lastSeq += 1L;
/*     */     }
/* 139 */     this.lastBufSeq = seq;
/* 140 */     return this.lastSeq;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void setFormat(Format fmt)
/*     */   {
/* 146 */     this.myformat = fmt;
/*     */     
/*     */ 
/* 149 */     if (this.sinkstream != null) {
/* 150 */       int rate = 0;
/*     */       
/* 152 */       if ((fmt instanceof AudioFormat))
/*     */       {
/*     */ 
/*     */ 
/* 156 */         if ((ulawAudio.matches(fmt)) || (dviAudio.matches(fmt)) || (mpegAudio.matches(fmt)))
/*     */         {
/*     */ 
/* 159 */           rate = (int)((AudioFormat)fmt).getSampleRate() * ((AudioFormat)fmt).getSampleSizeInBits();
/*     */         }
/* 161 */         else if (gsmAudio.matches(fmt)) {
/* 162 */           rate = 13200;
/* 163 */         } else if (g723Audio.matches(fmt))
/* 164 */           rate = 6300;
/* 165 */         this.sinkstream.rate = rate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 185 */       System.err.println("RTPSinkStream is NULL");
/*     */     }
/*     */   }
/*     */   
/*     */   public long getSenderPacketCount() {
/* 190 */     return this.lastSRpacketcount;
/*     */   }
/*     */   
/* 193 */   public long getSenderByteCount() { return this.lastSRoctetcount; }
/*     */   
/*     */   public long getNTPTimeStampMSW() {
/* 196 */     return this.lastSRntptimestamp >> 32;
/*     */   }
/*     */   
/* 199 */   public long getNTPTimeStampLSW() { return this.lastSRntptimestamp; }
/*     */   
/*     */ 
/* 202 */   public long getRTPTimeStamp() { return this.lastSRrtptimestamp; }
/*     */   
/*     */   public Feedback getSenderFeedback() {
/* 205 */     SSRCCache cache = getSSRCCache();
/* 206 */     Report report = null;
/*     */     
/* 208 */     Vector reports = null;
/* 209 */     Vector feedback = null;
/* 210 */     Feedback reportblk = null;
/*     */     try {
/* 212 */       Participant localpartc = cache.sm.getLocalParticipant();
/* 213 */       reports = localpartc.getReports();
/* 214 */       for (int i = 0; i < reports.size(); i++) {
/* 215 */         report = (Report)reports.elementAt(i);
/* 216 */         feedback = report.getFeedbackReports();
/* 217 */         for (int j = 0; j < feedback.size(); j++) {
/* 218 */           reportblk = (Feedback)feedback.elementAt(j);
/*     */           
/* 220 */           long ssrc = reportblk.getSSRC();
/* 221 */           if (ssrc == getSSRC())
/* 222 */             return reportblk;
/*     */         }
/*     */       }
/* 225 */       return null;
/*     */     } catch (NullPointerException e) {}
/* 227 */     return null;
/*     */   }
/*     */   
/*     */   public RTPStream getStream()
/*     */   {
/* 232 */     return this;
/*     */   }
/*     */   
/*     */   public Participant getParticipant() {
/* 236 */     SSRCCache cache = getSSRCCache();
/* 237 */     if (((this.sourceInfo instanceof javax.media.rtp.LocalParticipant)) && (cache.sm.IsNonParticipating()))
/*     */     {
/* 239 */       return null;
/*     */     }
/* 241 */     return this.sourceInfo;
/*     */   }
/*     */   
/*     */   public void setSourceDescription(SourceDescription[] userdesclist)
/*     */   {
/* 246 */     super.setSourceDescription(userdesclist);
/*     */   }
/*     */   
/*     */   public void close() {
/*     */     try {
/* 251 */       stop();
/*     */     } catch (IOException e) {}
/* 253 */     SSRCCache cache = getSSRCCache();
/* 254 */     cache.sm.removeSendStream(this);
/*     */   }
/*     */   
/*     */   public SenderReport getSenderReport() {
/* 258 */     SSRCCache cache = getSSRCCache();
/* 259 */     Report report = null;
/*     */     
/* 261 */     Vector reports = null;
/* 262 */     Vector feedback = null;
/* 263 */     Feedback reportblk = null;
/*     */     try {
/* 265 */       Participant localpartc = cache.sm.getLocalParticipant();
/* 266 */       reports = localpartc.getReports();
/* 267 */       for (int i = 0; i < reports.size(); i++) {
/* 268 */         report = (Report)reports.elementAt(i);
/* 269 */         feedback = report.getFeedbackReports();
/* 270 */         for (int j = 0; j < feedback.size(); j++) {
/* 271 */           reportblk = (Feedback)feedback.elementAt(j);
/*     */           
/* 273 */           long ssrc = reportblk.getSSRC();
/* 274 */           if (ssrc == getSSRC())
/* 275 */             return (SenderReport)report;
/*     */         }
/*     */       }
/* 278 */       return null;
/*     */     } catch (NullPointerException e) {}
/* 280 */     return null;
/*     */   }
/*     */   
/*     */   public DataSource getDataSource()
/*     */   {
/* 285 */     return this.pds;
/*     */   }
/*     */   
/*     */   public void stop() throws IOException {
/* 289 */     if (this.pds != null) {
/* 290 */       this.pds.stop();
/*     */     }
/* 292 */     if (this.sinkstream != null) {
/* 293 */       this.sinkstream.stop();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void start()
/*     */     throws IOException
/*     */   {
/* 301 */     if (!this.inited) {
/* 302 */       this.inited = true;
/* 303 */       this.probation = 0;
/* 304 */       initsource((int)TrueRandom.rand());
/* 305 */       this.lasttimestamp = ((int)TrueRandom.rand());
/*     */     }
/* 307 */     if (this.pds != null)
/* 308 */       this.pds.start();
/* 309 */     if (this.sinkstream != null) {
/* 310 */       this.sinkstream.start();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void createDS() {}
/*     */   
/*     */   public int setBitRate(int rate)
/*     */   {
/* 319 */     if (this.sinkstream != null)
/* 320 */       this.sinkstream.rate = rate;
/* 321 */     return rate;
/*     */   }
/*     */   
/*     */   public TransmissionStats getSourceTransmissionStats() {
/* 325 */     return this.stats;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\rtp\SendSSRCInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */