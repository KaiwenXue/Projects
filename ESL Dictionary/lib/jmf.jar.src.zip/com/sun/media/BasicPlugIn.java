/*     */ package com.sun.media;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Vector;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Control;
/*     */ import javax.media.Format;
/*     */ import javax.media.PlugIn;
/*     */ import javax.media.PlugInManager;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ public abstract class BasicPlugIn
/*     */   implements PlugIn
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*  19 */   protected Object[] controls = new Control[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  45 */   private static boolean jdkInit = false;
/*     */   private static Method forName3ArgsM;
/*     */   private static Method getSystemClassLoaderM;
/*     */   private static ClassLoader systemClassLoader;
/*     */   private static Method getContextClassLoaderM;
/*     */   
/*     */   protected void error() {
/*  52 */     throw new RuntimeException(getClass().getName() + " PlugIn error");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object[] getControls()
/*     */   {
/*  59 */     return (Object[])this.controls;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getControl(String controlType)
/*     */   {
/*     */     try
/*     */     {
/*  67 */       Class cls = Class.forName(controlType);
/*  68 */       Object[] cs = getControls();
/*  69 */       for (int i = 0; i < cs.length; i++) {
/*  70 */         if (cls.isInstance(cs[i]))
/*  71 */           return cs[i];
/*     */       }
/*  73 */       return null;
/*     */     }
/*     */     catch (Exception e) {}
/*  76 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Format matches(Format in, Format[] outs)
/*     */   {
/*  84 */     for (int i = 0; i < outs.length; i++) {
/*  85 */       if (in.matches(outs[i])) {
/*  86 */         return outs[i];
/*     */       }
/*     */     }
/*  89 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] validateByteArraySize(Buffer buffer, int newSize)
/*     */   {
/* 100 */     Object objectArray = buffer.getData();
/*     */     
/*     */     byte[] typedArray;
/* 103 */     if ((objectArray instanceof byte[])) {
/* 104 */       typedArray = (byte[])objectArray;
/* 105 */       if (typedArray.length >= newSize) {
/* 106 */         return typedArray;
/*     */       }
/*     */       
/* 109 */       byte[] tempArray = new byte[newSize];
/* 110 */       System.arraycopy(typedArray, 0, tempArray, 0, typedArray.length);
/* 111 */       typedArray = tempArray;
/*     */     } else {
/* 113 */       typedArray = new byte[newSize];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 119 */     buffer.setData(typedArray);
/* 120 */     return typedArray;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected short[] validateShortArraySize(Buffer buffer, int newSize)
/*     */   {
/* 128 */     Object objectArray = buffer.getData();
/*     */     
/*     */     short[] typedArray;
/* 131 */     if ((objectArray instanceof short[])) {
/* 132 */       typedArray = (short[])objectArray;
/* 133 */       if (typedArray.length >= newSize) {
/* 134 */         return typedArray;
/*     */       }
/*     */       
/* 137 */       short[] tempArray = new short[newSize];
/* 138 */       System.arraycopy(typedArray, 0, tempArray, 0, typedArray.length);
/* 139 */       typedArray = tempArray;
/*     */     } else {
/* 141 */       typedArray = new short[newSize];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 147 */     buffer.setData(typedArray);
/* 148 */     return typedArray;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int[] validateIntArraySize(Buffer buffer, int newSize)
/*     */   {
/* 155 */     Object objectArray = buffer.getData();
/*     */     
/*     */     int[] typedArray;
/* 158 */     if ((objectArray instanceof int[])) {
/* 159 */       typedArray = (int[])objectArray;
/* 160 */       if (typedArray.length >= newSize) {
/* 161 */         return typedArray;
/*     */       }
/*     */       
/* 164 */       int[] tempArray = new int[newSize];
/* 165 */       System.arraycopy(typedArray, 0, tempArray, 0, typedArray.length);
/* 166 */       typedArray = tempArray;
/*     */     } else {
/* 168 */       typedArray = new int[newSize];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 174 */     buffer.setData(typedArray);
/* 175 */     return typedArray;
/*     */   }
/*     */   
/*     */   protected final long getNativeData(Object data) {
/* 179 */     if ((data instanceof NBA)) {
/* 180 */       return ((NBA)data).getNativeData();
/*     */     }
/* 182 */     return 0L;
/*     */   }
/*     */   
/*     */   protected Object getInputData(Buffer inBuffer) {
/* 186 */     Object inData = null;
/* 187 */     if ((inBuffer instanceof ExtBuffer)) {
/* 188 */       ((ExtBuffer)inBuffer).setNativePreferred(true);
/* 189 */       inData = ((ExtBuffer)inBuffer).getNativeData();
/*     */     }
/* 191 */     if (inData == null)
/* 192 */       inData = inBuffer.getData();
/* 193 */     return inData;
/*     */   }
/*     */   
/*     */   protected Object getOutputData(Buffer buffer) {
/* 197 */     Object data = null;
/* 198 */     if ((buffer instanceof ExtBuffer)) {
/* 199 */       data = ((ExtBuffer)buffer).getNativeData();
/*     */     }
/* 201 */     if (data == null)
/* 202 */       data = buffer.getData();
/* 203 */     return data;
/*     */   }
/*     */   
/*     */   protected Object validateData(Buffer buffer, int length, boolean allowNative) {
/* 207 */     Format format = buffer.getFormat();
/* 208 */     Class dataType = format.getDataType();
/*     */     
/* 210 */     if ((length < 1) && (format != null) && 
/* 211 */       ((format instanceof VideoFormat))) {
/* 212 */       length = ((VideoFormat)format).getMaxDataLength();
/*     */     }
/*     */     
/* 215 */     if ((allowNative) && ((buffer instanceof ExtBuffer)) && (((ExtBuffer)buffer).isNativePreferred()))
/*     */     {
/* 217 */       ExtBuffer extb = (ExtBuffer)buffer;
/* 218 */       if ((extb.getNativeData() == null) || (extb.getNativeData().getSize() < length))
/*     */       {
/* 220 */         extb.setNativeData(new NBA(format.getDataType(), length)); }
/* 221 */       return extb.getNativeData();
/*     */     }
/* 223 */     if (dataType == Format.byteArray)
/* 224 */       return validateByteArraySize(buffer, length);
/* 225 */     if (dataType == Format.shortArray)
/* 226 */       return validateShortArraySize(buffer, length);
/* 227 */     if (dataType == Format.intArray) {
/* 228 */       return validateIntArraySize(buffer, length);
/*     */     }
/* 230 */     System.err.println("Error in validateData");
/* 231 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean checkIfJDK12()
/*     */   {
/* 237 */     if (jdkInit)
/* 238 */       return forName3ArgsM != null;
/* 239 */     jdkInit = true;
/*     */     try {
/* 241 */       forName3ArgsM = class$java$lang$Class.getMethod("forName", new Class[] { String.class, Boolean.TYPE, ClassLoader.class });
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 246 */       getSystemClassLoaderM = ClassLoader.class.getMethod("getSystemClassLoader", null);
/*     */       
/*     */ 
/* 249 */       systemClassLoader = (ClassLoader)getSystemClassLoaderM.invoke(ClassLoader.class, null);
/*     */       
/* 251 */       getContextClassLoaderM = Thread.class.getMethod("getContextClassLoader", null);
/*     */       
/* 253 */       return true;
/*     */     } catch (Throwable t) {
/* 255 */       forName3ArgsM = null; }
/* 256 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class getClassForName(String className)
/*     */     throws ClassNotFoundException
/*     */   {
/*     */     try
/*     */     {
/* 271 */       return Class.forName(className);
/*     */     } catch (Exception e) {
/* 273 */       if (!checkIfJDK12()) {
/* 274 */         throw new ClassNotFoundException(e.getMessage());
/*     */       }
/*     */     } catch (Error e) {
/* 277 */       if (!checkIfJDK12()) {
/* 278 */         throw e;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 288 */         return (Class)forName3ArgsM.invoke(class$java$lang$Class, new Object[] { className, new Boolean(true), systemClassLoader });
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/*     */ 
/*     */ 
/* 300 */           ClassLoader contextClassLoader = (ClassLoader)getContextClassLoaderM.invoke(Thread.currentThread(), null);
/*     */           
/* 302 */           return (Class)forName3ArgsM.invoke(class$java$lang$Class, new Object[] { className, new Boolean(true), contextClassLoader });
/*     */         }
/*     */         catch (Exception e) {
/* 305 */           throw new ClassNotFoundException(e.getMessage());
/*     */         } catch (Error e) {
/* 307 */           throw e;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean plugInExists(String name, int type)
/*     */   {
/* 315 */     Vector cnames = PlugInManager.getPlugInList(null, null, type);
/* 316 */     for (int i = 0; i < cnames.size(); i++) {
/* 317 */       if (name.equals((String)cnames.elementAt(i)))
/* 318 */         return true;
/*     */     }
/* 320 */     return false;
/*     */   }
/*     */   
/*     */   public abstract void reset();
/*     */   
/*     */   public abstract void close();
/*     */   
/*     */   public abstract void open()
/*     */     throws ResourceUnavailableException;
/*     */   
/*     */   public abstract String getName();
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\BasicPlugIn.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */