/*     */ package com.sun.media;
/*     */ 
/*     */ import com.ms.security.PermissionID;
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.rtp.util.RTPTimeBase;
/*     */ import com.sun.media.util.LoopThread;
/*     */ import com.sun.media.util.MediaThread;
/*     */ import com.sun.media.util.jdk12;
/*     */ import com.sun.media.util.jdk12PriorityAction;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Vector;
/*     */ import javax.media.BadHeaderException;
/*     */ import javax.media.Controls;
/*     */ import javax.media.Demultiplexer;
/*     */ import javax.media.Duration;
/*     */ import javax.media.Format;
/*     */ import javax.media.IncompatibleSourceException;
/*     */ import javax.media.MediaHandler;
/*     */ import javax.media.PlugIn;
/*     */ import javax.media.PlugInManager;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.SystemTimeBase;
/*     */ import javax.media.Time;
/*     */ import javax.media.Track;
/*     */ import javax.media.format.AudioFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ import javax.media.protocol.ContentDescriptor;
/*     */ import javax.media.protocol.DataSource;
/*     */ import javax.media.protocol.Positionable;
/*     */ import javax.media.protocol.PullDataSource;
/*     */ import javax.media.protocol.PushDataSource;
/*     */ import javax.media.protocol.SourceStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicSourceModule
/*     */   extends BasicModule
/*     */   implements Duration, Positionable
/*     */ {
/*     */   PlaybackEngine engine;
/*     */   protected DataSource source;
/*     */   protected Demultiplexer parser;
/*  55 */   protected Track[] tracks = new Track[0];
/*     */   protected SourceThread[] loops;
/*     */   protected String[] connectorNames;
/*  58 */   protected long bitsRead = 0L;
/*     */   
/*     */ 
/*  61 */   private static JMFSecurity jmfSecurity = null;
/*  62 */   private static boolean securityPrivelege = false;
/*  63 */   private Method[] m = new Method[1];
/*  64 */   private Class[] cl = new Class[1];
/*  65 */   private Object[][] args = new Object[1][0];
/*  66 */   Object resetSync = new Object();
/*     */   
/*  68 */   protected boolean started = false;
/*  69 */   protected SystemTimeBase systemTimeBase = new SystemTimeBase();
/*  70 */   protected long lastSystemTime = 0L;
/*  71 */   protected long originSystemTime = 0L;
/*  72 */   protected long currentSystemTime = 0L;
/*     */   
/*  74 */   protected Time lastPositionSet = new Time(0L);
/*     */   
/*     */ 
/*  77 */   RTPTimeBase rtpMapperUpdatable = null;
/*  78 */   RTPTimeBase rtpMapper = null;
/*  79 */   long currentRTPTime = 0L;
/*  80 */   long oldOffset = 0L;
/*  81 */   boolean rtpOffsetInvalid = true;
/*  82 */   String cname = null;
/*     */   
/*     */   static
/*     */   {
/*     */     try {
/*  87 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  88 */       securityPrivelege = true;
/*     */     }
/*     */     catch (SecurityException e) {}
/*     */   }
/*     */   
/*     */   public static BasicSourceModule createModule(DataSource ds)
/*     */     throws IOException, IncompatibleSourceException
/*     */   {
/*  96 */     Demultiplexer parser = createDemultiplexer(ds);
/*  97 */     if (parser == null)
/*  98 */       return null;
/*  99 */     return new BasicSourceModule(ds, parser);
/*     */   }
/*     */   
/*     */   protected BasicSourceModule(DataSource ds, Demultiplexer demux)
/*     */   {
/* 104 */     this.source = ds;
/* 105 */     this.parser = demux;
/*     */     
/* 107 */     SourceStream stream = null;
/* 108 */     if ((this.source instanceof PullDataSource)) {
/* 109 */       stream = ((PullDataSource)this.source).getStreams()[0];
/* 110 */     } else if ((this.source instanceof PushDataSource)) {
/* 111 */       stream = ((PushDataSource)this.source).getStreams()[0];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static Demultiplexer createDemultiplexer(DataSource ds)
/*     */     throws IOException, IncompatibleSourceException
/*     */   {
/* 123 */     ContentDescriptor cd = new ContentDescriptor(ds.getContentType());
/* 124 */     Vector cnames = PlugInManager.getPlugInList(cd, null, 1);
/*     */     
/* 126 */     Demultiplexer parser = null;
/* 127 */     IOException ioe = null;
/* 128 */     IncompatibleSourceException ise = null;
/* 129 */     for (int i = 0; i < cnames.size(); i++) {
/*     */       try
/*     */       {
/* 132 */         Class cls = BasicPlugIn.getClassForName((String)cnames.elementAt(i));
/* 133 */         Object p = cls.newInstance();
/*     */         
/* 135 */         if ((p instanceof Demultiplexer)) {
/* 136 */           parser = (Demultiplexer)p;
/*     */           try {
/* 138 */             parser.setSource(ds);
/*     */           } catch (IOException e) {
/* 140 */             parser = null;
/* 141 */             ioe = e;
/* 142 */             continue;
/*     */           } catch (IncompatibleSourceException e) {
/* 144 */             parser = null;
/* 145 */             ise = e;
/* 146 */             continue;
/*     */           }
/* 148 */           break;
/*     */         }
/*     */       }
/*     */       catch (ClassNotFoundException e) {}catch (InstantiationException e) {}catch (IllegalAccessException e) {}
/*     */     }
/*     */     
/*     */ 
/* 155 */     if (parser == null) {
/* 156 */       if (ioe != null)
/* 157 */         throw ioe;
/* 158 */       if (ise != null)
/* 159 */         throw ise;
/*     */     }
/* 161 */     return parser;
/*     */   }
/*     */   
/* 164 */   public String errMsg = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean doRealize()
/*     */   {
/*     */     try
/*     */     {
/* 172 */       this.parser.open();
/*     */     } catch (ResourceUnavailableException e) {
/* 174 */       this.errMsg = ("Resource unavailable: " + e.getMessage());
/* 175 */       return false;
/*     */     }
/*     */     try
/*     */     {
/* 179 */       this.parser.start();
/* 180 */       this.tracks = this.parser.getTracks();
/*     */     } catch (BadHeaderException e) {
/* 182 */       this.errMsg = ("Bad header in the media: " + e.getMessage());
/* 183 */       this.parser.close();
/* 184 */       return false;
/*     */     } catch (IOException e) {
/* 186 */       this.errMsg = ("IO exception: " + e.getMessage());
/* 187 */       this.parser.close();
/* 188 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 192 */     if ((this.tracks == null) || (this.tracks.length == 0)) {
/* 193 */       this.errMsg = "The media has 0 track";
/* 194 */       this.parser.close();
/* 195 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 200 */     if (jmfSecurity != null) {
/* 201 */       String permission = null;
/*     */       try {
/* 203 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 204 */           permission = "thread";
/* 205 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/* 206 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */           
/* 208 */           permission = "thread group";
/* 209 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/* 210 */           this.m[0].invoke(this.cl[0], this.args[0]);
/* 211 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/* 212 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/* 213 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 220 */         securityPrivelege = false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 226 */     this.loops = new SourceThread[this.tracks.length];
/* 227 */     this.connectorNames = new String[this.tracks.length];
/* 228 */     for (int i = 0; i < this.tracks.length; i++) {
/* 229 */       MyOutputConnector oc = new MyOutputConnector(this.tracks[i]);
/* 230 */       oc.setProtocol(0);
/* 231 */       oc.setSize(1);
/* 232 */       this.connectorNames[i] = this.tracks[i].toString();
/* 233 */       registerOutputConnector(this.tracks[i].toString(), oc);
/* 234 */       this.loops[i] = null;
/*     */     }
/*     */     
/* 237 */     this.engine = ((PlaybackEngine)getController());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 243 */     if ((this.engine == null) || (!this.engine.isRTP())) {
/* 244 */       this.parser.stop();
/*     */     }
/* 246 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   SourceThread createSourceThread(int idx)
/*     */   {
/* 255 */     SourceThread thread = null;
/* 256 */     MyOutputConnector oc = (MyOutputConnector)getOutputConnector(this.connectorNames[idx]);
/*     */     
/*     */ 
/* 259 */     if ((oc == null) || (oc.getInputConnector() == null)) {
/* 260 */       this.tracks[idx].setEnabled(false);
/* 261 */       return null;
/*     */     }
/*     */     
/* 264 */     if (jmfSecurity != null) {
/* 265 */       String permission = null;
/*     */       try {
/* 267 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/* 268 */           permission = "thread";
/* 269 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/*     */           
/* 271 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */           
/* 273 */           permission = "thread group";
/* 274 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/*     */           
/* 276 */           this.m[0].invoke(this.cl[0], this.args[0]);
/* 277 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/* 278 */           PolicyEngine.checkPermission(PermissionID.THREAD);
/* 279 */           PolicyEngine.assertPermission(PermissionID.THREAD);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/* 286 */         securityPrivelege = false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 292 */     if ((jmfSecurity != null) && (jmfSecurity.getName().startsWith("jdk12")))
/*     */     {
/*     */       try {
/* 295 */         Constructor cons = CreateSourceThreadAction.cons;
/* 296 */         Constructor pcons = jdk12PriorityAction.cons;
/*     */         
/* 298 */         thread = (SourceThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { SourceThread.class, this, oc, new Integer(idx) }) });
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         int priority;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 309 */         if ((this.tracks[idx].getFormat() instanceof AudioFormat)) {
/* 310 */           priority = MediaThread.getAudioPriority();
/*     */         } else {
/* 312 */           priority = MediaThread.getVideoPriority();
/*     */         }
/* 314 */         thread.useVideoPriority();
/*     */         
/* 316 */         jdk12.doPrivM.invoke(jdk12.ac, new Object[] { pcons.newInstance(new Object[] { thread, new Integer(priority) }) });
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 326 */         thread = null;
/*     */       }
/*     */     }
/*     */     else {
/* 330 */       thread = new SourceThread(this, oc, idx);
/*     */       
/*     */ 
/* 333 */       if ((this.tracks[idx].getFormat() instanceof AudioFormat)) {
/* 334 */         thread.useAudioPriority();
/*     */       } else {
/* 336 */         thread.useVideoPriority();
/*     */       }
/*     */     }
/* 339 */     if (thread == null)
/*     */     {
/* 341 */       this.tracks[idx].setEnabled(false);
/*     */     }
/*     */     
/* 344 */     return thread;
/*     */   }
/*     */   
/*     */   public void doFailedRealize()
/*     */   {
/* 349 */     this.parser.stop();
/* 350 */     this.parser.close();
/*     */   }
/*     */   
/*     */   public void abortRealize() {
/* 354 */     this.parser.stop();
/* 355 */     this.parser.close();
/*     */   }
/*     */   
/*     */   public boolean doPrefetch() {
/* 359 */     super.doPrefetch();
/* 360 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void abortPrefetch()
/*     */   {
/* 367 */     doStop();
/*     */   }
/*     */   
/*     */   public void doStart()
/*     */   {
/* 372 */     this.lastSystemTime = this.systemTimeBase.getNanoseconds();
/* 373 */     this.originSystemTime = this.currentSystemTime;
/*     */     
/* 375 */     this.rtpOffsetInvalid = true;
/*     */     
/* 377 */     super.doStart();
/*     */     try {
/* 379 */       this.parser.start();
/*     */     }
/*     */     catch (IOException e) {}
/* 382 */     for (int i = 0; i < this.loops.length; i++)
/*     */     {
/*     */ 
/* 385 */       if ((this.tracks[i].isEnabled()) && (
/* 386 */         (this.loops[i] != null) || ((this.loops[i] = createSourceThread(i)) != null)))
/*     */       {
/*     */ 
/*     */ 
/* 390 */         this.loops[i].start();
/*     */       }
/*     */     }
/*     */     
/* 394 */     this.started = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doStop()
/*     */   {
/* 402 */     this.started = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void pause()
/*     */   {
/* 409 */     synchronized (this.resetSync) {
/* 410 */       for (int i = 0; i < this.loops.length; i++) {
/* 411 */         if ((this.tracks[i].isEnabled()) && (this.loops[i] != null) && (!this.loops[i].resetted))
/* 412 */           this.loops[i].pause();
/*     */       }
/* 414 */       this.parser.stop();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void doClose()
/*     */   {
/* 422 */     this.parser.close();
/* 423 */     if (this.tracks == null) {
/* 424 */       return;
/*     */     }
/* 426 */     for (int i = 0; i < this.tracks.length; i++) {
/* 427 */       if (this.loops[i] != null) {
/* 428 */         this.loops[i].kill();
/*     */       }
/*     */     }
/* 431 */     if (this.rtpMapperUpdatable != null) {
/* 432 */       RTPTimeBase.returnMapperUpdatable(this.rtpMapperUpdatable);
/* 433 */       this.rtpMapperUpdatable = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void reset() {
/* 438 */     synchronized (this.resetSync) {
/* 439 */       super.reset();
/* 440 */       for (int i = 0; i < this.loops.length; i++) {
/* 441 */         if ((this.tracks[i].isEnabled()) && (
/* 442 */           (this.loops[i] != null) || ((this.loops[i] = createSourceThread(i)) != null)))
/*     */         {
/*     */ 
/*     */ 
/* 446 */           this.loops[i].resetted = true;
/* 447 */           this.loops[i].start();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getOutputConnectorNames()
/*     */   {
/* 458 */     return this.connectorNames;
/*     */   }
/*     */   
/*     */   public Time getDuration() {
/* 462 */     return this.parser.getDuration();
/*     */   }
/*     */   
/*     */   public Time setPosition(Time when, int rounding) {
/* 466 */     Time t = this.parser.setPosition(when, rounding);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 474 */     if (this.lastPositionSet.getNanoseconds() == t.getNanoseconds()) {
/* 475 */       this.lastPositionSet = new Time(t.getNanoseconds() + 1L);
/*     */     } else
/* 477 */       this.lastPositionSet = t;
/* 478 */     return t;
/*     */   }
/*     */   
/*     */   public boolean isPositionable() {
/* 482 */     return this.parser.isPositionable();
/*     */   }
/*     */   
/*     */   public boolean isRandomAccess() {
/* 486 */     return this.parser.isRandomAccess();
/*     */   }
/*     */   
/*     */   public Object[] getControls() {
/* 490 */     return this.parser.getControls();
/*     */   }
/*     */   
/*     */   public Object getControl(String s) {
/* 494 */     return this.parser.getControl(s);
/*     */   }
/*     */   
/*     */   public Demultiplexer getDemultiplexer() {
/* 498 */     return this.parser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getBitsRead()
/*     */   {
/* 510 */     return this.bitsRead;
/*     */   }
/*     */   
/*     */   public void resetBitsRead() {
/* 514 */     this.bitsRead = 0L;
/*     */   }
/*     */   
/*     */   boolean readHasBlocked() {
/* 518 */     if (this.loops == null) return false;
/* 519 */     for (int i = 0; i < this.loops.length; i++) {
/* 520 */       if ((this.loops[i] != null) && (this.loops[i].readBlocked))
/* 521 */         return true;
/*     */     }
/* 523 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 528 */   int latencyTrack = -1;
/*     */   
/*     */ 
/*     */ 
/*     */   public void checkLatency()
/*     */   {
/* 534 */     if (this.latencyTrack > -1) {
/* 535 */       if ((this.tracks[this.latencyTrack].isEnabled()) && (this.loops[this.latencyTrack] != null)) {
/* 536 */         this.loops[this.latencyTrack].checkLatency = true;
/* 537 */         return;
/*     */       }
/* 539 */       this.latencyTrack = -1;
/*     */     }
/*     */     
/*     */ 
/* 543 */     for (int i = 0; i < this.tracks.length; i++)
/*     */     {
/* 545 */       if (this.tracks[i].isEnabled())
/*     */       {
/*     */ 
/* 548 */         this.latencyTrack = i;
/* 549 */         if ((this.tracks[i].getFormat() instanceof VideoFormat)) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 555 */     if ((this.latencyTrack > -1) && (this.loops[this.latencyTrack] != null)) {
/* 556 */       this.loops[this.latencyTrack].checkLatency = true;
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean checkAllPaused() {
/* 561 */     for (int i = 0; i < this.loops.length; i++) {
/* 562 */       if ((this.tracks[i].isEnabled()) && (this.loops[i] != null) && (!this.loops[i].isPaused()))
/* 563 */         return false;
/*     */     }
/* 565 */     return true;
/*     */   }
/*     */   
/*     */   public void doFailedPrefetch() {}
/*     */   
/*     */   public void doDealloc() {}
/*     */   
/*     */   public void setFormat(Connector connector, Format format) {}
/*     */   
/*     */   public void process() {}
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\BasicSourceModule.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */