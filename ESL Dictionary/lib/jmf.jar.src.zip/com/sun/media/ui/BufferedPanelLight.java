/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.peer.LightweightPeer;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ public class BufferedPanelLight extends Container
/*     */ {
/*     */   protected boolean buffered;
/*     */   protected boolean autoFlushing;
/*     */   protected Image background;
/*     */   protected boolean windowCreated;
/*     */   protected transient Image buffer;
/*     */   protected transient Graphics bufferGraphics;
/*     */   protected transient Region damage;
/*     */   
/*     */   public BufferedPanelLight(LayoutManager layout)
/*     */   {
/*  27 */     setLayout(layout);
/*     */     
/*  29 */     this.buffered = true;
/*  30 */     this.autoFlushing = true;
/*  31 */     this.background = null;
/*  32 */     this.windowCreated = false;
/*  33 */     this.buffer = null;
/*  34 */     this.bufferGraphics = null;
/*  35 */     this.damage = new Region();
/*     */   }
/*     */   
/*     */   public BufferedPanelLight() {
/*  39 */     this(null);
/*     */   }
/*     */   
/*     */   public boolean isBuffered() {
/*  43 */     return this.buffered;
/*     */   }
/*     */   
/*     */   public void setBuffered(boolean buffered) {
/*  47 */     if (buffered != this.buffered) {
/*  48 */       this.buffered = buffered;
/*  49 */       if (buffered) {
/*  50 */         repaint();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isAutoFlushing() {
/*  56 */     return this.autoFlushing;
/*     */   }
/*     */   
/*     */   public void setAutoFlushing(boolean flushing) {
/*  60 */     if (flushing != this.autoFlushing) {
/*  61 */       this.autoFlushing = flushing;
/*     */     }
/*     */   }
/*     */   
/*     */   public Image getBackgroundTile() {
/*  66 */     return this.background;
/*     */   }
/*     */   
/*     */   public void setBackgroundTile(Image background) {
/*  70 */     this.background = background;
/*  71 */     repaint();
/*     */   }
/*     */   
/*     */   public void addNotify() {
/*  75 */     super.addNotify();
/*  76 */     this.windowCreated = true;
/*  77 */     if (this.buffered) {
/*  78 */       createBufferImage();
/*  79 */       repaint();
/*     */     }
/*     */   }
/*     */   
/*     */   public void reshape(int x, int y, int width, int height) {
/*  84 */     Rectangle old = getBounds();
/*     */     
/*  86 */     super.reshape(x, y, width, height);
/*  87 */     if ((this.windowCreated) && ((width != old.width) || (height != old.height)))
/*     */     {
/*  89 */       if (this.buffered)
/*     */       {
/*  91 */         createBufferImage();
/*  92 */         repaint();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void flushBuffer() {
/*  98 */     Dimension size = getSize();
/*  99 */     super.repaint(0L, 0, 0, size.width, size.height);
/*     */   }
/*     */   
/*     */   void createBufferImage()
/*     */   {
/* 104 */     Dimension size = getSize();
/*     */     
/* 106 */     if ((size.width > 0) && (size.height > 0))
/*     */     {
/* 108 */       this.buffer = createImage(size.width, size.height);
/* 109 */       if (this.buffer != null) {
/* 110 */         this.bufferGraphics = this.buffer.getGraphics();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void renderBuffer()
/*     */   {
/* 120 */     if (this.damage.isEmpty()) {
/* 121 */       return;
/*     */     }
/*     */     
/*     */ 
/* 125 */     if (this.buffer == null) {
/*     */       return;
/*     */     }
/*     */     
/*     */     Region rects;
/* 130 */     synchronized (this.damage) {
/* 131 */       rects = this.damage;
/* 132 */       this.damage = new Region();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 137 */     for (Enumeration e = rects.rectangles(); e.hasMoreElements();) {
/* 138 */       Rectangle rect = (Rectangle)e.nextElement();
/* 139 */       render(rect);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void render(Rectangle rect)
/*     */   {
/* 146 */     Component[] children = getComponents();
/*     */     
/*     */ 
/*     */ 
/* 150 */     synchronized (this.buffer)
/*     */     {
/* 152 */       this.bufferGraphics.setClip(rect);
/* 153 */       paintBackground(this.bufferGraphics);
/* 154 */       this.bufferGraphics.setColor(getForeground());
/*     */       
/*     */ 
/*     */ 
/* 158 */       for (int c = children.length - 1; c >= 0; c--) {
/* 159 */         Component child = children[c];
/* 160 */         if ((isLightweight(child)) && (child.isVisible())) {
/* 161 */           Rectangle clip = child.getBounds();
/* 162 */           if (clip.intersects(rect)) {
/* 163 */             Graphics g = this.bufferGraphics.create(clip.x, clip.y, clip.width, clip.height);
/*     */             
/* 165 */             child.paint(g);
/* 166 */             g.dispose();
/*     */           }
/*     */         }
/*     */       }
/* 170 */       this.bufferGraphics.setClip(0, 0, getSize().width, getSize().height);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void paintBackground(Graphics g) {
/* 175 */     Dimension size = getSize();
/*     */     
/* 177 */     if (this.background == null)
/*     */     {
/* 179 */       g.setColor(getBackground());
/* 180 */       g.fillRect(0, 0, size.width, size.height);
/*     */     }
/*     */     else {
/* 183 */       Rectangle tile = new Rectangle(0, 0, this.background.getWidth(this), this.background.getHeight(this));
/*     */       
/*     */ 
/* 186 */       Rectangle clip = g.getClipBounds();
/*     */       
/* 188 */       for (goto 149; tile.y < size.height;) {
/* 189 */         while (tile.x < size.width) {
/* 190 */           if ((clip == null) || (clip.intersects(tile))) {
/* 191 */             g.drawImage(this.background, tile.x, tile.y, this);
/*     */           }
/* 193 */           tile.x += tile.width;
/*     */         }
/* 195 */         tile.x = 0;
/* 196 */         tile.y += tile.height;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   boolean isLightweight(Component comp) {
/* 202 */     return comp.getPeer() instanceof LightweightPeer;
/*     */   }
/*     */   
/*     */   public void repaint(long time, int x, int y, int width, int height) {
/* 206 */     if (this.buffered) {
/* 207 */       synchronized (this.damage) {
/* 208 */         this.damage.addRectangle(new Rectangle(x, y, width, height));
/*     */       }
/* 210 */       if (this.autoFlushing) {
/* 211 */         flushBuffer();
/*     */       }
/*     */     } else {
/* 214 */       super.repaint(time, x, y, width, height);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void update(Graphics g)
/*     */   {
/* 221 */     if (this.buffered) {
/* 222 */       paint(g);
/*     */     } else {
/* 224 */       super.update(g);
/*     */     }
/*     */   }
/*     */   
/*     */   public void paint(Graphics g) {
/* 229 */     if ((this.buffered) && (this.buffer != null)) {
/* 230 */       renderBuffer();
/* 231 */       g.drawImage(this.buffer, 0, 0, this);
/*     */     } else {
/* 233 */       super.paint(g);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 244 */   protected Object lock = new Object();
/*     */   
/*     */   private void readObject(ObjectInputStream is)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 249 */     is.defaultReadObject();
/* 250 */     this.damage = new Region();
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\ui\BufferedPanelLight.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */