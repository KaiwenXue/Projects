/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Window;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToolTip
/*     */   extends Window
/*     */ {
/*     */   private static final int MARGIN_HORZ = 4;
/*     */   private static final int MARGIN_VERT = 2;
/*  44 */   private String[] arrStrings = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ToolTip(String strText)
/*     */   {
/*  51 */     super(new Frame());
/*     */     
/*     */ 
/*     */ 
/*  55 */     this.arrStrings = new String[1];
/*  56 */     this.arrStrings[0] = new String(strText);
/*  57 */     Font font = new Font("Helvetica", 0, 10);
/*  58 */     setFont(font);
/*  59 */     resizePopup();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ToolTip(String[] arrStrings)
/*     */   {
/*  67 */     super(new Frame());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  72 */     arrStrings = new String[arrStrings.length];
/*  73 */     for (int i = 0; i < arrStrings.length; i++)
/*  74 */       arrStrings[i] = new String(arrStrings[i]);
/*  75 */     Font font = new Font("Helvetica", 0, 10);
/*  76 */     setFont(font);
/*  77 */     resizePopup();
/*     */   }
/*     */   
/*     */   public void setText(String strText) {
/*  81 */     this.arrStrings = new String[1];
/*  82 */     this.arrStrings[0] = new String(strText);
/*  83 */     resizePopup();
/*  84 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void paint(Graphics graphics)
/*     */   {
/* 100 */     Rectangle rect = getBounds();
/* 101 */     Font font = getFont();
/* 102 */     FontMetrics fontMetrics = getFontMetrics(font);
/*     */     
/* 104 */     graphics.setColor(new Color(255, 255, 192));
/* 105 */     graphics.fillRect(0, 0, rect.width, rect.height);
/*     */     
/* 107 */     graphics.setColor(Color.black);
/* 108 */     graphics.drawRect(0, 0, rect.width - 1, rect.height - 1);
/*     */     
/* 110 */     int nX = 4;
/* 111 */     int nY = 2 + fontMetrics.getAscent();
/* 112 */     int nHeight = fontMetrics.getHeight();
/* 113 */     for (int i = 0; i < this.arrStrings.length; i++) {
/* 114 */       graphics.drawString(this.arrStrings[i], nX, nY);
/* 115 */       nY += nHeight;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void resizePopup()
/*     */   {
/* 124 */     int nWidth = 0;
/* 125 */     int nHeight = 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */     Rectangle rect = getBounds();
/* 134 */     Font font = getFont();
/* 135 */     FontMetrics fontMetrics = getFontMetrics(font);
/*     */     
/* 137 */     for (int i = 0; i < this.arrStrings.length; i++) {
/* 138 */       int nWidthText = fontMetrics.stringWidth(this.arrStrings[i]);
/* 139 */       nWidth = Math.max(nWidth, nWidthText);
/*     */     }
/* 141 */     nHeight = fontMetrics.getHeight() * this.arrStrings.length;
/*     */     
/* 143 */     rect.width = (nWidth + 8);
/* 144 */     rect.height = (nHeight + 4);
/* 145 */     Dimension dim = getSize();
/* 146 */     if ((dim.height != rect.height) || (rect.width > dim.width) || (rect.width < dim.width / 2)) {
/* 147 */       setBounds(rect);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\ui\ToolTip.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */