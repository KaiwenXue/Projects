/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import com.ms.security.PolicyEngine;
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.util.MediaThread;
/*     */ import com.sun.media.util.jdk12;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.CachingControl;
/*     */ import javax.media.CachingControlEvent;
/*     */ import javax.media.Clock;
/*     */ import javax.media.Controller;
/*     */ import javax.media.Duration;
/*     */ import javax.media.Player;
/*     */ import javax.media.Time;
/*     */ 
/*     */ public class ProgressSlider extends BasicComp implements java.awt.event.MouseListener, java.awt.event.MouseMotionListener, Runnable, java.awt.event.ComponentListener, javax.media.ControllerListener
/*     */ {
/*     */   Image imageGrabber;
/*     */   Image imageGrabberDown;
/*     */   int grabberWidth;
/*     */   int grabberHeight;
/*     */   boolean grabbed;
/*     */   boolean entered;
/*     */   int grabberPosition;
/*  36 */   int leftBorder = 0;
/*  37 */   int rightBorder = 0;
/*     */   int sliderWidth;
/*  39 */   MediaThread timer = null;
/*  40 */   protected boolean justSeeked = false;
/*  41 */   protected boolean stopTimer = false;
/*     */   
/*  43 */   private static JMFSecurity jmfSecurity = null;
/*  44 */   private static boolean securityPrivelege = false;
/*  45 */   private Method[] m = new Method[1];
/*  46 */   private Class[] cl = new Class[1];
/*  47 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   private Player player;
/*     */   private DefaultControlPanel controlPanel;
/*  51 */   private ToolTip toolTip = null;
/*  52 */   private double progressCaching = 1.0D;
/*     */   
/*  54 */   private boolean resetMediaTime = false;
/*     */   
/*     */   static {
/*     */     try {
/*  58 */       jmfSecurity = com.sun.media.JMFSecurityManager.getJMFSecurity();
/*  59 */       securityPrivelege = true;
/*     */     }
/*     */     catch (SecurityException e) {}
/*     */   }
/*     */   
/*     */   public ProgressSlider(String label, DefaultControlPanel cp, Player p) {
/*  65 */     super(label);
/*  66 */     this.player = p;
/*  67 */     this.controlPanel = cp;
/*     */     
/*  69 */     this.imageGrabber = BasicComp.fetchImage("grabber.gif");
/*  70 */     this.imageGrabberDown = BasicComp.fetchImage("grabber-pressed.gif");
/*     */     
/*     */ 
/*  73 */     this.grabberWidth = this.imageGrabber.getWidth(this);
/*  74 */     this.grabberHeight = this.imageGrabber.getHeight(this);
/*  75 */     this.leftBorder = (this.grabberWidth / 2);
/*  76 */     this.rightBorder = this.leftBorder;
/*     */     
/*  78 */     addMouseListener(this);
/*  79 */     addMouseMotionListener(this);
/*  80 */     this.grabberPosition = 0;
/*  81 */     this.grabbed = false;
/*  82 */     this.entered = false;
/*  83 */     this.height = 18;
/*  84 */     this.width = 20;
/*  85 */     this.sliderWidth = (this.width - this.leftBorder - this.rightBorder);
/*     */     
/*  87 */     addComponentListener(this);
/*  88 */     this.player.addControllerListener(this);
/*     */   }
/*     */   
/*     */   public void addNotify() {
/*  92 */     super.addNotify();
/*     */     
/*  94 */     if (jmfSecurity != null) {
/*  95 */       String permission = null;
/*     */       try {
/*  97 */         if (jmfSecurity.getName().startsWith("jmf-security")) {
/*  98 */           permission = "thread";
/*  99 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 16);
/* 100 */           this.m[0].invoke(this.cl[0], this.args[0]);
/*     */           
/* 102 */           permission = "thread group";
/* 103 */           jmfSecurity.requestPermission(this.m, this.cl, this.args, 32);
/* 104 */           this.m[0].invoke(this.cl[0], this.args[0]);
/* 105 */         } else if (jmfSecurity.getName().startsWith("internet")) {
/* 106 */           PolicyEngine.checkPermission(com.ms.security.PermissionID.THREAD);
/* 107 */           PolicyEngine.assertPermission(com.ms.security.PermissionID.THREAD);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/* 114 */         securityPrivelege = false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 120 */     if ((jmfSecurity != null) && (jmfSecurity.getName().startsWith("jdk12"))) {
/*     */       try {
/* 122 */         ProgressSlider slider = this;
/* 123 */         Constructor cons = com.sun.media.util.jdk12CreateThreadRunnableAction.cons;
/*     */         
/* 125 */         this.timer = ((MediaThread)jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { MediaThread.class, this }) }));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */         this.timer.setName("Progress Slider thread");
/*     */         
/*     */ 
/*     */ 
/* 138 */         cons = com.sun.media.util.jdk12PriorityAction.cons;
/* 139 */         jdk12.doPrivM.invoke(jdk12.ac, new Object[] { cons.newInstance(new Object[] { this.timer, new Integer(MediaThread.getControlPriority()) }) });
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 147 */         this.stopTimer = false;
/* 148 */         this.timer.start();
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     else
/*     */     {
/* 154 */       this.timer = new MediaThread(this);
/* 155 */       this.timer.setName("Progress Slider thread");
/* 156 */       this.timer.useControlPriority();
/* 157 */       this.stopTimer = false;
/* 158 */       this.timer.start();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 167 */   Object disposeLock = new Object();
/* 168 */   Object syncStop = new Object();
/*     */   
/*     */   public void removeNotify() {
/* 171 */     if (this.timer != null) {
/* 172 */       synchronized (this.syncStop) {
/* 173 */         this.stopTimer = true;
/* 174 */         this.timer = null;
/*     */       }
/*     */     }
/* 177 */     synchronized (this.disposeLock) {
/* 178 */       if (this.toolTip != null) {
/* 179 */         this.toolTip.setVisible(false);
/*     */       }
/*     */     }
/*     */     
/* 183 */     super.removeNotify();
/*     */   }
/*     */   
/*     */   public synchronized void dispose() {
/* 187 */     synchronized (this.syncStop) {
/* 188 */       if (this.timer != null) {
/* 189 */         this.stopTimer = true;
/*     */       }
/*     */     }
/* 192 */     removeMouseListener(this);
/* 193 */     removeMouseMotionListener(this);
/* 194 */     removeComponentListener(this);
/* 195 */     synchronized (this.disposeLock) {
/* 196 */       if (this.toolTip != null) {
/* 197 */         this.toolTip.dispose();
/* 198 */         this.toolTip = null;
/*     */       }
/*     */     }
/* 201 */     this.timer = null;
/* 202 */     this.player = null;
/*     */   }
/*     */   
/*     */   public void run() {
/* 206 */     int counter = 0;
/* 207 */     int pausecnt = -1;
/*     */     
/* 209 */     boolean doUpdate = true;
/*     */     
/* 211 */     while (!this.stopTimer) {
/*     */       try {
/* 213 */         if ((this.player != null) && (this.player.getState() == 600)) {
/* 214 */           doUpdate = true;
/* 215 */           pausecnt = -1;
/* 216 */         } else if ((this.player != null) && (pausecnt < 5)) {
/* 217 */           pausecnt++;
/* 218 */           doUpdate = true;
/* 219 */         } else if (this.resetMediaTime) {
/* 220 */           doUpdate = true;
/* 221 */           this.resetMediaTime = false;
/*     */         } else {
/* 223 */           doUpdate = false;
/*     */         }
/*     */         try
/*     */         {
/* 227 */           if (doUpdate) {
/* 228 */             long nanoDuration = this.player.getDuration().getNanoseconds();
/*     */             
/* 230 */             if (nanoDuration > 0L) {
/* 231 */               long nanoTime = this.player.getMediaNanoseconds();
/*     */               
/*     */ 
/* 234 */               seek((float)nanoTime / (float)nanoDuration);
/* 235 */               if (!this.grabbed) {
/* 236 */                 updateToolTip(nanoTime);
/*     */               }
/*     */             }
/*     */           }
/*     */         } catch (Exception e) {}
/* 241 */         int sleepTime = isEnabled() ? 200 : 1000;
/*     */         try {
/* 243 */           Thread.sleep(sleepTime);
/*     */         } catch (Exception e) {}
/* 245 */         counter++;
/* 246 */         if (counter == 1000 / sleepTime) {
/* 247 */           counter = 0;
/* 248 */           this.controlPanel.update();
/*     */         }
/*     */         
/* 251 */         if (this.justSeeked) {
/* 252 */           this.justSeeked = false;
/* 253 */           try { Thread.sleep(1000L);
/*     */           }
/*     */           catch (Exception e) {}
/*     */         }
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void paint(Graphics g)
/*     */   {
/* 271 */     if (isEnabled()) {
/* 272 */       int y = this.height / 2 - 2;
/* 273 */       int grabberY = this.height / 2 - this.grabberHeight / 2;
/* 274 */       g.setColor(getBackground().darker());
/* 275 */       g.drawRect(this.leftBorder, y, this.sliderWidth, 3);
/* 276 */       g.setColor(getBackground());
/* 277 */       int downloadCredit = this.grabberWidth;
/* 278 */       g.draw3DRect(this.leftBorder, y, (int)((this.sliderWidth - downloadCredit) * this.progressCaching + downloadCredit), 3, false);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 301 */       if ((this.grabbed) || (this.entered)) {
/* 302 */         g.drawImage(this.imageGrabberDown, this.grabberPosition + this.leftBorder - this.grabberWidth / 2, grabberY, this);
/*     */       }
/*     */       else
/*     */       {
/* 306 */         g.drawImage(this.imageGrabber, this.grabberPosition + this.leftBorder - this.grabberWidth / 2, grabberY, this);
/*     */       }
/*     */       
/*     */     }
/* 310 */     else if (this.player != null) {
/* 311 */       String strTime = formatTime(this.player.getMediaNanoseconds());
/* 312 */       java.awt.Font font = getFont();
/* 313 */       g.setFont(font);
/* 314 */       FontMetrics fontMetrics = getFontMetrics(font);
/* 315 */       g.drawString(strTime, 2, 2 + fontMetrics.getAscent());
/*     */     }
/*     */   }
/*     */   
/*     */   private void sliderSeek(float fraction) {
/* 320 */     if (this.player == null)
/* 321 */       return;
/* 322 */     long value = (fraction * (float)this.player.getDuration().getNanoseconds());
/* 323 */     this.justSeeked = true;
/* 324 */     if (value >= 0L) {
/* 325 */       this.player.setMediaTime(new Time(value));
/* 326 */       this.controlPanel.resetPauseCount();
/* 327 */       this.controlPanel.update();
/*     */     }
/*     */   }
/*     */   
/*     */   public void seek(float fraction) {
/* 332 */     if (this.justSeeked)
/* 333 */       return;
/* 334 */     if (!this.grabbed) {
/* 335 */       int newPosition = (int)(fraction * this.sliderWidth);
/* 336 */       if (newPosition > this.sliderWidth)
/* 337 */         newPosition = this.sliderWidth;
/* 338 */       if (newPosition < 0)
/* 339 */         newPosition = 0;
/* 340 */       if ((this.grabberPosition != newPosition) || (!isEnabled())) {
/* 341 */         this.grabberPosition = newPosition;
/* 342 */         repaint();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 348 */     return new Dimension(20, this.height);
/*     */   }
/*     */   
/*     */   public float sliderToSeek(int x) {
/* 352 */     float s = x / this.sliderWidth;
/* 353 */     return s;
/*     */   }
/*     */   
/*     */   public int mouseToSlider(int x) {
/* 357 */     if (x < this.leftBorder)
/* 358 */       x = this.leftBorder;
/* 359 */     if (x > this.width - this.rightBorder) {
/* 360 */       x = this.width - this.rightBorder;
/*     */     }
/* 362 */     x -= this.leftBorder;
/* 363 */     return x;
/*     */   }
/*     */   
/*     */   public void mousePressed(MouseEvent me) {
/* 367 */     if (!isEnabled())
/* 368 */       return;
/* 369 */     this.grabbed = true;
/* 370 */     this.grabberPosition = mouseToSlider(me.getX());
/* 371 */     repaint();
/*     */   }
/*     */   
/*     */   public synchronized void mouseReleased(MouseEvent me) {
/* 375 */     if (!isEnabled())
/* 376 */       return;
/* 377 */     this.grabbed = false;
/* 378 */     this.grabberPosition = mouseToSlider(me.getX());
/* 379 */     float seek = sliderToSeek(this.grabberPosition);
/* 380 */     sliderSeek(seek);
/* 381 */     if ((this.toolTip != null) && (!this.entered)) {
/* 382 */       this.toolTip.dispose();
/* 383 */       this.toolTip = null;
/*     */     }
/* 385 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void mouseEntered(MouseEvent me)
/*     */   {
/* 395 */     this.entered = true;
/* 396 */     if ((this.toolTip == null) && (isEnabled()) && (this.player != null)) {
/* 397 */       this.toolTip = new ToolTip("time/duration");
/* 398 */       updateToolTip(this.player.getMediaNanoseconds());
/* 399 */       if (isShowing()) {
/* 400 */         Point pointScreen = getLocationOnScreen();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 405 */         pointScreen.y += this.height + 4;
/* 406 */         this.toolTip.setLocation(pointScreen);
/* 407 */         this.toolTip.show();
/*     */       }
/*     */     }
/* 410 */     repaint();
/*     */   }
/*     */   
/*     */   public synchronized void mouseExited(MouseEvent me) {
/* 414 */     if ((this.toolTip != null) && (!this.grabbed)) {
/* 415 */       this.toolTip.dispose();
/* 416 */       this.toolTip = null;
/*     */     }
/* 418 */     if (!isEnabled())
/* 419 */       return;
/* 420 */     this.entered = false;
/* 421 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void mouseMoved(MouseEvent me)
/*     */   {
/* 428 */     if ((this.toolTip != null) && (isShowing())) {
/* 429 */       Dimension dim = this.toolTip.getSize();
/* 430 */       Point pointScreen = getLocationOnScreen();
/* 431 */       pointScreen.x += me.getX() - dim.width - 2;
/* 432 */       pointScreen.y += me.getY();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void mouseDragged(MouseEvent me)
/*     */   {
/* 441 */     if ((!isEnabled()) || (this.player == null))
/* 442 */       return;
/* 443 */     int newPosition = mouseToSlider(me.getX());
/* 444 */     if (newPosition != this.grabberPosition) {
/* 445 */       this.grabberPosition = newPosition;
/* 446 */       float seek = sliderToSeek(this.grabberPosition);
/* 447 */       if (this.player.getState() != 600)
/* 448 */         sliderSeek(seek);
/* 449 */       long value = (seek * (float)this.player.getDuration().getNanoseconds());
/* 450 */       updateToolTip(value);
/* 451 */       repaint();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void componentResized(ComponentEvent event)
/*     */   {
/* 458 */     Dimension dim = getSize();
/* 459 */     if (dim.width - this.leftBorder - this.rightBorder < 1) {
/* 460 */       return;
/*     */     }
/* 462 */     this.grabberPosition = ((int)(this.grabberPosition * ((dim.width - this.leftBorder - this.rightBorder) / (this.width - this.leftBorder - this.rightBorder))));
/* 463 */     this.width = dim.width;
/* 464 */     this.sliderWidth = (this.width - this.leftBorder - this.rightBorder);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void controllerUpdate(javax.media.ControllerEvent event)
/*     */   {
/* 481 */     if ((event instanceof CachingControlEvent)) {
/* 482 */       CachingControl cachingControl = ((CachingControlEvent)event).getCachingControl();
/* 483 */       long length = cachingControl.getContentLength();
/* 484 */       long progress = cachingControl.getContentProgress();
/* 485 */       this.progressCaching = (progress / length);
/* 486 */       repaint();
/* 487 */     } else if ((event instanceof javax.media.MediaTimeSetEvent)) {
/* 488 */       this.resetMediaTime = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private String formatTime(Time time)
/*     */   {
/* 494 */     String strTime = new String("<unknown>");
/*     */     
/* 496 */     if ((time == null) || (time == Time.TIME_UNKNOWN) || (time == Duration.DURATION_UNKNOWN)) {
/* 497 */       return strTime;
/*     */     }
/* 499 */     long nano = time.getNanoseconds();
/* 500 */     strTime = formatTime(nano);
/* 501 */     return strTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String formatTime(long nanoSeconds)
/*     */   {
/* 514 */     int seconds = (int)(nanoSeconds / 1000000000L);
/* 515 */     int hours = seconds / 3600;
/* 516 */     int minutes = (seconds - hours * 3600) / 60;
/* 517 */     seconds = seconds - hours * 3600 - minutes * 60;
/* 518 */     nanoSeconds = nanoSeconds % 1000000000L / 10000000L;
/*     */     
/* 520 */     int hours10 = hours / 10;
/* 521 */     hours %= 10;
/* 522 */     int minutes10 = minutes / 10;
/* 523 */     minutes %= 10;
/* 524 */     int seconds10 = seconds / 10;
/* 525 */     seconds %= 10;
/* 526 */     long nano10 = nanoSeconds / 10L;
/* 527 */     nanoSeconds %= 10L;
/*     */     
/* 529 */     String strTime = new String("" + hours10 + hours + ":" + minutes10 + minutes + ":" + seconds10 + seconds + "." + nano10 + nanoSeconds);
/* 530 */     return strTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void updateToolTip(long nanoMedia)
/*     */   {
/* 537 */     if ((this.toolTip == null) || (this.player == null)) {
/* 538 */       return;
/*     */     }
/* 540 */     Time timeDuration = this.player.getDuration();
/* 541 */     String strTool = new String(formatTime(nanoMedia) + " / " + formatTime(timeDuration));
/* 542 */     this.toolTip.setText(strTool);
/*     */   }
/*     */   
/*     */   public void mouseClicked(MouseEvent me) {}
/*     */   
/*     */   public void componentMoved(ComponentEvent event) {}
/*     */   
/*     */   public void componentShown(ComponentEvent event) {}
/*     */   
/*     */   public void componentHidden(ComponentEvent event) {}
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\ui\ProgressSlider.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */