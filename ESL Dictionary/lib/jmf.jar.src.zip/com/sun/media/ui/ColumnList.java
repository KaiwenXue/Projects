/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class ColumnList extends java.awt.Canvas implements java.awt.event.MouseListener, java.awt.event.FocusListener, java.awt.event.KeyListener, java.awt.event.ComponentListener
/*     */ {
/*     */   public static final int TYPE_INTEGER = 1;
/*     */   public static final int TYPE_DOUBLE = 2;
/*     */   public static final int TYPE_STRING = 3;
/*     */   public static final int TYPE_DATE = 4;
/*     */   private static final int MARGIN_VERT = 2;
/*     */   private static final int MARGIN_HORZ = 6;
/*  24 */   private static final Color COLOR_HEADER_BG = Color.lightGray;
/*  25 */   private static final Color COLOR_HEADER_FG = Color.black;
/*  26 */   private static final Color COLOR_SHADOW_TOP = Color.white;
/*  27 */   private static final Color COLOR_SHADOW_BOTTOM = Color.darkGray;
/*     */   
/*     */ 
/*  30 */   private static final Color COLOR_SEL_BG = Color.white;
/*  31 */   private static final Color COLOR_SEL_FG = Color.black;
/*     */   
/*  33 */   private Vector vectorColumns = new Vector();
/*  34 */   private Vector vectorRows = new Vector();
/*     */   
/*  36 */   private boolean boolFocus = false;
/*  37 */   private boolean boolSetColumnWidthAsPreferred = false;
/*  38 */   private int nScrollPosHorz = 0;
/*  39 */   private int nScrollPosVert = 0;
/*  40 */   private int nCurrentIndex = 0;
/*  41 */   private int nVisibleRows = 1;
/*     */   
/*  43 */   private Font fontHeader = new Font("Dialog", 0, 12);
/*  44 */   private Font fontItem = new Font("Dialog", 0, 12);
/*     */   
/*     */ 
/*     */   private int nHeightHeader;
/*     */   
/*     */ 
/*     */   private int nHeightRow;
/*     */   
/*     */ 
/*     */   public ColumnList(String[] arrColumnNames)
/*     */   {
/*  55 */     int nCount = arrColumnNames.length;
/*  56 */     for (int i = 0; i < nCount; i++) {
/*  57 */       ColumnData column = new ColumnData(arrColumnNames[i], 3);
/*  58 */       this.vectorColumns.addElement(column);
/*     */     }
/*     */     try
/*     */     {
/*  62 */       init();
/*     */     }
/*     */     catch (Exception e) {
/*  65 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void addRow(Object[] arrValues)
/*     */   {
/*  72 */     RowData rowData = new RowData(arrValues);
/*  73 */     this.vectorRows.addElement(rowData);
/*  74 */     repaint();
/*     */   }
/*     */   
/*     */   public void removeRow(int nRowIndex) {
/*  78 */     this.vectorRows.removeElementAt(nRowIndex);
/*  79 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCellValue(Object value, int nRowIndex, int nColumnIndex)
/*     */   {
/*  85 */     RowData rowData = (RowData)this.vectorRows.elementAt(nRowIndex);
/*  86 */     rowData.setValue(value, nColumnIndex);
/*  87 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setColumnWidth(int nWidth, int nColumnIndex)
/*     */   {
/*  93 */     ColumnData columnData = (ColumnData)this.vectorColumns.elementAt(nColumnIndex);
/*  94 */     columnData.nWidth = nWidth;
/*  95 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColumnWidth(int nWidth)
/*     */   {
/* 104 */     int nCount = this.vectorColumns.size();
/* 105 */     for (int i = 0; i < nCount; i++) {
/* 106 */       ColumnData columnData = (ColumnData)this.vectorColumns.elementAt(i);
/* 107 */       columnData.nWidth = nWidth;
/*     */     }
/* 109 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setColumnWidthAsPreferred(int nColumnIndex)
/*     */   {
/* 116 */     ColumnData columnData = (ColumnData)this.vectorColumns.elementAt(nColumnIndex);
/* 117 */     int nWidth = getPreferredColumnWidth(nColumnIndex);
/* 118 */     columnData.nWidth = nWidth;
/* 119 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColumnWidthAsPreferred()
/*     */   {
/* 132 */     int nCount = this.vectorColumns.size();
/* 133 */     int nWidthTotal = 0;
/* 134 */     ColumnData columnData; for (int i = 0; i < nCount; i++) {
/* 135 */       columnData = (ColumnData)this.vectorColumns.elementAt(i);
/* 136 */       int nWidth = getPreferredColumnWidth(i);
/* 137 */       columnData.nWidth = nWidth;
/* 138 */       nWidthTotal += nWidth;
/*     */     }
/* 140 */     Rectangle rect = getBounds();
/* 141 */     if (rect.width < 1)
/* 142 */       this.boolSetColumnWidthAsPreferred = true;
/* 143 */     rect.width -= 2;
/* 144 */     if (rect.width > nWidthTotal) {
/* 145 */       int nWidthExtra = (rect.width - nWidthTotal) / nCount;
/* 146 */       nWidthTotal = rect.width;
/* 147 */       for (i = 0; i < nCount; i++) {
/* 148 */         columnData = (ColumnData)this.vectorColumns.elementAt(i);
/* 149 */         if (i < nCount - 1) {
/* 150 */           columnData.nWidth += nWidthExtra;
/*     */         } else
/* 152 */           columnData.nWidth = nWidthTotal;
/* 153 */         nWidthTotal -= columnData.nWidth;
/*     */       }
/*     */     }
/* 156 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Dimension getPreferredSize()
/*     */   {
/* 167 */     Dimension dim = new Dimension();
/*     */     
/* 169 */     dim.height += this.nHeightHeader;
/* 170 */     int nHeight = this.nHeightRow;
/* 171 */     nHeight *= this.vectorRows.size();
/* 172 */     dim.height += nHeight;
/*     */     
/*     */ 
/* 175 */     int nCount = this.vectorColumns.size();
/* 176 */     for (int i = 0; i < nCount; i++) {
/* 177 */       int nWidth = getPreferredColumnWidth(i);
/* 178 */       dim.width += nWidth;
/*     */     }
/*     */     
/* 181 */     dim.width += 3;
/* 182 */     dim.height += 3;
/* 183 */     return dim;
/*     */   }
/*     */   
/*     */   public boolean isFocusTraversable() {
/* 187 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(Graphics g)
/*     */   {
/* 195 */     Rectangle rectClient = getBounds();
/* 196 */     java.awt.Image image = createImage(rectClient.width, rectClient.height);
/* 197 */     Graphics graphics; if (image != null) {
/* 198 */       graphics = image.getGraphics();
/*     */     } else {
/* 200 */       graphics = g;
/*     */     }
/* 202 */     paint(graphics);
/*     */     
/* 204 */     if (image != null) {
/* 205 */       g.drawImage(image, 0, 0, this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void paint(Graphics graphics)
/*     */   {
/* 227 */     Rectangle rectClient = getBounds();
/* 228 */     rectClient.x = 0;
/* 229 */     rectClient.y = 0;
/* 230 */     Rectangle rect = new Rectangle(rectClient);
/*     */     
/* 232 */     super.paint(graphics);
/*     */     
/* 234 */     graphics.setColor(COLOR_SHADOW_BOTTOM);
/* 235 */     graphics.drawRect(rect.x, rect.y, rect.width - 2, rect.height - 2);
/* 236 */     graphics.setColor(COLOR_SHADOW_TOP);
/* 237 */     graphics.drawLine(rect.x + rect.width - 1, rect.y + 1, rect.x + rect.width - 1, rect.y + rect.height - 1);
/* 238 */     graphics.drawLine(rect.x + 1, rect.y + rect.height - 1, rect.x + rect.width - 1, rect.y + rect.height - 1);
/*     */     
/* 240 */     int nColCount = this.vectorColumns.size();
/* 241 */     int nRowCount = this.vectorRows.size();
/*     */     
/* 243 */     rect.x += 1;
/* 244 */     rect.y += 1;
/* 245 */     int nStartX = rect.x;
/*     */     
/*     */ 
/* 248 */     FontMetrics fontMetrics = getFontMetrics(this.fontHeader);
/* 249 */     graphics.setFont(this.fontHeader);
/* 250 */     int nHeight = fontMetrics.getHeight();
/* 251 */     rect.height = this.nHeightHeader;
/* 252 */     ColumnData columnData; String strValue; int nLength; int nWidth; int nX; int nY; for (int i = this.nScrollPosHorz; i < nColCount; i++) {
/* 253 */       columnData = (ColumnData)this.vectorColumns.elementAt(i);
/* 254 */       rect.width = columnData.nWidth;
/* 255 */       if (rect.x + rect.width > rectClient.x + rectClient.width - 1) {
/* 256 */         rect.width = (rectClient.x + rectClient.width - 1 - rect.x);
/*     */       }
/*     */       
/* 259 */       graphics.setColor(COLOR_HEADER_BG);
/* 260 */       graphics.fillRect(rect.x, rect.y, rect.width, rect.height);
/* 261 */       graphics.setColor(COLOR_SHADOW_TOP);
/* 262 */       graphics.drawLine(rect.x, rect.y, rect.x, rect.y + rect.height - 2);
/* 263 */       graphics.drawLine(rect.x, rect.y, rect.x + rect.width - 2, rect.y);
/* 264 */       graphics.setColor(COLOR_SHADOW_BOTTOM);
/* 265 */       graphics.drawLine(rect.x + rect.width - 1, rect.y + 1, rect.x + rect.width - 1, rect.y + rect.height - 1);
/* 266 */       graphics.drawLine(rect.x + 1, rect.y + rect.height - 1, rect.x + rect.width - 1, rect.y + rect.height - 1);
/*     */       
/* 268 */       strValue = columnData.strName;
/* 269 */       nLength = strValue.length();
/* 270 */       nWidth = fontMetrics.stringWidth(strValue);
/* 271 */       while ((nWidth > rect.width - 12) && (nLength > 0)) {
/* 272 */         nLength--;
/* 273 */         strValue = strValue.substring(0, nLength) + "...";
/* 274 */         nWidth = fontMetrics.stringWidth(strValue);
/*     */       }
/* 276 */       nX = rect.x + (rect.width - nWidth) / 2;
/* 277 */       nY = rect.y + rect.height - (rect.height - nHeight) / 2 - fontMetrics.getMaxDescent();
/* 278 */       graphics.setColor(getForeground());
/* 279 */       graphics.drawString(strValue, nX, nY);
/*     */       
/* 281 */       rect.x += rect.width;
/*     */     }
/*     */     
/*     */ 
/* 285 */     Font font = getFont();
/* 286 */     fontMetrics = getFontMetrics(font);
/* 287 */     graphics.setFont(font);
/* 288 */     nHeight = fontMetrics.getHeight();
/*     */     
/* 290 */     rect.y += rect.height;
/* 291 */     rect.height = this.nHeightRow;
/* 292 */     for (int j = this.nScrollPosVert; j < nRowCount; j++) {
/* 293 */       rect.x = nStartX;
/* 294 */       if (j == this.nCurrentIndex) {
/* 295 */         rectClient.width -= 3;
/* 296 */         graphics.setColor(COLOR_SEL_BG);
/* 297 */         graphics.fillRect(rect.x, rect.y, rect.width, rect.height);
/* 298 */         graphics.setColor(COLOR_SEL_FG);
/* 299 */         if (this.boolFocus == true) {
/* 300 */           drawDottedLine(graphics, rect.x, rect.y, rect.x + rect.width - 1, rect.y);
/* 301 */           drawDottedLine(graphics, rect.x, rect.y + rect.height - 1, rect.x + rect.width - 1, rect.y + rect.height - 1);
/*     */         }
/*     */       }
/*     */       else {
/* 305 */         graphics.setColor(getForeground());
/*     */       }
/* 307 */       RowData rowData = (RowData)this.vectorRows.elementAt(j);
/* 308 */       for (i = this.nScrollPosHorz; i < nColCount; i++) {
/* 309 */         columnData = (ColumnData)this.vectorColumns.elementAt(i);
/* 310 */         rect.width = columnData.nWidth;
/* 311 */         if (rect.x + rect.width > rectClient.x + rectClient.width - 1)
/* 312 */           rect.width = (rectClient.x + rectClient.width - 1 - rect.x);
/* 313 */         strValue = rowData.getValue(i).toString();
/* 314 */         nLength = strValue.length();
/* 315 */         nWidth = fontMetrics.stringWidth(strValue);
/* 316 */         while ((nWidth > rect.width - 12) && (nLength > 0)) {
/* 317 */           nLength--;
/* 318 */           strValue = strValue.substring(0, nLength) + "...";
/* 319 */           nWidth = fontMetrics.stringWidth(strValue);
/*     */         }
/* 321 */         nX = rect.x + 6;
/* 322 */         nY = rect.y + rect.height - (rect.height - nHeight) / 2 - fontMetrics.getMaxDescent();
/* 323 */         graphics.drawString(strValue, nX, nY);
/* 324 */         rect.x += rect.width;
/*     */       }
/* 326 */       rect.y += rect.height;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void mouseClicked(MouseEvent event) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void mousePressed(MouseEvent event)
/*     */   {
/* 338 */     int x = event.getX();
/* 339 */     int y = event.getY();
/* 340 */     y -= 1 + this.nHeightHeader;
/* 341 */     if (y >= 0) {
/* 342 */       int nIndex = y / this.nHeightRow;
/* 343 */       if ((nIndex >= 0) && (nIndex < this.vectorRows.size() - this.nScrollPosVert)) {
/* 344 */         this.nCurrentIndex = (nIndex + this.nScrollPosVert);
/*     */       }
/*     */     }
/* 347 */     requestFocus();
/* 348 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void mouseReleased(MouseEvent event) {}
/*     */   
/*     */ 
/*     */   public void mouseEntered(MouseEvent event) {}
/*     */   
/*     */ 
/*     */   public void mouseExited(MouseEvent event) {}
/*     */   
/*     */ 
/*     */   public void keyTyped(KeyEvent event) {}
/*     */   
/*     */ 
/*     */   public void keyPressed(KeyEvent event)
/*     */   {
/* 367 */     int nKeyCode = event.getKeyCode();
/* 368 */     int nIndex = this.nCurrentIndex;
/* 369 */     if (nKeyCode == 40) {
/* 370 */       nIndex++;
/* 371 */     } else if (nKeyCode == 38) {
/* 372 */       nIndex--;
/* 373 */     } else if (nKeyCode == 36) {
/* 374 */       nIndex = 0;
/* 375 */     } else if (nKeyCode == 35) {
/* 376 */       nIndex = this.vectorRows.size() - 1;
/* 377 */     } else if (nKeyCode == 33) {
/* 378 */       nIndex -= this.nVisibleRows;
/* 379 */     } else if (nKeyCode == 34) {
/* 380 */       nIndex += this.nVisibleRows;
/*     */     }
/* 382 */     if (nIndex > this.vectorRows.size() - 1)
/* 383 */       nIndex = this.vectorRows.size() - 1;
/* 384 */     if (nIndex < 0) {
/* 385 */       nIndex = 0;
/*     */     }
/* 387 */     if (nIndex != this.nCurrentIndex) {
/* 388 */       this.nCurrentIndex = nIndex;
/* 389 */       if (this.nScrollPosVert + this.nVisibleRows < this.nCurrentIndex)
/* 390 */         this.nScrollPosVert = (this.nCurrentIndex - this.nVisibleRows + 1);
/* 391 */       if (this.nScrollPosVert > this.nCurrentIndex)
/* 392 */         this.nScrollPosVert = this.nCurrentIndex;
/* 393 */       repaint();
/*     */     }
/*     */   }
/*     */   
/*     */   public void keyReleased(KeyEvent event) {}
/*     */   
/*     */   public void focusGained(FocusEvent event)
/*     */   {
/* 401 */     if (this.boolFocus == true)
/* 402 */       return;
/* 403 */     this.boolFocus = true;
/* 404 */     repaint();
/*     */   }
/*     */   
/*     */   public void focusLost(FocusEvent event) {
/* 408 */     if (!this.boolFocus)
/* 409 */       return;
/* 410 */     this.boolFocus = false;
/* 411 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */   public void componentResized(ComponentEvent event)
/*     */   {
/* 417 */     if (this.boolSetColumnWidthAsPreferred == true) {
/* 418 */       this.boolSetColumnWidthAsPreferred = false;
/* 419 */       setColumnWidthAsPreferred();
/*     */     }
/* 421 */     Rectangle rect = getBounds();
/* 422 */     rect.height -= 3 + this.nHeightHeader;
/* 423 */     this.nVisibleRows = (rect.height / this.nHeightRow);
/* 424 */     if (this.nVisibleRows < 1) {
/* 425 */       this.nVisibleRows = 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void componentMoved(ComponentEvent event) {}
/*     */   
/*     */   public void componentShown(ComponentEvent event) {}
/*     */   
/*     */   public void componentHidden(ComponentEvent event) {}
/*     */   
/*     */   private void init()
/*     */     throws Exception
/*     */   {
/* 439 */     setFont(this.fontItem);
/* 440 */     computeHeights();
/* 441 */     setBackground(Color.white);
/*     */     
/* 443 */     addMouseListener(this);
/* 444 */     addKeyListener(this);
/* 445 */     addFocusListener(this);
/* 446 */     addComponentListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getPreferredColumnWidth(int nColumnIndex)
/*     */   {
/* 460 */     ColumnData columnData = (ColumnData)this.vectorColumns.elementAt(nColumnIndex);
/*     */     
/*     */ 
/* 463 */     FontMetrics fontMetrics = getFontMetrics(this.fontHeader);
/* 464 */     String strValue = columnData.strName;
/* 465 */     int nWidthMax = fontMetrics.stringWidth(strValue) + 12 + 2;
/*     */     
/*     */ 
/* 468 */     Font font = getFont();
/* 469 */     fontMetrics = getFontMetrics(font);
/* 470 */     int nCount = this.vectorRows.size();
/* 471 */     for (int i = 0; i < nCount; i++) {
/* 472 */       RowData rowData = (RowData)this.vectorRows.elementAt(i);
/* 473 */       strValue = rowData.getValue(nColumnIndex).toString();
/* 474 */       int nWidth = fontMetrics.stringWidth(strValue) + 12;
/* 475 */       nWidthMax = Math.max(nWidthMax, nWidth);
/*     */     }
/*     */     
/* 478 */     return nWidthMax;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void computeHeights()
/*     */   {
/* 485 */     FontMetrics fontMetrics = getFontMetrics(this.fontHeader);
/* 486 */     this.nHeightHeader = fontMetrics.getHeight();
/* 487 */     this.nHeightHeader += 2;
/* 488 */     this.nHeightHeader += 4;
/*     */     
/* 490 */     Font font = getFont();
/* 491 */     fontMetrics = getFontMetrics(font);
/* 492 */     this.nHeightRow = fontMetrics.getHeight();
/* 493 */     this.nHeightRow += 4;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void drawDottedLine(Graphics graphics, int nX1, int nY1, int nX2, int nY2)
/*     */   {
/* 500 */     if ((nX1 == nX2) && (nY1 == nY2)) {
/* 501 */       drawDot(graphics, nX1, nY1); return;
/*     */     }
/*     */     int nX;
/* 504 */     if (nX1 > nX2) {
/* 505 */       nX = nX1;
/* 506 */       nX1 = nX2;
/* 507 */       nX2 = nX; }
/*     */     int nY;
/* 509 */     if (nY1 > nY2) {
/* 510 */       nY = nY1;
/* 511 */       nY1 = nY2;
/* 512 */       nY2 = nY; }
/*     */     double dDiv;
/* 514 */     if (nX2 - nX1 > nY2 - nY1) {
/* 515 */       dDiv = (nY2 - nY1) / (nX2 - nX1);
/* 516 */       for (nX = nX1; nX <= nX2; nX++) {
/* 517 */         nY = (int)Math.rint(nY1 + (nX - nX1) * dDiv);
/* 518 */         drawDot(graphics, nX, nY);
/*     */       }
/*     */     }
/*     */     else {
/* 522 */       dDiv = (nX2 - nX1) / (nY2 - nY1);
/* 523 */       for (nY = nY1; nY <= nY2; nY++) {
/* 524 */         nX = (int)Math.rint(nX1 + (nY - nY1) * dDiv);
/* 525 */         drawDot(graphics, nX, nY);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void drawDot(Graphics graphics, int nX, int nY)
/*     */   {
/* 532 */     if ((nX + nY) % 2 == 0) {
/* 533 */       graphics.drawLine(nX, nY, nX, nY);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\ui\ColumnList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */