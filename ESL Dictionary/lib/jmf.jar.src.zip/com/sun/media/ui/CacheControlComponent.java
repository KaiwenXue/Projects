/*    */ package com.sun.media.ui;
/*    */ 
/*    */ import com.sun.media.util.JMFI18N;
/*    */ import java.awt.Component;
/*    */ import java.awt.Container;
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.GridBagLayout;
/*    */ import java.awt.Label;
/*    */ import javax.media.CachingControl;
/*    */ import javax.media.ExtendedCachingControl;
/*    */ import javax.media.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheControlComponent
/*    */   extends BufferedPanel
/*    */ {
/*    */   public CacheControlComponent(CachingControl ctrl, Player player)
/*    */   {
/* 21 */     this.ctrl = ctrl;
/* 22 */     this.player = player;
/*    */     
/* 24 */     if ((ctrl instanceof ExtendedCachingControl)) {
/* 25 */       this.xtdctrl = ((ExtendedCachingControl)ctrl);
/*    */     }
/* 27 */     setBackground(DefaultControlPanel.colorBackground);
/* 28 */     setBackgroundTile(BasicComp.fetchImage("texture3.gif"));
/* 29 */     GridBagLayout gbl; setLayout(gbl = new GridBagLayout());
/* 30 */     GridBagConstraints gbc = new GridBagConstraints();
/* 31 */     gbc.gridx = 0;
/* 32 */     gbc.gridy = 0;
/* 33 */     gbc.gridwidth = 0;
/* 34 */     Label label = new Label(JMFI18N.getResource("mediaplayer.download"), 1);
/* 35 */     add(label);
/* 36 */     gbl.setConstraints(label, gbc);
/*    */     
/* 38 */     gbc.gridy += 1;
/* 39 */     gbc.gridwidth = 1;
/* 40 */     this.cancelButton = new CancelButton();
/* 41 */     add(this.cancelButton);
/* 42 */     gbl.setConstraints(this.cancelButton, gbc);
/* 43 */     gbc.gridx += 1;
/* 44 */     this.progressBar = new ProgressBar(ctrl);
/* 45 */     add(this.progressBar);
/* 46 */     gbl.setConstraints(this.progressBar, gbc);
/*    */   }
/*    */   
/*    */   public void addNotify() {
/* 50 */     super.addNotify();
/* 51 */     setSize(getPreferredSize());
/*    */   }
/*    */   
/*    */   public Component getProgressBar() {
/* 55 */     return this.progressBar;
/*    */   }
/*    */   
/* 58 */   protected CachingControl ctrl = null;
/* 59 */   private ExtendedCachingControl xtdctrl = null;
/* 60 */   protected Player player = null;
/* 61 */   protected ButtonComp cancelButton = null;
/* 62 */   protected ProgressBar progressBar = null;
/*    */   
/*    */   class CancelButton extends ButtonComp
/*    */   {
/*    */     public CancelButton() {
/* 67 */       super("pause.gif", "pause-active.gif", "pause-pressed.gif", "pause-disabled.gif", "play.gif", "play-active.gif", "play-pressed.gif", "play-disabled.gif");
/*    */     }
/*    */     
/*    */ 
/*    */     public void action()
/*    */     {
/* 73 */       super.action();
/* 74 */       if ((CacheControlComponent.this.player == null) || 
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 85 */         (CacheControlComponent.this.xtdctrl != null)) {
/* 86 */         if (this.state) {
/* 87 */           CacheControlComponent.this.xtdctrl.pauseDownload();
/*    */         } else {
/* 89 */           CacheControlComponent.this.xtdctrl.resumeDownload();
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\ui\CacheControlComponent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */