/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import com.sun.media.controls.NumericControl;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.InputEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ 
/*     */ public class Slider
/*     */   extends BasicComp
/*     */   implements MouseListener, MouseMotionListener
/*     */ {
/*     */   Image imageGrabber;
/*     */   Image imageGrabberX;
/*     */   Image imageGrabberDown;
/*  22 */   Graphics paintG = null;
/*     */   
/*     */   boolean grabbed;
/*     */   boolean entered;
/*     */   int grabberPosition;
/*  27 */   int leftBorder = 8;
/*  28 */   int rightBorder = 8;
/*     */   int sliderWidth;
/*     */   int width;
/*     */   int height;
/*     */   int displayPercent;
/*     */   float[] detents;
/*  34 */   Dimension dimension; float lower = 0.0F; float upper = 1.0F; float range = 1.0F; float value = 0.5F;
/*  35 */   boolean dragging = false;
/*  36 */   boolean grabberVisible = true;
/*     */   
/*     */   public Slider() {
/*  39 */     this(null, null);
/*     */   }
/*     */   
/*     */   public Slider(float[] detents) {
/*  43 */     this(detents, null);
/*     */   }
/*     */   
/*     */   public Slider(float[] detents, Color background) {
/*  47 */     super("Slider");
/*  48 */     this.imageGrabber = BasicComp.fetchImage("grabber.gif");
/*  49 */     this.imageGrabberDown = BasicComp.fetchImage("grabber-pressed.gif");
/*  50 */     this.imageGrabberX = BasicComp.fetchImage("grabber-disabled.gif");
/*     */     
/*  52 */     this.detents = detents;
/*  53 */     if (background != null) {
/*  54 */       setBackground(background);
/*     */     }
/*  56 */     this.width = 115;
/*  57 */     this.height = 18;
/*  58 */     this.displayPercent = 100;
/*  59 */     this.dimension = new Dimension(this.width, this.height);
/*  60 */     this.sliderWidth = (this.width - this.leftBorder - this.rightBorder);
/*  61 */     setSize(this.width, this.height);
/*  62 */     setVisible(true);
/*  63 */     this.grabbed = false;
/*  64 */     this.entered = false;
/*  65 */     addMouseListener(this);
/*  66 */     addMouseMotionListener(this);
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean state) {
/*  70 */     super.setEnabled(state);
/*  71 */     repaint();
/*     */   }
/*     */   
/*     */   public Point getPosition() {
/*  75 */     return new Point(this.grabberPosition + this.leftBorder, 10);
/*     */   }
/*     */   
/*     */   public void setDisplayPercent(int percent) {
/*  79 */     if (percent != this.displayPercent) {
/*  80 */       this.displayPercent = percent;
/*  81 */       if (this.displayPercent > 100) {
/*  82 */         this.displayPercent = 100;
/*  83 */       } else if (this.displayPercent < 0) {
/*  84 */         this.displayPercent = 0;
/*     */       }
/*  86 */       repaint();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isGrabberVisible() {
/*  91 */     return this.grabberVisible;
/*     */   }
/*     */   
/*     */   public void setGrabberVisible(boolean visible) {
/*  95 */     if (this.grabberVisible != visible) {
/*  96 */       this.grabberVisible = visible;
/*  97 */       repaint();
/*     */     }
/*     */   }
/*     */   
/*     */   public void paint(Graphics g) {
/* 102 */     Dimension size = getSize();
/*     */     
/* 104 */     int y = size.height / 2 - 2;
/*     */     
/* 106 */     this.paintG = g;
/*     */     
/* 108 */     int grabberX = this.grabberPosition + this.leftBorder - 5;
/*     */     
/*     */ 
/* 111 */     g.setColor(getBackground().darker());
/* 112 */     g.drawRect(this.leftBorder, y, this.sliderWidth, 3);
/* 113 */     g.setColor(getBackground());
/* 114 */     g.draw3DRect(this.leftBorder, y, this.sliderWidth * this.displayPercent / 100, 3, false);
/*     */     
/*     */ 
/* 117 */     if ((this.detents != null) && (this.detents.length != 0)) {
/* 118 */       this.paintG.setColor(Color.black);
/* 119 */       for (int i = 0; i < this.detents.length; i++) {
/* 120 */         int x = this.leftBorder + (int)(this.detents[i] * this.sliderWidth / this.range);
/* 121 */         this.paintG.drawLine(x, 12, x, 15);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 126 */     if (this.grabberVisible) {
/*     */       Image image;
/* 128 */       if (isEnabled()) {
/* 129 */         if ((this.grabbed) || (this.entered)) {
/* 130 */           image = this.imageGrabberDown;
/*     */         } else
/* 132 */           image = this.imageGrabber;
/*     */       } else {
/* 134 */         image = this.imageGrabberX;
/*     */       }
/* 136 */       this.paintG.drawImage(image, grabberX, 4, this);
/*     */     }
/*     */   }
/*     */   
/*     */   private int limitGrabber(int mousex) {
/* 141 */     int x = mousex - this.leftBorder;
/* 142 */     if (x < 0) {
/* 143 */       x = 0;
/* 144 */     } else if (x > this.sliderWidth)
/* 145 */       x = this.sliderWidth;
/* 146 */     return x;
/*     */   }
/*     */   
/*     */   private void setSliderPosition(float value, float range) {
/* 150 */     this.grabberPosition = ((int)(value / range * this.sliderWidth));
/*     */   }
/*     */   
/*     */   private void seek() {
/* 154 */     if ((this.control != null) && ((this.control instanceof NumericControl))) {
/* 155 */       NumericControl nc = (NumericControl)this.control;
/* 156 */       float lower = nc.getLowerLimit();
/* 157 */       float upper = nc.getUpperLimit();
/* 158 */       float value = this.grabberPosition / this.sliderWidth * (upper - lower) + lower;
/*     */       
/* 160 */       if ((this.detents != null) && (this.detents.length > 0) && (this.dragging)) {
/* 161 */         float tolerance = (upper - lower) * 0.05F;
/* 162 */         for (int i = 0; i < this.detents.length; i++) {
/* 163 */           if (Math.abs(this.detents[i] - value) <= tolerance) {
/* 164 */             value = this.detents[i];
/*     */           }
/*     */         }
/*     */       }
/* 168 */       float result = nc.setValue(value);
/* 169 */       if (value != result)
/* 170 */         setSliderPosition(result - lower, upper - lower);
/*     */     }
/* 172 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mousePressed(MouseEvent me)
/*     */   {
/* 180 */     int modifier = me.getModifiers();
/* 181 */     if (((modifier & 0x8) == 0) && ((modifier & 0x4) == 0))
/*     */     {
/* 183 */       if (isEnabled()) {
/* 184 */         this.dragging = false;
/* 185 */         this.grabbed = true;
/* 186 */         this.grabberPosition = limitGrabber(me.getX());
/* 187 */         seek();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseReleased(MouseEvent me) {
/* 193 */     int modifier = me.getModifiers();
/* 194 */     if (((modifier & 0x8) == 0) && ((modifier & 0x4) == 0))
/*     */     {
/* 196 */       if (isEnabled()) {
/* 197 */         this.dragging = false;
/* 198 */         this.grabbed = false;
/* 199 */         repaint();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseDragged(MouseEvent me) {
/* 205 */     int modifier = me.getModifiers();
/* 206 */     if (((modifier & 0x8) == 0) && ((modifier & 0x4) == 0))
/*     */     {
/* 208 */       if (isEnabled()) {
/* 209 */         this.dragging = true;
/* 210 */         this.grabberPosition = limitGrabber(me.getX());
/* 211 */         seek();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseEntered(MouseEvent me) {
/* 217 */     this.entered = true;
/* 218 */     repaint();
/*     */   }
/*     */   
/*     */   public void mouseExited(MouseEvent me) {
/* 222 */     this.entered = false;
/* 223 */     repaint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void mouseClicked(MouseEvent me) {}
/*     */   
/*     */ 
/*     */   public void mouseMoved(MouseEvent me) {}
/*     */   
/*     */ 
/*     */   public void setSize(int width, int height)
/*     */   {
/* 236 */     super.setSize(width, height);
/* 237 */     this.paintG = null;
/* 238 */     repaint();
/*     */   }
/*     */   
/*     */   public Dimension getPreferredSize() {
/* 242 */     return this.dimension;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\ui\Slider.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */