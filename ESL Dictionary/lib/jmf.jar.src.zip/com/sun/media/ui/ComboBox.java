/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Frame;
/*     */ import java.awt.List;
/*     */ import java.awt.TextComponent;
/*     */ import java.awt.TextField;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ 
/*     */ public class ComboBox extends java.awt.Panel implements ItemListener
/*     */ {
/*     */   TextField edit;
/*     */   java.awt.Button bPullDown;
/*  19 */   PullDownList listWindow = null;
/*  20 */   List list = null;
/*  21 */   boolean mouseIn = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComboBox()
/*     */   {
/*  28 */     this(3);
/*     */   }
/*     */   
/*     */   public ComboBox(int cols) {
/*  32 */     setLayout(new java.awt.BorderLayout());
/*     */     
/*  34 */     this.edit = new TextField(cols);
/*  35 */     this.bPullDown = new java.awt.Button("...");
/*  36 */     add("Center", this.edit);
/*  37 */     add("East", this.bPullDown);
/*     */     
/*  39 */     this.list = new List(6);
/*  40 */     this.list.setBackground(java.awt.Color.white);
/*  41 */     this.list.addItemListener(this);
/*     */     
/*  43 */     this.bPullDown.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(java.awt.event.ActionEvent ae) {
/*  45 */         ComboBox.this.pullDown();
/*     */       }
/*     */       
/*  48 */     });
/*  49 */     this.bPullDown.addMouseListener(new java.awt.event.MouseAdapter() {
/*     */       public void mouseEntered(MouseEvent me) {
/*  51 */         if (ComboBox.this.listWindow == null)
/*  52 */           ComboBox.this.firstTime();
/*  53 */         ComboBox.this.mouseIn = true;
/*     */       }
/*     */       
/*     */       public void mouseExited(MouseEvent me) {
/*  57 */         ComboBox.this.mouseIn = false;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void firstTime()
/*     */   {
/*  64 */     Component frame = this;
/*  65 */     while ((!(frame instanceof Frame)) && (frame != null)) {
/*  66 */       frame = frame.getParent();
/*     */     }
/*  68 */     if (frame == null) {
/*  69 */       System.out.println("No frame found in hierarchy");
/*  70 */       System.exit(0);
/*     */     }
/*  72 */     this.listWindow = new PullDownList((Frame)frame, this.list);
/*  73 */     this.listWindow.validate();
/*     */   }
/*     */   
/*     */   public void itemStateChanged(ItemEvent ie) {
/*  77 */     if (ie.getStateChange() == 1) {
/*  78 */       String s = this.list.getSelectedItem();
/*  79 */       this.edit.setText(s);
/*  80 */       this.edit.selectAll();
/*  81 */       pullDown();
/*     */     }
/*     */   }
/*     */   
/*     */   public void pullDown() {
/*  86 */     if (!this.listWindow.isVisible()) {
/*  87 */       this.listWindow.show(this);
/*     */     } else
/*  89 */       this.listWindow.setVisible(false);
/*     */   }
/*     */   
/*     */   public void addActionListener(ActionListener al) {
/*  93 */     this.edit.addActionListener(al);
/*     */   }
/*     */   
/*     */   public void removeActionListener(ActionListener al) {
/*  97 */     this.edit.removeActionListener(al);
/*     */   }
/*     */   
/*     */   public void addItemListener(ItemListener il) {
/* 101 */     this.list.addItemListener(il);
/*     */   }
/*     */   
/*     */   public void removeItemListener(ItemListener il) {
/* 105 */     this.list.removeItemListener(il);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 114 */     return this.edit.getText();
/*     */   }
/*     */   
/*     */   public void setEditable(boolean f) {
/* 118 */     this.edit.setEditable(f);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(String item)
/*     */   {
/* 127 */     this.list.add(item);
/*     */   }
/*     */   
/*     */   public void add(String item, int index) {
/* 131 */     this.list.add(item, index);
/*     */   }
/*     */   
/*     */   public void addItem(String item) {
/* 135 */     this.list.addItem(item);
/*     */   }
/*     */   
/*     */   public void addItem(String item, int index) {
/* 139 */     this.list.addItem(item, index);
/*     */   }
/*     */   
/*     */   public void delItem(int index) {
/* 143 */     this.list.delItem(index);
/*     */   }
/*     */   
/*     */   public String getSelectedItem() {
/* 147 */     return this.list.getSelectedItem();
/*     */   }
/*     */   
/*     */   public int getSelectedIndex() {
/* 151 */     return this.list.getSelectedIndex();
/*     */   }
/*     */   
/*     */   public void select(int index) {
/* 155 */     this.list.select(index);
/* 156 */     String s = this.list.getSelectedItem();
/* 157 */     this.edit.setText(s);
/* 158 */     this.edit.selectAll();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   class PullDownList
/*     */     extends java.awt.Window
/*     */   {
/*     */     List list;
/*     */     
/*     */ 
/* 169 */     int height = 100;
/* 170 */     int HEIGHT = 100;
/*     */     
/*     */     public PullDownList(Frame f, List list) {
/* 173 */       super();
/* 174 */       setLayout(null);
/* 175 */       setBackground(java.awt.Color.black);
/* 176 */       this.list = list;
/* 177 */       add(list);
/*     */       
/* 179 */       list.addMouseListener(new ComboBox.3(this));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void show(Component parent)
/*     */     {
/* 186 */       java.awt.Point p = parent.getLocationOnScreen();
/* 187 */       Dimension psize = parent.getSize();
/* 188 */       this.height = this.list.getPreferredSize().height;
/* 189 */       if (this.height == 0)
/* 190 */         this.height = this.HEIGHT;
/* 191 */       this.list.setBounds(1, 1, psize.width - 2, this.HEIGHT);
/* 192 */       setBounds(p.x, p.y + psize.height, psize.width, this.HEIGHT + 2);
/* 193 */       validate();
/* 194 */       setVisible(true);
/*     */     }
/*     */     
/*     */     public List getList() {
/* 198 */       return this.list;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\ui\ComboBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */