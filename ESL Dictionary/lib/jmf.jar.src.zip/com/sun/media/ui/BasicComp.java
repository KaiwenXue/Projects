/*    */ package com.sun.media.ui;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.awt.Image;
/*    */ import java.awt.MediaTracker;
/*    */ import java.awt.Panel;
/*    */ import java.awt.Toolkit;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.io.PrintStream;
/*    */ import javax.media.Control;
/*    */ 
/*    */ public class BasicComp
/*    */   extends Container
/*    */ {
/* 16 */   protected String label = null;
/* 17 */   private ActionListener al = null;
/* 18 */   static Panel panel = new Panel();
/* 19 */   Control control = null;
/*    */   int width;
/*    */   int height;
/*    */   
/* 23 */   protected BasicComp(String label) { this.label = label; }
/*    */   
/*    */   public void setActionListener(ActionListener al)
/*    */   {
/* 27 */     this.al = al;
/*    */   }
/*    */   
/*    */   protected void informListener() {
/* 31 */     if (this.al != null) {
/* 32 */       this.al.actionPerformed(new ActionEvent(this, 1001, this.label));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public static synchronized Image fetchImage(String name)
/*    */   {
/* 39 */     Image image = null;
/*    */     
/*    */ 
/* 42 */     byte[] bits = ImageLib.getImage(name);
/* 43 */     if (bits == null) {
/* 44 */       return null;
/*    */     }
/* 46 */     image = Toolkit.getDefaultToolkit().createImage(bits);
/*    */     try
/*    */     {
/* 49 */       MediaTracker imageTracker = new MediaTracker(panel);
/* 50 */       imageTracker.addImage(image, 0);
/* 51 */       imageTracker.waitForID(0);
/*    */     } catch (InterruptedException e) {
/* 53 */       System.err.println("ImageLoader: Interrupted at waitForID");
/*    */     }
/*    */     
/* 56 */     return image;
/*    */   }
/*    */   
/*    */   public String getLabel() {
/* 60 */     return this.label;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\ui\BasicComp.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */