/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ public class BufferedPanel extends java.awt.Panel
/*     */ {
/*     */   protected boolean buffered;
/*     */   protected boolean autoFlushing;
/*     */   protected java.awt.Image background;
/*     */   protected boolean windowCreated;
/*     */   protected transient java.awt.Image buffer;
/*     */   protected transient Graphics bufferGraphics;
/*     */   protected transient Region damage;
/*     */   
/*     */   public BufferedPanel(java.awt.LayoutManager layout)
/*     */   {
/*  19 */     setLayout(layout);
/*     */     
/*  21 */     this.buffered = true;
/*  22 */     this.autoFlushing = true;
/*  23 */     this.background = null;
/*  24 */     this.windowCreated = false;
/*  25 */     this.buffer = null;
/*  26 */     this.bufferGraphics = null;
/*  27 */     this.damage = new Region();
/*     */   }
/*     */   
/*     */   public BufferedPanel() {
/*  31 */     this(null);
/*     */   }
/*     */   
/*     */   public boolean isBuffered() {
/*  35 */     return this.buffered;
/*     */   }
/*     */   
/*     */   public void setBuffered(boolean buffered) {
/*  39 */     if (buffered != this.buffered) {
/*  40 */       this.buffered = buffered;
/*  41 */       if (buffered) {
/*  42 */         repaint();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isAutoFlushing() {
/*  48 */     return this.autoFlushing;
/*     */   }
/*     */   
/*     */   public void setAutoFlushing(boolean flushing) {
/*  52 */     if (flushing != this.autoFlushing) {
/*  53 */       this.autoFlushing = flushing;
/*     */     }
/*     */   }
/*     */   
/*     */   public java.awt.Image getBackgroundTile() {
/*  58 */     return this.background;
/*     */   }
/*     */   
/*     */   public void setBackgroundTile(java.awt.Image background) {
/*  62 */     this.background = background;
/*  63 */     repaint();
/*     */   }
/*     */   
/*     */   public void addNotify() {
/*  67 */     super.addNotify();
/*  68 */     this.windowCreated = true;
/*  69 */     if (this.buffered) {
/*  70 */       createBufferImage();
/*  71 */       repaint();
/*     */     }
/*     */   }
/*     */   
/*     */   public void reshape(int x, int y, int width, int height) {
/*  76 */     Rectangle old = getBounds();
/*     */     
/*  78 */     super.reshape(x, y, width, height);
/*  79 */     if ((this.windowCreated) && ((width != old.width) || (height != old.height)))
/*     */     {
/*  81 */       if (this.buffered)
/*     */       {
/*  83 */         createBufferImage();
/*  84 */         repaint();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void flushBuffer() {
/*  90 */     java.awt.Dimension size = getSize();
/*  91 */     super.repaint(0L, 0, 0, size.width, size.height);
/*     */   }
/*     */   
/*     */   void createBufferImage()
/*     */   {
/*  96 */     java.awt.Dimension size = getSize();
/*     */     
/*  98 */     if ((size.width > 0) && (size.height > 0))
/*     */     {
/* 100 */       this.buffer = createImage(size.width, size.height);
/* 101 */       if (this.buffer != null) {
/* 102 */         this.bufferGraphics = this.buffer.getGraphics();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void renderBuffer()
/*     */   {
/* 112 */     if (this.damage.isEmpty()) {
/* 113 */       return;
/*     */     }
/*     */     
/*     */ 
/* 117 */     if (this.buffer == null) {
/*     */       return;
/*     */     }
/*     */     
/*     */     Region rects;
/* 122 */     synchronized (this.damage) {
/* 123 */       rects = this.damage;
/* 124 */       this.damage = new Region();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 129 */     for (java.util.Enumeration e = rects.rectangles(); e.hasMoreElements();) {
/* 130 */       Rectangle rect = (Rectangle)e.nextElement();
/* 131 */       render(rect);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void render(Rectangle rect)
/*     */   {
/* 138 */     Component[] children = getComponents();
/*     */     
/*     */ 
/*     */ 
/* 142 */     synchronized (this.buffer)
/*     */     {
/* 144 */       this.bufferGraphics.setClip(rect);
/* 145 */       paintBackground(this.bufferGraphics);
/* 146 */       this.bufferGraphics.setColor(getForeground());
/*     */       
/*     */ 
/*     */ 
/* 150 */       for (int c = children.length - 1; c >= 0; c--) {
/* 151 */         Component child = children[c];
/* 152 */         if ((isLightweight(child)) && (child.isVisible())) {
/* 153 */           Rectangle clip = child.getBounds();
/* 154 */           if (clip.intersects(rect)) {
/* 155 */             Graphics g = this.bufferGraphics.create(clip.x, clip.y, clip.width, clip.height);
/*     */             
/* 157 */             child.paint(g);
/* 158 */             g.dispose();
/*     */           }
/*     */         }
/*     */       }
/* 162 */       this.bufferGraphics.setClip(0, 0, getSize().width, getSize().height);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void paintBackground(Graphics g) {
/* 167 */     java.awt.Dimension size = getSize();
/*     */     
/* 169 */     if (this.background == null)
/*     */     {
/* 171 */       g.setColor(getBackground());
/* 172 */       g.fillRect(0, 0, size.width, size.height);
/*     */     }
/*     */     else {
/* 175 */       Rectangle tile = new Rectangle(0, 0, this.background.getWidth(this), this.background.getHeight(this));
/*     */       
/*     */ 
/* 178 */       Rectangle clip = g.getClipBounds();
/*     */       
/* 180 */       for (goto 149; tile.y < size.height;) {
/* 181 */         while (tile.x < size.width) {
/* 182 */           if ((clip == null) || (clip.intersects(tile))) {
/* 183 */             g.drawImage(this.background, tile.x, tile.y, this);
/*     */           }
/* 185 */           tile.x += tile.width;
/*     */         }
/* 187 */         tile.x = 0;
/* 188 */         tile.y += tile.height;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   boolean isLightweight(Component comp) {
/* 194 */     return comp.getPeer() instanceof java.awt.peer.LightweightPeer;
/*     */   }
/*     */   
/*     */   public void repaint(long time, int x, int y, int width, int height) {
/* 198 */     if (this.buffered) {
/* 199 */       synchronized (this.damage) {
/* 200 */         this.damage.addRectangle(new Rectangle(x, y, width, height));
/*     */       }
/* 202 */       if (this.autoFlushing) {
/* 203 */         flushBuffer();
/*     */       }
/*     */     } else {
/* 206 */       super.repaint(time, x, y, width, height);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void update(Graphics g)
/*     */   {
/* 213 */     if (this.buffered) {
/* 214 */       paint(g);
/*     */     } else {
/* 216 */       super.update(g);
/*     */     }
/*     */   }
/*     */   
/*     */   public void paint(Graphics g) {
/* 221 */     if ((this.buffered) && (this.buffer != null)) {
/* 222 */       renderBuffer();
/* 223 */       g.drawImage(this.buffer, 0, 0, this);
/*     */     } else {
/* 225 */       super.paint(g);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 236 */   protected Object lock = new Object();
/*     */   
/*     */   private void readObject(java.io.ObjectInputStream is)
/*     */     throws java.io.IOException, ClassNotFoundException
/*     */   {
/* 241 */     is.defaultReadObject();
/* 242 */     this.damage = new Region();
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\ui\BufferedPanel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */