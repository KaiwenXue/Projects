/*     */ package com.sun.media.ui;
/*     */ 
/*     */ import com.sun.media.JMFSecurity;
/*     */ import com.sun.media.JMFSecurityManager;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.media.GainChangeEvent;
/*     */ import javax.media.GainChangeListener;
/*     */ import javax.media.GainControl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GainControlComponent
/*     */   extends Container
/*     */   implements GainChangeListener
/*     */ {
/*  24 */   private static JMFSecurity jmfSecurity = null;
/*  25 */   private static boolean securityPrivelege = false;
/*  26 */   private Method[] m = new Method[1];
/*  27 */   private Class[] cl = new Class[1];
/*  28 */   private Object[][] args = new Object[1][0];
/*     */   
/*     */   static {
/*     */     try {
/*  32 */       jmfSecurity = JMFSecurityManager.getJMFSecurity();
/*  33 */       securityPrivelege = true;
/*     */     }
/*     */     catch (SecurityException e) {}
/*     */   }
/*     */   
/*     */   public GainControlComponent(GainControl gain)
/*     */   {
/*  40 */     GridBagConstraints gbc = new GridBagConstraints();
/*     */     
/*  42 */     this.gain = gain;
/*  43 */     gain.addGainChangeListener(this);
/*     */     GridBagLayout gbl;
/*  45 */     setLayout(gbl = new GridBagLayout());
/*     */     
/*  47 */     if (canChangeVolume())
/*     */     {
/*  49 */       gbc.insets = new Insets(0, 0, 0, 0);
/*  50 */       gbc.gridheight = 2;
/*     */       
/*  52 */       this.muteButton = new MuteButton();
/*  53 */       add(this.muteButton);
/*  54 */       gbl.setConstraints(this.muteButton, gbc);
/*     */       
/*  56 */       gbc.gridx = 1;
/*  57 */       gbc.gridheight = 1;
/*  58 */       this.upButton = new VolumeButton("volumeUp.gif", "volumeUp-active.gif", "volumeUp-pressed.gif", "volumeUp-disabled.gif", "Increase volume", 0.05F);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  64 */       add(this.upButton);
/*  65 */       gbl.setConstraints(this.upButton, gbc);
/*     */       
/*  67 */       gbc.gridy = 1;
/*  68 */       this.downButton = new VolumeButton("volumeDown.gif", "volumeDown-active.gif", "volumeDown-pressed.gif", "volumeDown-disabled.gif", "Decrease volume", -0.05F);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */       add(this.downButton);
/*  76 */       gbl.setConstraints(this.downButton, gbc);
/*     */     } else {
/*  78 */       this.fUseVolumeControl = false;
/*  79 */       this.muteButton = new MuteButton();
/*  80 */       add(this.muteButton);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void gainChange(GainChangeEvent e)
/*     */   {
/*  87 */     if (this.fUseVolumeControl == true) {
/*  88 */       float level = e.getLevel();
/*  89 */       this.upButton.setEnabled(level < 1.0F);
/*  90 */       this.downButton.setEnabled(level > 0.0F);
/*     */     }
/*  92 */     this.muteButton.setValue(e.getMute());
/*     */   }
/*     */   
/*     */   protected boolean canChangeVolume()
/*     */   {
/*  97 */     if ((this.gain == null) || (this.gain.getLevel() < 0.0F)) {
/*  98 */       return false;
/*     */     }
/*     */     
/* 101 */     return true;
/*     */   }
/*     */   
/* 104 */   protected GainControl gain = null;
/* 105 */   protected MuteButton muteButton = null;
/* 106 */   protected VolumeButton upButton = null;
/* 107 */   protected VolumeButton downButton = null;
/* 108 */   protected boolean fUseVolumeControl = true;
/*     */   
/*     */   protected static final float VolumeIncrement = 0.05F;
/*     */   
/*     */   protected static final int RepeatDelay = 100;
/*     */   
/*     */   class VolumeButton
/*     */     extends ButtonComp
/*     */   {
/*     */     protected float increment;
/*     */     
/*     */     public VolumeButton(String imgNormal, String imgActive, String imgDown, String imgDisabled, String tip, float increment)
/*     */     {
/* 121 */       super(imgNormal, imgActive, imgDown, imgDisabled, imgNormal, imgActive, imgDown, imgDisabled);
/*     */       
/*     */ 
/* 124 */       this.increment = increment;
/*     */     }
/*     */     
/*     */ 
/*     */     public void action()
/*     */     {
/* 130 */       if (GainControlComponent.this.gain != null) {
/* 131 */         float level = GainControlComponent.this.gain.getLevel() + this.increment;
/* 132 */         if (level < 0.0F) {
/* 133 */           level = 0.0F;
/* 134 */         } else if (level > 1.0F) {
/* 135 */           level = 1.0F;
/*     */         }
/*     */         
/* 138 */         GainControlComponent.this.gain.setLevel(level);
/* 139 */         GainControlComponent.this.gain.setMute(false);
/*     */       }
/*     */     }
/*     */     
/*     */     public void mousePressed(MouseEvent e) {
/* 144 */       super.mousePressed(e);
/* 145 */       if (this.repeater == null) {
/* 146 */         this.repeater = new GainControlComponent.1(this);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 175 */         this.repeater.start();
/*     */       }
/*     */     }
/*     */     
/*     */     public void mouseReleased(MouseEvent e) {
/* 180 */       super.mouseReleased(e);
/* 181 */       if (this.repeater != null) {
/* 182 */         Thread killIt = this.repeater;
/* 183 */         this.repeater = null;
/* 184 */         boolean permission = true;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */         if (GainControlComponent.securityPrivelege) {
/* 195 */           if (GainControlComponent.jmfSecurity != null) {
/*     */             try {
/* 197 */               GainControlComponent.jmfSecurity.requestPermission(GainControlComponent.this.m, GainControlComponent.this.cl, GainControlComponent.this.args, 16);
/* 198 */               GainControlComponent.this.m[0].invoke(GainControlComponent.this.cl[0], GainControlComponent.this.args[0]);
/*     */ 
/*     */             }
/*     */             catch (Exception ex)
/*     */             {
/*     */ 
/* 204 */               permission = false;
/*     */             }
/*     */           }
/*     */         } else {
/* 208 */           permission = false;
/*     */         }
/* 210 */         if (permission) {
/* 211 */           killIt.interrupt();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 217 */       if (enabled != isEnabled()) {
/* 218 */         super.setEnabled(enabled);
/* 219 */         mouseActivity();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 224 */     Thread repeater = null;
/*     */   }
/*     */   
/*     */   class MuteButton extends ButtonComp
/*     */   {
/*     */     public MuteButton() {
/* 230 */       super("audio.gif", "audio-active.gif", "audio-pressed.gif", "audio-disabled.gif", "mute.gif", "mute-active.gif", "mute-pressed.gif", "audio-disabled.gif");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void action()
/*     */     {
/* 238 */       if (GainControlComponent.this.gain != null) {
/* 239 */         GainControlComponent.this.gain.setMute(!GainControlComponent.this.gain.getMute());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\ui\GainControlComponent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */