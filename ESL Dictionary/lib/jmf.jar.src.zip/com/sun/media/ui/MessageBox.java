/*    */ package com.sun.media.ui;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Button;
/*    */ import java.awt.Component;
/*    */ import java.awt.Container;
/*    */ import java.awt.FlowLayout;
/*    */ import java.awt.Frame;
/*    */ import java.awt.Label;
/*    */ import java.awt.Panel;
/*    */ import java.awt.Window;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ 
/*    */ public class MessageBox extends Frame
/*    */ {
/*    */   public MessageBox(String title, String message)
/*    */   {
/* 19 */     super(title);
/* 20 */     setLayout(new BorderLayout());
/*    */     
/*    */ 
/* 23 */     Panel bottom = new Panel();
/* 24 */     bottom.setLayout(new FlowLayout());
/* 25 */     Button ok = new Button("Grrr!!!");
/* 26 */     ok.addActionListener(new ActionListener() {
/*    */       public void actionPerformed(ActionEvent ae) {
/* 28 */         MessageBox.this.dispose();
/*    */       }
/* 30 */     });
/* 31 */     bottom.add(ok);
/*    */     
/*    */ 
/* 34 */     add("Center", new Label(message, 1));
/*    */     
/* 36 */     add("South", bottom);
/*    */     
/* 38 */     setVisible(true);
/*    */   }
/*    */   
/*    */   public void addNotify() {
/* 42 */     super.addNotify();
/* 43 */     pack();
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\ui\MessageBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */