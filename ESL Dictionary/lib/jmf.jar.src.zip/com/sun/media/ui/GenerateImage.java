/*    */ package com.sun.media.ui;
/*    */ 
/*    */ import java.awt.Image;
/*    */ import java.awt.Toolkit;
/*    */ import java.awt.image.DirectColorModel;
/*    */ import java.awt.image.IndexColorModel;
/*    */ import java.awt.image.MemoryImageSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenerateImage
/*    */ {
/* 14 */   private IndexColorModel icm = null;
/* 15 */   private DirectColorModel dcm = null;
/*    */   
/* 17 */   private Image image = null;
/* 18 */   private byte[] data = null;
/*    */   private int width;
/*    */   private int height;
/* 21 */   byte[] reds = new byte['Ā'];
/* 22 */   byte[] greens = new byte['Ā'];
/* 23 */   byte[] blues = new byte['Ā'];
/*    */   
/*    */   private native int getColors(byte[] paramArrayOfByte, int paramInt);
/*    */   
/*    */   private native boolean generateImage(String paramString);
/*    */   
/* 29 */   public GenerateImage() { int ncolors = getColors(this.reds, 0);
/* 30 */     getColors(this.greens, 1);
/* 31 */     getColors(this.blues, 2);
/* 32 */     this.icm = new IndexColorModel(8, 256, this.reds, this.greens, this.blues, 0);
/*    */   }
/*    */   
/*    */   public Image getImage(String imageName) {
/* 36 */     this.image = null;
/* 37 */     this.data = null;
/* 38 */     if (generateImage(imageName)) {
/* 39 */       createImage();
/* 40 */       return this.image;
/*    */     }
/* 42 */     return null;
/*    */   }
/*    */   
/*    */   protected synchronized void createBuffer(int w, int h) {
/* 46 */     this.width = w;
/* 47 */     this.height = h;
/* 48 */     this.data = new byte[w * h];
/*    */   }
/*    */   
/*    */   protected synchronized void createImage() {
/* 52 */     MemoryImageSource mis = new MemoryImageSource(this.width, this.height, this.icm, this.data, 0, this.width);
/*    */     
/* 54 */     Toolkit tk = Toolkit.getDefaultToolkit();
/* 55 */     this.image = tk.createImage(mis);
/* 56 */     tk.prepareImage(this.image, this.width, this.height, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\ui\GenerateImage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */