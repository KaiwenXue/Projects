/*     */ package com.sun.media.codec.audio.msadpcm;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.codec.audio.AudioCodec;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaDecoder
/*     */   extends AudioCodec
/*     */ {
/*     */   private static final boolean DEBUG = true;
/*     */   private MsAdpcmState[] state;
/*     */   
/*     */   public JavaDecoder()
/*     */   {
/*  33 */     this.inputFormats = new Format[] { new AudioFormat("msadpcm") };
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  38 */     return "msadpcm decoder";
/*     */   }
/*     */   
/*     */ 
/*     */   public Format[] getSupportedOutputFormats(Format in)
/*     */   {
/*  44 */     if (in == null) {
/*  45 */       return new Format[] { new AudioFormat("LINEAR") };
/*     */     }
/*  47 */     if (BasicPlugIn.matches(in, this.inputFormats) == null) {
/*  48 */       return new Format[0];
/*     */     }
/*  50 */     if (!(in instanceof AudioFormat)) {
/*  51 */       return new Format[] { new AudioFormat("LINEAR") };
/*     */     }
/*  53 */     AudioFormat af = (AudioFormat)in;
/*     */     
/*  55 */     int frameSize = af.getFrameSizeInBits();
/*  56 */     if ((frameSize != 2048) && (frameSize != 4096) && (frameSize != 8192))
/*     */     {
/*     */ 
/*  59 */       return new Format[0];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  64 */     return new Format[] { new AudioFormat("LINEAR", af.getSampleRate(), 16, af.getChannels(), 0, 1) };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open()
/*     */   {
/*  79 */     this.state = new MsAdpcmState[2];
/*  80 */     this.state[0] = new MsAdpcmState();
/*  81 */     this.state[1] = new MsAdpcmState();
/*     */   }
/*     */   
/*     */ 
/*     */   public void close()
/*     */   {
/*  87 */     this.state[0] = null;
/*  88 */     this.state[1] = null;
/*  89 */     this.state = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer)
/*     */   {
/*  98 */     if (!checkInputBuffer(inputBuffer)) {
/*  99 */       return 1;
/*     */     }
/*     */     
/* 102 */     if (isEOM(inputBuffer)) {
/* 103 */       propagateEOM(outputBuffer);
/* 104 */       return 0;
/*     */     }
/*     */     
/* 107 */     byte[] inData = (byte[])inputBuffer.getData();
/*     */     
/*     */ 
/* 110 */     byte[] outData = validateByteArraySize(outputBuffer, inData.length * 4);
/* 111 */     AudioFormat iaf = (AudioFormat)inputBuffer.getFormat();
/*     */     
/* 113 */     int blockAlign = iaf.getFrameSizeInBits() >> 3;
/* 114 */     int channels = iaf.getChannels();
/*     */     
/* 116 */     int outLength = decode(inData, outData, inputBuffer.getLength(), blockAlign, channels);
/*     */     
/* 118 */     updateOutput(outputBuffer, this.outputFormat, outLength, 0);
/*     */     
/* 120 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int decode(byte[] inpData, byte[] outData, int inLength, int blockAlign, int channels)
/*     */   {
/* 130 */     int dataBytesInBlock = blockAlign - 7 * channels;
/* 131 */     int outBytes = 4 * channels + (blockAlign - 7 * channels) * 4;
/* 132 */     int readPtr = 0;
/* 133 */     int writePtr = 0;
/* 134 */     int numberOfBlocks = inLength / blockAlign;
/*     */     
/*     */ 
/* 137 */     int n = 1;
/* 138 */     for (; n <= numberOfBlocks; 
/* 139 */         readPtr += blockAlign) {
/* 140 */       MsAdpcm.decodeBlock(inpData, readPtr, outData, writePtr, dataBytesInBlock, this.state, channels);n++;writePtr += outBytes;
/*     */     }
/*     */     
/*     */ 
/* 144 */     return writePtr;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\codec\audio\msadpcm\JavaDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */