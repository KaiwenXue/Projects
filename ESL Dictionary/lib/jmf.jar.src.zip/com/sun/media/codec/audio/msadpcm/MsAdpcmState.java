package com.sun.media.codec.audio.msadpcm;

class MsAdpcmState
{
  int index;
  int bpred;
  int sample1;
  int sample2;
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\codec\audio\msadpcm\MsAdpcmState.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */