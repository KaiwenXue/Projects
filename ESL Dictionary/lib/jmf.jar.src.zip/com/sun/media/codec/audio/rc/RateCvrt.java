/*     */ package com.sun.media.codec.audio.rc;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.codec.audio.AudioCodec;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RateCvrt
/*     */   extends AudioCodec
/*     */ {
/*     */   public RateCvrt()
/*     */   {
/*  31 */     this.inputFormats = new Format[] { new AudioFormat("LINEAR") };
/*     */   }
/*     */   
/*     */ 
/*     */   public String getName()
/*     */   {
/*  37 */     return "Rate Conversion";
/*     */   }
/*     */   
/*     */   public Format[] getSupportedOutputFormats(Format input)
/*     */   {
/*  42 */     if (input == null) {
/*  43 */       return new Format[] { new AudioFormat("LINEAR") };
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  50 */     if ((input instanceof AudioFormat))
/*     */     {
/*  52 */       AudioFormat af = (AudioFormat)input;
/*  53 */       int ssize = af.getSampleSizeInBits();
/*  54 */       int chnl = af.getChannels();
/*  55 */       int endian = af.getEndian();
/*  56 */       int signed = af.getSigned();
/*     */       
/*  58 */       this.outputFormats = new Format[] { new AudioFormat("LINEAR", 8000.0D, ssize, chnl, endian, signed), new AudioFormat("LINEAR", 11025.0D, ssize, chnl, endian, signed), new AudioFormat("LINEAR", 16000.0D, ssize, chnl, endian, signed), new AudioFormat("LINEAR", 22050.0D, ssize, chnl, endian, signed), new AudioFormat("LINEAR", 32000.0D, ssize, chnl, endian, signed), new AudioFormat("LINEAR", 44100.0D, ssize, chnl, endian, signed), new AudioFormat("LINEAR", 48000.0D, ssize, chnl, endian, signed) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */       this.outputFormats = new Format[0];
/*     */     }
/*     */     
/* 106 */     return this.outputFormats;
/*     */   }
/*     */   
/*     */   public synchronized int process(Buffer in, Buffer out)
/*     */   {
/* 111 */     if (!checkInputBuffer(in))
/*     */     {
/* 113 */       return 1;
/*     */     }
/*     */     
/* 116 */     if (isEOM(in)) {
/* 117 */       propagateEOM(out);
/* 118 */       return 0;
/*     */     }
/*     */     
/* 121 */     int inOffset = in.getOffset();
/* 122 */     int inLen = in.getLength();
/*     */     
/*     */ 
/* 125 */     double inRate = ((AudioFormat)this.inputFormat).getSampleRate();
/* 126 */     double outRate = ((AudioFormat)this.outputFormat).getSampleRate();
/* 127 */     int chnl = ((AudioFormat)this.inputFormat).getChannels();
/* 128 */     int bsize = ((AudioFormat)this.inputFormat).getSampleSizeInBits() / 8;
/* 129 */     int step = 0;
/*     */     
/* 131 */     if (chnl == 2) {
/* 132 */       if (bsize == 2) {
/* 133 */         step = 4;
/*     */       } else {
/* 135 */         step = 2;
/*     */       }
/* 137 */     } else if (bsize == 2) {
/* 138 */       step = 2;
/*     */     } else {
/* 140 */       step = 1;
/*     */     }
/*     */     
/* 143 */     if ((outRate == 0.0D) || (inRate == 0.0D)) {
/* 144 */       return 1;
/*     */     }
/*     */     
/* 147 */     double ratio = inRate / outRate;
/*     */     
/* 149 */     int outLen = (int)((inLen - inOffset) * outRate / inRate + 0.5D);
/* 150 */     switch (step) {
/*     */     case 2: 
/* 152 */       if (outLen % 2 == 1)
/* 153 */         outLen++;
/*     */       break;
/*     */     case 4: 
/* 156 */       if (outLen % 4 != 0) {
/* 157 */         outLen = outLen / 4 + 1 << 2;
/*     */       }
/*     */       break;
/*     */     }
/* 161 */     if (this.inputFormat.getDataType() == Format.byteArray)
/* 162 */       return doByteCvrt(in, inLen, inOffset, out, outLen, step, ratio);
/* 163 */     if (this.inputFormat.getDataType() == Format.shortArray)
/* 164 */       return doShortCvrt(in, inLen, inOffset, out, outLen, step, ratio);
/* 165 */     if (this.inputFormat.getDataType() == Format.intArray) {
/* 166 */       return doIntCvrt(in, inLen, inOffset, out, outLen, step, ratio);
/*     */     }
/*     */     
/* 169 */     return 1;
/*     */   }
/*     */   
/*     */   private int doByteCvrt(Buffer in, int inLen, int inOffset, Buffer out, int outLen, int step, double ratio) {
/* 173 */     byte[] inData = (byte[])in.getData();
/* 174 */     byte[] outData = validateByteArraySize(out, outLen);
/* 175 */     int outOffset = 0;
/*     */     
/* 177 */     out.setData(outData);
/* 178 */     out.setFormat(this.outputFormat);
/* 179 */     out.setOffset(0);
/* 180 */     out.setLength(outLen);
/*     */     
/*     */ 
/* 183 */     double sum = 0.0D;
/* 184 */     int inPtr = inOffset;
/* 185 */     int outPtr = outOffset;
/* 186 */     int inEnd = inOffset + inLen;
/*     */     
/* 188 */     if (ratio == 1.0D) {
/* 189 */       System.arraycopy(inData, inOffset, outData, outOffset, inLen);
/* 190 */       return 0;
/*     */     }
/*     */     
/* 193 */     if (ratio > 1.0D) {
/*     */       do {
/* 195 */         for (int i = 0; i < step; i++) {
/* 196 */           outData[(outPtr++)] = inData[(inPtr + i)];
/*     */         }
/*     */         
/* 199 */         sum += ratio;
/* 200 */         while (sum > 0.0D) {
/* 201 */           inPtr += step;
/* 202 */           sum -= 1.0D;
/*     */         }
/* 194 */         if (inPtr > inEnd - step) break; } while (outPtr <= outLen - step);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 207 */       byte[] d = new byte[step];
/* 208 */       while (inPtr <= inEnd - step) {
/* 209 */         for (int i = 0; i < step; i++) {
/* 210 */           outData[(outPtr++)] = inData[(inPtr + i)];
/* 211 */           d[i] = inData[(inPtr + i)];
/*     */         }
/*     */         
/* 214 */         while (sum += ratio < 1.0D) {
/* 215 */           if (outPtr <= outLen - step) {
/* 216 */             for (int i = 0; i < step; i++) {
/* 217 */               outData[(outPtr++)] = d[i];
/*     */             }
/*     */           }
/*     */         }
/* 221 */         sum -= 1.0D;
/* 222 */         inPtr += step;
/*     */       }
/*     */     }
/*     */     
/* 226 */     return 0;
/*     */   }
/*     */   
/*     */   private int doShortCvrt(Buffer in, int inLen, int inOffset, Buffer out, int outLen, int step, double ratio)
/*     */   {
/* 231 */     short[] inData = (short[])in.getData();
/* 232 */     short[] outData = validateShortArraySize(out, outLen);
/* 233 */     int outOffset = 0;
/*     */     
/* 235 */     out.setData(outData);
/* 236 */     out.setFormat(this.outputFormat);
/* 237 */     out.setOffset(0);
/* 238 */     out.setLength(outLen);
/*     */     
/*     */ 
/* 241 */     double sum = 0.0D;
/* 242 */     int inPtr = inOffset;
/* 243 */     int outPtr = outOffset;
/* 244 */     int inEnd = inOffset + inLen;
/*     */     
/* 246 */     if (ratio == 1.0D) {
/* 247 */       System.arraycopy(inData, inOffset, outData, outOffset, inLen);
/* 248 */       return 0;
/*     */     }
/*     */     
/* 251 */     if (ratio > 1.0D) {
/*     */       do {
/* 253 */         for (int i = 0; i < step; i++) {
/* 254 */           outData[(outPtr++)] = inData[(inPtr + i)];
/*     */         }
/*     */         
/* 257 */         sum += ratio;
/* 258 */         while (sum > 0.0D) {
/* 259 */           inPtr += step;
/* 260 */           sum -= 1.0D;
/*     */         }
/* 252 */         if (inPtr > inEnd - step) break; } while (outPtr <= outLen - step);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 265 */       short[] d = new short[step];
/* 266 */       while (inPtr <= inEnd - step) {
/* 267 */         for (int i = 0; i < step; i++) {
/* 268 */           outData[(outPtr++)] = inData[(inPtr + i)];
/* 269 */           d[i] = inData[(inPtr + i)];
/*     */         }
/*     */         
/* 272 */         while (sum += ratio < 1.0D) {
/* 273 */           if (outPtr <= outLen - step) {
/* 274 */             for (int i = 0; i < step; i++)
/* 275 */               outData[(outPtr++)] = d[i];
/*     */           }
/*     */         }
/* 278 */         sum -= 1.0D;
/* 279 */         inPtr += step;
/*     */       }
/*     */     }
/*     */     
/* 283 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   private int doIntCvrt(Buffer in, int inLen, int inOffset, Buffer out, int outLen, int step, double ratio)
/*     */   {
/* 289 */     int[] inData = (int[])in.getData();
/* 290 */     int[] outData = validateIntArraySize(out, outLen);
/* 291 */     int outOffset = 0;
/*     */     
/* 293 */     out.setData(outData);
/* 294 */     out.setFormat(this.outputFormat);
/* 295 */     out.setOffset(0);
/* 296 */     out.setLength(outLen);
/*     */     
/*     */ 
/* 299 */     double sum = 0.0D;
/* 300 */     int inPtr = inOffset;
/* 301 */     int outPtr = outOffset;
/* 302 */     int inEnd = inOffset + inLen;
/*     */     
/* 304 */     if (ratio == 1.0D) {
/* 305 */       System.arraycopy(inData, inOffset, outData, outOffset, inLen);
/* 306 */       return 0;
/*     */     }
/*     */     
/* 309 */     if (ratio > 1.0D) {
/*     */       do {
/* 311 */         for (int i = 0; i < step; i++) {
/* 312 */           outData[(outPtr++)] = inData[(inPtr + i)];
/*     */         }
/*     */         
/* 315 */         sum += ratio;
/* 316 */         while (sum > 0.0D) {
/* 317 */           inPtr += step;
/* 318 */           sum -= 1.0D;
/*     */         }
/* 310 */         if (inPtr > inEnd - step) break; } while (outPtr <= outLen - step);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 323 */       int[] d = new int[step];
/* 324 */       while (inPtr <= inEnd - step) {
/* 325 */         for (int i = 0; i < step; i++) {
/* 326 */           outData[(outPtr++)] = inData[(inPtr + i)];
/* 327 */           d[i] = inData[(inPtr + i)];
/*     */         }
/*     */         
/* 330 */         while (sum += ratio < 1.0D) {
/* 331 */           if (outPtr <= outLen - step) {
/* 332 */             for (int i = 0; i < step; i++)
/* 333 */               outData[(outPtr++)] = d[i];
/*     */           }
/*     */         }
/* 336 */         sum -= 1.0D;
/* 337 */         inPtr += step;
/*     */       }
/*     */     }
/*     */     
/* 341 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\codec\audio\rc\RateCvrt.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */