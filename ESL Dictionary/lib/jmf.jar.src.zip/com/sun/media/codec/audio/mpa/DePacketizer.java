/*     */ package com.sun.media.codec.audio.mpa;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import com.sun.media.codec.audio.AudioCodec;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DePacketizer
/*     */   extends AudioCodec
/*     */ {
/*  25 */   private static int OUT_BUF_SIZE = 4096;
/*     */   
/*  27 */   private static int MAX_SEQ = 65535;
/*     */   
/*  29 */   private static Format[] defaultSupportedOutputFormats = { new AudioFormat("mpegaudio", 44100.0D, 16, -1, 1, 1), new AudioFormat("mpegaudio", 48000.0D, 16, -1, 1, 1), new AudioFormat("mpegaudio", 32000.0D, 16, -1, 1, 1), new AudioFormat("mpegaudio", 22050.0D, 16, -1, 1, 1), new AudioFormat("mpegaudio", 24000.0D, 16, -1, 1, 1), new AudioFormat("mpegaudio", 16000.0D, 16, -1, 1, 1), new AudioFormat("mpegaudio", 11025.0D, 16, -1, 1, 1), new AudioFormat("mpegaudio", 12000.0D, 16, -1, 1, 1), new AudioFormat("mpegaudio", 8000.0D, 16, -1, 1, 1), new AudioFormat("mpeglayer3", 44100.0D, 16, -1, 1, 1), new AudioFormat("mpeglayer3", 48000.0D, 16, -1, 1, 1), new AudioFormat("mpeglayer3", 32000.0D, 16, -1, 1, 1), new AudioFormat("mpeglayer3", 22050.0D, 16, -1, 1, 1), new AudioFormat("mpeglayer3", 24000.0D, 16, -1, 1, 1), new AudioFormat("mpeglayer3", 16000.0D, 16, -1, 1, 1), new AudioFormat("mpeglayer3", 11025.0D, 16, -1, 1, 1), new AudioFormat("mpeglayer3", 12000.0D, 16, -1, 1, 1), new AudioFormat("mpeglayer3", 8000.0D, 16, -1, 1, 1) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 104 */   private boolean bufferContinued = false;
/* 105 */   private boolean frameContinued = false;
/* 106 */   private int frameSize = 0;
/* 107 */   private int frameBegin = 0;
/* 108 */   private int frameOffset = 0;
/* 109 */   private long frameTimeStamp = 0L;
/* 110 */   private long bufTimeStamp = 0L;
/* 111 */   private long prevSeq = -1L;
/* 112 */   private long outSeq = 0L;
/* 113 */   private MPAParse mpaParse = new MPAParse();
/* 114 */   private MPAHeader mpaHeader = new MPAHeader();
/*     */   
/*     */ 
/*     */   private static final boolean debug = false;
/*     */   
/*     */ 
/*     */   public DePacketizer()
/*     */   {
/* 122 */     this.inputFormats = new Format[] { new AudioFormat("mpegaudio/rtp") };
/*     */   }
/*     */   
/*     */   public String getName() {
/* 126 */     return "MPEG Audio DePacketizer";
/*     */   }
/*     */   
/*     */   public Format[] getSupportedOutputFormats(Format in)
/*     */   {
/* 131 */     if (in == null) {
/* 132 */       return defaultSupportedOutputFormats;
/*     */     }
/*     */     
/* 135 */     if (BasicPlugIn.matches(in, this.inputFormats) == null) {
/* 136 */       return new Format[1];
/*     */     }
/*     */     
/* 139 */     if (!(in instanceof AudioFormat)) {
/* 140 */       return defaultSupportedOutputFormats;
/*     */     }
/*     */     
/* 143 */     if (this.outputFormat != null) {
/* 144 */       return new Format[] { this.outputFormat };
/*     */     }
/*     */     
/* 147 */     AudioFormat af = (AudioFormat)in;
/* 148 */     AudioFormat of = new AudioFormat("mpegaudio", af.getSampleRate() == -1.0D ? 44100.0D : af.getSampleRate(), af.getSampleSizeInBits() == -1 ? 16 : af.getSampleSizeInBits(), af.getChannels() == -1 ? 2 : af.getChannels());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 155 */     return new Format[] { of };
/*     */   }
/*     */   
/*     */ 
/*     */   public void open() {}
/*     */   
/*     */ 
/*     */   public void close() {}
/*     */   
/*     */   public int process(Buffer inputBuffer, Buffer outputBuffer)
/*     */   {
/*     */     try
/*     */     {
/* 168 */       return doProcess(inputBuffer, outputBuffer);
/*     */     } catch (Exception ex) {
/* 170 */       ex.printStackTrace();
/*     */     }
/* 172 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int doProcess(Buffer inputBuffer, Buffer outputBuffer)
/*     */   {
/* 189 */     if (!checkInputBuffer(inputBuffer)) {
/* 190 */       return 1;
/*     */     }
/*     */     
/* 193 */     if (isEOM(inputBuffer)) {
/* 194 */       propagateEOM(outputBuffer);
/* 195 */       this.mpaParse.reset();
/* 196 */       return 0;
/*     */     }
/*     */     
/* 199 */     byte[] inData = (byte[])inputBuffer.getData();
/* 200 */     int inOffset = inputBuffer.getOffset();
/* 201 */     int inLength = inputBuffer.getLength();
/* 202 */     int packetOffset = ((inData[(inOffset + 2)] & 0xFF) << 8) + (inData[(inOffset + 3)] & 0xFF);
/*     */     
/* 204 */     inOffset += 4;
/* 205 */     inLength -= 4;
/* 206 */     if (packetOffset > 0)
/*     */     {
/* 208 */       if (!this.frameContinued)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 215 */         return 4;
/*     */       }
/*     */       
/* 218 */       if (inputBuffer.getTimeStamp() != this.frameTimeStamp)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 226 */         dropFrame(outputBuffer);
/* 227 */         return 4;
/*     */       }
/*     */       
/* 230 */       if (getSequenceDiff(this.prevSeq, inputBuffer.getSequenceNumber()) != 1)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 239 */         dropFrame(outputBuffer);
/* 240 */         return 4;
/*     */       }
/* 242 */       this.prevSeq = inputBuffer.getSequenceNumber();
/*     */       
/*     */ 
/* 245 */       if (!copyBuffer(inData, inOffset, inLength, outputBuffer, this.frameBegin + this.frameOffset))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 252 */         dropFrame(outputBuffer);
/* 253 */         return 4;
/*     */       }
/*     */       
/* 256 */       this.frameOffset += inLength;
/*     */       
/*     */ 
/* 259 */       if (this.frameOffset < this.frameSize) {
/* 260 */         return 4;
/*     */       }
/* 262 */       this.frameContinued = false;
/* 263 */       this.frameOffset = 0;
/* 264 */       if ((this.mpaHeader.layer == 3) && (this.frameBegin == 0))
/*     */       {
/* 266 */         return 4;
/*     */       }
/* 268 */       outputBuffer.setTimeStamp(this.bufTimeStamp);
/* 269 */       outputBuffer.setFlags(outputBuffer.getFlags() | 0x20);
/*     */       
/* 271 */       this.bufferContinued = false;
/* 272 */       return 0;
/*     */     }
/* 274 */     if (this.frameContinued)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 280 */       dropFrame(outputBuffer);
/*     */     }
/*     */     
/* 283 */     this.frameContinued = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 292 */     this.prevSeq = inputBuffer.getSequenceNumber();
/* 293 */     this.frameTimeStamp = inputBuffer.getTimeStamp();
/* 294 */     int rc = this.mpaParse.getHeader(this.mpaHeader, inData, inOffset, inLength);
/* 295 */     if ((rc != MPAParse.MPA_OK) && (rc != MPAParse.MPA_HDR_DOUBTED)) {
/* 296 */       return 1;
/*     */     }
/*     */     
/* 299 */     String encoding = this.mpaHeader.layer == 3 ? "mpeglayer3" : "mpegaudio";
/*     */     
/* 301 */     AudioFormat af = (AudioFormat)this.outputFormat;
/* 302 */     if ((af == null) || (!encoding.equalsIgnoreCase(af.getEncoding())) || (af.getSampleRate() != this.mpaHeader.samplingRate) || (af.getChannels() != this.mpaHeader.nChannels))
/*     */     {
/*     */ 
/*     */ 
/* 306 */       this.outputFormat = new AudioFormat(encoding, this.mpaHeader.samplingRate, 16, this.mpaHeader.nChannels, 1, 1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 312 */     this.frameSize = (this.mpaHeader.bitsInFrame >> 3);
/* 313 */     if (this.frameSize > inLength) {
/* 314 */       if (!this.bufferContinued) {
/* 315 */         outputBuffer.setLength(0);
/* 316 */         outputBuffer.setOffset(0);
/* 317 */         this.bufTimeStamp = this.frameTimeStamp;
/* 318 */         outputBuffer.setFormat(this.outputFormat);
/* 319 */         outputBuffer.setSequenceNumber(this.outSeq++);
/*     */       }
/* 321 */       this.bufferContinued = true;
/* 322 */       this.frameContinued = true;
/* 323 */       this.frameBegin = outputBuffer.getLength();
/* 324 */       this.frameOffset = inLength;
/*     */       
/* 326 */       copyBuffer(inData, inOffset, inLength, outputBuffer, outputBuffer.getLength());
/*     */       
/* 328 */       return 4;
/*     */     }
/*     */     
/* 331 */     if ((this.mpaHeader.layer == 3) && (inLength < this.frameSize * 2 - 2))
/*     */     {
/* 333 */       if (!this.bufferContinued) {
/* 334 */         outputBuffer.setLength(0);
/* 335 */         outputBuffer.setOffset(0);
/* 336 */         this.bufTimeStamp = this.frameTimeStamp;
/* 337 */         byte[] outData = (byte[])outputBuffer.getData();
/* 338 */         if ((outData == null) || (outData.length < OUT_BUF_SIZE)) {
/* 339 */           outData = new byte[OUT_BUF_SIZE];
/* 340 */           outputBuffer.setData(outData);
/*     */         }
/*     */       }
/*     */       
/* 344 */       if (!copyBuffer(inData, inOffset, inLength, outputBuffer, outputBuffer.getLength()))
/*     */       {
/*     */ 
/* 347 */         outputBuffer.setFormat(this.outputFormat);
/* 348 */         outputBuffer.setSequenceNumber(this.outSeq++);
/* 349 */         outputBuffer.setTimeStamp(this.bufTimeStamp);
/* 350 */         outputBuffer.setFlags(outputBuffer.getFlags() | 0x20);
/*     */         
/* 352 */         this.bufferContinued = false;
/* 353 */         return 2;
/*     */       }
/*     */       
/*     */ 
/* 357 */       if (outputBuffer.getLength() + this.frameSize + 4 > OUT_BUF_SIZE)
/*     */       {
/* 359 */         outputBuffer.setFormat(this.outputFormat);
/* 360 */         outputBuffer.setSequenceNumber(this.outSeq++);
/* 361 */         outputBuffer.setTimeStamp(this.bufTimeStamp);
/* 362 */         outputBuffer.setFlags(outputBuffer.getFlags() | 0x20);
/*     */         
/* 364 */         this.bufferContinued = false;
/* 365 */         return 0;
/*     */       }
/* 367 */       this.bufferContinued = true;
/* 368 */       return 4;
/*     */     }
/*     */     
/*     */ 
/* 372 */     Object outData = outputBuffer.getData();
/* 373 */     outputBuffer.setData(inputBuffer.getData());
/* 374 */     inputBuffer.setData(outData);
/* 375 */     outputBuffer.setLength(inLength);
/* 376 */     outputBuffer.setFormat(this.outputFormat);
/* 377 */     outputBuffer.setOffset(inOffset);
/* 378 */     outputBuffer.setSequenceNumber(this.outSeq++);
/* 379 */     outputBuffer.setTimeStamp(this.frameTimeStamp);
/* 380 */     outputBuffer.setFlags(outputBuffer.getFlags() | 0x20);
/*     */     
/* 382 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean copyBuffer(byte[] inData, int inOff, int inLen, Buffer outputBuffer, int outOff)
/*     */   {
/* 388 */     byte[] outData = (byte[])outputBuffer.getData();
/* 389 */     if ((outData == null) || (outOff + inLen > outData.length))
/*     */     {
/* 391 */       if (outOff + inLen > OUT_BUF_SIZE)
/*     */       {
/* 393 */         return false;
/*     */       }
/* 395 */       byte[] newData = new byte[OUT_BUF_SIZE];
/* 396 */       if (outOff > 0) {
/* 397 */         System.arraycopy(outData, 0, newData, 0, outData.length);
/*     */       }
/* 399 */       outData = newData;
/* 400 */       outputBuffer.setData(outData);
/*     */     }
/* 402 */     System.arraycopy(inData, inOff, outData, outOff, inLen);
/* 403 */     outputBuffer.setLength(outputBuffer.getLength() + inLen);
/*     */     
/* 405 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getSequenceDiff(long p, long c)
/*     */   {
/* 416 */     if (c > p)
/* 417 */       return (int)(c - p);
/* 418 */     if (c == p)
/* 419 */       return 0;
/* 420 */     if ((p > MAX_SEQ - 100) && (c < 100L))
/*     */     {
/* 422 */       return (int)(MAX_SEQ - p + c + 1L);
/*     */     }
/* 424 */     return (int)(c - p);
/*     */   }
/*     */   
/*     */   private void dropFrame(Buffer outputBuffer) {
/* 428 */     outputBuffer.setLength(this.frameBegin - outputBuffer.getOffset());
/* 429 */     this.frameBegin = (outputBuffer.getLength() + outputBuffer.getOffset());
/* 430 */     this.frameSize = 0;
/* 431 */     this.frameOffset = 0;
/* 432 */     this.frameContinued = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\codec\audio\mpa\DePacketizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */