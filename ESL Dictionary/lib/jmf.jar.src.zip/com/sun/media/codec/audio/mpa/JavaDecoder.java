/*     */ package com.sun.media.codec.audio.mpa;
/*     */ 
/*     */ import codecLib.mpa.Decoder;
/*     */ import codecLib.mpa.FrameInfo;
/*     */ import codecLib.mpa.MPADException;
/*     */ import codecLib.mpa.OutputConverter;
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.codec.audio.AudioCodec;
/*     */ import java.io.PrintStream;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaDecoder
/*     */   extends AudioCodec
/*     */ {
/*  32 */   private int pendingDataSize = 0;
/*     */   private static final int OUTSIZE = 32768;
/*  34 */   private byte[] pendingData = new byte[32768];
/*  35 */   private Decoder decoder = null;
/*  36 */   private FrameInfo info = null;
/*  37 */   private boolean expectingSameInputBuffer = false;
/*  38 */   private long accumTS = 0L;
/*  39 */   private AudioFormat aFormat = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JavaDecoder()
/*     */   {
/*  48 */     this.inputFormats = new Format[] { new AudioFormat("mpegaudio", 16000.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 22050.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 24000.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 32000.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 44100.0D, -1, -1, -1, 1), new AudioFormat("mpegaudio", 48000.0D, -1, -1, -1, 1) };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 140 */     return "MPEG Layer 3 Decoder";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Format[] getSupportedOutputFormats(Format input)
/*     */   {
/* 154 */     if (input == null) {
/* 155 */       return new Format[] { new AudioFormat("LINEAR") };
/*     */     }
/*     */     
/* 158 */     if ((input instanceof AudioFormat)) {
/* 159 */       AudioFormat af = (AudioFormat)input;
/* 160 */       this.outputFormats = new Format[] { new AudioFormat("LINEAR", af.getSampleRate(), af.getSampleSizeInBits(), af.getChannels(), 1, 1) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 172 */       this.outputFormats = new Format[0];
/*     */     }
/* 174 */     return this.outputFormats;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void open()
/*     */     throws ResourceUnavailableException
/*     */   {
/* 186 */     if (this.decoder != null) {
/* 187 */       close();
/*     */     }
/*     */     try
/*     */     {
/* 191 */       this.decoder = new Decoder();
/* 192 */       this.pendingDataSize = 0;
/* 193 */       this.expectingSameInputBuffer = false;
/* 194 */       this.accumTS = 0L;
/* 195 */       this.aFormat = ((AudioFormat)this.outputFormat);
/*     */       
/*     */ 
/* 198 */       return;
/*     */     } catch (Throwable e) {
/* 200 */       System.out.println("mpa JavaDecoder: open " + e);
/*     */       
/*     */ 
/* 203 */       throw new ResourceUnavailableException("could not open " + getName());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/* 213 */     if (this.decoder != null) {
/* 214 */       this.decoder = null;
/*     */     }
/* 216 */     if (this.info != null) {
/* 217 */       this.info = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void reset()
/*     */   {
/* 228 */     if (this.decoder != null) {
/* 229 */       close();
/*     */       try
/*     */       {
/* 232 */         open();
/*     */       } catch (ResourceUnavailableException rue) {
/* 234 */         System.err.println("MP3 Decoder: " + rue);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 239 */   float[][] fsamp = new float[12]['Ҁ'];
/*     */   
/* 241 */   int[] fsampOffset = new int[12];
/* 242 */   int MAXOUTFRAMESIZE = 27648;
/*     */   
/*     */ 
/* 245 */   int MIMINFRAMESIZE = 13;
/* 246 */   int outFrameSize = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized int process(Buffer in, Buffer out)
/*     */   {
/* 260 */     if (isEOM(in)) {
/* 261 */       propagateEOM(out);
/* 262 */       return 0;
/*     */     }
/*     */     
/* 265 */     Object inObject = in.getData();
/* 266 */     Object outObject = out.getData();
/*     */     
/* 268 */     if (outObject == null) {
/* 269 */       outObject = new byte[32768];
/* 270 */       out.setData(outObject);
/*     */     }
/*     */     
/* 273 */     if ((!(inObject instanceof byte[])) || (!(outObject instanceof byte[])))
/*     */     {
/* 275 */       return 1;
/*     */     }
/*     */     
/* 278 */     byte[] inData = (byte[])inObject;
/* 279 */     byte[] outData = (byte[])outObject;
/* 280 */     int inLength = in.getLength();
/* 281 */     int inOffset = in.getOffset();
/* 282 */     int outDataSize = outData.length;
/* 283 */     int outOffset = 0;
/* 284 */     int pendingDataOffset = 0;
/* 285 */     int byteCount = 0;
/*     */     
/* 287 */     if ((!this.expectingSameInputBuffer) && 
/* 288 */       (this.pendingDataSize + inLength <= this.pendingData.length)) {
/* 289 */       System.arraycopy(inData, inOffset, this.pendingData, this.pendingDataSize, inLength);
/*     */       
/*     */ 
/* 292 */       this.pendingDataSize += inLength;
/*     */     }
/*     */     
/*     */ 
/* 296 */     if (this.decoder != null)
/*     */     {
/*     */ 
/*     */ 
/* 300 */       while (outDataSize - outOffset >= this.MAXOUTFRAMESIZE)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 305 */         if (this.pendingDataSize < this.MIMINFRAMESIZE) {
/*     */           break;
/*     */         }
/*     */         
/* 309 */         if (this.info == null) {
/* 310 */           this.info = new FrameInfo();
/*     */           try {
/* 312 */             this.decoder.getNextFrameInfo(this.info, this.pendingData, pendingDataOffset, this.pendingDataSize);
/*     */             
/*     */ 
/*     */ 
/* 316 */             this.outFrameSize = (this.info.getNumberOfSamples() * this.info.getNumberOfChannels() * 2);
/*     */ 
/*     */           }
/*     */           catch (MPADException e)
/*     */           {
/* 321 */             this.info = null;
/* 322 */             break;
/*     */           }
/*     */         }
/*     */         try
/*     */         {
/* 327 */           byteCount = this.decoder.decode(this.fsamp, this.fsampOffset, this.pendingData, pendingDataOffset, this.pendingDataSize);
/*     */ 
/*     */         }
/*     */         catch (MPADException e)
/*     */         {
/*     */ 
/* 333 */           if (e.getState() == -10) {
/* 334 */             return 1;
/*     */           }
/*     */           try {
/* 337 */             this.decoder.getCurrFrameInfo(this.info);
/*     */           }
/*     */           catch (MPADException e2) {
/* 340 */             this.info = null;
/* 341 */             break;
/*     */           }
/*     */           
/* 344 */           if (e.getState() == -9) {
/* 345 */             byteCount = this.info.getHeaderOffset() + this.info.getFrameLength();
/* 346 */             pendingDataOffset += byteCount;
/* 347 */             this.pendingDataSize -= byteCount;
/* 348 */             continue;
/*     */           }
/*     */           
/*     */ 
/* 352 */           this.info = null;
/* 353 */           break;
/*     */         }
/*     */         
/* 356 */         if (this.info.getNumberOfChannels() == 1) {
/* 357 */           OutputConverter.convert(outData, outOffset, this.fsamp[0], this.fsampOffset[0], this.info.getNumberOfSamples());
/*     */         }
/*     */         else
/*     */         {
/* 361 */           OutputConverter.convert(outData, outOffset, this.fsamp[0], this.fsampOffset[0], this.fsamp[1], this.fsampOffset[1], this.info.getNumberOfSamples());
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 367 */         outOffset += this.outFrameSize;
/* 368 */         pendingDataOffset += byteCount;
/* 369 */         this.pendingDataSize -= byteCount;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 374 */     if (pendingDataOffset != 0) {
/* 375 */       System.arraycopy(this.pendingData, pendingDataOffset, this.pendingData, 0, this.pendingDataSize);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 380 */     out.setLength(outOffset);
/* 381 */     out.setFormat(this.outputFormat);
/* 382 */     if ((this.aFormat != null) && (this.accumTS != 0L) && (in.getTimeStamp() > 0L)) {
/* 383 */       out.setTimeStamp(in.getTimeStamp() + this.aFormat.computeDuration(this.accumTS));
/*     */     }
/*     */     
/* 386 */     if (this.pendingDataSize > 1024) {
/* 387 */       this.expectingSameInputBuffer = true;
/* 388 */       this.accumTS += out.getLength();
/* 389 */       return 2;
/*     */     }
/* 391 */     this.accumTS = 0L;
/* 392 */     this.expectingSameInputBuffer = false;
/* 393 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\codec\audio\mpa\JavaDecoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */