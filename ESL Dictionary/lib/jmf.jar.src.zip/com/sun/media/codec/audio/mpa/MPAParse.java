/*     */ package com.sun.media.codec.audio.mpa;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MPAParse
/*     */ {
/*  32 */   private static int MPA_MAX_BYTES_IN_FRAME = 2024;
/*     */   
/*  34 */   private static int MPA_MIN_BYTES_IN_FRAME = 21;
/*     */   
/*     */ 
/*  37 */   private static int MPA_NSAMP = 1152;
/*     */   
/*     */ 
/*  40 */   private static int MPA_LAYER1 = 3;
/*  41 */   private static int MPA_LAYER2 = 2;
/*  42 */   private static int MPA_LAYER3 = 1;
/*     */   
/*     */ 
/*  45 */   private static int MPA_MPEG1 = 1;
/*  46 */   private static int MPA_MPEG2 = 0;
/*     */   
/*     */ 
/*  49 */   private static int MPA_MONO = 3;
/*     */   
/*     */ 
/*  52 */   public static int[][] SAMPLE_TABLE = { { 22050, 24000, 16000, 0 }, { 44100, 48000, 32000, 0 } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */   public static int[][] BITRATE_TABLE1 = { { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 }, { 0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, -1 }, { 0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, -1 }, { 0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, -1 } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */   public static int[][] BITRATE_TABLE2 = { { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 }, { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, -1 }, { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, -1 }, { 0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, -1 } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */   private static int[] MAX_FREE_BITS = { 0, 11520, 13824, 5376 };
/*     */   
/*     */ 
/*  93 */   public static int[] SLOT_BITS_MASK = { 0, 7, 7, 31 };
/*     */   
/*     */ 
/*  96 */   public static int[][] SAMPLES_PER_FRAME = { { 0, 576, 1152, 384 }, { 0, 1152, 1152, 384 } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 101 */   public static int MPA_OK = 0;
/* 102 */   public static int MPA_HDR_DOUBTED = 1;
/* 103 */   public static int MPA_ERR_LOWBUFFER = -1;
/* 104 */   public static int MPA_ERR_NULLPTR = -2;
/* 105 */   public static int MPA_ERR_NOHDR = -3;
/*     */   
/* 107 */   private boolean firstFound = false;
/* 108 */   private int firstId = 0;
/* 109 */   private int firstLayer = 0;
/* 110 */   private int firstSamplingRate = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 116 */     return "MPEG Audio Parser";
/*     */   }
/*     */   
/*     */   public void reset() {
/* 120 */     this.firstFound = false;
/* 121 */     this.firstId = 0;
/* 122 */     this.firstLayer = 0;
/* 123 */     this.firstSamplingRate = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeader(MPAHeader header, byte[] inData, int inOffset, int inLength)
/*     */   {
/* 142 */     int status = MPA_ERR_NOHDR;
/* 143 */     boolean found = false;
/*     */     
/*     */ 
/* 146 */     int offset = inOffset;
/* 147 */     int off2 = 0;
/*     */     
/* 149 */     if (inLength < 4) {
/* 150 */       return status;
/*     */     }
/* 152 */     int bufend = offset + inLength;
/*     */     
/*     */ 
/*     */     break label59;
/*     */     
/*     */ 
/*     */     break label59;
/*     */     
/* 160 */     offset++;
/* 161 */     if (offset + 3 >= bufend) {
/* 162 */       if (!found)
/*     */       {
/* 164 */         return status;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*     */       for (;;)
/*     */       {
/*     */         label59:
/*     */         int maxLen;
/* 158 */         if (((inData[offset] & 0xFF) == 255) && ((inData[(offset + 1)] & 0xF6) > 240) && ((inData[(offset + 2)] & 0xF0) != 240) && ((inData[(offset + 2)] & 0xC) != 12) && ((inData[(offset + 3)] & 0x3) != 2))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 167 */           id = inData[(offset + 1)] >> 3 & 0x1;
/* 168 */           layer = inData[(offset + 1)] >> 1 & 0x3;
/* 169 */           crc = inData[(offset + 1)] & 0x1;
/* 170 */           bitrateIndex = inData[(offset + 2)] >> 4 & 0xF;
/* 171 */           samplingIndex = inData[(offset + 2)] >> 2 & 0x3;
/* 172 */           paddingBit = inData[(offset + 2)] >> 1 & 0x1;
/* 173 */           channelMode = inData[(offset + 3)] >> 6 & 0x3;
/*     */           
/* 175 */           int nSamples = SAMPLES_PER_FRAME[id][layer];
/* 176 */           int samplingRate = SAMPLE_TABLE[id][samplingIndex];
/*     */           
/* 178 */           if (bitrateIndex != 0) {
/* 179 */             int bitsInFrame = (id == MPA_MPEG1 ? BITRATE_TABLE1[layer][bitrateIndex] : BITRATE_TABLE2[layer][bitrateIndex]) * 1000 * nSamples / samplingRate & (SLOT_BITS_MASK[layer] ^ 0xFFFFFFFF);
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 186 */             if (paddingBit != 0) {
/* 187 */               bitsInFrame += SLOT_BITS_MASK[layer] + 1;
/*     */             }
/* 189 */             off2 = offset + (bitsInFrame >> 3);
/* 190 */             if (off2 + 1 < bufend) {
/* 191 */               if (((inData[off2] & 0xFF) == 255) && ((inData[(off2 + 1)] & 0xFE) == (inData[(offset + 1)] & 0xFE)))
/*     */               {
/* 193 */                 if (this.firstFound) {
/* 194 */                   if ((id == this.firstId) && (layer == this.firstLayer) && (samplingRate == this.firstSamplingRate))
/*     */                   {
/*     */ 
/* 197 */                     header.headerOffset = offset;
/* 198 */                     found = true;
/* 199 */                     status = MPA_OK;
/*     */                     break label800;
/*     */                   }
/* 202 */                   offset++;
/* 203 */                   continue;
/*     */                 }
/* 205 */                 header.headerOffset = offset;
/* 206 */                 found = true;
/* 207 */                 status = MPA_OK;
/*     */                 
/*     */                 break label800;
/*     */               }
/* 211 */               if ((offset == inOffset) && (this.firstFound) && (id == this.firstId) && (layer == this.firstLayer) && (samplingRate == this.firstSamplingRate))
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/* 216 */                 if (!found) {
/* 217 */                   header.headerOffset = offset;
/*     */                 }
/* 219 */                 found = true;
/*     */                 
/*     */ 
/* 222 */                 status = MPA_HDR_DOUBTED;
/*     */                 break label800;
/*     */               }
/* 225 */               offset++;
/* 226 */               continue;
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 233 */             if (!found) {
/* 234 */               header.headerOffset = offset;
/*     */             }
/* 236 */             found = true;
/* 237 */             status = MPA_HDR_DOUBTED;
/* 238 */             offset++;
/* 239 */             continue;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 244 */           maxLen = MAX_FREE_BITS[layer] >> 3;
/* 245 */           off2 = 48;
/* 246 */           if (offset + off2 + 3 >= bufend) {
/* 247 */             if (!found) {
/* 248 */               header.headerOffset = offset;
/*     */             }
/* 250 */             found = true;
/* 251 */             status = MPA_HDR_DOUBTED;
/* 252 */             offset++;
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/*     */           break;
/*     */         }
/*     */         
/*     */         try
/*     */         {
/* 262 */           while (((inData[(offset + off2)] & 0xFF) != 255) || ((inData[(offset + off2 + 1)] & 0xFE) != (inData[(offset + 1)] & 0xFE)) || ((inData[(offset + off2 + 2)] & 0xFC) != (inData[(offset + 2)] & 0xFC)) || ((inData[(offset + off2 + 3)] & 0x3) != 2))
/*     */           {
/* 264 */             off2++;
/* 265 */             if (off2 > maxLen) {
/* 266 */               offset++;
/* 267 */               break;
/*     */             }
/* 269 */             if (offset + off2 + 3 >= bufend) {
/* 270 */               if (!found) {
/* 271 */                 header.headerOffset = offset;
/*     */               }
/* 273 */               found = true;
/* 274 */               status = MPA_HDR_DOUBTED;
/* 275 */               offset++;
/* 276 */               break;
/*     */             }
/*     */           }
/*     */         } catch (Exception ex) {
/* 280 */           System.err.println("Exception: off " + offset + " off2 " + off2 + " bufend " + bufend);
/*     */           
/*     */ 
/* 283 */           ex.printStackTrace();
/* 284 */           return MPA_ERR_NOHDR;
/*     */         } }
/* 286 */       header.headerOffset = offset;
/* 287 */       found = true;
/* 288 */       status = MPA_OK;
/*     */     }
/*     */     
/*     */     label800:
/*     */     
/* 293 */     offset = header.headerOffset;
/*     */     
/* 295 */     int id = inData[(offset + 1)] >> 3 & 0x1;
/* 296 */     int layer = inData[(offset + 1)] >> 1 & 0x3;
/* 297 */     int crc = inData[(offset + 1)] & 0x1;
/* 298 */     int bitrateIndex = inData[(offset + 2)] >> 4 & 0xF;
/* 299 */     int samplingIndex = inData[(offset + 2)] >> 2 & 0x3;
/* 300 */     int paddingBit = inData[(offset + 2)] >> 1 & 0x1;
/* 301 */     int channelMode = inData[(offset + 3)] >> 6 & 0x3;
/*     */     
/* 303 */     header.layer = (4 - layer);
/* 304 */     header.nSamples = SAMPLES_PER_FRAME[id][layer];
/* 305 */     header.samplingRate = SAMPLE_TABLE[id][samplingIndex];
/* 306 */     header.bitRate = (id == MPA_MPEG1 ? BITRATE_TABLE1[layer][bitrateIndex] : BITRATE_TABLE2[layer][bitrateIndex]);
/*     */     
/*     */ 
/* 309 */     header.nChannels = (channelMode == MPA_MONO ? 1 : 2);
/*     */     
/* 311 */     if (header.bitRate > 0) {
/* 312 */       header.bitsInFrame = (header.bitRate * 1000 * header.nSamples / header.samplingRate & (SLOT_BITS_MASK[layer] ^ 0xFFFFFFFF));
/*     */       
/*     */ 
/* 315 */       if (paddingBit != 0) {
/* 316 */         header.bitsInFrame += SLOT_BITS_MASK[layer] + 1;
/*     */       }
/* 318 */     } else if (status == MPA_OK) {
/* 319 */       header.bitsInFrame = (off2 << 3);
/*     */     }
/*     */     else {
/* 322 */       header.bitsInFrame = (bufend - offset << 3);
/*     */     }
/*     */     
/*     */ 
/* 326 */     if (layer == MPA_LAYER3) {
/* 327 */       int hoff = crc == 1 ? 4 : 6;
/* 328 */       if (id == MPA_MPEG1) {
/* 329 */         header.negOffset = ((inData[(offset + hoff)] & 0xFF) << 1 | inData[(offset + hoff + 1)] >> 7 & 0x1);
/*     */       }
/*     */       else
/* 332 */         header.negOffset = (inData[(offset + hoff)] & 0xFF);
/*     */     } else {
/* 334 */       header.negOffset = 0;
/*     */     }
/*     */     
/* 337 */     if ((!this.firstFound) && (status == MPA_OK)) {
/* 338 */       this.firstFound = true;
/* 339 */       this.firstId = id;
/* 340 */       this.firstLayer = layer;
/* 341 */       this.firstSamplingRate = header.samplingRate;
/*     */     }
/*     */     
/* 344 */     return status;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\codec\audio\mpa\MPAParse.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */