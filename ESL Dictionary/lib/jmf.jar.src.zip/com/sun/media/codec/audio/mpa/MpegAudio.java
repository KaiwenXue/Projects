package com.sun.media.codec.audio.mpa;

public class MpegAudio
{
  public static native boolean nGetHeader(byte[] paramArrayOfByte, int paramInt, MPAHeader paramMPAHeader);
  
  public static native int nOpen(int[] paramArrayOfInt);
  
  public static native boolean nClose(int paramInt);
  
  public static native boolean nConvert(int paramInt1, byte[] paramArrayOfByte1, int paramInt2, int paramInt3, byte[] paramArrayOfByte2, int paramInt4, int paramInt5, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt6, int[] paramArrayOfInt3);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\codec\audio\mpa\MpegAudio.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */