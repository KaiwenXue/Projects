/*    */ package com.sun.media.codec.audio.ulaw;
/*    */ 
/*    */ import com.sun.media.BasicCodec;
/*    */ import com.sun.media.BasicPlugIn;
/*    */ import com.sun.media.codec.audio.AudioCodec;
/*    */ import javax.media.Buffer;
/*    */ import javax.media.Format;
/*    */ import javax.media.format.AudioFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DePacketizer
/*    */   extends AudioCodec
/*    */ {
/*    */   public DePacketizer()
/*    */   {
/* 26 */     this.inputFormats = new Format[] { new AudioFormat("ULAW/rtp") };
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 31 */     return "ULAW DePacketizer";
/*    */   }
/*    */   
/*    */ 
/*    */   public Format[] getSupportedOutputFormats(Format in)
/*    */   {
/* 37 */     if (in == null) {
/* 38 */       return new Format[] { new AudioFormat("ULAW") };
/*    */     }
/* 40 */     if (BasicPlugIn.matches(in, this.inputFormats) == null) {
/* 41 */       return new Format[1];
/*    */     }
/* 43 */     if (!(in instanceof AudioFormat)) {
/* 44 */       return new Format[] { new AudioFormat("ULAW") };
/*    */     }
/* 46 */     AudioFormat af = (AudioFormat)in;
/* 47 */     return new Format[] { new AudioFormat("ULAW", af.getSampleRate(), af.getSampleSizeInBits(), af.getChannels()) };
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void open() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void close() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int process(Buffer inputBuffer, Buffer outputBuffer)
/*    */   {
/* 72 */     if (!checkInputBuffer(inputBuffer)) {
/* 73 */       return 1;
/*    */     }
/*    */     
/* 76 */     if (isEOM(inputBuffer)) {
/* 77 */       propagateEOM(outputBuffer);
/* 78 */       return 0;
/*    */     }
/*    */     
/* 81 */     Object outData = outputBuffer.getData();
/* 82 */     outputBuffer.setData(inputBuffer.getData());
/* 83 */     inputBuffer.setData(outData);
/* 84 */     outputBuffer.setLength(inputBuffer.getLength());
/* 85 */     outputBuffer.setFormat(this.outputFormat);
/* 86 */     outputBuffer.setOffset(inputBuffer.getOffset());
/* 87 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\codec\audio\ulaw\DePacketizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */