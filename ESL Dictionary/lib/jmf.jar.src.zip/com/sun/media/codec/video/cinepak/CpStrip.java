/*    */ package com.sun.media.codec.video.cinepak;
/*    */ 
/*    */ 
/*    */ public class CpStrip
/*    */ {
/*    */   private int fSizeOfStrip;
/*    */   
/*    */   private int fx0;
/*    */   
/*    */   private int fy0;
/*    */   
/*    */   private int fx1;
/*    */   
/*    */   private int fy1;
/*    */   
/*    */   private int fCID;
/*    */   
/*    */   public CodeEntry[] Detail;
/*    */   
/*    */   public CodeEntry[] Smooth;
/*    */   
/*    */ 
/*    */   public CpStrip()
/*    */   {
/* 25 */     this.fSizeOfStrip = 0;
/*    */     
/* 27 */     this.fx0 = 0;
/*    */     
/* 29 */     this.fy0 = 0;
/*    */     
/* 31 */     this.fx1 = 0;
/*    */     
/* 33 */     this.fy1 = 0;
/*    */     
/* 35 */     this.fCID = 0;
/*    */     
/*    */ 
/*    */ 
/* 39 */     this.Detail = new CodeEntry['Ā'];
/*    */     
/* 41 */     this.Smooth = new CodeEntry['Ā'];
/*    */     
/* 43 */     for (int i = 0; i < 256; i++)
/*    */     {
/* 45 */       this.Detail[i] = new CodeEntry();
/*    */       
/* 47 */       this.Smooth[i] = new CodeEntry();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\codec\video\cinepak\CpStrip.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */