/*     */ package com.sun.media.codec.video.jpeg;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JPEGFrame
/*     */ {
/* 122 */   public long rtptimestamp = -1L;
/*     */   
/*     */ 
/*     */ 
/* 126 */   public int dataLength = 0;
/*     */   
/*     */   private RTPDePacketizer depacketizer;
/* 129 */   private int hdrOffset = 0;
/*     */   private long firstSeq;
/* 131 */   private long numPkts = 0L;
/*     */   
/* 133 */   final int FRAME_BUFFER_INITIAL_SIZE = 32000;
/*     */   
/*     */ 
/* 136 */   int lquantOffset = 2 + APP0.length + 2 + 2 + 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */   int cquantOffset = this.lquantOffset + 64 + 2 + 2 + 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JPEGFrame(RTPDePacketizer depacketizer, Buffer buffer, byte[] frameBuffer)
/*     */   {
/* 156 */     this.depacketizer = depacketizer;
/* 157 */     this.firstSeq = buffer.getSequenceNumber();
/*     */     
/* 159 */     if (depacketizer.frameBuffer == null) {
/* 160 */       if (frameBuffer != null) {
/* 161 */         depacketizer.frameBuffer = frameBuffer;
/*     */       } else {
/* 163 */         depacketizer.frameBuffer = new byte['紀'];
/*     */       }
/*     */     }
/* 166 */     this.rtptimestamp = buffer.getTimeStamp();
/* 167 */     int extraskip = 0;
/*     */     
/*     */ 
/*     */ 
/* 171 */     if (!hasJFIFHeader(buffer)) {
/* 172 */       extraskip = generateJFIFHeader(buffer);
/*     */     }
/* 174 */     add(buffer, extraskip);
/*     */   }
/*     */   
/*     */   public void add(Buffer buffer, int extraskip)
/*     */   {
/* 179 */     int chunkSize = buffer.getLength() - 8 - extraskip;
/*     */     
/* 181 */     int foff = this.depacketizer.getFragOffset((byte[])buffer.getData(), buffer.getOffset());
/*     */     
/*     */ 
/* 184 */     foff += this.hdrOffset;
/*     */     
/*     */ 
/*     */ 
/* 188 */     if (this.depacketizer.frameBuffer.length >= foff + chunkSize + 2)
/*     */     {
/* 190 */       System.arraycopy((byte[])buffer.getData(), buffer.getOffset() + 8 + extraskip, this.depacketizer.frameBuffer, foff, chunkSize);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 196 */       this.dataLength += chunkSize;
/* 197 */       this.numPkts += 1L;
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 202 */       increaseFrameBuffer(foff + chunkSize + 2);
/* 203 */       add(buffer, extraskip);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean gotAllPackets(long lastSeq)
/*     */   {
/* 209 */     return lastSeq - this.firstSeq + 1L == this.numPkts;
/*     */   }
/*     */   
/*     */   public void completeTransfer(Buffer inBuffer, Buffer outBuffer)
/*     */   {
/* 214 */     int offset = inBuffer.getOffset();
/*     */     
/*     */ 
/* 217 */     byte[] inBuff = (byte[])inBuffer.getData();
/*     */     
/* 219 */     int height = inBuff[(offset + 7)] & 0xFF;
/*     */     
/* 221 */     int width = inBuff[(offset + 6)] & 0xFF;
/*     */     
/* 223 */     this.depacketizer.quality = (inBuff[(offset + 5)] & 0xFF);
/*     */     
/* 225 */     this.depacketizer.type = (inBuff[(offset + 4)] & 0xFF);
/*     */     
/* 227 */     Dimension d = new Dimension(width * 8, height * 8);
/*     */     
/* 229 */     inBuffer.setFormat(new VideoFormat("jpeg", d, 0, inBuffer.getFormat().getDataType(), -1.0F));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 235 */     if ((this.depacketizer.frameBuffer[(this.dataLength - 2)] != -1) || (this.depacketizer.frameBuffer[(this.dataLength - 1)] != -39))
/*     */     {
/* 237 */       this.depacketizer.frameBuffer[(this.dataLength++)] = -1;
/* 238 */       this.depacketizer.frameBuffer[(this.dataLength++)] = -39;
/*     */     }
/*     */     
/* 241 */     outBuffer.setData(this.depacketizer.frameBuffer);
/* 242 */     outBuffer.setSequenceNumber(this.depacketizer.sequenceNumber++);
/* 243 */     outBuffer.setLength(this.dataLength);
/* 244 */     this.depacketizer.frameBuffer = null;
/*     */   }
/*     */   
/*     */ 
/*     */   private void increaseFrameBuffer(int amount)
/*     */   {
/* 250 */     byte[] newFrameBuffer = new byte[amount];
/*     */     
/*     */ 
/* 253 */     System.arraycopy(this.depacketizer.frameBuffer, 0, newFrameBuffer, 0, this.depacketizer.frameBuffer.length);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 259 */     this.depacketizer.frameBuffer = newFrameBuffer;
/*     */   }
/*     */   
/*     */   private boolean hasJFIFHeader(Buffer buffer) {
/* 263 */     byte[] data = (byte[])buffer.getData();
/* 264 */     int offset = buffer.getOffset();
/* 265 */     if (((data[(offset + 8)] & 0xFF) != 255) || ((data[(offset + 9)] & 0xFF) != 216))
/*     */     {
/* 267 */       return false;
/*     */     }
/* 269 */     return true;
/*     */   }
/*     */   
/*     */   private int generateJFIFHeader(Buffer buffer) {
/* 273 */     int extraskip = 0;
/* 274 */     byte[] data = (byte[])buffer.getData();
/* 275 */     int offset = buffer.getOffset();
/* 276 */     int type = data[(offset + 4)] & 0xFF;
/*     */     
/* 278 */     int quality = data[(offset + 5)] & 0xFF;
/*     */     
/* 280 */     int width = data[(offset + 6)] & 0xFF;
/*     */     
/* 282 */     int height = data[(offset + 7)] & 0xFF;
/*     */     
/* 284 */     if ((quality == this.depacketizer.lastQuality) && (width == this.depacketizer.lastWidth) && (height == this.depacketizer.lastHeight) && (type == this.depacketizer.lastType))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 289 */       System.arraycopy(this.depacketizer.lastJFIFHeader, 0, this.depacketizer.frameBuffer, 0, this.depacketizer.lastJFIFHeader.length);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 294 */       this.hdrOffset = this.depacketizer.lastJFIFHeader.length;
/*     */     } else {
/* 296 */       this.hdrOffset = makeHeaders(this.depacketizer.frameBuffer, 0, type, quality, width, height);
/*     */       
/* 298 */       this.depacketizer.lastJFIFHeader = new byte[this.hdrOffset];
/* 299 */       System.arraycopy(this.depacketizer.frameBuffer, 0, this.depacketizer.lastJFIFHeader, 0, this.hdrOffset);
/*     */       
/*     */ 
/* 302 */       this.depacketizer.lastQuality = quality;
/* 303 */       this.depacketizer.lastType = type;
/* 304 */       this.depacketizer.lastWidth = width;
/* 305 */       this.depacketizer.lastHeight = height;
/*     */     }
/*     */     
/* 308 */     if (quality >= 100) {
/* 309 */       extraskip = 132;
/*     */       
/* 311 */       System.arraycopy(data, offset + 8 + 4, this.depacketizer.frameBuffer, this.lquantOffset, 64);
/*     */       
/*     */ 
/*     */ 
/* 315 */       System.arraycopy(data, offset + 8 + 4 + 64, this.depacketizer.frameBuffer, this.cquantOffset, 64);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 320 */     this.dataLength += this.depacketizer.lastJFIFHeader.length;
/* 321 */     return extraskip;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 327 */   static final byte[] APP0 = { -1, -32, 0, 16, 74, 70, 73, 70, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int makeHeaders(byte[] p, int offset, int type, int q, int w, int h)
/*     */   {
/* 341 */     int[] lqt = new int[64];
/* 342 */     int[] cqt = new int[64];
/*     */     
/*     */ 
/*     */ 
/* 346 */     w *= 8;
/* 347 */     h *= 8;
/*     */     
/* 349 */     makeQTables(q, lqt, cqt);
/*     */     
/* 351 */     p[(offset++)] = -1;
/* 352 */     p[(offset++)] = -40;
/*     */     
/*     */ 
/* 355 */     for (int app = 0; app < APP0.length; app++) {
/* 356 */       p[(offset++)] = APP0[app];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 363 */     offset = makeQuantHeader(p, offset, lqt, 0);
/* 364 */     offset = makeQuantHeader(p, offset, cqt, 1);
/*     */     
/* 366 */     offset = makeHuffmanHeader(p, offset, lum_dc_codelens, lum_dc_codelens.length, lum_dc_symbols, lum_dc_symbols.length, 0, 0);
/*     */     
/*     */ 
/*     */ 
/* 370 */     offset = makeHuffmanHeader(p, offset, lum_ac_codelens, lum_ac_codelens.length, lum_ac_symbols, lum_ac_symbols.length, 0, 1);
/*     */     
/*     */ 
/*     */ 
/* 374 */     offset = makeHuffmanHeader(p, offset, chm_dc_codelens, chm_dc_codelens.length, chm_dc_symbols, chm_dc_symbols.length, 1, 0);
/*     */     
/*     */ 
/*     */ 
/* 378 */     offset = makeHuffmanHeader(p, offset, chm_ac_codelens, chm_ac_codelens.length, chm_ac_symbols, chm_ac_symbols.length, 1, 1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 383 */     p[(offset++)] = -1;
/* 384 */     p[(offset++)] = -64;
/* 385 */     p[(offset++)] = 0;
/* 386 */     p[(offset++)] = 17;
/* 387 */     p[(offset++)] = 8;
/* 388 */     p[(offset++)] = ((byte)(h >> 8 & 0xFF));
/* 389 */     p[(offset++)] = ((byte)(h & 0xFF));
/* 390 */     p[(offset++)] = ((byte)(w >> 8 & 0xFF));
/* 391 */     p[(offset++)] = ((byte)(w & 0xFF));
/* 392 */     p[(offset++)] = 3;
/* 393 */     p[(offset++)] = 0;
/* 394 */     if (type == 2) {
/* 395 */       p[(offset++)] = 17;
/* 396 */     } else if (type == 1) {
/* 397 */       p[(offset++)] = 34;
/*     */     } else
/* 399 */       p[(offset++)] = 33;
/* 400 */     p[(offset++)] = 0;
/* 401 */     p[(offset++)] = 1;
/*     */     
/* 403 */     p[(offset++)] = 17;
/* 404 */     p[(offset++)] = 1;
/* 405 */     p[(offset++)] = 2;
/* 406 */     p[(offset++)] = 17;
/* 407 */     p[(offset++)] = 1;
/*     */     
/* 409 */     p[(offset++)] = -1;
/* 410 */     p[(offset++)] = -38;
/* 411 */     p[(offset++)] = 0;
/* 412 */     p[(offset++)] = 12;
/* 413 */     p[(offset++)] = 3;
/* 414 */     p[(offset++)] = 0;
/* 415 */     p[(offset++)] = 0;
/* 416 */     p[(offset++)] = 1;
/* 417 */     p[(offset++)] = 17;
/* 418 */     p[(offset++)] = 2;
/* 419 */     p[(offset++)] = 17;
/* 420 */     p[(offset++)] = 0;
/* 421 */     p[(offset++)] = 63;
/* 422 */     p[(offset++)] = 0;
/*     */     
/* 424 */     return offset;
/*     */   }
/*     */   
/* 427 */   static int[] lum_dc_codelens = { 0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0 };
/*     */   
/*     */ 
/*     */ 
/* 431 */   static int[] lum_dc_symbols = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };
/*     */   
/*     */ 
/*     */ 
/* 435 */   static int[] lum_ac_codelens = { 0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 125 };
/*     */   
/*     */ 
/*     */ 
/* 439 */   static int[] lum_ac_symbols = { 1, 2, 3, 0, 4, 17, 5, 18, 33, 49, 65, 6, 19, 81, 97, 7, 34, 113, 20, 50, 129, 145, 161, 8, 35, 66, 177, 193, 21, 82, 209, 240, 36, 51, 98, 114, 130, 9, 10, 22, 23, 24, 25, 26, 37, 38, 39, 40, 41, 42, 52, 53, 54, 55, 56, 57, 58, 67, 68, 69, 70, 71, 72, 73, 74, 83, 84, 85, 86, 87, 88, 89, 90, 99, 100, 101, 102, 103, 104, 105, 106, 115, 116, 117, 118, 119, 120, 121, 122, 131, 132, 133, 134, 135, 136, 137, 138, 146, 147, 148, 149, 150, 151, 152, 153, 154, 162, 163, 164, 165, 166, 167, 168, 169, 170, 178, 179, 180, 181, 182, 183, 184, 185, 186, 194, 195, 196, 197, 198, 199, 200, 201, 202, 210, 211, 212, 213, 214, 215, 216, 217, 218, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 463 */   static int[] chm_dc_codelens = { 0, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0 };
/*     */   
/*     */ 
/*     */ 
/* 467 */   static int[] chm_dc_symbols = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };
/*     */   
/*     */ 
/*     */ 
/* 471 */   static int[] chm_ac_codelens = { 0, 2, 1, 2, 4, 4, 3, 4, 7, 5, 4, 4, 0, 1, 2, 119 };
/*     */   
/*     */ 
/*     */ 
/* 475 */   static int[] chm_ac_symbols = { 0, 1, 2, 3, 17, 4, 5, 33, 49, 6, 18, 65, 81, 7, 97, 113, 19, 34, 50, 129, 8, 20, 66, 145, 161, 177, 193, 9, 35, 51, 82, 240, 21, 98, 114, 209, 10, 22, 36, 52, 225, 37, 241, 23, 24, 25, 26, 38, 39, 40, 41, 42, 53, 54, 55, 56, 57, 58, 67, 68, 69, 70, 71, 72, 73, 74, 83, 84, 85, 86, 87, 88, 89, 90, 99, 100, 101, 102, 103, 104, 105, 106, 115, 116, 117, 118, 119, 120, 121, 122, 130, 131, 132, 133, 134, 135, 136, 137, 138, 146, 147, 148, 149, 150, 151, 152, 153, 154, 162, 163, 164, 165, 166, 167, 168, 169, 170, 178, 179, 180, 181, 182, 183, 184, 185, 186, 194, 195, 196, 197, 198, 199, 200, 201, 202, 210, 211, 212, 213, 214, 215, 216, 217, 218, 226, 227, 228, 229, 230, 231, 232, 233, 234, 242, 243, 244, 245, 246, 247, 248, 249, 250 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int makeQuantHeader(byte[] p, int offset, int[] qt, int tableNo)
/*     */   {
/* 501 */     p[(offset++)] = -1;
/* 502 */     p[(offset++)] = -37;
/* 503 */     p[(offset++)] = 0;
/* 504 */     p[(offset++)] = 67;
/* 505 */     p[(offset++)] = ((byte)tableNo);
/* 506 */     for (int i = 0; i < 64; i++) {
/* 507 */       p[(offset++)] = ((byte)qt[i]);
/*     */     }
/* 509 */     return offset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int makeHuffmanHeader(byte[] p, int offset, int[] codelens, int ncodes, int[] symbols, int nsymbols, int tableNo, int tableClass)
/*     */   {
/* 518 */     p[(offset++)] = -1;
/* 519 */     p[(offset++)] = -60;
/* 520 */     p[(offset++)] = 0;
/* 521 */     p[(offset++)] = ((byte)(3 + ncodes + nsymbols));
/* 522 */     p[(offset++)] = ((byte)(tableClass << 4 | tableNo));
/* 523 */     for (int i = 0; i < ncodes; i++)
/* 524 */       p[(offset++)] = ((byte)codelens[i]);
/* 525 */     for (i = 0; i < nsymbols; i++)
/* 526 */       p[(offset++)] = ((byte)symbols[i]);
/* 527 */     return offset;
/*     */   }
/*     */   
/* 530 */   static int[] ZigZag = { 0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 544 */   static int[] jpeg_luma_quantizer = { 16, 11, 10, 16, 24, 40, 51, 61, 12, 12, 14, 19, 26, 58, 60, 55, 14, 13, 16, 24, 40, 57, 69, 56, 14, 17, 22, 29, 51, 87, 80, 62, 18, 22, 37, 56, 68, 109, 103, 77, 24, 35, 55, 64, 81, 104, 113, 92, 49, 64, 78, 87, 103, 121, 120, 101, 72, 92, 95, 98, 112, 100, 103, 99 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 558 */   static int[] jpeg_chroma_quantizer = { 17, 18, 24, 47, 99, 99, 99, 99, 18, 21, 26, 66, 99, 99, 99, 99, 24, 26, 56, 99, 99, 99, 99, 99, 47, 66, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void makeQTables(int q, int[] lum_q, int[] chr_q)
/*     */   {
/* 574 */     int factor = q;
/*     */     
/* 576 */     if (q < 1) factor = 1;
/* 577 */     if (q > 99) factor = 99;
/* 578 */     if (q < 50) {
/* 579 */       q = 5000 / factor;
/*     */     } else {
/* 581 */       q = 200 - factor * 2;
/*     */     }
/* 583 */     for (int i = 0; i < 64; i++) {
/* 584 */       int lq = (jpeg_luma_quantizer[ZigZag[i]] * q + 50) / 100;
/* 585 */       int cq = (jpeg_chroma_quantizer[ZigZag[i]] * q + 50) / 100;
/*     */       
/*     */ 
/* 588 */       if (lq < 1) {
/* 589 */         lq = 1;
/* 590 */       } else if (lq > 255)
/* 591 */         lq = 255;
/* 592 */       lum_q[i] = lq;
/*     */       
/* 594 */       if (cq < 1) {
/* 595 */         cq = 1;
/* 596 */       } else if (cq > 255)
/* 597 */         cq = 255;
/* 598 */       chr_q[i] = cq;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\codec\video\jpeg\JPEGFrame.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */