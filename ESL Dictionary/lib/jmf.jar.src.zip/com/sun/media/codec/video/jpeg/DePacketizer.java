/*     */ package com.sun.media.codec.video.jpeg;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import java.awt.Dimension;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.JPEGFormat;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DePacketizer
/*     */   extends BasicCodec
/*     */ {
/*  31 */   private VideoFormat inputFormat = null;
/*  32 */   private JPEGFormat outputFormat = null;
/*     */   
/*     */ 
/*  35 */   private int decimation = -1;
/*  36 */   private int quality = -1;
/*     */   
/*     */ 
/*  39 */   private RTPDePacketizer rtpdp = null;
/*     */   
/*  41 */   int DEFAULT_WIDTH = 320;
/*  42 */   int DEFAULT_HEIGHT = 240;
/*     */   
/*     */ 
/*     */ 
/*     */   public DePacketizer()
/*     */   {
/*  48 */     this.inputFormats = new Format[] { new VideoFormat("jpeg/rtp") };
/*  49 */     this.outputFormats = new Format[] { new VideoFormat("jpeg") };
/*     */   }
/*     */   
/*     */   protected Format getInputFormat() {
/*  53 */     return this.inputFormat;
/*     */   }
/*     */   
/*     */   protected Format getOutputFormat() {
/*  57 */     return this.outputFormat;
/*     */   }
/*     */   
/*     */   public Format[] getSupportedOutputFormats(Format in)
/*     */   {
/*  62 */     if (in == null) {
/*  63 */       return this.outputFormats;
/*     */     }
/*     */     
/*  66 */     if (BasicPlugIn.matches(in, this.inputFormats) == null) {
/*  67 */       return new Format[0];
/*     */     }
/*  69 */     Format[] out = new Format[1];
/*  70 */     out[0] = makeJPEGFormat(in);
/*  71 */     return out;
/*     */   }
/*     */   
/*     */   public Format setInputFormat(Format input) {
/*  75 */     this.inputFormat = ((VideoFormat)input);
/*  76 */     if (this.opened) {
/*  77 */       this.outputFormat = makeJPEGFormat(this.inputFormat);
/*     */     }
/*  79 */     return input;
/*     */   }
/*     */   
/*     */   public Format setOutputFormat(Format output) {
/*  83 */     if (!(output instanceof VideoFormat)) return null;
/*  84 */     this.outputFormat = makeJPEGFormat(output);
/*  85 */     return this.outputFormat;
/*     */   }
/*     */   
/*     */   private final JPEGFormat makeJPEGFormat(Format in) {
/*  89 */     VideoFormat vf = (VideoFormat)in;
/*  90 */     return new JPEGFormat(vf.getSize() != null ? vf.getSize() : new Dimension(this.DEFAULT_WIDTH, this.DEFAULT_HEIGHT), -1, Format.byteArray, vf.getFrameRate(), this.quality, this.decimation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open()
/*     */     throws ResourceUnavailableException
/*     */   {
/* 100 */     if ((this.inputFormat == null) || (this.outputFormat == null))
/* 101 */       throw new ResourceUnavailableException("Incorrect formats set on JPEG converter");
/* 102 */     this.rtpdp = new RTPDePacketizer();
/* 103 */     super.open();
/*     */   }
/*     */   
/*     */   public synchronized void close() {
/* 107 */     this.rtpdp = null;
/* 108 */     super.close();
/*     */   }
/*     */   
/*     */ 
/*     */   public void reset() {}
/*     */   
/*     */   public synchronized int process(Buffer inBuffer, Buffer outBuffer)
/*     */   {
/* 116 */     if (isEOM(inBuffer)) {
/* 117 */       propagateEOM(outBuffer);
/* 118 */       return 0;
/*     */     }
/* 120 */     if (inBuffer.isDiscard()) {
/* 121 */       updateOutput(outBuffer, this.outputFormat, 0, 0);
/* 122 */       outBuffer.setDiscard(true);
/* 123 */       return 4;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */     int retVal = this.rtpdp.process(inBuffer, outBuffer);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 140 */     if (retVal != 0) {
/* 141 */       return retVal;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 146 */     int type = this.rtpdp.getType();
/* 147 */     int q = this.rtpdp.getQuality();
/*     */     
/*     */ 
/*     */ 
/* 151 */     if ((type != this.decimation) || (q != this.quality)) {
/* 152 */       this.decimation = type;
/* 153 */       this.quality = q;
/* 154 */       this.outputFormat = makeJPEGFormat(inBuffer.getFormat());
/*     */     }
/* 156 */     outBuffer.setFormat(this.outputFormat);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 180 */     outBuffer.setOffset(0);
/*     */     
/* 182 */     outBuffer.setTimeStamp(inBuffer.getTimeStamp());
/*     */     
/* 184 */     inBuffer.setLength(0);
/*     */     
/* 186 */     outBuffer.setFlags(outBuffer.getFlags() | 0x10);
/*     */     
/* 188 */     return 0;
/*     */   }
/*     */   
/*     */   public void finalize() {
/* 192 */     close();
/*     */   }
/*     */   
/*     */   public String getName() {
/* 196 */     return "JPEG DePacketizer";
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\codec\video\jpeg\DePacketizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */