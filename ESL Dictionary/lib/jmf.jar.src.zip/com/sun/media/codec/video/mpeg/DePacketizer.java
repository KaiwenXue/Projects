/*     */ package com.sun.media.codec.video.mpeg;
/*     */ 
/*     */ import com.sun.media.BasicCodec;
/*     */ import com.sun.media.BasicPlugIn;
/*     */ import javax.media.Buffer;
/*     */ import javax.media.Format;
/*     */ import javax.media.ResourceUnavailableException;
/*     */ import javax.media.format.VideoFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DePacketizer
/*     */   extends BasicCodec
/*     */ {
/*  25 */   private VideoFormat inputFormat = null;
/*  26 */   private VideoFormat outputFormat = null;
/*     */   
/*     */ 
/*  29 */   private RTPDePacketizer rtpdp = null;
/*     */   
/*     */ 
/*     */   public DePacketizer()
/*     */   {
/*  34 */     this.inputFormats = new Format[] { new VideoFormat("mpeg/rtp") };
/*  35 */     this.outputFormats = new Format[] { new VideoFormat("mpeg") };
/*     */   }
/*     */   
/*     */   protected Format getInputFormat() {
/*  39 */     return this.inputFormat;
/*     */   }
/*     */   
/*     */   protected Format getOutputFormat() {
/*  43 */     return this.outputFormat;
/*     */   }
/*     */   
/*     */   public Format[] getSupportedOutputFormats(Format in)
/*     */   {
/*  48 */     if (in == null) {
/*  49 */       return this.outputFormats;
/*     */     }
/*     */     
/*  52 */     if (BasicPlugIn.matches(in, this.inputFormats) == null) {
/*  53 */       return new Format[0];
/*     */     }
/*  55 */     Format[] out = new Format[1];
/*  56 */     out[0] = makeMPEGFormat(in);
/*  57 */     return out;
/*     */   }
/*     */   
/*     */   public Format setInputFormat(Format input) {
/*  61 */     this.inputFormat = ((VideoFormat)input);
/*  62 */     return input;
/*     */   }
/*     */   
/*     */   public Format setOutputFormat(Format output) {
/*  66 */     if (!(output instanceof VideoFormat)) return null;
/*  67 */     this.outputFormat = makeMPEGFormat(output);
/*  68 */     return output;
/*     */   }
/*     */   
/*     */   private final VideoFormat makeMPEGFormat(Format in) {
/*  72 */     VideoFormat vf = (VideoFormat)in;
/*  73 */     return new VideoFormat("mpeg", vf.getSize(), -1, Format.byteArray, vf.getFrameRate());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void open()
/*     */     throws ResourceUnavailableException
/*     */   {
/*  81 */     if ((this.inputFormat == null) || (this.outputFormat == null)) {
/*  82 */       throw new ResourceUnavailableException("Incorrect formats set on MPEG video depacketizer");
/*     */     }
/*  84 */     this.rtpdp = new RTPDePacketizer();
/*     */   }
/*     */   
/*     */   public synchronized void close() {
/*  88 */     this.rtpdp = null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void reset() {}
/*     */   
/*     */   public synchronized int process(Buffer inBuffer, Buffer outBuffer)
/*     */   {
/*  96 */     if (isEOM(inBuffer)) {
/*  97 */       propagateEOM(outBuffer);
/*  98 */       return 0;
/*     */     }
/* 100 */     if (inBuffer.isDiscard()) {
/* 101 */       updateOutput(outBuffer, this.outputFormat, 0, 0);
/* 102 */       outBuffer.setDiscard(true);
/* 103 */       return 4;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */     int retVal = this.rtpdp.process(inBuffer, outBuffer);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 119 */     if (retVal != 0) {
/* 120 */       return retVal;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */     if (this.outputFormat == null) {
/* 128 */       this.outputFormat = ((VideoFormat)outBuffer.getFormat());
/*     */     }
/*     */     
/* 131 */     return 0;
/*     */   }
/*     */   
/*     */   public void finalize() {
/* 135 */     close();
/*     */   }
/*     */   
/*     */   public String getName() {
/* 139 */     return "MPEG Video DePacketizer";
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\codec\video\mpeg\DePacketizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */