package com.sun.media;

import javax.media.Controls;
import javax.media.Format;

public abstract interface Module
  extends Controls
{
  public abstract String[] getInputConnectorNames();
  
  public abstract String[] getOutputConnectorNames();
  
  public abstract InputConnector getInputConnector(String paramString);
  
  public abstract OutputConnector getOutputConnector(String paramString);
  
  public abstract void registerInputConnector(String paramString, InputConnector paramInputConnector);
  
  public abstract void registerOutputConnector(String paramString, OutputConnector paramOutputConnector);
  
  public abstract void reset();
  
  public abstract void connectorPushed(InputConnector paramInputConnector);
  
  public abstract String getName();
  
  public abstract void setName(String paramString);
  
  public abstract void setFormat(Connector paramConnector, Format paramFormat);
  
  public abstract void setModuleListener(ModuleListener paramModuleListener);
  
  public abstract boolean isInterrupted();
  
  public abstract void setJMD(JMD paramJMD);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\Module.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */