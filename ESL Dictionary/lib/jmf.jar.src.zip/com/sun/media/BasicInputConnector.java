/*     */ package com.sun.media;
/*     */ 
/*     */ import javax.media.Buffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicInputConnector
/*     */   extends BasicConnector
/*     */   implements InputConnector
/*     */ {
/*  18 */   protected OutputConnector outputConnector = null;
/*  19 */   private boolean reset = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public OutputConnector getOutputConnector()
/*     */   {
/*  26 */     return this.outputConnector;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  30 */     synchronized (this.circularBuffer) {
/*  31 */       this.reset = true;
/*  32 */       super.reset();
/*  33 */       this.circularBuffer.notifyAll();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isValidBufferAvailable()
/*     */   {
/*  41 */     return this.circularBuffer.canRead();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Buffer getValidBuffer()
/*     */   {
/*  50 */     switch (this.protocol) {
/*     */     case 0: 
/*  52 */       synchronized (this.circularBuffer) {
/*  53 */         if ((!isValidBufferAvailable()) && (this.reset)) {
/*  54 */           ??? = null;return (Buffer)???; }
/*  55 */         this.reset = false;
/*  56 */         Buffer localBuffer1 = this.circularBuffer.read();return localBuffer1;
/*     */       }
/*     */     case 1: 
/*  59 */       synchronized (this.circularBuffer) {
/*  60 */         this.reset = false;
/*  61 */         while ((!this.reset) && (!isValidBufferAvailable())) {
/*     */           try {
/*  63 */             this.circularBuffer.wait();
/*     */           } catch (Exception e) {}
/*     */         }
/*  66 */         if (this.reset) {
/*  67 */           e = null;return e; }
/*  68 */         Buffer buffer = this.circularBuffer.read();
/*  69 */         this.circularBuffer.notifyAll();
/*  70 */         Buffer localBuffer2 = buffer;return localBuffer2;
/*     */       }
/*     */     }
/*  73 */     throw new RuntimeException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutputConnector(OutputConnector outputConnector)
/*     */   {
/*  83 */     this.outputConnector = outputConnector;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readReport()
/*     */   {
/*  93 */     switch (this.protocol) {
/*     */     case 0: 
/*     */     case 1: 
/*  96 */       synchronized (this.circularBuffer) {
/*  97 */         if (this.reset) return;
/*  98 */         this.circularBuffer.readReport();
/*  99 */         this.circularBuffer.notifyAll();
/* 100 */         return;
/*     */       }
/*     */     }
/* 103 */     throw new RuntimeException();
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\BasicInputConnector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */