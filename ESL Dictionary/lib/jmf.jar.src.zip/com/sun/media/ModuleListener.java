package com.sun.media;

import javax.media.Buffer;
import javax.media.Format;

public abstract interface ModuleListener
{
  public abstract void bufferPrefetched(Module paramModule);
  
  public abstract void stopAtTime(Module paramModule);
  
  public abstract void mediaEnded(Module paramModule);
  
  public abstract void resetted(Module paramModule);
  
  public abstract void dataBlocked(Module paramModule, boolean paramBoolean);
  
  public abstract void framesBehind(Module paramModule, float paramFloat, InputConnector paramInputConnector);
  
  public abstract void markedDataArrived(Module paramModule, Buffer paramBuffer);
  
  public abstract void formatChanged(Module paramModule, Format paramFormat1, Format paramFormat2);
  
  public abstract void formatChangedFailure(Module paramModule, Format paramFormat1, Format paramFormat2);
  
  public abstract void pluginTerminated(Module paramModule);
  
  public abstract void internalErrorOccurred(Module paramModule);
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\com\sun\media\ModuleListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */