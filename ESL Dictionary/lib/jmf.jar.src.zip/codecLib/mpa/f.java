package codecLib.mpa;

class f
{
  byte jdField_int;
  byte jdField_do;
  byte[] a;
  byte[][] jdField_if;
  byte[][] jdField_for;
  
  f(int paramInt1, int paramInt2, byte[] paramArrayOfByte, byte[][] paramArrayOfByte1, byte[][] paramArrayOfByte2)
  {
    this.jdField_int = ((byte)paramInt1);
    this.jdField_do = ((byte)paramInt2);
    this.a = paramArrayOfByte;
    this.jdField_if = paramArrayOfByte1;
    this.jdField_for = paramArrayOfByte2;
  }
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\codecLib\mpa\f.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */