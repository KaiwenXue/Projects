package codecLib.mpa;

class l
{
  int jdField_long;
  int l;
  int c;
  int d;
  int i;
  int f;
  int jdField_for;
  int jdField_goto;
  int jdField_else;
  int a;
  int jdField_int;
  int jdField_void;
  int jdField_case;
  int jdField_do;
  int jdField_try;
  int g;
  int k;
  int jdField_char;
  int jdField_byte;
  int h;
  int jdField_null;
  int j;
  int jdField_if;
  int e;
  int jdField_new;
  int b;
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\codecLib\mpa\l.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */