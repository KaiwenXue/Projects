package codecLib.mpa;

public class MPADException
  extends Exception
  implements Constants
{
  private int bB = -1;
  private String bC = "MPADException0";
  
  public MPADException() {}
  
  public MPADException(String paramString)
  {
    super(e.a(paramString));
    this.bC = paramString;
  }
  
  public MPADException(int paramInt)
  {
    this.bB = paramInt;
  }
  
  public String toString()
  {
    String str1;
    switch (this.bB)
    {
    case -1: 
      str1 = "MPADException0";
      break;
    case -2: 
      str1 = "MPADException1";
      break;
    case -3: 
      str1 = "MPADException2";
      break;
    case -4: 
      str1 = "MPADException3";
      break;
    case -7: 
      str1 = "MPADException4";
      break;
    case -8: 
      str1 = "MPADException5";
      break;
    case -9: 
      str1 = "MPADException6";
      break;
    case -6: 
    case -5: 
    default: 
      str1 = this.bC;
    }
    String str2 = getClass().getName();
    return str2 + ": " + e.a(str1);
  }
  
  public int getState()
  {
    return this.bB;
  }
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\codecLib\mpa\MPADException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */