package codecLib.mpa;

public class Decoder
  implements Constants
{
  private m cn = new m();
  private c cs;
  private l ck = new l();
  private k cm;
  private j cl;
  private i cj;
  private byte[] cv = new byte['৳'];
  private boolean cp = false;
  private static final short[][][] cr = { { { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 }, { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, -1 }, { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, -1 }, { 0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, -1 } }, { { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 }, { 0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, -1 }, { 0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, -1 }, { 0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, -1 } } };
  private static final int[][] co = { { 22050, 24000, 16000, 0 }, { 44100, 48000, 32000, 0 } };
  private static final short[] ct = { 0, 11520, 13824, 5376 };
  private static final byte[] cu = { 0, 7, 7, 31 };
  private static final short[][] cq = { { 0, 576, 1152, 384 }, { 0, 1152, 1152, 384 } };
  
  public Decoder()
  {
    this.cn.bw[1] = a(9, 1024);
    this.cn.bw[2] = a(3, 32);
    this.cn.bw[3] = a(5, 128);
    this.cn.bx = new a();
    this.cs = new c(this.cn, this.cn.bx);
  }
  
  public Decoder(boolean paramBoolean, int paramInt)
  {
    this.cn.bw[1] = a(9, 1024);
    this.cn.bw[2] = a(3, 32);
    this.cn.bw[3] = a(5, 128);
    this.cn.bx = new a();
    this.cs = new c(this.cn, this.cn.bx);
    this.cn.br = (!paramBoolean ? 1 : 0);
    if ((paramInt >= 0) && (paramInt <= 2)) {
      this.cn.bz = paramInt;
    }
  }
  
  public void setQuality(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt <= 2)) {
      this.cn.bz = paramInt;
    }
  }
  
  public int getQuality()
  {
    return this.cn.bz;
  }
  
  public int decode(float[][] paramArrayOfFloat, int[] paramArrayOfInt, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws MPADException
  {
    l locall = this.cn.bn;
    if ((this.cn.bz < 0) || (this.cn.bz > 2)) {
      this.cn.bz = 0;
    }
    int j = a(locall, paramArrayOfByte, paramInt1, paramInt2);
    locall.b = j;
    locall.jdField_char >>= this.cn.bz;
    int i = locall.jdField_case;
    if (paramInt2 - i < 13) {
      throw new MPADException(-3);
    }
    i += (locall.jdField_if >> 3);
    paramInt1 += i;
    paramInt2 -= i;
    int k = locall.jdField_do >> 3;
    int m;
    int n;
    if (locall.l == 1)
    {
      m = paramInt1 > 511 ? paramInt1 - 511 : 0;
      n = paramInt2 > k + 8 ? k + 8 : paramInt2;
      System.arraycopy(paramArrayOfByte, m, this.cv, 0, n + paramInt1 - m);
    }
    else
    {
      m = paramInt1;
      n = paramInt2 > k ? k : paramInt2;
      System.arraycopy(paramArrayOfByte, m, this.cv, 0, n);
    }
    paramArrayOfByte = this.cv;
    if (this.cp) {
      n = k + 8;
    }
    this.cn.bv.a(paramArrayOfByte, paramInt1 - m, n);
    this.cn.bm = paramArrayOfFloat;
    this.cn.bo = paramArrayOfInt;
    this.cs.ao = this.cn.bx;
    this.cs.au = this.cn.bl;
    this.cn.bk = this.cn.bx.cw;
    this.cn.bx.cA = 0;
    this.cn.by = 0;
    switch (locall.l)
    {
    case 3: 
      if (this.cm == null) {
        this.cm = new k(this.cn, this.cs);
      }
      this.cm.jdMethod_do();
      this.cn.bx.cw = this.cn.bk;
      break;
    case 2: 
      if (this.cl == null) {
        this.cl = new j(this.cn, this.cs);
      }
      this.cl.a();
      break;
    case 1: 
      throw new MPADException(-10);
    default: 
      throw new MPADException(-1);
    }
    return locall.jdField_case + (locall.jdField_do >> 3);
  }
  
  public int decodeLast(float[][] paramArrayOfFloat, int[] paramArrayOfInt, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws MPADException
  {
    this.cp = true;
    int i = decode(paramArrayOfFloat, paramArrayOfInt, paramArrayOfByte, paramInt1, paramInt2);
    this.cp = false;
    return i;
  }
  
  public void setMultiChannelRequest(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    this.cn.bx.cz = paramInt1;
    this.cn.bx.cB = paramArrayOfByte;
    this.cn.bx.cJ = paramInt2;
    this.cn.bx.cG = paramInt3;
  }
  
  public void getMultiChannelInfo(MultiChannelInfo paramMultiChannelInfo)
  {
    paramMultiChannelInfo.status = this.cn.bx.cE;
    paramMultiChannelInfo.presentChannels = this.cn.bx.cC;
    paramMultiChannelInfo.extFrameLength = this.cn.bx.cA;
    paramMultiChannelInfo.numberOfArrangementChannels = this.cn.bx.cK;
    paramMultiChannelInfo.numberOfLanguageChannels = this.cn.bx.cF;
    paramMultiChannelInfo.MLSamplingRate = this.cn.bx.cM;
    paramMultiChannelInfo.numberOfMLSamples = this.cn.bx.cx;
    for (int i = 0; i < 12; i++) {
      paramMultiChannelInfo.LFESamples[i] = this.cn.bx.cI[i];
    }
  }
  
  public void setCheckCRC(boolean paramBoolean)
  {
    this.cn.br = (!paramBoolean ? 1 : 0);
  }
  
  public boolean getCheckCRC()
  {
    return this.cn.br == 0;
  }
  
  public void getNextFrameInfo(FrameInfo paramFrameInfo, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws MPADException
  {
    l locall = null;
    if ((paramArrayOfByte != null) && (paramInt2 >= 4))
    {
      a(this.ck, paramArrayOfByte, paramInt1, paramInt2);
      locall = this.ck;
    }
    if (locall == null) {
      throw new MPADException(-1);
    }
    paramFrameInfo.mpegId = (2 - locall.jdField_long);
    paramFrameInfo.layerId = (4 - locall.l);
    paramFrameInfo.modeId = locall.jdField_goto;
    paramFrameInfo.headerOffset = locall.jdField_case;
    paramFrameInfo.frameLength = (locall.jdField_do >> 3);
    paramFrameInfo.bitRate = locall.jdField_try;
    paramFrameInfo.samplingRate = locall.g;
    paramFrameInfo.numberOfChannels = locall.k;
    paramFrameInfo.numberOfSamples = locall.jdField_char;
    paramFrameInfo.negativeOffset = locall.jdField_byte;
  }
  
  public void getCurrFrameInfo(FrameInfo paramFrameInfo)
    throws MPADException
  {
    l locall = null;
    if (this.cn.bn.l == 0) {
      throw new MPADException(-1);
    }
    locall = this.cn.bn;
    paramFrameInfo.mpegId = (2 - locall.jdField_long);
    paramFrameInfo.layerId = (4 - locall.l);
    paramFrameInfo.modeId = locall.jdField_goto;
    paramFrameInfo.headerOffset = locall.jdField_case;
    paramFrameInfo.frameLength = (locall.jdField_do >> 3);
    paramFrameInfo.bitRate = locall.jdField_try;
    paramFrameInfo.samplingRate = locall.g;
    paramFrameInfo.numberOfChannels = locall.k;
    paramFrameInfo.numberOfSamples = locall.jdField_char;
    paramFrameInfo.negativeOffset = locall.jdField_byte;
  }
  
  public void reset()
  {
    this.cm = null;
    this.cl = null;
    this.cj = null;
  }
  
  private int a(l paraml, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws MPADException
  {
    int i = 0;
    int j = 0;
    int k = -7;
    int m = 0;
    if (paramInt2 < 4)
    {
      throw new MPADException(-7);
      break label72;
      i++;
      if (i + 3 >= paramInt2)
      {
        if (m != 0) {
          break label672;
        }
        if (k == -7) {
          throw new MPADException(-7);
        }
        return k;
      }
    }
    label72:
    int i9;
    while (((paramArrayOfByte[(paramInt1 + i)] & 0xFF) == 255) && ((paramArrayOfByte[(paramInt1 + i + 1)] & 0xF6) > 240) && ((paramArrayOfByte[(paramInt1 + i + 2)] & 0xF0) != 240) && ((paramArrayOfByte[(paramInt1 + i + 2)] & 0xC) != 12) && ((paramArrayOfByte[(paramInt1 + i + 3)] & 0x3) != 2))
    {
      int n = paramArrayOfByte[(paramInt1 + i + 1)] >> 3 & 0x1;
      int i1 = paramArrayOfByte[(paramInt1 + i + 1)] >> 1 & 0x3;
      int i2 = paramArrayOfByte[(paramInt1 + i + 2)] >> 4 & 0xF;
      int i4 = paramArrayOfByte[(paramInt1 + i + 2)] >> 2 & 0x3;
      i6 = paramArrayOfByte[(paramInt1 + i + 2)] >> 1 & 0x1;
      if (i2 != 0)
      {
        int i3 = cr[n][i1][i2];
        int i5 = co[n][i4];
        int i8 = cq[n][i1];
        i7 = i3 * 1000 * i8 / i5 & (cu[i1] ^ 0xFFFFFFFF);
        if (i6 != 0) {
          i7 += cu[i1] + 1;
        }
        j = i + (i7 >> 3);
        if (j + 1 < paramInt2)
        {
          if (((paramArrayOfByte[(paramInt1 + j)] & 0xFF) == 255) && ((paramArrayOfByte[(paramInt1 + j + 1)] & 0xFE) == (paramArrayOfByte[(paramInt1 + i + 1)] & 0xFE)))
          {
            paraml.jdField_case = i;
            k = 0;
            break label672;
          }
          if ((i == 0) && (n == paraml.jdField_long) && (i1 == paraml.l) && (paraml.i == i4))
          {
            paraml.jdField_case = 0;
            m = 1;
            k = 1;
            break label672;
          }
          i++;
        }
        else
        {
          if (m == 0) {
            paraml.jdField_case = i;
          }
          m = 1;
          k = 1;
          if ((i == 0) && (n == paraml.jdField_long) && (i1 == paraml.l) && (paraml.i == i4)) {
            break label672;
          }
          i++;
        }
      }
      else
      {
        i9 = ct[i1] >> 3;
        j = 48;
      }
    }
    while (((paramArrayOfByte[(paramInt1 + i + j)] & 0xFF) != 255) || ((paramArrayOfByte[(paramInt1 + i + j + 1)] & 0xFE) != (paramArrayOfByte[(paramInt1 + i + 1)] & 0xFE)) || ((paramArrayOfByte[(paramInt1 + i + j + 2)] & 0xFC) != (paramArrayOfByte[(paramInt1 + i + 2)] & 0xFC)) || ((paramArrayOfByte[(paramInt1 + i + j + 3)] & 0x3) == 2))
    {
      j++;
      if (j > i9)
      {
        i++;
        break label72;
      }
      if (i + j + 3 >= paramInt2)
      {
        if (m == 0) {
          paraml.jdField_case = i;
        }
        m = 1;
        k = 1;
        i++;
        break label72;
        break;
      }
    }
    int i7 = j << 3;
    paraml.jdField_case = i;
    k = 0;
    label672:
    i = paraml.jdField_case;
    paraml.jdField_long = (paramArrayOfByte[(paramInt1 + i + 1)] >> 3 & 0x1);
    paraml.l = (paramArrayOfByte[(paramInt1 + i + 1)] >> 1 & 0x3);
    paraml.c = (paramArrayOfByte[(paramInt1 + i + 1)] & 0x1);
    paraml.d = (paramArrayOfByte[(paramInt1 + i + 2)] >> 4 & 0xF);
    paraml.i = (paramArrayOfByte[(paramInt1 + i + 2)] >> 2 & 0x3);
    int i6 = paramArrayOfByte[(paramInt1 + i + 2)] >> 1 & 0x1;
    paraml.jdField_try = cr[paraml.jdField_long][paraml.l][paraml.d];
    paraml.g = co[paraml.jdField_long][paraml.i];
    paraml.jdField_char = cq[paraml.jdField_long][paraml.l];
    if (paraml.d != 0)
    {
      paraml.jdField_try = cr[paraml.jdField_long][paraml.l][paraml.d];
      paraml.jdField_do = (paraml.jdField_try * 1000 * paraml.jdField_char / paraml.g & (cu[paraml.l] ^ 0xFFFFFFFF));
      if (i6 != 0) {
        paraml.jdField_do += cu[paraml.l] + 1;
      }
    }
    else if (k == 0)
    {
      paraml.jdField_do = (j << 3);
    }
    else
    {
      paraml.jdField_do = (paramInt2 - i << 3);
    }
    paraml.jdField_for = (paramArrayOfByte[(paramInt1 + i + 2)] & 0x1);
    paraml.jdField_goto = (paramArrayOfByte[(paramInt1 + i + 3)] >> 6 & 0x3);
    paraml.jdField_else = (paramArrayOfByte[(paramInt1 + i + 3)] >> 4 & 0x3);
    paraml.a = (paramArrayOfByte[(paramInt1 + i + 3)] >> 3 & 0x1);
    paraml.jdField_int = (paramArrayOfByte[(paramInt1 + i + 3)] >> 2 & 0x1);
    paraml.jdField_void = (paramArrayOfByte[(paramInt1 + i + 3)] & 0x3);
    paraml.k = (paraml.jdField_goto != 3 ? 2 : 1);
    if (paraml.c == 0)
    {
      paraml.h = ((paramArrayOfByte[(paramInt1 + i + 4)] & 0xFF) << 8 | paramArrayOfByte[(paramInt1 + i + 5)] & 0xFF);
      paraml.e = ((paramArrayOfByte[(paramInt1 + i + 2)] & 0xFF) << 8 | paramArrayOfByte[(paramInt1 + i + 3)] & 0xFF);
      paraml.jdField_if = 48;
    }
    else
    {
      paraml.jdField_if = 32;
    }
    if (paraml.l == 1)
    {
      j = paraml.jdField_if >> 3;
      if (paraml.jdField_long == 1) {
        paraml.jdField_byte = ((paramArrayOfByte[(paramInt1 + i + j)] & 0xFF) << 1 | (paramArrayOfByte[(paramInt1 + i + j + 1)] & 0xFF) >> 7);
      } else {
        paraml.jdField_byte = (paramArrayOfByte[(paramInt1 + i + j)] & 0xFF);
      }
    }
    else
    {
      paraml.jdField_byte = 0;
    }
    if (k == -7) {
      throw new MPADException(-7);
    }
    return k;
  }
  
  private byte[] a(int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte = new byte[3 * paramInt2];
    int m = 0;
    for (int i = 0; i < paramInt1; i = (byte)(i + 1)) {
      for (int j = 0; j < paramInt1; j = (byte)(j + 1)) {
        for (int k = 0; k < paramInt1; k = (byte)(k + 1))
        {
          arrayOfByte[(m++)] = k;
          arrayOfByte[(m++)] = j;
          arrayOfByte[(m++)] = i;
        }
      }
    }
    return arrayOfByte;
  }
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\codecLib\mpa\Decoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */