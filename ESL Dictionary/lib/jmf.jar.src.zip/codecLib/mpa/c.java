package codecLib.mpa;

class c
  extends Defines
  implements Tables
{
  private static final int am = 64;
  private static final float aM = 0.03125F;
  private m X;
  private b ag = new b();
  private b ax = new b();
  private b ay = new b();
  private b ar = new b();
  private int[][] az = new int[7][32];
  private int[][][] ah = new int[7][3][32];
  a ao;
  int at;
  int aF;
  int T;
  int R;
  int Z;
  int aJ;
  int aw;
  int aB;
  int ac;
  int aH;
  int aL;
  int aA;
  int af;
  int aE;
  int Y;
  int U;
  int aI;
  int ak;
  int an;
  int aq;
  int aG;
  int as;
  int aD;
  int[] ab = new int[12];
  int[] ae = new int[12];
  int[] ai = new int[12];
  int[] ap = new int[8];
  int[][] W = new int[8][6];
  int[][][] ad = new int[8][6][3];
  int[][] aa = new int[8][6];
  int av;
  int aj;
  int[] aK = new int[12];
  float[] S = new float[12];
  b al = new b();
  float[][][] au;
  private static final byte[][] V = { { 6, 4, 4, 4, 2, 2, 2, 0, 2, 2, 2, 0, 0, 0, 0, 0 }, { 4, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, { 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, { 4, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, { 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 } };
  private static final byte[] Q = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 8, 9, 9, 10, 10, 10, 10, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11 };
  private static final float[] aC = { 1.5258789E-5F, 1.922487E-5F, 2.4221818E-5F, 3.0517578E-5F, 3.844974E-5F, 4.8443635E-5F, 6.1035156E-5F, 7.689948E-5F, 9.688727E-5F, 1.2207031E-4F, 1.5379896E-4F, 1.9377454E-4F, 2.4414062E-4F, 3.0759792E-4F, 3.8754908E-4F, 4.8828125E-4F, 6.1519584E-4F, 7.7509816E-4F, 9.765625E-4F, 0.0012303917F, 0.0015501963F, 0.001953125F, 0.0024607833F, 0.0031003926F, 0.00390625F, 0.0049215667F, 0.0062007853F, 0.0078125F, 0.009843133F, 0.012401571F, 0.015625F, 0.019686267F, 0.024803141F, 0.03125F, 0.039372534F, 0.049606282F, 0.0625F, 0.07874507F, 0.099212565F, 0.125F, 0.15749013F, 0.19842513F, 0.25F, 0.31498027F, 0.39685026F, 0.5F, 0.62996054F, 0.7937005F, 1.0F, 1.2599211F, 1.587401F, 2.0F, 2.5198421F, 3.174802F, 4.0F, 5.0396843F, 6.349604F, 8.0F, 10.079369F, 12.699208F, 16.0F, 20.158737F, 25.398417F, 1.0E20F };
  
  c(m paramm, a parama)
  {
    this.X = paramm;
    this.ao = parama;
  }
  
  int jdMethod_int(int paramInt)
  {
    int j = this.X.bv.jdMethod_if();
    int m = 16;
    b.a(this.ax, this.X.bv);
    b.a(this.ay, this.X.bv);
    int n = this.X.bv.jdMethod_for(9);
    if ((this.at = n >> 8) != 0)
    {
      if ((this.ao.cB == null) || (this.ao.cG <= 4)) {
        return -4;
      }
      this.aF = (n & 0xFF);
      m = 24;
      paramInt -= (this.aF << 3);
    }
    if (this.X.bv.jdMethod_goto() < paramInt) {
      return -3;
    }
    this.X.bv.jdMethod_do(m - 15);
    n = this.X.bv.jdMethod_if(15);
    this.T = (n >> 13);
    this.R = (n >> 11 & 0x3);
    this.Z = (n >> 10 & 0x1);
    this.aJ = (n >> 9 & 0x1);
    this.aw = (n >> 7 & 0x3);
    this.aB = (n >> 4 & 0x7);
    this.ac = (n >> 3 & 0x1);
    this.aH = (n >> 2 & 0x1);
    this.aL = (n >> 1 & 0x1);
    this.aA = (n & 0x1);
    int i1 = g.a(this.ay, 65535, m);
    paramInt -= m;
    int i2;
    if ((this.X.bn.l != 1) && (this.at != 0))
    {
      i2 = a(this.ar, paramInt);
      if (i2 < 0) {
        return i2;
      }
      paramInt += i2;
    }
    if (this.aA != 0)
    {
      b.a(this.ay, this.X.bv);
      i1 = g.a(this.ay, i1, 71);
      this.X.bv.a(71);
      paramInt -= 71;
    }
    this.af = this.X.bv.jdMethod_if(16);
    paramInt -= 16;
    int i = this.X.bv.jdMethod_if();
    b.a(this.ay, this.X.bv);
    int k;
    if (this.X.bn.l != 1)
    {
      jdMethod_new();
      jdMethod_case();
      jdMethod_if(this.az);
      i1 = g.a(this.ay, i1, this.X.bv.jdMethod_if() - i);
      if (this.af != i1) {
        return -2;
      }
      a(this.az);
      for (k = 0; k < 12; k++)
      {
        jdMethod_do(this.ah, k);
        a(this.ah, k);
        jdMethod_new(k);
      }
      if (this.aG != 0) {
        for (i2 = 0; i2 < 2; i2++) {
          for (int i3 = 0; i3 < 8; i3++)
          {
            for (int i4 = 0; i4 < 9; i4++) {
              this.au[i2][i3][i4] = this.au[i2][i3][(i4 + 36)];
            }
            for (i4 = 0; i4 < 3; i4++) {
              for (int i5 = 0; i5 < 12; i5++) {
                this.au[i2][i3][(9 + 12 * i4 + i5)] = this.X.bu[i4][i5][i2][i3];
              }
            }
          }
        }
      }
      jdMethod_for();
      jdMethod_int();
      if (this.Z != 0)
      {
        jdMethod_try();
        for (k = 0; k < 12; k++) {
          this.ao.cI[k] = this.S[k];
        }
      }
    }
    else
    {
      return -10;
    }
    if ((this.aB > 0) && (this.aH == 0))
    {
      if (this.ac != 0) {
        this.X.bA = Tables.t_bal[4];
      } else {
        this.X.bA = Tables.t_bal[1];
      }
      this.ak = this.X.bA.jdField_int;
      jdMethod_byte();
      jdMethod_do(this.az);
      for (k = 0; k < 12 >> this.ac; k++)
      {
        a(this.ah);
        jdMethod_if(this.ah, k);
      }
    }
    this.ao.cy = (this.T & 0x1);
    this.ao.cH = this.Z;
    this.ao.cF = this.aB;
    this.ao.cM = (this.X.bn.g >> this.ac);
    this.ao.cx = (1152 >> this.ac);
    this.ao.cC = (this.X.bn.k == 1 ? 4 : 12);
    if ((this.T & 0x1) != 0) {
      this.ao.cC |= 0x10;
    }
    switch (this.R)
    {
    case 0: 
      this.ao.cL = 0;
      break;
    case 1: 
      this.ao.cL = 1;
      this.ao.cC |= 0x20;
      break;
    case 2: 
      this.ao.cL = 2;
      this.ao.cC |= 0x60;
      break;
    case 3: 
      this.ao.cL = 0;
      this.ao.cD = 2;
      this.ao.cC |= 0x8000;
    }
    if (this.Z != 0) {
      this.ao.cC |= 0x80;
    }
    this.ao.cK = (this.ao.cy + this.ao.cL + this.ao.cD);
    if (this.aH == 0) {
      for (k = 0; k < this.aB; k++) {
        this.ao.cC |= 256 << k;
      }
    }
    this.X.bv.a(j - this.X.bv.jdMethod_if());
    return 0;
  }
  
  private void jdMethod_new()
  {
    this.X.bA = Tables.t_bal[1];
    this.ak = this.X.bA.jdField_int;
    if (this.R == 3)
    {
      if ((this.T == 1) || (this.T == 3))
      {
        this.aE = 3;
        this.Y = 2;
        this.U = 1;
        this.aI = 2;
      }
      else
      {
        this.aE = 2;
        this.Y = 0;
        this.U = 0;
        this.aI = 5;
      }
    }
    else if (this.R == 2)
    {
      if ((this.T == 1) || (this.T == 3))
      {
        this.aE = 3;
        this.Y = 3;
        this.U = 4;
        this.aI = 0;
      }
      else
      {
        this.aE = 2;
        this.Y = 2;
        this.U = 3;
        this.aI = 3;
      }
    }
    else if (this.R == 1)
    {
      if ((this.T == 1) || (this.T == 3))
      {
        this.aE = 2;
        this.Y = 3;
        this.U = 3;
        this.aI = 1;
      }
      else
      {
        this.aE = 1;
        this.Y = 2;
        this.U = 1;
        this.aI = 4;
      }
    }
    else if ((this.T == 1) || (this.T == 3))
    {
      this.aE = 1;
      this.Y = 2;
      this.U = 1;
      this.aI = 2;
    }
    else
    {
      this.aE = 0;
      this.Y = 0;
      this.U = 0;
      this.aI = 5;
    }
    if ((this.aB > 0) && (this.aH > 0)) {
      this.aB = 0;
    }
  }
  
  private void jdMethod_case()
  {
    int k = this.X.bv.jdMethod_if(3);
    this.an = (k >>> 2);
    this.aq = ((k & 0x2) >> 1);
    this.aG = (k & 0x1);
    for (int i = 0; i < 12; i++)
    {
      this.ab[i] = 0;
      this.ae[i] = 0;
    }
    if (this.Y == 0)
    {
      this.as = 0;
    }
    else if (this.an == 1)
    {
      this.as = this.X.bv.jdMethod_if(this.Y);
      for (i = 0; i < 12; i++) {
        this.ab[i] = this.as;
      }
    }
    else
    {
      this.as = 0;
      for (i = 0; i < 12; i++) {
        this.ab[i] = this.X.bv.jdMethod_if(this.Y);
      }
    }
    if (this.aq == 1)
    {
      this.aD = this.X.bv.jdMethod_if(1);
      if (this.U != 0) {
        for (i = 0; i < 12; i++)
        {
          this.ae[i] = this.X.bv.jdMethod_if(this.U);
          if (this.R == 3) {
            this.ai[i] = this.X.bv.jdMethod_if(1);
          }
        }
      }
    }
    else
    {
      this.aD = 0;
    }
    if (this.aG == 1) {
      for (i = 0; i < 8; i++) {
        if ((this.ap[i] = this.X.bv.jdMethod_if(1)) == 1)
        {
          k = V[this.aI][this.ae[i]];
          for (int j = 0; j < k; j++) {
            this.W[i][j] = this.X.bv.jdMethod_if(2);
          }
        }
      }
    }
  }
  
  private void jdMethod_if(int[][] paramArrayOfInt)
  {
    int i = this.X.bn.k;
    int j = this.X.bn.k + this.aE;
    f localf = this.X.bA;
    int i1 = this.ak;
    byte[][] arrayOfByte = this.X.bs[0];
    if (this.Z != 0) {
      this.av = this.X.bv.jdMethod_if(localf.a[0]);
    }
    int m;
    if (this.aq == 0) {
      for (k = 0; k < i1; k++) {
        for (m = i; m < j; m++) {
          if ((this.T != 3) || (k < 12) || (m != 2)) {
            arrayOfByte[m][k] = ((byte)this.X.bv.jdMethod_if(localf.a[k]));
          } else {
            arrayOfByte[m][k] = 0;
          }
        }
      }
    } else {
      for (k = 0; k < i1; k++)
      {
        int n = Q[k];
        if (this.ae[n] == 0)
        {
          for (m = i; m < j; m++) {
            if ((this.T == 3) && (k >= 12) && (m == 2)) {
              arrayOfByte[m][k] = 0;
            } else if ((this.R == 3) && (this.ai[n] == 1))
            {
              if ((this.T != 0) && (m == 4)) {
                arrayOfByte[m][k] = arrayOfByte[3][k];
              } else if ((this.T == 0) && (m == 3)) {
                arrayOfByte[m][k] = arrayOfByte[2][k];
              } else {
                arrayOfByte[m][k] = ((byte)this.X.bv.jdMethod_if(localf.a[k]));
              }
            }
            else {
              arrayOfByte[m][k] = ((byte)this.X.bv.jdMethod_if(localf.a[k]));
            }
          }
        }
        else if (this.U == 1)
        {
          if ((this.T == 3) && (k >= 12)) {
            arrayOfByte[2][k] = 0;
          } else if (this.ab[n] == 1) {
            arrayOfByte[2][k] = arrayOfByte[0][k];
          } else if (this.ab[n] == 2) {
            arrayOfByte[2][k] = arrayOfByte[1][k];
          } else if (this.aD != 0) {
            arrayOfByte[2][k] = arrayOfByte[1][k];
          } else {
            arrayOfByte[2][k] = arrayOfByte[0][k];
          }
          if (this.R == 3)
          {
            arrayOfByte[3][k] = ((byte)this.X.bv.jdMethod_if(localf.a[k]));
            if (this.ai[n] == 1) {
              arrayOfByte[4][k] = arrayOfByte[3][k];
            } else {
              arrayOfByte[4][k] = ((byte)this.X.bv.jdMethod_if(localf.a[k]));
            }
          }
        }
        else if (this.U == 3)
        {
          if ((this.T == 3) && (k >= 12)) {
            arrayOfByte[2][k] = 0;
          } else if ((this.ae[n] == 1) || (this.ae[n] == 4)) {
            arrayOfByte[2][k] = ((byte)this.X.bv.jdMethod_if(localf.a[k]));
          } else if ((this.R == 2) || (this.ab[n] == 1) || (this.ab[n] == 5) || ((this.ab[n] != 2) && (this.aD == 0))) {
            arrayOfByte[2][k] = arrayOfByte[0][k];
          } else {
            arrayOfByte[2][k] = arrayOfByte[1][k];
          }
          if (this.ae[n] == 2) {
            arrayOfByte[3][k] = ((byte)this.X.bv.jdMethod_if(localf.a[k]));
          } else if (this.ae[n] == 4) {
            arrayOfByte[3][k] = arrayOfByte[2][k];
          } else if ((this.R == 2) || (this.ab[n] == 4) || (this.ab[n] == 5) || ((this.ab[n] < 3) && (this.aD != 0))) {
            arrayOfByte[3][k] = arrayOfByte[1][k];
          } else {
            arrayOfByte[3][k] = arrayOfByte[0][k];
          }
        }
        else if (this.U == 4)
        {
          if ((this.T == 3) && (k >= 12)) {
            arrayOfByte[2][k] = 0;
          } else {
            switch (this.ae[n])
            {
            case 1: 
            case 2: 
            case 4: 
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 12: 
            case 14: 
              arrayOfByte[2][k] = ((byte)this.X.bv.jdMethod_if(localf.a[k]));
              break;
            case 3: 
            case 5: 
            case 6: 
            case 7: 
            case 13: 
              if ((this.ab[n] == 1) || (this.ab[n] == 7)) {
                arrayOfByte[2][k] = arrayOfByte[0][k];
              } else if ((this.ab[n] == 2) || (this.ab[n] == 6)) {
                arrayOfByte[2][k] = arrayOfByte[1][k];
              } else if (this.aD != 0) {
                arrayOfByte[2][k] = arrayOfByte[1][k];
              } else {
                arrayOfByte[2][k] = arrayOfByte[0][k];
              }
              break;
            }
          }
          switch (this.ae[n])
          {
          case 1: 
          case 3: 
          case 5: 
          case 8: 
          case 10: 
          case 13: 
            arrayOfByte[3][k] = ((byte)this.X.bv.jdMethod_if(localf.a[k]));
            break;
          case 2: 
          case 4: 
          case 6: 
          case 7: 
          case 12: 
            arrayOfByte[3][k] = arrayOfByte[0][k];
            break;
          case 9: 
          case 11: 
          case 14: 
            arrayOfByte[3][k] = arrayOfByte[2][k];
          }
          switch (this.ae[n])
          {
          case 2: 
          case 3: 
          case 6: 
          case 9: 
            arrayOfByte[4][k] = ((byte)this.X.bv.jdMethod_if(localf.a[k]));
            break;
          case 1: 
          case 4: 
          case 5: 
          case 7: 
          case 11: 
            arrayOfByte[4][k] = arrayOfByte[1][k];
            break;
          case 10: 
          case 12: 
          case 14: 
            arrayOfByte[4][k] = arrayOfByte[2][k];
            break;
          case 8: 
          case 13: 
            arrayOfByte[4][k] = arrayOfByte[3][k];
          }
        }
      }
    }
    for (int k = i1; k < 32; k++) {
      for (m = i; m < j; m++) {
        arrayOfByte[m][k] = 0;
      }
    }
    for (k = 0; k < i1; k++) {
      for (m = i; m < j; m++) {
        if (arrayOfByte[m][k] != 0) {
          paramArrayOfInt[m][k] = this.X.bv.jdMethod_if(2);
        } else {
          paramArrayOfInt[m][k] = 4;
        }
      }
    }
    for (k = i1; k < 32; k++) {
      for (m = i; m < j; m++) {
        paramArrayOfInt[m][k] = 4;
      }
    }
  }
  
  private void a(int[][] paramArrayOfInt)
  {
    int i = this.X.bn.k;
    int j = this.X.bn.k + this.aE;
    int i2 = this.ak;
    byte[][] arrayOfByte = this.X.bs[0];
    byte[][][] arrayOfByte1 = this.X.bp;
    if ((j > this.X.bn.k) && (j < 7) && (this.aG == 1)) {
      for (k = 0; k < 8; k++) {
        if (this.ap[k] == 1) {
          for (int n = 0; n < V[this.aI][this.ae[k]]; n++) {
            if (this.W[k][n] != 0)
            {
              this.aa[k][n] = this.X.bv.jdMethod_if(3);
              for (int i1 = 0; i1 < this.W[k][n]; i1++) {
                this.ad[k][n][i1] = this.X.bv.jdMethod_if(8);
              }
            }
            else
            {
              this.ad[k][n][0] = 127;
              this.aa[k][n] = 0;
            }
          }
        }
      }
    }
    if ((i == this.X.bn.k) && (this.Z != 0) && (this.av != 0)) {
      this.aj = this.X.bv.jdMethod_if(6);
    }
    int m;
    for (int k = 0; k < i2; k++) {
      for (m = i; m < j; m++) {
        if (arrayOfByte[m][k] != 0) {
          switch (paramArrayOfInt[m][k])
          {
          case 0: 
            arrayOfByte1[0][m][k] = ((byte)this.X.bv.jdMethod_if(6));
            arrayOfByte1[1][m][k] = ((byte)this.X.bv.jdMethod_if(6));
            arrayOfByte1[2][m][k] = ((byte)this.X.bv.jdMethod_if(6));
            break;
          case 1: 
            arrayOfByte1[0][m][k] = (arrayOfByte1[1][m][k] = (byte)this.X.bv.jdMethod_if(6));
            arrayOfByte1[2][m][k] = ((byte)this.X.bv.jdMethod_if(6));
            break;
          case 3: 
            arrayOfByte1[0][m][k] = ((byte)this.X.bv.jdMethod_if(6));
            arrayOfByte1[1][m][k] = (arrayOfByte1[2][m][k] = (byte)this.X.bv.jdMethod_if(6));
            break;
          case 2: 
            arrayOfByte1[0][m][k] = (arrayOfByte1[1][m][k] = arrayOfByte1[2][m][k] = (byte)this.X.bv.jdMethod_if(6));
            break;
          default: 
            arrayOfByte1[0][m][k] = (arrayOfByte1[1][m][k] = arrayOfByte1[2][m][k] = 63);
            break;
          }
        } else {
          arrayOfByte1[0][m][k] = (arrayOfByte1[1][m][k] = arrayOfByte1[2][m][k] = 63);
        }
      }
    }
    for (k = i2; k < 32; k++) {
      for (m = i; m < j; m++) {
        arrayOfByte1[0][m][k] = (arrayOfByte1[1][m][k] = arrayOfByte1[2][m][k] = 63);
      }
    }
  }
  
  private void jdMethod_do(int[][][] paramArrayOfInt, int paramInt)
  {
    int i = this.X.bn.k;
    int j = this.X.bn.k + this.aE;
    int i3 = 0;
    f localf = this.X.bA;
    int i4 = this.ak;
    byte[][] arrayOfByte = this.X.bs[0];
    if ((this.Z != 0) && (this.av > 0)) {
      this.aK[paramInt] = this.X.bv.jdMethod_if(this.av + 1);
    }
    int m;
    int n;
    for (int k = 0; k < i4; k++)
    {
      int i1 = Q[k];
      for (m = i; m < j; m++)
      {
        int i2;
        if (arrayOfByte[m][k] != 0)
        {
          i2 = 1;
          if (this.aq == 1)
          {
            if ((this.U == 4) && (((this.ae[i1] == 1) && (m == 4)) || ((this.ae[i1] == 2) && (m == 3)) || ((this.ae[i1] == 3) && (m == 2)) || ((this.ae[i1] == 4) && (m != 2)) || ((this.ae[i1] == 5) && (m != 3)) || ((this.ae[i1] == 6) && (m != 4)) || (this.ae[i1] == 7) || ((this.ae[i1] == 8) && (m == 4)) || ((this.ae[i1] == 9) && (m == 3)) || ((this.ae[i1] == 10) && (m == 4)) || ((this.ae[i1] == 11) && (m != 2)) || ((this.ae[i1] == 12) && (m != 2)) || ((this.ae[i1] == 13) && (m != 3)) || ((this.ae[i1] == 14) && (m != 2)))) {
              i2 = 0;
            }
            if ((this.U == 3) && (((this.ae[i1] == 1) && (m == 3)) || ((this.ae[i1] == 2) && (m == 2)) || (this.ae[i1] == 3) || ((this.ae[i1] == 4) && (m == 3)))) {
              i2 = 0;
            }
            if ((this.U == 1) && (this.ae[i1] == 1) && (m == 2)) {
              i2 = 0;
            }
            if ((this.R == 3) && (this.ai[i1] == 1)) {
              if (((this.T == 1) || (this.T == 3)) && (m == 4)) {
                i2 = 0;
              } else if ((this.T == 0) && (m == 3)) {
                i2 = 0;
              }
            }
          }
        }
        else
        {
          i2 = 0;
        }
        if (i2 == 1)
        {
          n = localf.jdField_for[k][arrayOfByte[m][k]];
          if (n > 0)
          {
            paramArrayOfInt[m][0][k] = this.X.bv.jdMethod_if(n);
            paramArrayOfInt[m][1][k] = this.X.bv.jdMethod_if(n);
            paramArrayOfInt[m][2][k] = this.X.bv.jdMethod_if(n);
          }
          else
          {
            i3 = this.X.bv.jdMethod_if(-n);
            n = -n & 0x6;
            n /= 2;
            byte[] arrayOfByte1 = this.X.bw[n];
            paramArrayOfInt[m][0][k] = arrayOfByte1[(3 * i3)];
            paramArrayOfInt[m][1][k] = arrayOfByte1[(3 * i3 + 1)];
            paramArrayOfInt[m][2][k] = arrayOfByte1[(3 * i3 + 2)];
          }
        }
        else
        {
          for (n = 0; n < 3; n++) {
            paramArrayOfInt[m][n][k] = 0;
          }
        }
      }
    }
    for (k = i4; k < 32; k++) {
      for (m = i; m < j; m++) {
        for (n = 0; n < 3; n++) {
          paramArrayOfInt[m][n][k] = 0;
        }
      }
    }
  }
  
  private void a(int[][][] paramArrayOfInt, int paramInt)
  {
    int i = this.X.bn.k;
    int j = this.X.bn.k + this.aE;
    f localf = this.X.bA;
    int i5 = this.ak;
    byte[][] arrayOfByte = this.X.bs[0];
    float[][][][] arrayOfFloat = this.X.bu;
    paramInt *= 3;
    int m;
    float[][] arrayOfFloat1;
    int n;
    for (int k = 0; k < i5; k++)
    {
      int i1 = Q[k];
      for (m = 0; m < 3; m++)
      {
        arrayOfFloat1 = arrayOfFloat[((paramInt + m) / 12)][((paramInt + m) % 12)];
        for (n = i; n < j; n++) {
          if (arrayOfByte[n][k] != 0)
          {
            int i2;
            int i3;
            int i4;
            float f;
            if (this.aq == 0)
            {
              i2 = localf.jdField_if[k][arrayOfByte[n][k]];
              i3 = Tables.t_alloc[i2];
              i4 = paramArrayOfInt[n][m][k];
              f = Tables.t_d[i2];
              if ((i4 & i3) == 0) {
                f -= Tables.t_c[i2];
              }
              f += (i4 & i3 - 1) * Tables.t_finv_alloc[i2];
              arrayOfFloat1[n][k] = f;
            }
            else
            {
              if ((this.U == 4) && ((this.ae[i1] == 0) || ((this.ae[i1] == 1) && (n != 4)) || ((this.ae[i1] == 2) && (n != 3)) || ((this.ae[i1] == 3) && (n != 2)) || ((this.ae[i1] == 8) && (n != 4)) || ((this.ae[i1] == 9) && (n != 3)) || ((this.ae[i1] == 10) && (n != 4))))
              {
                i2 = localf.jdField_if[k][arrayOfByte[n][k]];
                i3 = Tables.t_alloc[i2];
                i4 = paramArrayOfInt[n][m][k];
                f = Tables.t_d[i2];
                if ((i4 & i3) == 0) {
                  f -= Tables.t_c[i2];
                }
                f += (i4 & i3 - 1) * Tables.t_finv_alloc[i2];
                arrayOfFloat1[n][k] = f;
              }
              if (((this.U != 4) || ((this.ae[i1] == 4) && (n == 2)) || ((this.ae[i1] == 5) && (n == 3)) || ((this.ae[i1] == 6) && (n == 4)) || ((this.ae[i1] == 11) && (n == 2)) || ((this.ae[i1] == 12) && (n == 2)) || ((this.ae[i1] == 13) && (n == 3)) || ((this.ae[i1] == 14) && (n == 2))) && ((this.U != 3) || (((this.ae[i1] != 1) || (n != 3)) && ((this.ae[i1] != 2) || (n != 2)) && (this.ae[i1] != 3) && ((this.ae[i1] != 4) || (n != 3)))) && ((this.U != 1) || (this.ae[i1] != 1) || (n != 2)) && ((this.R != 3) || (this.ai[i1] != 1) || (((this.T == 0) || (n != 4)) && ((this.T != 0) || (n != 3)))))
              {
                i2 = localf.jdField_if[k][arrayOfByte[n][k]];
                i3 = Tables.t_alloc[i2];
                i4 = paramArrayOfInt[n][m][k];
                f = Tables.t_d[i2];
                if ((i4 & i3) == 0) {
                  f -= Tables.t_c[i2];
                }
                f += (i4 & i3 - 1) * Tables.t_finv_alloc[i2];
                arrayOfFloat1[n][k] = f;
              }
            }
          }
          else
          {
            arrayOfFloat1[n][k] = 0.0F;
          }
        }
      }
    }
    for (k = i5; k < 32; k++) {
      for (m = 0; m < 3; m++)
      {
        arrayOfFloat1 = arrayOfFloat[((paramInt + m) / 12)][((paramInt + m) % 12)];
        for (n = i; n < j; n++) {
          arrayOfFloat1[n][k] = 0.0F;
        }
      }
    }
  }
  
  private void jdMethod_new(int paramInt)
  {
    int i = this.X.bn.k;
    int j = this.X.bn.k + this.aE;
    int i2 = paramInt >> 2;
    int i3 = this.ak;
    byte[][][] arrayOfByte = this.X.bp;
    float[][][][] arrayOfFloat = this.X.bu;
    paramInt *= 3;
    for (int k = 0; k < i3; k++)
    {
      int n = Q[k];
      for (int i1 = 0; i1 < 3; i1++)
      {
        float[][] arrayOfFloat1 = arrayOfFloat[((paramInt + i1) / 12)][((paramInt + i1) % 12)];
        int m;
        if (this.aq == 0) {
          for (m = i; m < j; m++) {
            arrayOfFloat1[m][k] *= Tables.t_multiple[arrayOfByte[i2][m][k]];
          }
        } else if (this.U == 0)
        {
          if (this.R == 3)
          {
            arrayOfFloat1[i][k] *= Tables.t_multiple[arrayOfByte[i2][i][k]];
            if (this.ai[n] == 0) {
              arrayOfFloat1[(i + 1)][k] *= Tables.t_multiple[arrayOfByte[i2][(i + 1)][k]];
            } else {
              arrayOfFloat1[(i + 1)][k] = (arrayOfFloat1[i][k] * aC[arrayOfByte[i2][i][k]] * Tables.t_multiple[arrayOfByte[i2][(i + 1)][k]]);
            }
          }
        }
        else if (this.U == 1) {
          switch (this.ae[n])
          {
          case 0: 
            arrayOfFloat1[2][k] *= Tables.t_multiple[arrayOfByte[i2][2][k]];
            if (this.R == 3)
            {
              arrayOfFloat1[3][k] *= Tables.t_multiple[arrayOfByte[i2][3][k]];
              if (this.ai[n] == 0) {
                arrayOfFloat1[4][k] *= Tables.t_multiple[arrayOfByte[i2][4][k]];
              } else {
                arrayOfFloat1[4][k] = (arrayOfFloat1[3][k] * aC[arrayOfByte[i2][3][k]] * Tables.t_multiple[arrayOfByte[i2][4][k]]);
              }
            }
            break;
          case 1: 
            if (this.ab[n] == 0) {
              if (this.aD != 0) {
                arrayOfFloat1[2][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
              } else {
                arrayOfFloat1[2][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
              }
            }
            if (this.ab[n] == 1) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            }
            if (this.ab[n] == 2) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            }
            if (this.R == 3)
            {
              arrayOfFloat1[3][k] *= Tables.t_multiple[arrayOfByte[i2][3][k]];
              if (this.ai[n] == 0) {
                arrayOfFloat1[4][k] *= Tables.t_multiple[arrayOfByte[i2][4][k]];
              } else {
                arrayOfFloat1[4][k] = (arrayOfFloat1[3][k] * aC[arrayOfByte[i2][3][k]] * Tables.t_multiple[arrayOfByte[i2][4][k]]);
              }
            }
            break;
          }
        } else if (this.U == 3) {
          switch (this.ae[n])
          {
          case 0: 
            for (m = i; m < j; m++) {
              arrayOfFloat1[m][k] *= Tables.t_multiple[arrayOfByte[i2][m][k]];
            }
            break;
          case 1: 
            arrayOfFloat1[2][k] *= Tables.t_multiple[arrayOfByte[i2][2][k]];
            if ((this.R == 2) || (this.ab[n] == 4) || (this.ab[n] == 5) || ((this.ab[n] != 3) && (this.aD != 0))) {
              arrayOfFloat1[3][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][3][k]]);
            } else {
              arrayOfFloat1[3][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][3][k]]);
            }
            break;
          case 2: 
            arrayOfFloat1[3][k] *= Tables.t_multiple[arrayOfByte[i2][3][k]];
            if ((this.R == 2) || (this.ab[n] == 1) || (this.ab[n] == 5) || ((this.ab[n] != 2) && (this.aD == 0))) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else {
              arrayOfFloat1[2][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            }
            break;
          case 3: 
            if ((this.R == 2) || (this.ab[n] == 1) || (this.ab[n] == 5) || ((this.ab[n] != 2) && (this.aD == 0))) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else {
              arrayOfFloat1[2][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            }
            if ((this.R == 2) || (this.ab[n] == 4) || (this.ab[n] == 5) || ((this.ab[n] != 3) && (this.aD != 0))) {
              arrayOfFloat1[3][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][3][k]]);
            } else {
              arrayOfFloat1[3][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][3][k]]);
            }
            break;
          case 4: 
            arrayOfFloat1[3][k] = arrayOfFloat1[2][k];
            arrayOfFloat1[2][k] *= Tables.t_multiple[arrayOfByte[i2][2][k]];
            arrayOfFloat1[3][k] *= Tables.t_multiple[arrayOfByte[i2][3][k]];
          }
        } else if (this.U == 4) {
          switch (this.ae[n])
          {
          case 0: 
            for (m = i; m < j; m++) {
              arrayOfFloat1[m][k] *= Tables.t_multiple[arrayOfByte[i2][m][k]];
            }
            break;
          case 1: 
            arrayOfFloat1[2][k] *= Tables.t_multiple[arrayOfByte[i2][2][k]];
            arrayOfFloat1[3][k] *= Tables.t_multiple[arrayOfByte[i2][3][k]];
            arrayOfFloat1[4][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][4][k]]);
            break;
          case 2: 
            arrayOfFloat1[2][k] *= Tables.t_multiple[arrayOfByte[i2][2][k]];
            arrayOfFloat1[3][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][3][k]]);
            arrayOfFloat1[4][k] *= Tables.t_multiple[arrayOfByte[i2][4][k]];
            break;
          case 3: 
            if ((this.ab[n] == 1) || (this.ab[n] == 7)) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else if ((this.ab[n] == 2) || (this.ab[n] == 6)) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else if (this.aD != 0) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else {
              arrayOfFloat1[2][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            }
            arrayOfFloat1[3][k] *= Tables.t_multiple[arrayOfByte[i2][3][k]];
            arrayOfFloat1[4][k] *= Tables.t_multiple[arrayOfByte[i2][4][k]];
            break;
          case 4: 
            arrayOfFloat1[2][k] *= Tables.t_multiple[arrayOfByte[i2][2][k]];
            arrayOfFloat1[3][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][3][k]]);
            arrayOfFloat1[4][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][4][k]]);
            break;
          case 5: 
            if ((this.ab[n] == 1) || (this.ab[n] == 7)) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else if ((this.ab[n] == 2) || (this.ab[n] == 6)) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else if (this.aD != 0) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else {
              arrayOfFloat1[2][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            }
            arrayOfFloat1[3][k] *= Tables.t_multiple[arrayOfByte[i2][3][k]];
            arrayOfFloat1[4][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][4][k]]);
            break;
          case 6: 
            if ((this.ab[n] == 1) || (this.ab[n] == 7)) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else if ((this.ab[n] == 2) || (this.ab[n] == 6)) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else if (this.aD != 0) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else {
              arrayOfFloat1[2][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            }
            arrayOfFloat1[3][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][3][k]]);
            arrayOfFloat1[4][k] *= Tables.t_multiple[arrayOfByte[i2][4][k]];
            break;
          case 7: 
            if ((this.ab[n] == 1) || (this.ab[n] == 7)) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else if ((this.ab[n] == 2) || (this.ab[n] == 6)) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else if (this.aD != 0) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else {
              arrayOfFloat1[2][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            }
            arrayOfFloat1[3][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][3][k]]);
            arrayOfFloat1[4][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][4][k]]);
            break;
          case 8: 
            arrayOfFloat1[2][k] *= Tables.t_multiple[arrayOfByte[i2][2][k]];
            arrayOfFloat1[4][k] = arrayOfFloat1[3][k];
            arrayOfFloat1[3][k] *= Tables.t_multiple[arrayOfByte[i2][3][k]];
            arrayOfFloat1[4][k] *= Tables.t_multiple[arrayOfByte[i2][4][k]];
            break;
          case 9: 
            arrayOfFloat1[3][k] = arrayOfFloat1[2][k];
            arrayOfFloat1[2][k] *= Tables.t_multiple[arrayOfByte[i2][2][k]];
            arrayOfFloat1[3][k] *= Tables.t_multiple[arrayOfByte[i2][3][k]];
            arrayOfFloat1[4][k] *= Tables.t_multiple[arrayOfByte[i2][4][k]];
            break;
          case 10: 
            arrayOfFloat1[4][k] = arrayOfFloat1[2][k];
            arrayOfFloat1[2][k] *= Tables.t_multiple[arrayOfByte[i2][2][k]];
            arrayOfFloat1[3][k] *= Tables.t_multiple[arrayOfByte[i2][3][k]];
            arrayOfFloat1[4][k] *= Tables.t_multiple[arrayOfByte[i2][4][k]];
            break;
          case 11: 
            arrayOfFloat1[3][k] = arrayOfFloat1[2][k];
            arrayOfFloat1[2][k] *= Tables.t_multiple[arrayOfByte[i2][2][k]];
            arrayOfFloat1[3][k] *= Tables.t_multiple[arrayOfByte[i2][3][k]];
            arrayOfFloat1[4][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][4][k]]);
            break;
          case 12: 
            arrayOfFloat1[4][k] = arrayOfFloat1[2][k];
            arrayOfFloat1[2][k] *= Tables.t_multiple[arrayOfByte[i2][2][k]];
            arrayOfFloat1[3][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][3][k]]);
            arrayOfFloat1[4][k] *= Tables.t_multiple[arrayOfByte[i2][4][k]];
            break;
          case 13: 
            if ((this.ab[n] == 1) || (this.ab[n] == 7)) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else if ((this.ab[n] == 2) || (this.ab[n] == 6)) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else if (this.aD != 0) {
              arrayOfFloat1[2][k] = (arrayOfFloat1[1][k] * aC[arrayOfByte[i2][1][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            } else {
              arrayOfFloat1[2][k] = (arrayOfFloat1[0][k] * aC[arrayOfByte[i2][0][k]] * Tables.t_multiple[arrayOfByte[i2][2][k]]);
            }
            arrayOfFloat1[4][k] = arrayOfFloat1[3][k];
            arrayOfFloat1[3][k] *= Tables.t_multiple[arrayOfByte[i2][3][k]];
            arrayOfFloat1[4][k] *= Tables.t_multiple[arrayOfByte[i2][4][k]];
            break;
          case 14: 
            arrayOfFloat1[4][k] = arrayOfFloat1[2][k];
            arrayOfFloat1[3][k] = arrayOfFloat1[2][k];
            arrayOfFloat1[2][k] *= Tables.t_multiple[arrayOfByte[i2][2][k]];
            arrayOfFloat1[3][k] *= Tables.t_multiple[arrayOfByte[i2][3][k]];
            arrayOfFloat1[4][k] *= Tables.t_multiple[arrayOfByte[i2][4][k]];
          }
        }
      }
    }
  }
  
  private void jdMethod_try()
  {
    f localf = this.X.bA;
    for (int i = 0; i < 12; i++)
    {
      int j = localf.jdField_if[0][this.av];
      int k = Tables.t_alloc[j];
      int m = this.aK[i];
      float f = Tables.t_d[j];
      if ((m & k) == 0) {
        f -= Tables.t_c[j];
      }
      f += (m & k - 1) * Tables.t_finv_alloc[j];
      this.S[i] = (f * Tables.t_multiple[this.aj]);
    }
  }
  
  private float a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    float[][][] arrayOfFloat = this.au;
    float f = 0.0F;
    for (int i = 0; i < this.W[paramInt1][paramInt5]; i++) {
      f += arrayOfFloat[paramInt4][paramInt1][(9 + paramInt2 + 12 * paramInt3 - i - this.aa[paramInt1][paramInt5])] * (this.ad[paramInt1][paramInt5][i] - 127) * 0.03125F;
    }
    return f;
  }
  
  private void jdMethod_for()
  {
    int n = 0;
    float[][][][] arrayOfFloat = this.X.bu;
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 12; j++) {
        for (int k = 0; k < 32; k++)
        {
          int m;
          if (this.an == 1)
          {
            m = this.as;
          }
          else
          {
            n = Q[k];
            m = this.ab[n];
          }
          if ((this.aG != 0) && (k < 8) && (this.ap[k] != 0)) {
            if ((this.R == 2) && (this.T != 0)) {
              switch (this.ae[k])
              {
              case 0: 
                arrayOfFloat[i][j][2][k] += a(k, j, i, 0, 0) + a(k, j, i, 1, 1);
                arrayOfFloat[i][j][3][k] += a(k, j, i, 0, 2) + a(k, j, i, 1, 3);
                arrayOfFloat[i][j][4][k] += a(k, j, i, 0, 4) + a(k, j, i, 1, 5);
                break;
              case 1: 
                arrayOfFloat[i][j][2][k] += a(k, j, i, 0, 0) + a(k, j, i, 1, 1);
                arrayOfFloat[i][j][3][k] += a(k, j, i, 0, 2) + a(k, j, i, 1, 3);
                break;
              case 2: 
                arrayOfFloat[i][j][2][k] += a(k, j, i, 0, 0) + a(k, j, i, 1, 1);
                arrayOfFloat[i][j][4][k] += a(k, j, i, 0, 2) + a(k, j, i, 1, 3);
                break;
              case 3: 
                arrayOfFloat[i][j][3][k] += a(k, j, i, 0, 0) + a(k, j, i, 1, 1);
                arrayOfFloat[i][j][4][k] += a(k, j, i, 0, 2) + a(k, j, i, 1, 3);
                break;
              case 4: 
                arrayOfFloat[i][j][2][k] += a(k, j, i, 0, 0) + a(k, j, i, 1, 1);
                break;
              case 5: 
                arrayOfFloat[i][j][3][k] += a(k, j, i, 0, 0) + a(k, j, i, 1, 1);
                break;
              case 6: 
                arrayOfFloat[i][j][4][k] += a(k, j, i, 0, 0) + a(k, j, i, 1, 1);
                break;
              case 8: 
                arrayOfFloat[i][j][2][k] += a(k, j, i, 0, 0) + a(k, j, i, 1, 1);
                break;
              case 9: 
                arrayOfFloat[i][j][4][k] += a(k, j, i, 0, 0) + a(k, j, i, 1, 1);
                break;
              case 10: 
                arrayOfFloat[i][j][3][k] += a(k, j, i, 0, 0) + a(k, j, i, 1, 1);
              }
            } else if (((this.R == 1) && (this.T != 0)) || ((this.R == 2) && (this.T == 0))) {
              switch (this.ae[k])
              {
              case 0: 
                arrayOfFloat[i][j][2][k] += a(k, j, i, 0, 0) + a(k, j, i, 1, 1);
                arrayOfFloat[i][j][3][k] += a(k, j, i, 0, 2) + a(k, j, i, 1, 3);
                break;
              case 1: 
                arrayOfFloat[i][j][2][k] += a(k, j, i, 0, 0) + a(k, j, i, 1, 1);
                break;
              case 2: 
                arrayOfFloat[i][j][3][k] += a(k, j, i, 0, 0) + a(k, j, i, 1, 1);
              }
            } else if (((this.R != 0) && (this.R != 3)) || ((this.T != 0) || ((this.R == 1) && (this.T == 0)))) {
              switch (this.ae[k])
              {
              case 0: 
                arrayOfFloat[i][j][2][k] += a(k, j, i, 0, 0) + a(k, j, i, 1, 1);
              }
            }
          }
          if (this.aw != 3)
          {
            float f1;
            float f2;
            if ((this.R == 2) && (this.T != 0))
            {
              float f3;
              switch (m)
              {
              case 0: 
                if (this.aw == 2)
                {
                  f3 = (arrayOfFloat[i][j][3][k] + arrayOfFloat[i][j][4][k]) * 0.5F;
                  arrayOfFloat[i][j][0][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] + f3);
                  arrayOfFloat[i][j][1][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - f3);
                }
                else
                {
                  arrayOfFloat[i][j][0][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                  arrayOfFloat[i][j][1][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][4][k]);
                }
                break;
              case 1: 
                if (this.aw == 2)
                {
                  f3 = (arrayOfFloat[i][j][3][k] + arrayOfFloat[i][j][4][k]) * 0.5F;
                  f1 = arrayOfFloat[i][j][2][k];
                  arrayOfFloat[i][j][2][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] + f3);
                  arrayOfFloat[i][j][1][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - f3);
                  arrayOfFloat[i][j][0][k] = f1;
                }
                else
                {
                  f1 = arrayOfFloat[i][j][2][k];
                  arrayOfFloat[i][j][2][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                  arrayOfFloat[i][j][1][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][4][k]);
                  arrayOfFloat[i][j][0][k] = f1;
                }
                break;
              case 2: 
                if (this.aw == 2)
                {
                  f3 = (arrayOfFloat[i][j][3][k] + arrayOfFloat[i][j][4][k]) * 0.5F;
                  f1 = arrayOfFloat[i][j][2][k];
                  arrayOfFloat[i][j][2][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - f3);
                  arrayOfFloat[i][j][0][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] + f3);
                  arrayOfFloat[i][j][1][k] = f1;
                }
                else
                {
                  f1 = arrayOfFloat[i][j][2][k];
                  arrayOfFloat[i][j][2][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][4][k]);
                  arrayOfFloat[i][j][0][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                  arrayOfFloat[i][j][1][k] = f1;
                }
                break;
              case 3: 
                if (this.aw == 2)
                {
                  f1 = arrayOfFloat[i][j][3][k];
                  arrayOfFloat[i][j][3][k] = (-2.0F * (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]) - arrayOfFloat[i][j][4][k]);
                  arrayOfFloat[i][j][1][k] = (arrayOfFloat[i][j][0][k] + arrayOfFloat[i][j][1][k] - 2.0F * arrayOfFloat[i][j][2][k] - f1);
                  arrayOfFloat[i][j][0][k] = f1;
                }
                else
                {
                  f1 = arrayOfFloat[i][j][3][k];
                  arrayOfFloat[i][j][3][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][3][k] - arrayOfFloat[i][j][2][k]);
                  arrayOfFloat[i][j][1][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][4][k]);
                  arrayOfFloat[i][j][0][k] = f1;
                }
                break;
              case 4: 
                if (this.aw == 2)
                {
                  f1 = arrayOfFloat[i][j][4][k];
                  arrayOfFloat[i][j][0][k] = (arrayOfFloat[i][j][0][k] + arrayOfFloat[i][j][1][k] - 2.0F * arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][4][k]);
                  arrayOfFloat[i][j][4][k] = (2.0F * arrayOfFloat[i][j][1][k] - 2.0F * (arrayOfFloat[i][j][2][k] + arrayOfFloat[i][j][4][k]) - arrayOfFloat[i][j][3][k]);
                  arrayOfFloat[i][j][1][k] = f1;
                }
                else
                {
                  f1 = arrayOfFloat[i][j][4][k];
                  arrayOfFloat[i][j][0][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                  arrayOfFloat[i][j][4][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][4][k] - arrayOfFloat[i][j][2][k]);
                  arrayOfFloat[i][j][1][k] = f1;
                }
                break;
              case 5: 
                if (this.aw == 2)
                {
                  f1 = arrayOfFloat[i][j][3][k];
                  arrayOfFloat[i][j][3][k] = (0.5F * (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][0][k] + arrayOfFloat[i][j][3][k] - arrayOfFloat[i][j][4][k]));
                  arrayOfFloat[i][j][0][k] = f1;
                  arrayOfFloat[i][j][1][k] = arrayOfFloat[i][j][4][k];
                  arrayOfFloat[i][j][4][k] = arrayOfFloat[i][j][3][k];
                }
                else
                {
                  f1 = arrayOfFloat[i][j][3][k];
                  arrayOfFloat[i][j][3][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][3][k] - arrayOfFloat[i][j][2][k]);
                  arrayOfFloat[i][j][0][k] = f1;
                  f1 = arrayOfFloat[i][j][4][k];
                  arrayOfFloat[i][j][4][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][4][k] - arrayOfFloat[i][j][2][k]);
                  arrayOfFloat[i][j][1][k] = f1;
                }
                break;
              case 6: 
                if (this.aw == 2)
                {
                  f1 = arrayOfFloat[i][j][2][k];
                  f2 = arrayOfFloat[i][j][3][k];
                  arrayOfFloat[i][j][3][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] + arrayOfFloat[i][j][3][k] - arrayOfFloat[i][j][4][k]);
                  arrayOfFloat[i][j][2][k] = (0.5F * (arrayOfFloat[i][j][0][k] + arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - f2));
                  arrayOfFloat[i][j][1][k] = f1;
                  arrayOfFloat[i][j][0][k] = f2;
                }
                else
                {
                  f1 = arrayOfFloat[i][j][2][k];
                  arrayOfFloat[i][j][2][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][4][k]);
                  arrayOfFloat[i][j][1][k] = f1;
                  f1 = arrayOfFloat[i][j][3][k];
                  arrayOfFloat[i][j][3][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][3][k] - arrayOfFloat[i][j][2][k]);
                  arrayOfFloat[i][j][0][k] = f1;
                }
                break;
              case 7: 
                if (this.aw == 2)
                {
                  f1 = arrayOfFloat[i][j][2][k];
                  f2 = arrayOfFloat[i][j][4][k];
                  arrayOfFloat[i][j][4][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][0][k] + arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k] - arrayOfFloat[i][j][4][k]);
                  arrayOfFloat[i][j][2][k] = (0.5F * (arrayOfFloat[i][j][0][k] + arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - f2));
                  arrayOfFloat[i][j][0][k] = f1;
                  arrayOfFloat[i][j][1][k] = f2;
                }
                else
                {
                  f1 = arrayOfFloat[i][j][2][k];
                  arrayOfFloat[i][j][2][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                  arrayOfFloat[i][j][0][k] = f1;
                  f1 = arrayOfFloat[i][j][4][k];
                  arrayOfFloat[i][j][4][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][4][k] - arrayOfFloat[i][j][2][k]);
                  arrayOfFloat[i][j][1][k] = f1;
                }
                break;
              }
            }
            else if ((this.R == 1) && (this.T != 0))
            {
              switch (m)
              {
              case 0: 
                if (this.aw == 2) {
                  arrayOfFloat[i][j][0][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] + arrayOfFloat[i][j][3][k]);
                } else {
                  arrayOfFloat[i][j][0][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                }
                arrayOfFloat[i][j][1][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                break;
              case 1: 
                f1 = arrayOfFloat[i][j][2][k];
                if (this.aw == 2) {
                  arrayOfFloat[i][j][2][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] + arrayOfFloat[i][j][3][k]);
                } else {
                  arrayOfFloat[i][j][2][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                }
                arrayOfFloat[i][j][1][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                arrayOfFloat[i][j][0][k] = f1;
                break;
              case 2: 
                f1 = arrayOfFloat[i][j][2][k];
                arrayOfFloat[i][j][2][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                if (this.aw == 2) {
                  arrayOfFloat[i][j][0][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] + arrayOfFloat[i][j][3][k]);
                } else {
                  arrayOfFloat[i][j][0][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                }
                arrayOfFloat[i][j][1][k] = f1;
                break;
              case 3: 
                f1 = arrayOfFloat[i][j][3][k];
                if (this.aw == 2) {
                  arrayOfFloat[i][j][3][k] = (-arrayOfFloat[i][j][0][k] + arrayOfFloat[i][j][2][k] + arrayOfFloat[i][j][3][k]);
                } else {
                  arrayOfFloat[i][j][3][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                }
                arrayOfFloat[i][j][1][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                arrayOfFloat[i][j][0][k] = f1;
                break;
              case 4: 
                f1 = arrayOfFloat[i][j][3][k];
                arrayOfFloat[i][j][3][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                if (this.aw == 2) {
                  arrayOfFloat[i][j][0][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] + arrayOfFloat[i][j][3][k]);
                } else {
                  arrayOfFloat[i][j][0][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k] - arrayOfFloat[i][j][3][k]);
                }
                arrayOfFloat[i][j][1][k] = f1;
                break;
              case 5: 
                f1 = arrayOfFloat[i][j][2][k];
                f2 = arrayOfFloat[i][j][3][k];
                arrayOfFloat[i][j][2][k] = (0.5F * (arrayOfFloat[i][j][0][k] + arrayOfFloat[i][j][1][k] - f1 - f2));
                arrayOfFloat[i][j][3][k] = (0.5F * (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][0][k] + f1 - f2));
                arrayOfFloat[i][j][0][k] = f1;
                arrayOfFloat[i][j][1][k] = f2;
              }
            }
            else if ((this.R == 1) || (this.T != 0))
            {
              switch (m)
              {
              case 0: 
                arrayOfFloat[i][j][0][k] -= arrayOfFloat[i][j][2][k];
                arrayOfFloat[i][j][1][k] -= arrayOfFloat[i][j][2][k];
                break;
              case 1: 
                f1 = arrayOfFloat[i][j][2][k];
                arrayOfFloat[i][j][2][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k]);
                arrayOfFloat[i][j][1][k] -= arrayOfFloat[i][j][2][k];
                arrayOfFloat[i][j][0][k] = f1;
                break;
              case 2: 
                f1 = arrayOfFloat[i][j][2][k];
                arrayOfFloat[i][j][2][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][2][k]);
                arrayOfFloat[i][j][0][k] -= arrayOfFloat[i][j][2][k];
                arrayOfFloat[i][j][1][k] = f1;
              }
            }
            else if (this.R == 2)
            {
              switch (m)
              {
              case 0: 
                arrayOfFloat[i][j][0][k] -= arrayOfFloat[i][j][2][k];
                arrayOfFloat[i][j][1][k] -= arrayOfFloat[i][j][3][k];
                break;
              case 1: 
                f1 = arrayOfFloat[i][j][2][k];
                arrayOfFloat[i][j][1][k] -= arrayOfFloat[i][j][3][k];
                arrayOfFloat[i][j][2][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k]);
                arrayOfFloat[i][j][0][k] = f1;
                break;
              case 2: 
                f1 = arrayOfFloat[i][j][3][k];
                arrayOfFloat[i][j][0][k] -= arrayOfFloat[i][j][2][k];
                arrayOfFloat[i][j][3][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][3][k]);
                arrayOfFloat[i][j][1][k] = f1;
                break;
              case 3: 
                f1 = arrayOfFloat[i][j][2][k];
                arrayOfFloat[i][j][2][k] = (arrayOfFloat[i][j][0][k] - arrayOfFloat[i][j][2][k]);
                arrayOfFloat[i][j][0][k] = f1;
                f1 = arrayOfFloat[i][j][3][k];
                arrayOfFloat[i][j][3][k] = (arrayOfFloat[i][j][1][k] - arrayOfFloat[i][j][3][k]);
                arrayOfFloat[i][j][1][k] = f1;
              }
            }
          }
        }
      }
    }
  }
  
  private void jdMethod_int()
  {
    float f1 = 0.0F;
    float f2 = 0.0F;
    float f3 = 0.0F;
    int i1 = this.X.bn.k;
    float[][][][] arrayOfFloat = this.X.bu;
    int i2 = this.X.bn.k + this.aE;
    switch (this.aw)
    {
    case 0: 
    case 2: 
      f1 = 2.4142137F;
      f2 = 1.4142135F * f1;
      f3 = 1.4142135F * f1;
      break;
    case 1: 
      f1 = 2.2071068F;
      f2 = 1.4142135F * f1;
      f3 = 2.0F * f1;
      break;
    case 3: 
      f1 = 1.0F;
      f2 = 1.0F;
      f3 = 1.0F;
    }
    if (this.aw != 3) {
      for (int k = 0; k < 12; k++) {
        for (int j = 0; j < 3; j++) {
          for (int m = 0; m < 32; m++)
          {
            for (int i = 0; i < i1; i++) {
              arrayOfFloat[j][k][i][m] *= f1;
            }
            if (this.aw != 1)
            {
              if (this.R == 3)
              {
                if (this.T != 0) {
                  arrayOfFloat[j][k][2][m] *= f2;
                }
              }
              else {
                for (int n = 2; n < i2; n++) {
                  arrayOfFloat[j][k][n][m] *= f2;
                }
              }
            }
            else if (this.R == 3)
            {
              if (this.T != 0) {
                arrayOfFloat[j][k][2][m] *= f2;
              }
            }
            else if (this.aE == 3)
            {
              arrayOfFloat[j][k][2][m] *= f2;
              arrayOfFloat[j][k][3][m] *= f3;
              arrayOfFloat[j][k][4][m] *= f3;
            }
            else if (this.aE == 2)
            {
              if (this.R == 2)
              {
                arrayOfFloat[j][k][2][m] *= f3;
                arrayOfFloat[j][k][3][m] *= f3;
              }
              else
              {
                arrayOfFloat[j][k][2][m] *= f2;
                arrayOfFloat[j][k][3][m] *= f3;
              }
            }
            else if (this.T == 0)
            {
              arrayOfFloat[j][k][2][m] *= f3;
            }
            else
            {
              arrayOfFloat[j][k][2][m] *= f2;
            }
          }
        }
      }
    }
  }
  
  private void jdMethod_byte()
  {
    int k = this.ak;
    f localf = this.X.bA;
    byte[][] arrayOfByte = this.X.bs[0];
    int m = this.aB;
    for (int i = 0; i < k; i++) {
      for (j = 0; j < m; j++) {
        arrayOfByte[j][i] = ((byte)this.X.bv.jdMethod_if(localf.a[i]));
      }
    }
    for (int j = 0; j < m; j++) {
      for (i = k; i < 32; i++) {
        arrayOfByte[j][i] = 0;
      }
    }
  }
  
  private void jdMethod_do(int[][] paramArrayOfInt)
  {
    int k = this.ak;
    byte[][][] arrayOfByte = this.X.bp;
    byte[][] arrayOfByte1 = this.X.bs[0];
    int m = this.aB;
    for (int i = 0; i < k; i++) {
      for (j = 0; j < m; j++) {
        if (arrayOfByte1[j][i] != 0) {
          paramArrayOfInt[j][i] = this.X.bv.jdMethod_if(2);
        } else {
          paramArrayOfInt[j][i] = 4;
        }
      }
    }
    for (int j = 0; j < m; j++) {
      for (i = k; i < 32; i++) {
        paramArrayOfInt[j][i] = 4;
      }
    }
    for (i = 0; i < k; i++) {
      for (j = 0; j < m; j++) {
        if (arrayOfByte1[j][i] != 0) {
          switch (paramArrayOfInt[j][i])
          {
          case 0: 
            arrayOfByte[0][j][i] = ((byte)this.X.bv.jdMethod_if(6));
            arrayOfByte[1][j][i] = ((byte)this.X.bv.jdMethod_if(6));
            arrayOfByte[2][j][i] = ((byte)this.X.bv.jdMethod_if(6));
            break;
          case 1: 
            arrayOfByte[0][j][i] = (arrayOfByte[1][j][i] = (byte)this.X.bv.jdMethod_if(6));
            arrayOfByte[2][j][i] = ((byte)this.X.bv.jdMethod_if(6));
            break;
          case 3: 
            arrayOfByte[0][j][i] = ((byte)this.X.bv.jdMethod_if(6));
            arrayOfByte[1][j][i] = (arrayOfByte[2][j][i] = (byte)this.X.bv.jdMethod_if(6));
            break;
          case 2: 
            arrayOfByte[0][j][i] = (arrayOfByte[1][j][i] = arrayOfByte[2][j][i] = (byte)this.X.bv.jdMethod_if(6));
            break;
          default: 
            arrayOfByte[0][j][i] = (arrayOfByte[1][j][i] = arrayOfByte[2][j][i] = 63);
            break;
          }
        } else {
          arrayOfByte[0][j][i] = (arrayOfByte[1][j][i] = arrayOfByte[2][j][i] = 63);
        }
      }
    }
    for (j = 0; j < m; j++) {
      for (i = k; i < 32; i++) {
        arrayOfByte[0][j][i] = (arrayOfByte[1][j][i] = arrayOfByte[2][j][i] = 63);
      }
    }
  }
  
  private void a(int[][][] paramArrayOfInt)
  {
    int m = 0;
    int n = this.ak;
    f localf = this.X.bA;
    int i1 = this.aB;
    byte[][] arrayOfByte = this.X.bs[0];
    int j;
    int k;
    for (int i = 0; i < n; i++) {
      for (j = 0; j < i1; j++) {
        if (arrayOfByte[j][i] != 0)
        {
          k = localf.jdField_for[i][arrayOfByte[j][i]];
          if (k > 0)
          {
            paramArrayOfInt[j][0][i] = this.X.bv.jdMethod_if(k);
            paramArrayOfInt[j][1][i] = this.X.bv.jdMethod_if(k);
            paramArrayOfInt[j][2][i] = this.X.bv.jdMethod_if(k);
          }
          else
          {
            m = this.X.bv.jdMethod_if(-k);
            k = -k & 0x6;
            k /= 2;
            byte[] arrayOfByte1 = this.X.bw[k];
            paramArrayOfInt[j][0][i] = arrayOfByte1[(3 * m)];
            paramArrayOfInt[j][1][i] = arrayOfByte1[(3 * m + 1)];
            paramArrayOfInt[j][2][i] = arrayOfByte1[(3 * m + 2)];
          }
        }
        else
        {
          paramArrayOfInt[j][0][i] = 0;
          paramArrayOfInt[j][1][i] = 0;
          paramArrayOfInt[j][2][i] = 0;
        }
      }
    }
    for (i = n; i < 32; i++) {
      for (j = 0; j < i1; j++) {
        for (k = 0; k < 3; k++) {
          paramArrayOfInt[j][k][i] = 0;
        }
      }
    }
  }
  
  private void jdMethod_if(int[][][] paramArrayOfInt, int paramInt)
  {
    int i2 = this.ak;
    f localf = this.X.bA;
    int i3 = this.aB;
    byte[][] arrayOfByte = this.X.bs[0];
    float[][][][] arrayOfFloat = this.X.bu;
    byte[][][] arrayOfByte1 = this.X.bp;
    int i4 = this.X.bn.k + this.aE;
    int i5 = paramInt >> 2 - this.ac;
    paramInt *= 3;
    int j;
    float[][] arrayOfFloat1;
    int k;
    for (int i = 0; i < i2; i++) {
      for (j = 0; j < 3; j++)
      {
        arrayOfFloat1 = arrayOfFloat[((paramInt + j) / 12)][((paramInt + j) % 12)];
        for (k = 0; k < i3; k++) {
          if (arrayOfByte[k][i] != 0)
          {
            int m = localf.jdField_if[i][arrayOfByte[k][i]];
            int n = Tables.t_alloc[m];
            int i1 = paramArrayOfInt[k][j][i];
            float f = Tables.t_d[m];
            if ((i1 & n) == 0) {
              f -= Tables.t_c[m];
            }
            f += (i1 & n - 1) * Tables.t_finv_alloc[m];
            f *= Tables.t_multiple[arrayOfByte1[i5][k][i]];
            arrayOfFloat1[(k + i4)][i] = f;
          }
          else
          {
            arrayOfFloat1[(k + i4)][i] = 0.0F;
          }
        }
      }
    }
    for (i = i2; i < 32; i++) {
      for (j = 0; j < 3; j++)
      {
        arrayOfFloat1 = arrayOfFloat[((paramInt + j) / 12)][((paramInt + j) % 12)];
        for (k = 0; k < i3; k++) {
          arrayOfFloat1[(k + i4)][i] = 0.0F;
        }
      }
    }
  }
  
  private int a(b paramb, int paramInt)
  {
    byte[] arrayOfByte = this.ao.cB;
    int i1 = this.ao.cJ;
    int i = this.ao.cG;
    if (arrayOfByte == null) {
      return -4;
    }
    if (i < 5) {
      return -6;
    }
    if (((arrayOfByte[i1] & 0xFF) != Byte.MAX_VALUE) || ((arrayOfByte[(i1 + 1)] & 0xFF) >> 4 != 15)) {
      return -4;
    }
    int m = (arrayOfByte[(i1 + 1)] & 0xF) << 12 | (arrayOfByte[(i1 + 2)] & 0xFF) << 4 | (arrayOfByte[(i1 + 3)] & 0xFF) >>> 4;
    int n = (arrayOfByte[(i1 + 3)] & 0xF) << 8 | arrayOfByte[(i1 + 4)] & 0xFF;
    int k = g.a(n, 65535, 12);
    n >>= 1;
    if (i < n) {
      return -6;
    }
    if (m != 0)
    {
      int j = n - 5 << 3;
      if (j > 116)
      {
        j = 116;
      }
      else if (j == 0)
      {
        if (k == m)
        {
          this.ao.cA = n;
          return n - 5 << 3;
        }
        return -5;
      }
      this.ag.a(arrayOfByte, i1 + 5, n - 5);
      k = g.a(this.ag, k, j);
      if (k != m) {
        return -5;
      }
    }
    b.a(this.X.bv.jdMethod_else(), this.X.bv.jdMethod_for(), arrayOfByte, i1 + 5, this.X.bv.jdMethod_new() + paramInt, 0, n - 5 << 3);
    this.X.bv.jdMethod_case();
    this.ao.cA = n;
    return n - 5 << 3;
  }
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\codecLib\mpa\c.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */