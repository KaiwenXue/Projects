package codecLib.mpa;

class a
  implements Constants
{
  int cz;
  byte[] cB;
  int cJ;
  int cG;
  int cE;
  int cC;
  int cA;
  int cy;
  int cL;
  int cD;
  int cK;
  int cH;
  int cF;
  int cM;
  int cx;
  int cw;
  float[] cI = new float[12];
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\codecLib\mpa\a.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */