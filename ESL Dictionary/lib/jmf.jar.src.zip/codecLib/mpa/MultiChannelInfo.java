package codecLib.mpa;

public class MultiChannelInfo
  implements Constants
{
  protected int status;
  protected int presentChannels;
  protected int extFrameLength;
  protected int numberOfArrangementChannels;
  protected int numberOfLanguageChannels;
  protected int MLSamplingRate;
  protected int numberOfMLSamples;
  protected float[] LFESamples = new float[12];
  
  public String toString()
  {
    if (this.status != 0) {
      return "(no info)";
    }
    int i = 0;
    int j = 0;
    if ((this.presentChannels & 0x4) != 0) {
      i++;
    }
    if ((this.presentChannels & 0x8) != 0) {
      i++;
    }
    if ((this.presentChannels & 0x10) != 0) {
      i++;
    }
    if ((this.presentChannels & 0x20) != 0) {
      j++;
    }
    if ((this.presentChannels & 0x40) != 0) {
      j++;
    }
    String str = "scheme: " + i + "/" + j;
    if ((this.presentChannels & 0x80) != 0) {
      str = str + "+lfe";
    }
    if ((this.presentChannels & 0x8000) != 0) {
      str = str + ", second stereo programm";
    }
    if (this.numberOfLanguageChannels > 0) {
      str = str + ", " + this.numberOfLanguageChannels + " language channels on " + this.MLSamplingRate + " Hz";
    }
    return str;
  }
  
  public int getStatus()
  {
    return this.status;
  }
  
  public int getPresentChannels()
  {
    return this.presentChannels;
  }
  
  public int getExtFrameLength()
  {
    return this.extFrameLength;
  }
  
  public int getNumberOfArrangementChannels()
  {
    return this.numberOfArrangementChannels;
  }
  
  public int getNumberOfLanguageChannels()
  {
    return this.numberOfLanguageChannels;
  }
  
  public int getMLSamplingRate()
  {
    return this.MLSamplingRate;
  }
  
  public int getNumberOfMLSamples()
  {
    return this.numberOfMLSamples;
  }
  
  public float[] getLFESamples()
  {
    return this.LFESamples;
  }
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\codecLib\mpa\MultiChannelInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */