package codecLib.mpa;

class g
{
  private b a = new b();
  
  static int a(b paramb, int paramInt1, int paramInt2)
  {
    int i = paramInt1 << 16;
    int j = -2147155968;
    int k;
    for (int n = 0; n < paramInt2 - 15; n += 16)
    {
      int m = paramb.a();
      for (int i1 = 0; i1 < 16; i1++)
      {
        k = (i ^ m) >> 31;
        k &= j;
        i <<= 1;
        i ^= k;
        m <<= 1;
      }
    }
    while (n < paramInt2)
    {
      k = (i ^ paramb.jdMethod_do()) >> 31;
      k &= j;
      i <<= 1;
      i ^= k;
      n++;
    }
    return i >>> 16;
  }
  
  static int a(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = paramInt2 << 16;
    int j = paramInt1 << 32 - paramInt3;
    int k = -2147155968;
    for (int n = 0; n < paramInt3; n++)
    {
      int m = (i ^ j) >> 31;
      m &= k;
      i <<= 1;
      i ^= m;
      j <<= 1;
    }
    return i >>> 16;
  }
  
  int a(b paramb, l paraml, int paramInt)
  {
    b.a(this.a, paramb);
    int i = a(paraml.e, 65535, 16);
    i = a(this.a, i, paramInt);
    return i - paraml.h;
  }
  
  int jdMethod_if(b paramb, l paraml, int paramInt)
  {
    int i = a(paraml.e, 65535, 16);
    i = a(paramb, i, paramInt);
    return i - paraml.h;
  }
  
  int jdMethod_do(b paramb, l paraml, int paramInt)
  {
    if (paraml.c == 1)
    {
      paraml.h = 0;
      return 0;
    }
    b.a(this.a, paramb);
    int i = a(paraml.e, 65535, 16);
    i = a(this.a, i, paramInt);
    return i - paraml.h;
  }
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\codecLib\mpa\g.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */