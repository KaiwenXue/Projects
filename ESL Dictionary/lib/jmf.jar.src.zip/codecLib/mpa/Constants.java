package codecLib.mpa;

public abstract interface Constants
{
  public static final boolean MC_EXT = true;
  public static final String VERSION = "mpad:0100:20010427:java";
  public static final int MAX_BYTES_IN_FRAME = 2024;
  public static final int MIN_BYTES_IN_FRAME = 13;
  public static final int SAMPLES_IN_CHANNEL = 1152;
  public static final int MAX_CHANNELS = 12;
  public static final int SAMPLES_IN_LFE_CHANNEL = 12;
  public static final int EXT_MAX_BYTES_IN_FRAME = 2047;
  public static final int OK = 0;
  public static final int ERR_FAILED = -1;
  public static final int ERR_CRCFAIL = -2;
  public static final int ERR_LOWBUFFER = -3;
  public static final int ERR_NEXTFRAME = -4;
  public static final int ERR_NOHDR = -7;
  public static final int ERR_BADANCIL = -8;
  public static final int ERR_NOPREV = -9;
  public static final int ERR_NOSUPPORT = -10;
  public static final int HDR_DOUBTED = 1;
  public static final int MC_REQ_NO = 0;
  public static final int MC_REQ_YES = 1;
  public static final int MC_REQ_IF = 2;
  public static final int MC_REQ_CHECK = 3;
  public static final int MC_REQ_MASK = 3;
  public static final int MC_CH_ML = 4;
  public static final int MC_CH_MR = 8;
  public static final int MC_CH_C = 16;
  public static final int MC_CH_SL = 32;
  public static final int MC_CH_SR = 64;
  public static final int MC_CH_LFE = 128;
  public static final int MC_CH_L1 = 256;
  public static final int MC_CH_L2 = 512;
  public static final int MC_CH_L3 = 1024;
  public static final int MC_CH_L4 = 2048;
  public static final int MC_CH_L5 = 4096;
  public static final int MC_CH_L6 = 8192;
  public static final int MC_CH_L7 = 16384;
  public static final int MC_CH_P2 = 32768;
  public static final int MC_CH_MAIN = 12;
  public static final int MC_CH_ALL = 65532;
  public static final int MC_CH_ARR = 252;
  public static final int MC_CH_LANG = 32512;
  public static final int MC_OK = 0;
  public static final int MC_ERR_FAILED = -1;
  public static final int MC_ERR_CRCFAIL = -2;
  public static final int MC_ERR_LOWBUFFER = -3;
  public static final int MC_EXT_ERR_NOEXT = -4;
  public static final int MC_EXT_ERR_CRCFAIL = -5;
  public static final int MC_EXT_ERR_LOWBUFFER = -6;
  public static final int MC_L1_NOTREADY = 1;
  public static final int MC_L3_NOSUPPORT = -10;
  public static final int MC_IND_ML = 0;
  public static final int MC_IND_MR = 1;
  public static final int MC_IND_C = 2;
  public static final int MC_IND_SL = 3;
  public static final int MC_IND_SR = 4;
  public static final int MC_IND_L1 = 5;
  public static final int MC_IND_L2 = 6;
  public static final int MC_IND_L3 = 7;
  public static final int MC_IND_L4 = 8;
  public static final int MC_IND_L5 = 9;
  public static final int MC_IND_L6 = 10;
  public static final int MC_IND_L7 = 11;
  public static final int MC_IND_P2L = 3;
  public static final int MC_IND_P2R = 4;
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\codecLib\mpa\Constants.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */