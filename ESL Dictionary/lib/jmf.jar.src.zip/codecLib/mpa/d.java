package codecLib.mpa;

class d
  implements Constants
{
  int jdField_case;
  int g;
  int jdField_byte;
  int b;
  int d;
  int i;
  int c;
  int[] jdField_long = new int[3];
  int[] jdField_goto = new int[3];
  int a;
  int jdField_char;
  int e;
  int jdField_new;
  int jdField_if;
  int jdField_try;
  int[] jdField_else = new int[3];
  int jdField_int;
  short[] jdField_void;
  int h;
  int jdField_do;
  int[] f = new int[4];
  int[] jdField_for = new int[4];
  int jdField_null;
}


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\jmf.jar!\codecLib\mpa\d.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */