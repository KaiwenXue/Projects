/*     */ package com.ibm.media.bean.multiplayer;
/*     */ 
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.MediaTracker;
/*     */ import java.awt.Toolkit;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageLabel
/*     */   extends Canvas
/*     */ {
/*     */   protected Image image;
/*  62 */   protected static String defaultImageString = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */   private String imageString = "<Existing Image>";
/*     */   
/*     */ 
/*  72 */   private boolean debug = false;
/*     */   
/*     */ 
/*  75 */   protected int border = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */   protected Color borderColor = null;
/*     */   
/*     */ 
/*     */ 
/*  85 */   protected int width = 80;
/*  86 */   protected int height = 60;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */   protected boolean explicitSize = false;
/* 104 */   private int explicitWidth = 0; private int explicitHeight = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private MediaTracker tracker;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 114 */   private static int lastTrackerID = 0;
/*     */   private int currentTrackerID;
/* 116 */   protected boolean doneLoading = false;
/*     */   
/*     */ 
/*     */   private Container parentContainer;
/*     */   
/* 121 */   boolean newEventsOnly = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageLabel() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageLabel(String imageURLString)
/*     */   {
/* 142 */     this(makeURL(imageURLString));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageLabel(URL imageURL)
/*     */   {
/* 151 */     this(loadImage(imageURL));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageLabel(URL imageDirectory, String file)
/*     */   {
/* 162 */     this(makeURL(imageDirectory, file));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageLabel(Image image)
/*     */   {
/* 175 */     this.image = image;
/* 176 */     this.tracker = new MediaTracker(this);
/* 177 */     this.currentTrackerID = (lastTrackerID++);
/* 178 */     this.tracker.addImage(image, this.currentTrackerID);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void waitForImage(boolean doLayout)
/*     */   {
/* 207 */     if (!this.doneLoading) {
/* 208 */       debug("[waitForImage] - Resizing and waiting for " + this.imageString);
/*     */       try {
/* 210 */         this.tracker.waitForID(this.currentTrackerID);
/*     */       }
/*     */       catch (InterruptedException ie) {}catch (Exception e) {
/* 213 */         System.out.println("Error loading " + this.imageString + ": " + e.getMessage());
/*     */         
/*     */ 
/* 216 */         e.printStackTrace();
/*     */       }
/* 218 */       if (this.tracker.isErrorID(0)) {
/* 219 */         new Throwable("Error loading image " + this.imageString).printStackTrace();
/*     */       }
/* 221 */       this.doneLoading = true;
/* 222 */       if (this.explicitWidth != 0) {
/* 223 */         this.width = this.explicitWidth;
/*     */       } else
/* 225 */         this.width = (this.image.getWidth(this) + 2 * this.border);
/* 226 */       if (this.explicitHeight != 0) {
/* 227 */         this.height = this.explicitHeight;
/*     */       } else
/* 229 */         this.height = (this.image.getHeight(this) + 2 * this.border);
/* 230 */       resize(this.width, this.height);
/* 231 */       debug("[waitForImage] - " + this.imageString + " is " + this.width + "x" + this.height + ".");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 238 */       if (((this.parentContainer = getParent()) != null) && (doLayout))
/*     */       {
/* 240 */         setBackground(this.parentContainer.getBackground());
/* 241 */         this.parentContainer.layout();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void centerAt(int x, int y)
/*     */   {
/* 265 */     debug("Placing center of " + this.imageString + " at (" + x + "," + y + ")");
/*     */     
/* 267 */     move(x - this.width / 2, y - this.height / 2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean inside(int x, int y)
/*     */   {
/* 278 */     return (x >= 0) && (x <= this.width) && (y >= 0) && (y <= this.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void paint(Graphics g)
/*     */   {
/* 287 */     if (!this.doneLoading) {
/* 288 */       waitForImage(true);
/*     */     } else {
/* 290 */       if (this.explicitSize) {
/* 291 */         g.drawImage(this.image, this.border, this.border, this.width - 2 * this.border, this.height - 2 * this.border, this);
/*     */       }
/*     */       else
/*     */       {
/* 295 */         g.drawImage(this.image, this.border, this.border, this); }
/* 296 */       drawRect(g, 0, 0, this.width - 1, this.height - 1, this.border, this.borderColor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Dimension preferredSize()
/*     */   {
/* 311 */     if (!this.doneLoading)
/* 312 */       waitForImage(false);
/* 313 */     return super.preferredSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Dimension minimumSize()
/*     */   {
/* 326 */     if (!this.doneLoading)
/* 327 */       waitForImage(false);
/* 328 */     return super.minimumSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void resize(int width, int height)
/*     */   {
/* 361 */     if (!this.doneLoading) {
/* 362 */       this.explicitSize = true;
/* 363 */       if (width > 0)
/* 364 */         this.explicitWidth = width;
/* 365 */       if (height > 0)
/* 366 */         this.explicitHeight = height;
/*     */     }
/* 368 */     super.resize(width, height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reshape(int x, int y, int width, int height)
/*     */   {
/* 395 */     if (!this.doneLoading) {
/* 396 */       this.explicitSize = true;
/* 397 */       if (width > 0)
/* 398 */         this.explicitWidth = width;
/* 399 */       if (height > 0)
/* 400 */         this.explicitHeight = height;
/*     */     }
/* 402 */     super.reshape(x, y, width, height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void drawRect(Graphics g, int left, int top, int width, int height, int lineThickness, Color rectangleColor)
/*     */   {
/* 421 */     g.setColor(rectangleColor);
/* 422 */     for (int i = 0; i < lineThickness; i++) {
/* 423 */       g.drawRect(left, top, width, height);
/* 424 */       if (i < lineThickness - 1) {
/* 425 */         left += 1;
/* 426 */         top += 1;
/* 427 */         width -= 2;
/* 428 */         height -= 2;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void debug(String message)
/*     */   {
/* 440 */     if (this.debug) {
/* 441 */       System.out.println(message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static URL makeURL(String s)
/*     */   {
/* 448 */     URL u = null;
/* 449 */     try { u = new URL(s);
/*     */     } catch (MalformedURLException mue) {
/* 451 */       System.out.println("Bad URL " + s + ": " + mue);
/* 452 */       mue.printStackTrace();
/*     */     }
/* 454 */     return u;
/*     */   }
/*     */   
/*     */   private static URL makeURL(URL directory, String file)
/*     */   {
/* 459 */     URL u = null;
/* 460 */     try { u = new URL(directory, file);
/*     */     } catch (MalformedURLException mue) {
/* 462 */       System.out.println("Bad URL " + directory.toExternalForm() + ", " + file + ": " + mue);
/*     */       
/*     */ 
/* 465 */       mue.printStackTrace();
/*     */     }
/* 467 */     return u;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Image loadImage(URL url)
/*     */   {
/* 475 */     Image original = null;
/* 476 */     if (url.getProtocol().equals("file")) {
/*     */       try
/*     */       {
/* 479 */         InputStream imageStream = url.openStream();
/* 480 */         if (imageStream == null)
/*     */         {
/* 482 */           System.out.println("null button image stream");
/* 483 */           return null;
/*     */         }
/* 485 */         int available = 0;
/* 486 */         while (imageStream.available() == 0) {}
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 491 */         available = imageStream.available();
/* 492 */         byte[] imageBytes = new byte[available];
/* 493 */         imageStream.read(imageBytes);
/* 494 */         original = Toolkit.getDefaultToolkit().createImage(imageBytes);
/*     */       }
/*     */       catch (IOException ioe) {
/* 497 */         System.out.println("Cannot read button image.");
/* 498 */         return null;
/*     */       }
/*     */       
/*     */     }
/*     */     else {
/* 503 */       original = Toolkit.getDefaultToolkit().getImage(url);
/*     */     }
/*     */     
/* 506 */     return original;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Image getImage()
/*     */   {
/* 513 */     return this.image;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getBorder()
/*     */   {
/* 520 */     return this.border;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBorder(int border)
/*     */   {
/* 526 */     this.border = border;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Color getBorderColor()
/*     */   {
/* 533 */     return this.borderColor;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBorderColor(Color borderColor)
/*     */   {
/* 539 */     this.borderColor = borderColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 550 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 556 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean hasExplicitSize()
/*     */   {
/* 568 */     return this.explicitSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getDefaultImageString()
/*     */   {
/* 577 */     return defaultImageString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setDefaultImageString(String file)
/*     */   {
/* 588 */     defaultImageString = file;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getImageString()
/*     */   {
/* 596 */     return this.imageString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isDebugging()
/*     */   {
/* 603 */     return this.debug;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setIsDebugging(boolean debug)
/*     */   {
/* 610 */     this.debug = debug;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\multiplayer.jar!\com\ibm\media\bean\multiplayer\ImageLabel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */