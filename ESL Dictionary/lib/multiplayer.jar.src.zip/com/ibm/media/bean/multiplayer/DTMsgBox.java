/*     */ package com.ibm.media.bean.multiplayer;
/*     */ 
/*     */ import java.awt.Button;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Panel;
/*     */ import java.awt.TextArea;
/*     */ import java.awt.TextComponent;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ActionEvent;
/*     */ 
/*     */ public class DTMsgBox extends DTFrame implements java.awt.event.ActionListener
/*     */ {
/*  15 */   private TextArea msgArea = new TextArea(8, 280);
/*  16 */   private String nullMsg = " ";
/*  17 */   private boolean isCleared = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DTMsgBox()
/*     */   {
/*  24 */     super(JMFUtil.getBIString("JMF_MultiPlayer"));
/*  25 */     initGUI();
/*     */   }
/*     */   
/*     */   public DTMsgBox(String title)
/*     */   {
/*  30 */     super(title);
/*  31 */     initGUI();
/*     */   }
/*     */   
/*     */   public DTMsgBox(String title, String msg)
/*     */   {
/*  36 */     super(title);
/*  37 */     if (msg != null) this.msgArea.setText(msg);
/*  38 */     initGUI();
/*     */   }
/*     */   
/*     */   private void initGUI()
/*     */   {
/*  43 */     Button o = new Button(JMFUtil.getBIString("OK"));
/*  44 */     Button c = new Button(JMFUtil.getBIString("CLEAR"));
/*  45 */     o.setActionCommand(JMFUtil.getBIString("OK"));o.addActionListener(this);
/*  46 */     c.setActionCommand(JMFUtil.getBIString("CLEAR"));c.addActionListener(this);
/*     */     
/*  48 */     Panel p = new Panel();
/*  49 */     p.setLayout(new java.awt.GridLayout(1, 2, 2, 0));
/*  50 */     p.add(o);
/*  51 */     p.add(c);
/*     */     
/*  53 */     this.msgArea.setEditable(false);
/*  54 */     this.msgArea.setBackground(java.awt.Color.white);
/*  55 */     setLayout(new java.awt.BorderLayout(10, 5));
/*  56 */     add("Center", this.msgArea);
/*  57 */     add("South", p);
/*  58 */     setLocation(500, 10);
/*  59 */     setSize(465, 240);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void go()
/*     */   {
/*  68 */     setVisible(true);
/*     */   }
/*     */   
/*     */   public void go(String msg)
/*     */   {
/*  73 */     if ((msg == null) || (msg.length() == 0)) msg = this.nullMsg;
/*  74 */     if (this.isCleared) this.msgArea.append(" \n" + msg); else
/*  75 */       this.msgArea.append("\n \n" + msg);
/*  76 */     this.isCleared = false;
/*  77 */     setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */   public void go(String msg, boolean wait)
/*     */   {
/*  83 */     if (wait) setCursor(new Cursor(3)); else
/*  84 */       setCursor(new Cursor(0));
/*  85 */     if ((msg == null) || (msg.length() == 0)) msg = this.nullMsg;
/*  86 */     if (this.isCleared) this.msgArea.append(" \n" + msg); else
/*  87 */       this.msgArea.append("\n \n" + msg);
/*  88 */     this.isCleared = false;
/*  89 */     setVisible(true);
/*     */   }
/*     */   
/*     */   public void go(String title, String msg)
/*     */   {
/*  94 */     setTitle(title);
/*  95 */     if ((msg == null) || (msg.length() == 0)) msg = this.nullMsg;
/*  96 */     if (this.isCleared) this.msgArea.append(" \n" + msg); else
/*  97 */       this.msgArea.append("\n \n" + msg);
/*  98 */     this.isCleared = false;
/*  99 */     setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void createAndGo(String msg)
/*     */   {
/* 108 */     DTMsgBox msgBox = new DTMsgBox();
/* 109 */     msgBox.go(msg);
/*     */   }
/*     */   
/*     */   public static void createAndGo(String title, String msg)
/*     */   {
/* 114 */     DTMsgBox msgBox = new DTMsgBox(title, msg);
/* 115 */     msgBox.setVisible(true);
/*     */   }
/*     */   
/*     */   public void actionPerformed(ActionEvent evt)
/*     */   {
/* 120 */     String s = evt.getActionCommand();
/* 121 */     if (s.equals(JMFUtil.getBIString("CLEAR"))) { this.msgArea.setText("");this.isCleared = true;
/* 122 */     } else if (s.equals(JMFUtil.getBIString("OK"))) { setVisible(false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\multiplayer.jar!\com\ibm\media\bean\multiplayer\DTMsgBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */