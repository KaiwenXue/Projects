/*    */ package com.ibm.media.bean.multiplayer;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Frame;
/*    */ import java.awt.Insets;
/*    */ import java.awt.Window;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DTFrame
/*    */   extends Frame
/*    */ {
/*    */   public DTFrame(String str)
/*    */   {
/* 19 */     super(str);
/* 20 */     addWindowListener(new DTWinAdapter(false));
/* 21 */     enableEvents(8L);
/* 22 */     setBackground(Color.lightGray);
/*    */   }
/*    */   
/*    */   public DTFrame(String str, boolean doExit)
/*    */   {
/* 27 */     super(str);
/* 28 */     addWindowListener(new DTWinAdapter(doExit));
/* 29 */     enableEvents(8L);
/* 30 */     setBackground(Color.lightGray);
/*    */   }
/*    */   
/*    */   public Insets getInsets()
/*    */   {
/* 35 */     return new Insets(30, 10, 10, 10);
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\multiplayer.jar!\com\ibm\media\bean\multiplayer\DTFrame.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */