/*    */ package com.ibm.media.bean.multiplayer;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Frame;
/*    */ import java.awt.Window;
/*    */ import java.awt.event.WindowAdapter;
/*    */ import java.awt.event.WindowEvent;
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DTWinAdapter
/*    */   extends WindowAdapter
/*    */ {
/* 15 */   boolean doExit = false;
/*    */   
/*    */   public DTWinAdapter(boolean close)
/*    */   {
/* 19 */     this.doExit = close;
/*    */   }
/*    */   
/*    */   public void windowClosing(WindowEvent evt)
/*    */   {
/* 24 */     Frame f = (Frame)evt.getSource();
/* 25 */     f.setVisible(false);
/* 26 */     if (this.doExit) {
/* 27 */       f.dispose();
/* 28 */       System.exit(0);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Kaiwen\Desktop\Dictionary\Dictionary_Program.jar!\lib\multiplayer.jar!\com\ibm\media\bean\multiplayer\DTWinAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */